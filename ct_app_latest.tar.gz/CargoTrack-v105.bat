@echo off
title CargoTrack v105
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel% neq 0 (
  echo.
  echo  Python was not found on this computer.
  echo  Please install it from https://www.python.org/downloads/
  echo  and tick "Add python.exe to PATH" during setup.
  echo.
  pause
  exit /b
)
where pythonw >nul 2>nul
if %errorlevel% equ 0 (
  start "" pythonw "%~dp0tray.py"
  exit /b
)
python tray.py
pause
