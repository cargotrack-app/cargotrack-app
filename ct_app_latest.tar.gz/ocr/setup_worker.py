#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CargoTrack OCR one-time auto-setup — DETACHED worker (v51).

server.py ise subprocess.Popen(..., start_new_session=True) se
chalata hai taake app/service restart is setup ko beech mein
na mar sake. Kaam wahi purana hai:
  1. PyPI JSON API se pip ka latest stable wheel download
     karke ocr/_bootstrap/ mein unzip (wheel khud ek zip hai;
     unzip ki hui pip `python -m pip` se chalti hai).
  2. Usi pip se ocr/requirements.txt ko ocr/pylibs mein
     --target install (--break-system-packages PEP 668 wale
     servers ke liye). pip ko --retries 5 --timeout 60
     --no-cache-dir milta hai taake ek network hichki poora
     setup na gira de.
  3. cv2 import probe — fail ho (GUI-wali opencv-python ne
     headless server par libGL manga ho) to pylibs ke cv2
     package dirs saaf karke SIRF opencv-python-headless
     dobara install karo, phir dobara probe karo.
  4. rapidocr import ki asal probe.
Halat ocr/setup_state.json mein — akhir mein setup.log ki
aakhri ~15 lines bhi state ke 'log_tail' mein mehfooz hoti
hain taake failure ki wajah app ke error message mein aa
sake. Tafseel ocr/setup.log mein. Sirf stdlib."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

OCR_DIR = Path(__file__).resolve().parent
PYLIBS = OCR_DIR / "pylibs"
BOOTSTRAP_DIR = OCR_DIR / "_bootstrap"
STATE_FILE = OCR_DIR / "setup_state.json"
LOG_FILE = OCR_DIR / "setup.log"
PIP_FLAGS = ["--retries", "5", "--timeout", "60", "--no-cache-dir"]


def log(msg):
    try:
        OCR_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S  ")
                    + str(msg) + "\n")
    except Exception:
        pass


def _state():
    try:
        st = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return st if isinstance(st, dict) else {}
    except Exception:
        return {}


def set_state(**kw):
    st = _state()
    st.update(kw)
    try:
        STATE_FILE.write_text(json.dumps(st, indent=1),
                              encoding="utf-8")
    except Exception:
        pass


def log_tail(n=15):
    """setup.log ki aakhri n saaf lines (timestamp hata kar)."""
    try:
        lines = LOG_FILE.read_text(
            encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    out = []
    for ln in lines[-n * 3:]:
        ln = ln.strip()
        m = re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\s+",
                     ln)
        if m:
            ln = ln[m.end():].strip()
        if ln:
            out.append(ln)
    return out[-n:]


def probe(module, env_extra=None):
    """Diye gaye module ka import test — app ke apne Python se."""
    env = None
    if env_extra:
        env = dict(os.environ)
        for k, v in env_extra.items():
            if k == "PYTHONPATH" and env.get("PYTHONPATH"):
                env[k] = v + os.pathsep + env["PYTHONPATH"]
            else:
                env[k] = v
    try:
        r = subprocess.run([sys.executable, "-c",
                            "import " + module],
                           capture_output=True, timeout=60,
                           env=env)
        return r.returncode == 0
    except Exception:
        return False


def headless_pin():
    """requirements.txt se opencv-python-headless wali spec
    (v51 mein range hai) — dobara install mein wahi istemal ho."""
    pin = "opencv-python-headless>=4.8"
    try:
        for ln in (OCR_DIR / "requirements.txt").read_text(
                encoding="utf-8").splitlines():
            ln = ln.split("#")[0].strip()
            if ln.lower().startswith("opencv-python-headless"):
                return ln
    except Exception:
        pass
    return pin


def main():
    t0 = time.time()
    set_state(state="running",
              started=datetime.now().isoformat(timespec="seconds"),
              pid=os.getpid(), error="")
    log("setup started — python " + sys.version.split()[0]
        + " (" + sys.executable + ")")
    try:
        # 1) pip wheel — PyPI JSON API se latest stable
        with urllib.request.urlopen(
                "https://pypi.org/pypi/pip/json", timeout=60) as r:
            meta = json.load(r)
        ver = str(meta["info"]["version"])
        wheel_url = None
        for f in meta.get("releases", {}).get(ver, []):
            if f.get("packagetype") == "bdist_wheel" \
                    and f.get("filename", "").endswith(".whl"):
                wheel_url = f["url"]
                break
        if not wheel_url:
            for f in meta.get("urls", []):
                if f.get("packagetype") == "bdist_wheel":
                    wheel_url = f["url"]
                    break
        if not wheel_url:
            raise RuntimeError("pip wheel not found on PyPI")
        log(f"downloading pip {ver} wheel")
        if BOOTSTRAP_DIR.exists():
            shutil.rmtree(BOOTSTRAP_DIR, ignore_errors=True)
        pkg_dir = BOOTSTRAP_DIR / "pkg"
        pkg_dir.mkdir(parents=True, exist_ok=True)
        whl_path = BOOTSTRAP_DIR / wheel_url.rsplit("/", 1)[-1]
        urllib.request.urlretrieve(wheel_url, str(whl_path))
        with zipfile.ZipFile(str(whl_path)) as z:
            z.extractall(str(pkg_dir))
        log("pip bootstrap ready")
        # 2) requirements -> ocr/pylibs (--target install)
        env = dict(os.environ)
        env["PYTHONPATH"] = str(pkg_dir) + (
            os.pathsep + env["PYTHONPATH"]
            if env.get("PYTHONPATH") else "")
        env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
        # pip apne temp files /tmp (ya %TEMP%) mein kholta hai —
        # chhote tmpfs /tmp wale servers par bade wheels (OpenCV)
        # unpack hote hote jagah khatam ho jati hai. Temp ko app
        # ke apne bootstrap folder mein rakho (wahi disk jahan
        # pylibs banna hai) taake install kahin na atke.
        tmp_dir = BOOTSTRAP_DIR / "tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        env["TMPDIR"] = str(tmp_dir)
        env["TEMP"] = str(tmp_dir)
        env["TMP"] = str(tmp_dir)
        cmd = [sys.executable, "-m", "pip", "install",
               "--break-system-packages"] + PIP_FLAGS + [
               "--target", str(PYLIBS),
               "-r", str(OCR_DIR / "requirements.txt")]
        log("running: " + " ".join(cmd))
        with open(LOG_FILE, "a", encoding="utf-8") as lf:
            r = subprocess.run(cmd, stdout=lf,
                               stderr=subprocess.STDOUT, env=env,
                               timeout=1800)
        if r.returncode != 0:
            raise RuntimeError(
                f"pip install failed (exit {r.returncode}) — "
                "pip output is in ocr/setup.log above this line")
        # 3) headless OpenCV ki guarantee — cv2 import probe;
        #    fail ho to cv2 dirs saaf karke sirf headless dobara
        pylibs_env = {"PYTHONPATH": str(PYLIBS)}
        if not probe("cv2", pylibs_env):
            log("cv2 import failed — removing cv2 packages and "
                "reinstalling headless OpenCV only")
            for pat in ("cv2", "opencv_python-*.dist-info",
                        "opencv_python_headless-*.dist-info"):
                for d in PYLIBS.glob(pat):
                    if d.is_dir():
                        shutil.rmtree(d, ignore_errors=True)
            pin = headless_pin()
            log("installing: " + pin)
            with open(LOG_FILE, "a", encoding="utf-8") as lf:
                r = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     "--break-system-packages"] + PIP_FLAGS + [
                     "--target", str(PYLIBS),
                     "--force-reinstall", "--upgrade",
                     "--no-deps", pin],
                    stdout=lf, stderr=subprocess.STDOUT, env=env,
                    timeout=900)
            if r.returncode != 0:
                raise RuntimeError("headless OpenCV reinstall "
                                   "failed — see setup.log")
            if not probe("cv2", pylibs_env):
                raise RuntimeError("cv2 import still failing "
                                   "after headless reinstall")
        # 4) asal jaanch — app ke Python se pylibs import
        if not probe("rapidocr_onnxruntime", pylibs_env):
            raise RuntimeError("rapidocr import failed after "
                               "install (see setup.log)")
        shutil.rmtree(BOOTSTRAP_DIR, ignore_errors=True)
        secs = round(time.time() - t0)
        log(f"setup READY in {secs}s — engine: "
            "app python + ocr/pylibs")
        set_state(state="ready",
                  finished=datetime.now().isoformat(
                      timespec="seconds"),
                  seconds=secs, error="", log_tail=log_tail())
        return 0
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
        log("setup FAILED: " + err)
        set_state(state="failed",
                  finished=datetime.now().isoformat(
                      timespec="seconds"),
                  error=err, log_tail=log_tail())
        return 1


if __name__ == "__main__":
    sys.exit(main())
