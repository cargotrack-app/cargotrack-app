#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CargoTrack v49 — bundled OCR runner (RapidOCR / onnxruntime).

Chhota sa subprocess: server.py ise har photo scan par ek dafa
chalata hai (image path argument), stdout par EK JSON line milti
hai: {"items":[{"box":[[x,y]x4],"text":..,"score":..}],"w":W,"h":H}
ya ghalti par {"error": "..."}. Process khatam hote hi model ki
memory khali ho jati hai — web server par bojh nahi rehta.
Koi Tesseract nahi, koi bahari install nahi: engine app ke
ocr/venv ke andar rehta hai.
"""
import json
import os
import sys
import tempfile

MAX_EDGE = 2000  # is se lambi side ko itna kar do — speed + accuracy


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "no image path given"}))
        return 2
    path = sys.argv[1]
    tmp = None
    try:
        from PIL import Image
        im = Image.open(path).convert("RGB")
        w, h = im.size
        scale = 1.0
        if max(w, h) > MAX_EDGE:
            scale = MAX_EDGE / float(max(w, h))
            im = im.resize((max(1, int(w * scale)),
                            max(1, int(h * scale))))
        fd, tmp = tempfile.mkstemp(prefix="ct_ocr_", suffix=".png")
        os.close(fd)
        im.save(tmp)
        from rapidocr_onnxruntime import RapidOCR
        res, _elapsed = RapidOCR()(tmp)
        items = []
        for box, txt, score in (res or []):
            # box coordinates ko asal (unscaled) image par wapas le jao
            pts = [[round(p[0] / scale, 1), round(p[1] / scale, 1)]
                   for p in box]
            items.append({"box": pts, "text": txt,
                          "score": round(float(score), 3)})
        print(json.dumps({"items": items, "w": w, "h": h}))
        return 0
    except Exception as e:  # har ghalti saaf JSON mein — server crash nahi
        print(json.dumps({"error": f"{type(e).__name__}: {e}"}))
        return 1
    finally:
        if tmp:
            try:
                os.unlink(tmp)
            except Exception:
                pass


if __name__ == "__main__":
    sys.exit(main())
