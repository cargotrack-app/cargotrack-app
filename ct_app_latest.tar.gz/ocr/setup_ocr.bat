@echo off
REM CargoTrack v49 — photo-scan (OCR) engine ki ek-dafa setup (Windows).
REM Sirf tab chalana hai jab app ke sath aya huwa ocr\venv is computer
REM par kaam na kare (masalan bilkul nayi Windows/Python). Ye ek virtual
REM environment banata hai aur RapidOCR us mein daalta hai — internet
REM chahiye, chand minute lag sakte hain.
title CargoTrack OCR setup - one time only
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel% neq 0 (
  echo Python nahi mila. Pehle https://www.python.org/downloads/ se
  echo Python install karein aur "Add python.exe to PATH" tick karein.
  pause
  exit /b
)
if exist venv rmdir /s /q venv
python -m venv venv
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo OCR engine tayyar hai. Ab CargoTrack dobara chalayein.
pause
