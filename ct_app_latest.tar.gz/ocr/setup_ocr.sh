#!/bin/sh
# CargoTrack v49 — photo-scan (OCR) engine ki ek-dafa setup (Linux/macOS).
# Sirf tab jab app ke sath aya huwa ocr/venv is machine par kaam na kare.
set -e
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"
rm -rf venv
"$PY" -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt
echo "OCR engine tayyar hai."
