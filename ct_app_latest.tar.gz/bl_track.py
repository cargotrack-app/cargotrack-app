#!/usr/bin/env python3
"""
bl-track.py — tez BL / Container tracking (bina browser ke, secondon mein).

Usage:
    python3 bl-track.py <BL_NUMBER> [CONTAINER_NUMBER]

Kaam:
  1. BL prefix se carrier pehchanta hai (offline, foran)
  2. track-trace.com se HTTP par tracking nikalta hai (browser nahi khulta)
  3. Vessel, voyage, ETA, status print karta hai
  4. Na mile to seedha tracking link de deta hai (1 click mein khud dekh lo)

House BL ho to container number bhi do — us se tracking ho jati hai.
"""

import re
import sys
import time
import html
import urllib.request
import urllib.parse
import http.cookiejar
from datetime import datetime

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

# Evergreen ki apni tracking site (ShipmentLink)
SL_URL = "https://ct.shipmentlink.com/servlet/TDB1_CargoTracking.do"

# ---- Carrier prefix table (BL number ke shuru ke 4 harf) ----
# 19 Oct 2026 correction: "COAU = COSCO" wali mapping ek kamzor blog source par
# thi — official COSCO code COSU hai. COAU hata diya gaya, kyunke ghalat carrier
# pehchan se tool ghalat system query karta tha.
CARRIERS = {
    "MAEU": "Maersk", "MSKU": "Maersk", "MRKU": "Maersk", "MCCQ": "Maersk (MCC)",
    "SEGU": "Maersk (Safmarine)", "SUDU": "Maersk (Hamburg Süd)",
    "COSU": "COSCO Shipping",
    # COSCO ke container prefixes (BL wale COSU/COAU se alag)
    "CSNU": "COSCO Shipping", "CSGU": "COSCO Shipping",
    "MSCU": "MSC (Mediterranean Shipping)", "MEDU": "MSC (Mediterranean Shipping)",
    "MCLU": "MSC (Mediterranean Shipping)",
    "EGHU": "Evergreen",
    # EGLV: Evergreen ke BL ka asal prefix (21 Oct 2026 — Yousuf ke
    # BL EGLV070600248927 par pakra gaya: list mein sirf EGHU tha,
    # jo container prefix hai, is liye Evergreen BL kabhi pehchana
    # hi nahi gaya aur "not found" aa jata tha).
    "EGLV": "Evergreen",
    # Evergreen ke container prefixes (BL wale EGLV se alag)
    "EGSU": "Evergreen", "EMCU": "Evergreen", "EITU": "Evergreen",
    "CMAU": "CMA CGM",
    "HLCU": "Hapag-Lloyd",
    "OOLU": "OOCL",
    "ONEU": "ONE (Ocean Network Express)", "TLLU": "ONE", "KKFU": "ONE",
    "YMLU": "Yang Ming",
    "WHLC": "Wan Hai",
    "ZIMU": "ZIM",
    "HMMU": "HMM (Hyundai Merchant Marine)",
    "PILU": "PIL (Pacific International Lines)",
    "ESLU": "Evergreen (subsidiary)",
    # MBAQ = RTW Shipping Lines (19 Oct 2026: Yousuf ne bataya)
    # "rtw shipping lines ka bl hota hy mba wala" — aur ye MASTER BL hai,
    # house BL nahi (Yousuf ki wazahat). Pehle ghalat label lagaya tha.
    "MBAQ": "RTW Shipping Lines",
    # EMKA/EMKAY = Emkay Line, Karachi NVOCC (2008 se, 132 ports)
    # Tracking: emkayline.com/trackbyblno.php?txt_bl_no={BL} (GET, verified 19 Oct 2026)
    "EMKA": "Emkay Line", "EMKY": "Emkay Line",
    # COAU: 20 Oct 2026 VERIFIED — Yousuf ne COSCO ki apni site par COAU BL
    # track karke dikhaya; COSCO API digits-only number (6468005230) par
    # record deta hai. (19 Oct ko full COAU form par "no record" aaya tha.)
    "COAU": "COSCO Shipping",
    # --- 19 Oct 2026: Yousuf ki 10 shipping lines (logos se) ---
    # (MAEU/YMLU/WHLC upar pehle se hain — F-24: duplicate keys hataye)
    "YMLY": "Yang Ming",
    "WANU": "Wan Hai",
    "STAR": "Star Lines",
    "BALT": "Baltic Lines",
    "NGSS": "New Golden Sea",
    "PELU": "Prolog Express Line", "PEL": "Prolog Express Line",
    # EMAS = EM-A Shipping (Karachi forwarder). Yousuf ka apna house BL
    # EMASUBKHI37726 (shared 12 Oct 2026) inhi ke letterhead par tha —
    # "SUBKHI" = sub-BL, Karachi. Is prefix ka BL aate hi foran pehchano.
    "EMAS": "EM-A Shipping",
    # --- 24 Oct 2026 (v51): Yousuf ki 43 BL photos se seekhe hue
    # prefix jo is table mein reh gaye thay. In ki kami se kai BL
    # pehchane hi nahi jate thay (sab se bara: Wan Hai ka 142G
    # pattern — neeche _BL_PATTERNS mein hai kyunke wo 4-huroof
    # prefix nahi hai).
    "KMTC": "KMTC",
    "YMJA": "Yang Ming",
    "SSLS": "Samudera",
    "FRLS": "Feeder Logistics",
    # Star Lines ke BL "STS" + port code se shuru hote hain
    # (STSCMBALKHI9113) — sirf "STAR" wala key in par kabhi match
    # nahi hota tha. PEL ke BL "PELM" se (PELMSASUBKHI030926) —
    # purana 3-huroof "PEL" key 4-huroof lookup mein marr gaya tha.
    "STSC": "Star Lines",
    "PELM": "Prolog Express Line",
}

# Forwarder contacts — jab online tracking na ho to in se rabta
# (phone/email verified jahan likha hai)
FORWARDER_CONTACTS = {
    "RTW Shipping Lines": {
        "phone": "+92 324 3333888",
        "whatsapp": "+254 701 137 728",
        "email": "info@rtwsl.com",
        "web": "https://www.rtwsl.com/",
        # 19 Oct 2026 verified: rtwsl.com homepage + web search — koi public
        # tracking portal nahi (homepage par sirf marketing pages; "Cargo
        # tracking" sirf service bullet hai). Ye BL direct rabte se track hoga.
        # NOTE: phone/whatsapp numbers 19 Oct ki research se aaye — site par
        # contact details openly nahi mile, is liye pehle call/WhatsApp par
        # confirm kar lena ke ye RTW ka hi number hai.
        "note": "The MBA prefix belongs to this carrier (master BL). Their website has no online tracking — please contact them directly.",
    },
    "EM-A Shipping": {
        "phone": "(021) 32601355-58-59",
        "email": "info@emashipping.com",
        "web": "https://www.emashipping.com/",
        "note": "Karachi freight forwarder (house BL). Ask them for the master BL or the container number.",
    },
}

# track-trace.com BOL company IDs (data-id values, verified 19 Oct 2026)
# POST /bol/select with number + shipper=<id> se direct tracking milta hai
# NOTE: 349 BOL list mein APL hai (container list mein MSC tha) — alag rakho!
# NOTE: MSC BOL list mein maujood hi nahi; track-trace kehta hai
# "we can not integrate Mediterranean Shipping completely due to technical reasons"
TT_BOL_COMPANY_IDS = {
    "Maersk": "347",
    "COSCO Shipping": "358",
    "Evergreen": "345",
    "CMA CGM": "351",
    "Hapag-Lloyd": "352",
    "OOCL": "354",
    "ONE (Ocean Network Express)": "355",
    "Yang Ming": "360",
    "Wan Hai": "370",
    # F-07 fix (v46 audit): "ZIM" was mapped to "360" — that is Yang
    # Ming's track-trace company id, so ZIM BLs were queried against
    # the WRONG company. ZIM's real track-trace id is unverified, so
    # the entry is removed: no query beats a wrong-company query.
    "HMM (Hyundai Merchant Marine)": "361",
    "PIL (Pacific International Lines)": "489",
}
# MSC automated tracking supported NAHI (bot-block + no public API + track-trace no integration)
NO_AUTO_TRACK = {"MSC (Mediterranean Shipping)"}

CARRIER_TRACK_URL = {
    "Maersk": "https://www.maersk.com/tracking/",
    "COSCO Shipping": "https://elines.coscoshipping.com/ebusiness/cargotracking",
    "MSC (Mediterranean Shipping)": "https://www.msc.com/en/track-a-shipment",
    "Evergreen": SL_URL,
    "CMA CGM": "https://www.cma-cgm.com/ebusiness/tracking",
    "Hapag-Lloyd": "https://www.hapag-lloyd.com/en/online-business/track/track-by-booking-solution.html",
    "OOCL": "https://www.oocl.com/eng/ourservices/eservices/cargotracking/Pages/cargotracking.aspx",
    "ONE (Ocean Network Express)": "https://ecomm.one-line.com/one-ecom/manage-shipment/cargo-tracking",
    "Yang Ming": "https://www.yangming.com/e-service/track_trace/track_trace.aspx",
    "Wan Hai": "https://www.wanhai.com/views/tracing/tracing",
    "ZIM": "https://www.zim.com/cargo-tracking",
    "HMM (Hyundai Merchant Marine)": "https://www.hmm21.com/e-service/general/cargo-tracking",
    "PIL (Pacific International Lines)": "https://www.pilship.com/en-pil-track-and-trace/134.html",
    # --- 19 Oct 2026: Yousuf ki chhoti lines (tracking via website/forwarder) ---
    "Emkay Line": "https://emkayline.com/#tracking",
    "Star Lines": "https://www.track-trace.com/",
    "Baltic Lines": "https://www.track-trace.com/",
    "New Golden Sea": "https://www.track-trace.com/",
    "Prolog Express Line": "https://www.track-trace.com/",
    "RTW Shipping Lines": "https://www.track-trace.com/",
}


def clean_text(html_text):
    t = re.sub(r"<script.*?</script>", "", html_text, flags=re.S | re.I)
    t = re.sub(r"<style.*?</style>", "", t, flags=re.S | re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    t = html.unescape(t)
    return re.sub(r"\s+", " ", t).strip()


def post_form(url, data, timeout=30):
    req = urllib.request.Request(
        url,
        data=urllib.parse.urlencode(data).encode(),
        headers={**UA, "Content-Type": "application/x-www-form-urlencoded"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        final = r.geturl()
        body = r.read().decode("utf-8", errors="replace")
    return final, body


def get_json(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        import json
        return json.loads(r.read().decode("utf-8", errors="replace"))


# ---- Evergreen: ShipmentLink (un ki apni tracking site) ----


def _sl_date(s):
    """'OCT-26-2026' -> '26 Oct 2026'."""
    m = re.match(r"([A-Za-z]{3})-(\d{2})-(\d{4})", (s or "").strip())
    if not m:
        return ""
    try:
        return datetime(int(m.group(3)),
                        datetime.strptime(m.group(1).title(), "%b").month,
                        int(m.group(2))).strftime("%d %b %Y")
    except Exception:
        return ""


def _sl_city(v):
    """'SINGAPORE (SG)' -> 'Singapore'."""
    v = re.sub(r"\s*\([A-Z]{2}\)\s*$", "", (v or "").strip())
    return v.title()


def _sl_split_voyage(vv):
    """'NORTHERN PRACTISE 51W' -> ('NORTHERN PRACTISE', '51W')."""
    m = re.match(r"^(.*?)\s+(\d{2,4}[A-Z]{0,2})$", (vv or "").strip())
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return (vv or "").strip(), ""


_SL_LABELS = ("Place of Receipt|Container Count|Port of Loading|"
              "Gross Weight|Port of Discharge|Measurement|"
              "Place of Delivery|Manifest Quantity|"
              "OCP Final Destination|Estimated On Board Date|"
              "Service Mode|Cut Off")


def _sl_field(text, label):
    m = re.search(re.escape(label) + r"\s+(.+?)(?=\s+(?:"
                  + _SL_LABELS + r")\b|$)", text)
    return m.group(1).strip() if m else ""


def _parse_shipmentlink_bl(body):
    """ShipmentLink BL result page ko parse karo. 'Basic
    Information' asal result par hi hota hai — ghalat number par
    page khaali aata hai, wahi found ki pehchan hai."""
    text = clean_text(body)
    if "Basic Information" not in text:
        return {"found": False,
                "note": ("No record of this BL was found in "
                         "Evergreen's system.")}
    out = {"found": True, "source": "Evergreen ShipmentLink",
           "direct_url": SL_URL}
    m = re.search(r"Vessel Voyage on B/L\s+(.+?)\s+Estimated Date "
                  r"of Arrival", text)
    if m:
        out["vessel"], out["voyage"] = _sl_split_voyage(m.group(1))
    m = re.search(r"Estimated Date of Arrival at Destination\s*:\s*"
                  r"([A-Z]{3}-\d{2}-\d{4})", text)
    if m:
        out["eta"] = _sl_date(m.group(1))
    pol = _sl_field(text, "Port of Loading")
    pod = _sl_field(text, "Port of Discharge")
    if pol:
        out["pol"] = _sl_city(pol)
    if pod:
        out["pod"] = _sl_city(pod)
    w = _sl_field(text, "Gross Weight")
    if w:
        out["weight"] = re.sub(r"\.000\s*", " ", w).strip()
    etd = _sl_field(text, "Estimated On Board Date")
    if etd:
        out["etd"] = _sl_date(etd)
    # Container table: pehli row se number, size aur asal status
    m = re.search(r"VGM Current Status Date\s+([A-Z]{4}\d{7})\s+"
                  r"(\S+)\s+\S+\s+FCL/FCL\s+.*?KGS\s+(.+?)\s+"
                  r"([A-Z]{3}-\d{2}-\d{4})\s+Click Container", text)
    if m:
        out["containers"] = [m.group(1)]
        out["size_type"] = m.group(2)
        out["status"] = m.group(3).strip()
    else:
        ctns = re.findall(r"\b[A-Z]{4}\d{7}\b", text)
        if ctns:
            out["containers"] = list(dict.fromkeys(ctns))
        out["status"] = "In transit"
    return out


def track_shipmentlink_bl(bl_number):
    """Evergreen ki apni site (ShipmentLink) par BL tracking —
    21 Oct 2026 verified live EGLV070600248927 par. Site number ka
    sirf hissa (digits) leti hai; EGLV prefix hum hata dete hain."""
    digits = norm(bl_number)
    if digits.startswith("EGLV"):
        digits = digits[4:]
    try:
        _, body = post_form(SL_URL, {"TYPE": "BL", "BL": digits,
                                     "SEL": "s_bl", "NO": digits},
                            timeout=45)
    except Exception as e:
        return {"error": f"Could not reach ShipmentLink: {e}"}
    return _parse_shipmentlink_bl(body)


def _parse_shipmentlink_container(body, ctn_number):
    text = clean_text(body)
    if ctn_number not in text or "Estimated Date of Arrival" not in text:
        return {"found": False,
                "note": ("No record of this container was found in "
                         "Evergreen's system.")}
    out = {"found": True, "source": "Evergreen ShipmentLink",
           "direct_url": SL_URL, "containers": [ctn_number]}
    m = re.search(r"on B/L\s+(.+?)\s+Estimated Date of Arrival", text)
    if m:
        out["vessel"], out["voyage"] = _sl_split_voyage(m.group(1))
    m = re.search(r"Estimated Date of Arrival\s*:\s*"
                  r"([A-Z]{3}-\d{2}-\d{4})", text)
    if m:
        out["eta"] = _sl_date(m.group(1))
    m = re.search(re.escape(ctn_number) +
                  r"\s+(\S+)\s+([A-Z]{3}-\d{2}-\d{4})\s+(.+?)\s+"
                  r"([A-Z][A-Z ]+\([A-Z]{2}\))\s", text)
    if m:
        out["size_type"] = m.group(1)
        out["status"] = (f"{m.group(3).strip()} at "
                         f"{_sl_city(m.group(4))}")
        out["position"] = _sl_city(m.group(4))
    return out


def track_shipmentlink_container(ctn_number):
    """ShipmentLink par container tracking (TYPE=CNTR)."""
    try:
        _, body = post_form(SL_URL, {"TYPE": "CNTR", "CNTR": ctn_number,
                                     "SEL": "s_cntr", "NO": ctn_number},
                            timeout=45)
    except Exception as e:
        return {"error": f"Could not reach ShipmentLink: {e}"}
    return _parse_shipmentlink_container(body, ctn_number)


# ---- Carrier-specific direct APIs (verified 19 Oct 2026) ----
def _cosco_date(s):
    """'2026-10-26 08:00' -> '26 Oct 2026'."""
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", (s or "").strip())
    if not m:
        return ""
    try:
        return datetime(int(m.group(1)), int(m.group(2)),
                        int(m.group(3))).strftime("%d %b %Y")
    except Exception:
        return ""


def track_cosco_api(bl_number):
    """COSCO ka public cargo tracking API — bina browser ke.
    20 Oct 2026 fix: COAU wale BL andar sirf digits se milte hain
    (COAU6468005230 -> 6468005230), aur trackingPath ek dict hota hai.
    Legs (actualShipment) se asal vessel/ETA/status banta hai."""
    base = "https://elines.coscoshipping.com/ebtracking/public/bill"
    candidates = [bl_number]
    digits = re.sub(r"\D", "", bl_number)
    if digits and digits != bl_number:
        candidates.append(digits)
    content = None
    last_err = None
    responded = False
    for cand in candidates:
        try:
            data = get_json(f"{base}/{urllib.parse.quote(cand)}")
            responded = True
        except Exception as e:
            # F-10 fix (v46 audit): a failure on the full form must not
            # skip the digits-only candidate — that is the form that
            # actually resolves COAU BLs. Try every candidate first.
            last_err = e
            continue
        c = (data.get("data") or {}).get("content") or {}
        if c.get("isbillOfLadingExist"):
            content = c
            break
    if not content and not responded and last_err is not None:
        return {"error": f"Could not reach the COSCO API: {last_err}"}
    if not content:
        return {"found": False,
                "note": "No record of this BL was found in COSCO's system."}
    out = {"found": True, "source": "COSCO API"}
    tp = content.get("trackingPath") or {}
    pod_raw = ""
    if isinstance(tp, dict):
        pod_raw = tp.get("pod") or ""
        if "SAPT" in pod_raw:
            out["terminal"] = "SAPT"
        elif "KICT" in pod_raw:
            out["terminal"] = "KICT"
        elif "QICT" in pod_raw or "DP World" in pod_raw:
            out["terminal"] = "QICT"
        out["pol"] = (tp.get("fromCity") or "").split(",")[0].strip()
        out["pod"] = (tp.get("toCity") or "").split(",")[0].strip()
    legs = content.get("actualShipment") or content.get("actualShipmentPic") or []
    legs = [l for l in legs if l.get("vesselName")]
    if legs:
        first, last = legs[0], legs[-1]
        if not out.get("pol"):
            out["pol"] = first.get("portOfLoading", "")
        if not out.get("pod"):
            out["pod"] = last.get("portOfDischarge", "")
        out["vessel"] = last.get("vesselName", "")
        out["voyage"] = last.get("voyageNo", "")
        out["eta"] = _cosco_date(last.get("estimatedDateOfArrival"))
        if last.get("actualDischargeDate"):
            out["status"] = "Discharged"
            out["discharge_time"] = last["actualDischargeDate"]
        elif last.get("actualArrivalDate"):
            out["status"] = "Arrived"
        elif last.get("actualDepartureDate"):
            out["status"] = (f"In transit — departed "
                              f"{last.get('portOfLoading','')} "
                              f"{_cosco_date(last['actualDepartureDate'])}")
        # v96 FIX B: departed tareekh apne field mein bhi — kal ko
        # status 'Arrived'/'Discharged' ban jaye to bhi ye pakki
        # tareekh record se na mite.
        if last.get("actualDepartureDate"):
            out["departed"] = _cosco_date(last["actualDepartureDate"])
    ct = content.get("cargoTrackingContainer") or []
    ctns = [c.get("cntrNum") for c in ct if c.get("cntrNum")]
    if ctns:
        out["containers"] = ctns
    return out


def track_cosco_container_api(ctn_number):
    """COSCO ka public container status API."""
    base = "https://elines.coscoshipping.com/ebtracking/public/container/status"
    try:
        data = get_json(f"{base}/{urllib.parse.quote(ctn_number)}")
    except Exception as e:
        return {"error": f"Could not reach the COSCO API: {e}"}
    items = (data.get("data") or {}).get("content") or []
    # khaali (null) records hatao
    live = [x for x in items if x.get("transportation") or x.get("pol")
            or x.get("pod") or x.get("location")]
    if not live:
        if items:
            return {"found": False, "empty_container": True,
                    "note": ("This container exists in COSCO's system but is not on "
                             "an active shipment — it may be empty or an old record.")}
        return {"found": False,
                "note": "No record of this container was found in COSCO's system."}
    v = live[0]
    return {"found": True, "source": "COSCO API",
            "vessel": v.get("transportation"), "pol": v.get("pol"),
            "pod": v.get("pod"), "eta": v.get("podEta"),
            "status": v.get("containerNumberStatus"),
            "location": v.get("location")}


def track_emkay_api(bl_number):
    """Emkay Line ka tracking (simple GET — emkayline.com)."""
    url = (f"https://emkayline.com/trackbyblno.php?txt_bl_no="
           f"{urllib.parse.quote(bl_number)}")
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach the Emkay website: {e}"}
    text = clean_text(body)
    # table rows nikalo (header ke baad)
    # format: CONTAINER NO. | LAST ACTIVITY | ACTIVITY DATE | Description
    rows = re.findall(
        r"<tr>(?!.*<th)(.*?)</tr>", body, re.S | re.I)
    data_rows = []
    for row in rows:
        cells = [clean_text(c).strip()
                 for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        cells = [c for c in cells if c]
        if cells:
            data_rows.append(cells)
    if not data_rows:
        return {"found": False,
                "note": ("No activity record for this BL in Emkay's system — "
                         "the BL number may be incorrect, or the shipment "
                         "has not been entered yet."),
                "direct_url": url}
    # pehli row: container, last activity, date, description
    r0 = data_rows[0]
    # NOTE: Emkay's table columns are CONTAINER | LAST ACTIVITY |
    # ACTIVITY DATE | DESCRIPTION — the date is the last-activity
    # date, NOT an ETA. Never label it as ETA (v28 audit fix).
    return {"found": True, "source": "Emkay Line",
            "direct_url": url,
            "status": r0[1] if len(r0) > 1 else "",
            "activity_date": r0[2] if len(r0) > 2 else "",
            "raw_snippet": " | ".join(r0)}


def track_emkay_container_api(ctn_number):
    """Emkay Line container tracking (trackbycno.php) — 20 Oct 2026 verified.
    Table: BL No | VESSEL | VOYAGE | LAST ACTIVITY | ACTIVITY DATE | REMARKS
    Non-Emkay container par table khaali aati hai — safe extra layer."""
    url = (f"https://emkayline.com/trackbycno.php?txt_container_no="
           f"{urllib.parse.quote(ctn_number)}")
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach the Emkay website: {e}"}
    rows = re.findall(r"<tr>(?!.*<th)(.*?)</tr>", body, re.S | re.I)
    data_rows = []
    for row in rows:
        cells = [clean_text(c).strip()
                 for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        cells = [c for c in cells if c]
        if cells:
            data_rows.append(cells)
    if not data_rows:
        return {"found": False,
                "note": "No record of this container in Emkay's system.",
                "direct_url": url}
    r0 = data_rows[0]
    # Columns: BL | VESSEL | VOYAGE | LAST ACTIVITY | ACTIVITY DATE —
    # the last column is an activity date, NOT an ETA (v28 audit fix).
    return {"found": True, "source": "Emkay Line (container)",
            "direct_url": url,
            "bl_ref": r0[0] if len(r0) > 0 else "",
            "vessel": r0[1] if len(r0) > 1 else "",
            "voyage": r0[2] if len(r0) > 2 else "",
            "status": r0[3] if len(r0) > 3 else "",
            "activity_date": r0[4] if len(r0) > 4 else "",
            "raw_snippet": " | ".join(r0)}


_TERM_LABELS = ["Owner", "BL/ Shipping Bill No.", "Container No.",
    "Container Size/Type", "Category", "Status", "Vessel Voyage", "VIR No",
    "ETA", "ETD", "Discharge Time", "Load Time", "DO Issuance Date",
    "DO Expiry Date", "Gate In Time", "Gate Out Time", "Origin", "Destination",
    "Custom Seal No.", "Line Seal No.", "Security Seal No.", "Other Seal No.",
    "Custom Status", "Current Position", "Commodity", "Weight", "Weighment",
    "Scanning", "Present Holds"]


def _term_date(s):
    """'04-OCT-26 04.00.00 PM' ya '13-OCT-2026 16:59' -> '04 Oct 2026'."""
    m = re.match(r"(\d{1,2})-([A-Za-z]{3})-(\d{2,4})", (s or "").strip())
    if not m:
        return ""
    try:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        return datetime(y, datetime.strptime(m.group(2).title(), "%b").month,
                        int(m.group(1))).strftime("%d %b %Y")
    except Exception:
        return ""


def _parse_term_details(body):
    """ContainerDetails HTML se label->value dict (N/A wale skip)."""
    cells = [clean_text(c).strip()
             for c in re.findall(r"<td[^>]*>(.*?)</td>", body, re.S | re.I)]
    out = {}
    for i, c in enumerate(cells):
        if c in _TERM_LABELS and i + 1 < len(cells):
            v = cells[i + 1]
            if v and v not in ("N/A", "/") and v not in _TERM_LABELS:
                out[c] = v
    return out


def _term_fetch_details(opener, host, bu, hdr, rows):
    """ContainerDetails for the first 6 history rows (2 tries each —
    the terminal site often returns an empty template). v99fix:
    cap 3 -> 6 taake zyada dabbon wale BL ki listing rows (ek
    piddi har dabbe ki) sab ki details aa jayein — pehle 4th+
    dabbe ki discharge/gate-out gin-ti se reh jati thi."""
    got = []
    for row in rows[:6]:
        pid = row.get("pid")
        if not pid:
            continue
        for _try in range(2):
            try:
                data = urllib.parse.urlencode(
                    {"cntrPK": pid, "BU": bu}).encode()
                req = urllib.request.Request(
                    f"{host}/Enquiries/ContainerDetails", data=data,
                    headers=hdr)
                dbody = opener.open(req, timeout=45).read().decode(
                    "utf-8", "replace")
                d = _parse_term_details(dbody)
                if d:
                    # v99: detail apni source row ki pehchan
                    # saath rakhe — EM (empty-return) cycle ki
                    # details discharge/gate-out ki gin-ti
                    # mein nahi aatin (_term_apply_details
                    # dekho), aur ek hi dabbe ki duplicate
                    # rows ek hi unit gini jati hain.
                    d["_ctn"] = row.get("CONTAINER NO", "")
                    d["_row_status"] = row.get("STATUS", "")
                    d["_row_gate_out"] = \
                        row.get("GATE OUT TIME", "") or ""
                    d["_row_discharge"] = \
                        row.get("DISCHARGING TIME", "") or ""
                    got.append(d)
                    break
            except Exception:
                pass
            time.sleep(1)
        time.sleep(0.6)
    return got


def _term_gate_key(s):
    """Gate-out stamp ko tartib ke liye datetime banao —
    shipment ka gate_out SAB dabbon ke out hone ka waqt
    hai (sab se aakhri wala), is liye max chahiye hota
    hai. Na parse ho to datetime.min (asli parse wale
    stamp ke hote hue nakli kabhi max nahi bane ga)."""
    s = str(s or "").strip()
    for fmt in ("%d-%b-%y %I.%M.%S %p", "%d-%b-%Y %H:%M",
                "%d-%b-%y %H:%M", "%d-%b-%Y %I:%M %p"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    d = _term_date(s)
    if d:
        try:
            return datetime.strptime(d, "%d %b %Y")
        except Exception:
            pass
    return datetime.min


def _term_apply_details(out, details):
    """Map parsed ContainerDetails onto the result dict. The terminal
    name comes ONLY from the VIR number (PKKHIKICT / PKKHISAPT) —
    never a combined label, never a guess.

    v99fix derivation discipline (truth table / Phase-1 fail,
    30 Oct 2026):
    - Export-cycle (XM/XF) details kisi field mein hissa
      nahi leti — wo dabbe ke agle safar ka record hai.
    - Tamam fields IMPORT detail (d0 = pehli import detail)
      se ayenge; EM detail sirf wapsi ke saboot ke liye hai.
    - Position sirf tab jab wahi detail apne cycle ka koi
      EVENT stamp (discharge / gate-out) rakhti ho — event
      ke baghair position pichle cycle ki baqiyat hoti hai
      (COAU6468022200 ki 'Loaded on Vessel': dabba discharge
      hi nahi huwa tha, position Jun ke safar ki thi).
    - Import detail ki 'Gate In Time' khaali dabbe ki
      wapsi ka stamp hai (import cycle mein is ke ilawa
      koi gate-in hoti hi nahi) — use 'empty_gate_in'
      nishan ke sath mehfooz karo (OOLU2337916330)."""
    def _row_st(d):
        return (d.get("_row_status") or "").strip().upper()

    usable = [d for d in details
              if _row_st(d) not in _EXPORT_ROW_STATUS]
    if not usable:
        return out
    imp = [d for d in usable if _row_st(d) != "EM"]
    if not imp:
        imp = list(usable)
    d0 = imp[0]
    vv = d0.get("Vessel Voyage", "")
    if " / " in vv:
        out["vessel"], out["voyage"] = [x.strip() for x in vv.split(" / ", 1)]
    elif vv:
        out["vessel"] = vv
    out["eta"] = _term_date(d0.get("ETA", ""))
    out["etd"] = _term_date(d0.get("ETD", ""))
    out["pol"] = d0.get("Origin", "")
    out["pod"] = d0.get("Destination", "")
    vir = ""
    for d in imp + usable:
        if d.get("VIR No"):
            vir = d["VIR No"]
            break
    if "KICT" in vir:
        out["terminal"] = "KICT"
    elif "SAPT" in vir:
        out["terminal"] = "SAPT"
    out["vir"] = vir
    # position event-anchored: detail ke paas is cycle ka
    # discharge ya gate-out stamp ho to hi us ki position
    # is cycle ki hai (oper dekho).
    _anchored = any(_term_date(d0.get(k) or "") for k in
                    ("Discharge Time", "Gate Out Time",
                     "_row_discharge", "_row_gate_out"))
    out["position"] = d0.get("Current Position", "") \
        if _anchored else ""
    out["holds"] = d0.get("Present Holds", "")
    out["do_expiry"] = _term_date(d0.get("DO Expiry Date", ""))
    out["owner"] = d0.get("Owner", "")
    out["weight"] = d0.get("Weight", "")
    out["commodity"] = d0.get("Commodity", "")
    out["size_type"] = d0.get("Container Size/Type", "")
    out["custom_status"] = d0.get("Custom Status", "")
    out["category"] = d0.get("Category", "")
    out["gate_in"] = d0.get("Gate In Time", "")
    # import cycle ki pehli asal gate-in = empty return
    # ka terminal stamp (provenance nishan ke sath).
    for d in usable:
        _gi = d.get("Gate In Time") or ""
        if _gi and _term_date(_gi):
            out["empty_gate_in"] = _gi
            break
    # v99 (truth table 30 Oct 2026): discharge/gate-out
    # ki gin-ti sirf IMPORT cycle ki details par hogi —
    # EM (empty-return) cycle ki details is gin-ti mein
    # aati theen to mukammal gate-out shipment bhi
    # 'Partially discharged' ban jata tha aur asal
    # gate_out ghayb ho jata tha (MEDUT1383412: teeno
    # dabbe out + wapis, phir bhi 'Partially'). Aur ek
    # hi dabbe ki duplicate history rows (MCLSUB26104308:
    # ek dabba, do discharge rows — ek gate-out wali,
    # ek baghair) EK unit hain: kisi ek ka discharge /
    # gate_out us dabbe ka saboot hai, khaali wali row
    # use kaat nahi sakti.
    # imp oper function ke shuru mein hi ban chuki hai
    # (usable = ghair-export details; imp = un mein se
    # ghair-EM, warna tamam usable).
    _units = {}
    for _i, d in enumerate(imp):
        _units.setdefault(d.get("_ctn") or f"#{_i}", []).append(d)

    def _pick(ds, key, rowkey):
        # v99fix (d): sirf PARSE hone wala stamp hi saboot
        # hai — terminal khaali gate-out par 'N/A' likhta
        # hai; wo string 'Gate out' status bana deti thi
        # jabke gate_out ki tareekh kabhi thi hi nahi
        # (COAU6468022200 ka andaruni tazad: status 'Gate
        # out', gate_out NULL).
        for d in ds:
            if _term_date(d.get(key) or ""):
                return d[key]
        for d in ds:
            if _term_date(d.get(rowkey) or ""):
                return d[rowkey]
        return ""

    dis = [_pick(ds, "Discharge Time", "_row_discharge")
           for ds in _units.values()]
    out["discharge_time"] = dis[0] if dis else ""
    if dis and all(dis):
        out["status"] = "Discharged"
    elif any(dis):
        out["status"] = "Partially discharged"
    gate = [_pick(ds, "Gate Out Time", "_row_gate_out")
            for ds in _units.values()]
    if gate and all(gate):
        out["status"] = "Gate out"
        # shipment ka gate_out = aakhri dabbe ka gate-out
        # (MEDUT1385110: pehle dabbe wala stamp lag jane
        # se doosre dabbe ka 29-Oct gate-out chhup jata
        # tha).
        out["gate_out"] = max(gate, key=_term_gate_key)
    return out


def _term_history(host, bu, params):
    """One terminal session: enquiry page (affinity cookie) ->
    ContainerHistory. Returns (opener, hdr, rows) or an error dict."""
    hdr = {**UA, "X-Requested-With": "XMLHttpRequest",
           "Referer": f"{host}/Enquiries?is=ContainerBLEnquiry"}
    try:
        cj = http.cookiejar.CookieJar()
        op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(cj))
        req = urllib.request.Request(
            f"{host}/Enquiries/ContainerBLEnquiry", headers=hdr)
        op.open(req, timeout=30).read()
        q = urllib.parse.urlencode(params)
        req = urllib.request.Request(
            f"{host}/Enquiries/ContainerHistory?{q}", headers=hdr)
        body = op.open(req, timeout=30).read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": str(e)}
    m = re.search(r'"_jsonArray":"((?:\\.|[^"\\])*)"', body)
    if not m:
        # page aaya lekin us mein data wala hissa hi nahi — site
        # busy/masroof thi ya session na bana. Ye "record nahi
        # hai" ka saboot NAHI hai; error kehna hi imandari hai
        # (17:11 wali ghalti: khaali jawab par app ne dono
        # containers ko Not found keh diya tha).
        return {"error": "terminal returned a page without data"}
    try:
        import json as _json
        rows = _json.loads(_json.loads('"' + m.group(1) + '"'))
    except Exception:
        return {"error": "terminal data could not be read"}
    if not isinstance(rows, list):
        return {"error": "terminal data could not be read"}
    rows = [r for r in rows
            if isinstance(r, dict) and r.get("CONTAINER NO")
            and r["CONTAINER NO"] != "N/A"]
    if not rows:
        return {"found": False}
    return (op, hdr, rows)


def _term_row_ts(row):
    """History row ki sab se taza tareekh (datetime) — cycle pehchan
    ke liye. Koi tareekh na mile to None."""
    best = None
    for k in ("DISCHARGING TIME", "GATE OUT TIME", "GATE In TIME",
              "LOADING TIME"):
        d = _term_date(row.get(k) or "")
        if d:
            try:
                dt = datetime.strptime(d, "%d %b %Y")
            except Exception:
                continue
            if best is None or dt > best:
                best = dt
    return best


def _term_current_rows(rows):
    """Container ki history mein PICHLE safar ki ghost rows bhi aati
    hain (maslan 2024 ki row 2026 ke record ke sath) — wo gin-ti aur
    status dono kharab karti theen (gate-out shipment 'Partially
    discharged' ban jata tha). Sirf MOJOODA cycle ki rows rakho:
    sab se taza row se 150 din ke andar wali; jis container ki koi
    tareekh-wali row hi nahi, us ki rows joon ki toon."""
    by_ctn = {}
    for r in rows:
        by_ctn.setdefault(r.get("CONTAINER NO", ""), []).append(r)
    keep = []
    for ctn, rs in by_ctn.items():
        dated = [(r, _term_row_ts(r)) for r in rs]
        dated = [(r, t) for r, t in dated if t is not None]
        if not dated:
            keep.extend(rs)
            continue
        newest = max(t for _, t in dated)
        keep.extend(r for r, t in dated
                    if (newest - t).days <= 150)
    return keep or rows


# v99fix: history row ke STATUS codes — XM/XF dabbe ke
# AGLE (export) cycle ki rows hain. Un ki details is import
# BL ka saboot kabhi nahi ban sakteen (COAU6468022200: sirf
# Jun-2026 XM row thi, usi ki details se 'Loaded on Vessel'
# position aur 'N/A' par 'Gate out' status ban gaya tha).
_EXPORT_ROW_STATUS = {"XM", "XF"}


def _term_finish(host, bu, hdr, op, rows):
    rows = _term_current_rows(rows)
    out = {"found": True, "terminal": "", "containers": rows,
           "source": "Karachi Terminal (Hutchison Ports)"}
    # v99: details pehle IMPORT (IF) rows ki mangwao — EM
    # (empty-return) row ki details yard mein wapis khare
    # khaali dabbe ki halat hoti hai, import cycle ki
    # position/discharge NAHI (wo pehle aa jane se
    # mukammal shipment 'Partially discharged' ban jata
    # tha — MEDUT1383412, truth table 30 Oct 2026).
    rows = sorted(rows, key=lambda r: (
        (r.get("STATUS") or "").strip().upper() == "EM"))
    # v99fix: export-cycle (XM/XF) rows ki details kabhi
    # nahi mangwate — wo dabbe ki agli zindagi hai, is BL
    # ki nahi. Rows stored record mein rehti hain (saboot
    # ke tor par), lekin derivation mein hissa nahi leti.
    det_rows = [r for r in rows
                if (r.get("STATUS") or "").strip().upper()
                not in _EXPORT_ROW_STATUS]
    details = _term_fetch_details(op, host, bu, hdr, det_rows)
    if len(details) > 1:
        # belt-and-braces: pehle (mojooda) record ke VIR se na milne
        # wali details ghost cycle ki hain — gin-ti se bahar.
        # v99fix: anchor hamesha IMPORT detail ka VIR hai
        # (EM detail ka VIR agle cycle ka bhi ho sakta hai).
        vir0 = ""
        for d in details:
            if (d.get("_row_status") or "").strip().upper() != "EM" \
                    and d.get("VIR No"):
                vir0 = d["VIR No"]
                break
        if not vir0:
            vir0 = details[0].get("VIR No", "")
        if vir0:
            same = [d for d in details if d.get("VIR No") == vir0]
            if same:
                details = same
    if not any(d.get("Vessel Voyage") or d.get("ETA") for d in details):
        try:
            cj2 = http.cookiejar.CookieJar()
            op2 = urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(cj2))
            req = urllib.request.Request(
                f"{host}/Enquiries/ContainerBLEnquiry", headers=hdr)
            op2.open(req, timeout=30).read()
            details2 = _term_fetch_details(op2, host, bu, hdr, det_rows)
            if any(d.get("Vessel Voyage") or d.get("ETA")
                   for d in details2) or (details2 and not details):
                details = details2
        except Exception:
            pass
    # v112 (Yousuf, 4 Nov): VIR ke baghair koi Karachi record
    # current NAHI banta. Bare rows wale result ke paas koi
    # discharge/eta/vir tareekh nahi hoti, is liye tamam
    # purana-record guards (_stale_info/_prev_cycle) andhe
    # ho jate thay aur July-2026 ki EXPORT row (CBHU5680350)
    # "Arrived at Karachi terminal" ban gayi thi. Usool:
    # export-only rows, ya jin ki aakhri harkat 30+ din
    # purani ho aur VIR-wali detail na bani ho — found hi
    # nahi; layer mein saaf note jayega (QICT wala rawaiya).
    if not any((d.get("VIR No") or "").strip() for d in details):
        import datetime as _dtv
        _rows = out.get("containers") or []
        _exp_only = bool(_rows) and all(
            (r.get("STATUS") or "").strip().upper()
            in _EXPORT_ROW_STATUS for r in _rows)
        _ts = [t for t in (_term_row_ts(r) for r in _rows)
               if t is not None]
        _newest = max(_ts) if _ts else None
        if isinstance(_newest, _dtv.datetime):
            _newest = _newest.date()
        _old = (_newest is not None and
                (_dtv.date.today() - _newest).days > 30)
        if _exp_only or _old:
            _when = (_newest.strftime("%d %b %Y")
                     if _newest else "an unknown date")
            return {"found": False,
                    "note": (f"Karachi terminal holds only an "
                             f"OLD record for this number (last "
                             f"activity {_when}) — from a "
                             f"previous trip. Not counted as a "
                             f"current record.")}
        out["no_vir"] = True
    if details:
        _term_apply_details(out, details)
    return out


def _term_history_retry(host, bu, params, tries=3):
    """_term_history ko error par fresh session ke sath dobara
    try karo — terminal ki site aksar pehli koshish par khaali
    jawab deti hai aur dosri par record de deti hai."""
    r = {"error": "no attempt made"}
    for i in range(tries):
        r = _term_history(host, bu, params)
        if isinstance(r, tuple) or not r.get("error"):
            return r
        if i < tries - 1:
            time.sleep(2)
    return r


def track_terminal_bl(bl_number, host, bu):
    """Hutchison terminal (KICT/SAPT) full enquiry by BL number —
    verified 20 Oct 2026. One cookie session: enquiry page ->
    ContainerHistory (method=B) -> ContainerDetails per container."""
    r = _term_history_retry(host, bu, {"cntrNum": "",
                                       "BL": f"{bl_number}_1",
                                       "method": "B", "pTId": bu})
    if not isinstance(r, tuple):
        return r
    op, hdr, rows = r
    return _term_finish(host, bu, hdr, op, rows)


def track_terminal_container(ctn_number, host, bu):
    """Same terminal enquiry by CONTAINER number (method=C) —
    history step verified live 20 Oct 2026: it returns the same
    _jsonArray rows (with pid), so details work identically."""
    r = _term_history_retry(host, bu, {"cntrNum": ctn_number,
                                       "BL": "", "method": "C",
                                       "pTId": bu})
    if not isinstance(r, tuple):
        return r
    op, hdr, rows = r
    return _term_finish(host, bu, hdr, op, rows)


TERMINAL_HOSTS = [("KICT", "https://www.kictl.com"),
                  ("SAPT", "https://www.sapt.com.pk")]


def track_karachi_terminals(bl_number):
    """Try each Hutchison host in turn. The two hosts share one
    database, but the details call is unreliable: if the first host
    finds the containers yet returns no details (no vessel / ETA /
    discharge), the second host is tried as well and the richest
    result wins."""
    best = {"found": False}
    saw_error = False
    stale_note = ""
    for bu, host in TERMINAL_HOSTS:
        r = track_terminal_bl(bl_number, host, bu)
        if r.get("found"):
            _st, _wh = _stale_info(r)
            if _st:
                # v54: terminal par is number ka sirf PURANA
                # record hai (pichle safar ka — container
                # number dobara istemal hote hain). Use is
                # shipment ka result banana ghalat hai; QICT
                # par ye rok pehle se thi, yahan reh gayi thi
                # (CAIU4648550 par Jul 2023 ka record 2026 ke
                # BL ke result mein aa gaya tha).
                stale_note = (
                    f"Karachi terminal holds only an OLD record "
                    f"for this BL ({_wh}) — from a previous trip. "
                    f"Container numbers are reused, so this is "
                    f"not counted as a current record.")
                continue
            if r.get("vessel") or r.get("eta") or r.get("discharge_time"):
                return r
            if not best.get("found"):
                best = r
        elif r.get("error"):
            saw_error = True
    if not best.get("found"):
        # F-01 fix (v46 audit): a clean no-record from both hosts used to
        # leave NO note at all -> the layer showed an empty detail. The
        # note must say which case it actually was.
        if stale_note:
            best["note"] = stale_note
        elif saw_error:
            best["note"] = "The Karachi terminal sites did not respond."
        else:
            best["note"] = "No record at KICT or SAPT for this BL."
    return best


def track_karachi_terminals_container(ctn_number):
    """Container-number version of track_karachi_terminals: both
    Hutchison hosts share one database; richest result wins."""
    best = {"found": False}
    saw_error = False
    stale_note = ""
    for bu, host in TERMINAL_HOSTS:
        r = track_terminal_container(ctn_number, host, bu)
        if r.get("found"):
            _st, _wh = _stale_info(r)
            if _st:
                # v54: BL wali hi rok, container raste par bhi
                # (isi raste se Jul 2023 wala record aaya tha).
                stale_note = (
                    f"Karachi terminal holds only an OLD record "
                    f"for this container ({_wh}) — from a "
                    f"previous trip. Container numbers are "
                    f"reused, so this is not counted as a "
                    f"current record.")
                continue
            if r.get("vessel") or r.get("eta") or r.get("discharge_time"):
                return r
            if not best.get("found"):
                best = r
        elif r.get("error"):
            saw_error = True
        elif "OLD record" in (r.get("note") or ""):
            # v112: _term_finish ka purana-record note
            # picker mein ghayb na ho — "bina batae" wali
            # ghalti yahin se hoti thi.
            if not stale_note:
                stale_note = r["note"]
    if not best.get("found"):
        if stale_note:
            best["note"] = stale_note
        elif saw_error:
            best["note"] = "The Karachi terminal sites did not respond."
        else:
            best["note"] = "No record at KICT or SAPT for this container."
    return best


QICT_API = "https://lfs.qict.com.pk/API/api/ds/v1/BL-Inquiry"


def track_qict_bl(bl_number):
    """QICT (DP World Karachi) ki public BL inquiry — 20 Oct 2026 verified.
    Un ki apni website (lfs.qict.com.pk) ka public API hai; Emkay/RTW
    jaise NVOCC cargo aksar yahin milta hai. API slow hai (~25s) is
    liye 2 koshishein. Response double-encoded JSON hota hai."""
    import json as _json
    payload = urllib.parse.urlencode({
        "blno": bl_number, "UserID": "Test", "Password": "Test123",
        "Cellno": "123456"}).encode()
    # QICT's server is flaky: it often answers with an EMPTY body when
    # busy, which must never be read as "not found". Retry on empty
    # answers as well as on errors — only a real row ends the loop.
    rows = None
    for _try in range(4):
        try:
            req = urllib.request.Request(QICT_API, data=payload, headers={
                **UA, "Referer": "https://lfs.qict.com.pk/",
                "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                raw = resp.read().decode("utf-8", "replace").strip()
            parsed = _json.loads(raw) if raw else ""
            if isinstance(parsed, str):
                parsed = _json.loads(parsed) if parsed else []
            if parsed:
                rows = parsed
                break
        except Exception:
            pass
        time.sleep(2.5)
    if not rows:
        return {"found": False,
                "note": "No record was returned by QICT on this check."}
    r0 = rows[0]
    # Aggregate across ALL container rows (v28 audit fix): a BL with
    # several containers must not inherit the first row's standing
    # when another container is on hold or still in the yard.
    standings = [(r.get("STANDING") or "").strip().upper() for r in rows]
    trucks = [(r.get("TRUCK_IN_YARD") or "").strip().lower() for r in rows]
    positions = {(r.get("POSITION") or "").strip() for r in rows}
    positions.discard("")
    if "HOLD" in standings:
        status = "On hold at QICT"
    elif standings and all(x == "RELEASED" for x in standings) \
            and all(t == "delivered" for t in trucks if t):
        status = "Released — Delivered"
    elif standings and all(x == "RELEASED" for x in standings):
        status = "Released at QICT"
    elif standings[0]:
        status = f"At QICT — {standings[0].title()}"
    else:
        # v99: QICT Port Qasim par hai, Karachi par NAHI —
        # terminal ka sheher bhi usi ek sach se ayega.
        status = "At QICT terminal (Port Qasim)"
    position = (positions.pop() if len(positions) == 1
                else ("Multiple positions" if positions
                      else r0.get("POSITION", "")))
    truck = (trucks[0] if len(set(trucks)) == 1 else "")
    out = {"found": True, "terminal": "QICT", "source": "QICT (DP World)",
           "containers": [r.get("EQ_NBR") for r in rows if r.get("EQ_NBR")],
           "status": status, "position": position,
           "category": r0.get("CATEGORY", ""), "truck": truck,
           "gd_no": r0.get("GD_NO", ""),
           "qict_rows": rows}
    # Ctr-Inq se pehle container ki tafseel (vessel, discharge, holds)
    ctn0 = out["containers"][0] if out["containers"] else ""
    if ctn0:
        det = track_qict_container(ctn0)
        for k in ("vessel", "voyage", "discharge_time", "holds", "line",
                  "pod", "vir"):
            if det.get(k):
                out[k] = det[k]
    return out


QICT_CTR_API = "https://lfs.qict.com.pk/API/api/ds/v1/Ctr-Inq"


def track_qict_container(ctn_number):
    """QICT Ctr-Inq — container ki poori tafseel (vessel/voyage, discharge
    time, VIR, holds, shipping line). 20 Oct 2026 verified, tez (~1s)."""
    import json as _json
    payload = urllib.parse.urlencode({
        "ctrnbr": ctn_number, "UserID": "Test", "Password": "Test",
        "Cellno": "123456"}).encode()
    fields = {}
    for _try in range(2):
        try:
            req = urllib.request.Request(QICT_CTR_API, data=payload,
                headers={**UA, "Referer": "https://lfs.qict.com.pk/",
                         "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                raw = resp.read().decode("utf-8", "replace").strip()
            parsed = _json.loads(raw) if raw else ""
            if isinstance(parsed, str):
                parsed = _json.loads(parsed) if parsed else []
            fields = {i.get("FIELD_NAME", ""): i.get("FIELD_VALUE", "")
                      for i in (parsed or [])}
            if fields:
                break
        except Exception:
            fields = {}
        time.sleep(1.5)
    if not fields:
        return {}
    out = {"vessel": fields.get("Vessel", ""),
           "voyage": fields.get("Voyage", ""),
           "holds": fields.get("Hold Description", "").rstrip(","),
           "line": fields.get("Shipping Line", ""),
           "pod": fields.get("Port Of Discharge", ""),
           "vir": fields.get("VIR #", ""),
           "discharge_time": fields.get("Discharge Time", ""),
           # v99 (truth table 30 Oct 2026): ye fields QICT ke
           # jawab mein hamesha se thay — parser inhein phenk
           # deta tha, is liye har QICT gate-out be-tareekh
           # rehta tha (EMKAYMBAKHI59055 ka gate-out
           # 28-OCT-2026 00:12 'Out Time' mein darj tha).
           # 'Out Time' hi gate-out ka terminal saboot hai;
           # Position/Truck usi record ke asal fields hain.
           # EXPORT cycle par 'In Time' khaali dabbe ki
           # terminal wapsi (gate-in) aur 'Load Time' us ka
           # jahaz par load hona hai (EMKAYMBAKHI57984).
           # 'Empty Return Location' SIRF mukarrar yard ka
           # naam hai — wapsi ka saboot NAHI, is liye wo
           # yahan jaan boojh kar nahi liya gaya.
           "gate_out": fields.get("Out Time", ""),
           "position": fields.get("Position", ""),
           "truck": (fields.get("Truck In Yard", "")
                     or "").strip().lower(),
           "category": fields.get("Category", ""),
           "in_time": fields.get("In Time", ""),
           "load_time": fields.get("Load Time", "")}
    return {k: v for k, v in out.items() if v}


KGTL_URL = "https://www.kgtl.com.pk/en/online-tracking"


def _kgtl_search(term, radio):
    """KGTL (Karachi Gateway Terminal — AD Ports, East Wharf) ki
    public Online Tracking. ASP.NET WebForms hai: pehle radio
    (rdioBL / rdioCon) ka postback, phir search ka POST — teen
    talab, koi login nahi. 25 Oct 2026 ko asal BL/container par
    verified. Jawab ka HTML deta hai; site na mile to None."""
    import http.cookiejar as _cj
    cj = _cj.CookieJar()
    op = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [("User-Agent", UA["User-Agent"])]

    def _fields(h):
        d = {}
        for n in ("__VIEWSTATE", "__VIEWSTATEGENERATOR",
                  "__EVENTVALIDATION"):
            m = re.search(rf'name="{n}"[^>]*value="([^"]*)"', h or "")
            d[n] = m.group(1) if m else ""
        return d

    try:
        h = op.open(KGTL_URL, timeout=30).read().decode("utf-8", "ignore")
        d = _fields(h)
        d.update({"__EVENTTARGET": radio, "__EVENTARGUMENT": "",
                  "radio": radio})
        h = op.open(urllib.request.Request(
            KGTL_URL, data=urllib.parse.urlencode(d).encode(),
            method="POST"), timeout=30).read().decode("utf-8", "ignore")
        d = _fields(h)
        d.update({"__EVENTTARGET": "", "__EVENTARGUMENT": "",
                  "txtSearch": term, "radio": radio,
                  "btnSearch": "Search"})
        return op.open(urllib.request.Request(
            KGTL_URL, data=urllib.parse.urlencode(d).encode(),
            method="POST"), timeout=30).read().decode("utf-8", "ignore")
    except Exception:
        return None


def _kgtl_span(html, sid):
    m = re.search(rf'id="{sid}"[^>]*>([^<]*)<', html or "")
    return m.group(1).strip() if m else ""


def track_kgtl_bl(bl_number):
    """KGTL BL inquiry — BL panel (vessel, VIR, ATA/ATD) +
    container grid (number/size/yard state). Pehle container
    ki tafseel (holds, ETA, voyage) container wale raste se
    bhi li jati hai — QICT BL layer wala hi tareeqa."""
    html = _kgtl_search(bl_number, "rdioBL")
    if html is None:
        return {"found": False, "note": "The KGTL site did not respond."}
    if "Not found" in html or not _kgtl_span(html, "BLlblBLNbr"):
        return {"found": False,
                "note": "No record at KGTL for this BL."}
    rows = []
    gm = re.search(r'id="BLContainerGrid".*?</table>', html, re.S)
    if gm:
        for tr in re.findall(r"<tr>(.*?)</tr>", gm.group(0), re.S):
            tds = [re.sub(r"<[^>]+>", "", c).strip()
                   for c in re.findall(r"<td>(.*?)</td>", tr, re.S)]
            if len(tds) >= 3 and tds[0]:
                rows.append({"CONTAINER NO": tds[0], "SIZE": tds[1],
                             "LOCATION": tds[2]})
    containers = [r["CONTAINER NO"] for r in rows]
    states = [(r["LOCATION"] or "").strip().lower() for r in rows]
    ata = _kgtl_span(html, "BLlblATA")
    if states and all(x == "in yard" for x in states):
        status = "Discharged at KGTL — in yard"
    elif any(x == "in yard" for x in states):
        status = "Partially discharged at KGTL"
    elif ata:
        status = "At KGTL terminal (Karachi)"
    else:
        status = "Expected at KGTL (Karachi)"
    out = {"found": True, "terminal": "KGTL",
           "source": "KGTL (Karachi Gateway Terminal)",
           "containers": containers, "terminal_rows": rows,
           "status": status,
           "vessel": _kgtl_span(html, "BLlblVesselName"),
           "vir": _kgtl_span(html, "BLlblVIRNbr"),
           "ata": ata, "atd": _kgtl_span(html, "BLlblATD"),
           "pod": _kgtl_span(html, "BLlblDestination")}
    if status.startswith("Expected"):
        out["expected"] = True
    if len(set(states)) == 1 and states:
        out["position"] = rows[0]["LOCATION"]
    if containers:
        det = track_kgtl_container(containers[0])
        if det.get("found"):
            for k in ("voyage", "eta", "etd", "pol", "holds",
                      "weight", "commodity", "size_type", "category"):
                if det.get(k) and not out.get(k):
                    out[k] = det[k]
            if det.get("holds") and states and \
                    all(x == "in yard" for x in states):
                out["status"] = "On hold at KGTL — discharged, in yard"
    return {k: v for k, v in out.items() if v or k in
            ("found", "terminal", "source", "containers",
             "terminal_rows", "status")}


def track_kgtl_container(ctn_number):
    """KGTL container inquiry — BL se zyada tafseel deta hai:
    ETA/ETD, ATA/ATD, holds, ground date, voyage, weight.
    25 Oct 2026 verified (WHSU5010543)."""
    html = _kgtl_search(ctn_number, "rdioCon")
    if html is None:
        return {"found": False, "note": "The KGTL site did not respond."}
    if "Not found" in html or not _kgtl_span(html, "lblContainer"):
        return {"found": False,
                "note": "No record at KGTL for this container."}
    st = _kgtl_span(html, "lblStatus")
    ata = _kgtl_span(html, "lblATA")
    holds = _kgtl_span(html, "lblHolds")
    if holds and st.lower() == "in yard":
        # dabba discharge ho kar yard mein hai AUR hold par
        # bhi — dono haqeeqatein status mein; sirf "on hold"
        # likhne se milestone engine ko discharge nazar
        # nahi aata tha (v61 live QA mein pakra gaya).
        status = "On hold at KGTL — discharged, in yard"
    elif holds:
        status = "On hold at KGTL"
    elif st.lower() == "in yard":
        status = "Discharged at KGTL — in yard"
    elif st:
        status = f"At KGTL — {st}"
    elif ata:
        status = "At KGTL terminal (Karachi)"
    else:
        status = "Expected at KGTL (Karachi)"
    out = {"found": True, "terminal": "KGTL",
           "source": "KGTL (Karachi Gateway Terminal)",
           "containers": [ctn_number], "status": status,
           "bl": _kgtl_span(html, "lblBLNbr"),
           "vessel": _kgtl_span(html, "lblVessel"),
           "voyage": _kgtl_span(html, "lblVoyage"),
           "vir": _kgtl_span(html, "lblVIRNo"),
           "eta": _kgtl_span(html, "lblETA"),
           "etd": _kgtl_span(html, "lblETD"),
           "ata": ata, "atd": _kgtl_span(html, "lblATD"),
           "pol": _kgtl_span(html, "lblPOL"),
           "pod": _kgtl_span(html, "lblPOD"),
           "holds": holds,
           "position": _kgtl_span(html, "lblPosition") or st,
           "weight": _kgtl_span(html, "lblWeight"),
           "commodity": _kgtl_span(html, "lblDescription"),
           "size_type": _kgtl_span(html, "lblSize"),
           "category": _kgtl_span(html, "lblCategory"),
           "ground_date": _kgtl_span(html, "lblGroundDate")}
    if status.startswith("Expected"):
        out["expected"] = True
    return {k: v for k, v in out.items() if v or k in
            ("found", "terminal", "source", "containers", "status")}


def _parse_det_date(s):
    """'18-OCT-26', '18 Oct 2026', '21 Nov 2022', '2026-10-18'
    jaisi tareekhein parho — 2-rakmi saal bhi (KICT aksar
    '18-OCT-26' likhta hai, jo purani regex nahi parh pati
    thi). Na mile to None."""
    import datetime as _dt
    s = str(s or "")
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        try:
            return _dt.date(int(m.group(1)), int(m.group(2)),
                            int(m.group(3)))
        except Exception:
            return None
    m = re.search(r"(\d{1,2})[- ]([A-Za-z]{3})[A-Za-z]*[- ]"
                  r"(\d{4}|\d{2})\b", s)
    if not m:
        return None
    y = int(m.group(3))
    if y < 100:
        y = 2000 + y if y <= 69 else 1900 + y
    try:
        return _dt.datetime.strptime(
            f"{m.group(1)} {m.group(2)} {y}", "%d %b %Y").date()
    except Exception:
        return None


def _prev_cycle(res, out):
    """Container-mode record is shipment ke safar ka hai ya
    container ke PICHLE safar ka? Line/vessel leg se mili is
    shipment ki ETA se 45+ din peeche wali discharge/gate-out
    is BL ki ho hi nahi sakti (COAU6468022200 par pakra gaya:
    container ka June wala purana cycle Oct ke in-transit BL
    ko 'Gate out' bana raha tha)."""
    eta = _parse_det_date((out.get("result") or {}).get("eta"))
    if not eta:
        return False
    evs = []
    for k in ("discharge_time", "gate_out"):
        d = _parse_det_date(res.get(k))
        if d:
            evs.append(d)
    if not evs:
        return False
    return (eta - max(evs)).days > 45


def _stale_info(det):
    """Record ki tareekh 150 din se purani ho to (True, 'Nov 2022').
    Container number dobara istemal hote hain — QICT kabhi pichle
    safar ka record de deta hai (CXDU1175597 par Nov 2022 ka
    MSC JOANNA record mila, jabke asal safar 2026 ka tha).
    v54: tareekh discharge_time ke ilawa ETA se bhi li jati
    hai, 2-rakmi saal bhi chalte hain, aur VIR ke aakhri 8
    digits sirf tab gine jate hain jab saal maqool ho — KICT
    ka VIR ('PKKHIKICT_121026100008') serial par khatam hota
    hai jo ghalti se saal 0008 parh leta tha aur sahi record
    ko purana qarar de deta."""
    import datetime as _dt
    dates = []
    for key in ("discharge_time", "eta"):
        d = _parse_det_date(det.get(key))
        if d:
            dates.append(d)
    vir = str(det.get("vir") or "")
    m2 = re.search(r"(\d{2})(\d{2})(\d{4})\s*$", vir)
    if m2:
        try:
            d = _dt.date(int(m2.group(3)), int(m2.group(2)),
                         int(m2.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    # v55: QICT ka VIR apni tareekh khud rakhta hai —
    # 'PKBQMQICT_100226152301' = DDMMYY + HHMMSS (10 Feb 2026).
    # Discharge/ETA khaali hon to bhi ye tareekh guard ko milti
    # hai; Feb 2026 ke pichle-safar wale det 'At QICT terminal'
    # ban kar nikal aate thay (BMOU2755409 / MOAU0774432).
    m3 = re.search(r"QICT_(\d{2})(\d{2})(\d{2})\d{6}\s*$", vir)
    if m3:
        try:
            _yy = int(m3.group(3))
            _yy = 2000 + _yy if _yy <= 69 else 1900 + _yy
            d = _dt.date(_yy, int(m3.group(2)), int(m3.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    # v61: KGTL ka VIR bhi apni tareekh rakhta hai —
    # 'PKKHIKGTL_101026105335' = DDMMYY + HHMMSS (10 Oct 2026).
    # Guard jis source par lage, har source par lage — KGTL
    # ke baghair is ke purane record bhi naye ban sakte thay.
    m4 = re.search(r"KGTL_(\d{2})(\d{2})(\d{2})\d{6}\s*$", vir)
    if m4:
        try:
            _yy = int(m4.group(3))
            _yy = 2000 + _yy if _yy <= 69 else 1900 + _yy
            d = _dt.date(_yy, int(m4.group(2)), int(m4.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    if not dates:
        return (False, "")
    newest = max(dates)
    age = (_dt.date.today() - newest).days
    return (age > 150, newest.strftime("%b %Y"))


def track_qict_container_layer(ctn_number):
    """QICT as a primary layer for a bare container number: Ctr-Inq
    answers in ~1s with vessel, discharge, holds and VIR."""
    det = track_qict_container(ctn_number)
    if not det:
        return {"found": False,
                "note": "No record was returned by QICT on this check."}
    _stale, _when = _stale_info(det)
    if _stale:
        return {"found": False,
                "note": (f"QICT holds only an OLD record for this "
                         f"container ({_when}) — from a previous trip. "
                         "Container numbers are reused, so this is not "
                         "counted as a current record.")}
    if (det.get("category") or "").strip().upper() == "EXPORT" \
            and det.get("in_time"):
        # v99fix3 (30 Oct 2026, Phase-2 retest FAIL): EK
        # usool, dono routes par — export gate-in kabhi
        # empty return NAHI hai. QICT row khud ye sabit
        # karti hai: Category EXPORT, Status FULL/LCL
        # (bhari export cargo, khaali dabba nahi),
        # Position Vessel + baad ki Load Time (dabba
        # jahaz par load ho kar gaya — depot mein wapis
        # aaya khaali dabba jahaz par FULL cargo ban kar
        # nahi jata). Ye SAPT XF row (1016) ki wahi
        # shakl hai, jis par Fix Round 2 + Audit ne
        # 'wapsi NAHI' ka faisla diya tha. 57984 ki row
        # bhi isi shakl ki hai — is liye us ka returned
        # bhi isi usool se dobara nikalta hai (neeche
        # _settle_empty_return dekho). Wapsi sirf EM row
        # se sabit hoti hai; QICT koi structured
        # empty-return deta hi nahi. BL-Inquiry is surat
        # mein khaali ho jati hai — is ka matlab 'nahi
        # mila' NAHI, 'cycle mukammal' hai. Is liye
        # writer returned NAHI likhta — sirf band-cycle
        # saboot (export In/Load Time) aage deta hai
        # taake _settle purani ghalat returned ko pehchan
        # kar retract kar sake. Export cycle ka VIR/jahaz/
        # voyage is BL ka NAHI hai, is liye wo yahan se
        # aage NAHI jayega.
        return {"found": True, "terminal": "QICT",
                "source": "QICT (DP World)",
                "containers": [ctn_number], "status": "Gate out",
                "cycle_closed": True,
                "qict_export_in": det["in_time"],
                "qict_export_load": det.get("load_time") or ""}
    if det.get("gate_out"):
        # v99: 'Out Time' parser ab parhta hai — ye leg ab
        # gate-out ki tareekh wali pakki khabar de sakti hai.
        status = "Gate out"
    elif det.get("holds"):
        status = "On hold at QICT"
    elif det.get("discharge_time"):
        status = "Discharged at QICT"
    elif det.get("vir"):
        status = "At QICT terminal (Port Qasim)"
    else:
        # v54: sirf vessel/line wali entry QICT ki EXPECTED
        # (inbound) list hoti hai — dabba abhi terminal par
        # NAHI pahuncha. Pehle ye bhi "At QICT terminal" ban
        # jata tha, jo card par seedhi ghalat maloomat thi
        # (HGMU1110890: jahaz CSTAR VOYAGER abhi raaste mein
        # tha aur card "At QICT terminal" keh raha tha).
        if det.get("vessel"):
            status = (f"Expected at QICT — on {det['vessel']}"
                      + (f" ({det['voyage']})"
                         if det.get("voyage") else "")
                      + ", still at sea")
        else:
            status = ("In QICT's system — entry only, nothing "
                      "further recorded yet")
    out = {"found": True, "terminal": "QICT", "source": "QICT (DP World)",
           "containers": [ctn_number], "status": status}
    if status.startswith(("Expected", "In QICT's system")):
        out["expected"] = True
    out.update(det)
    # v99 (investigation fix 1, truth table ke baad
    # tashih shuda): Ctr-Inq ka 'Out Time' ab parser
    # parhta hai — leg ke paas gate_out ya position ho to
    # wo gate-out ke baad ki halat bhi sabit kar sakti
    # hai. Nishan sirf tab jab leg ke paas in mein se
    # kuch bhi NAHI: aisi leg discharge sabit kar sakti
    # hai, gate-out ke baad ki halat kabhi nahi — is ke
    # discharge ko _ctn_evidence_add yard ka saboot nahi
    # banaye ga (wo record gate-out ke baad bhi hamesha
    # waisa hi rehta hai).
    if not det.get("gate_out") and not det.get("position"):
        out["discharge_only"] = True
    return out


CARRIER_APIS = {
    "COSCO Shipping": track_cosco_api,
    "COSCO Shipping (unverified)": track_cosco_api,
    "Emkay Line": track_emkay_api,
    "Evergreen": track_shipmentlink_bl,
}

CARRIER_CONTAINER_APIS = {
    "COSCO Shipping": track_cosco_container_api,
    "Evergreen": track_shipmentlink_container,
}


def track_bol_tracktrace(bl_number, carrier=None):
    """track-trace.com par BL tracking.
    Carrier maloom ho to us ki company ID se direct tracking (tez aur sahi).
    Returns dict.
    """
    # MSC automated tracking supported nahi — foran manual link do
    if carrier in NO_AUTO_TRACK:
        return {"found": False, "deferred": True,
                "direct_url": "https://www.msc.com/en/track-a-shipment",
                "note": (f"{carrier} does not allow automated tracking "
                         "(bot protection). Please enter the number on their "
                         "own tracking page using the link below.")}
    try:
        # Step 1: BL submit karo (config hidden field lazmi hai)
        final_url, body = post_form(
            "https://www.track-trace.com/bol",
            {"number": bl_number, "config": "207400", "commit": "Track!"},
        )
        # Step 2: agar carrier maloom hai to us se direct tracking
        if carrier and carrier in TT_BOL_COMPANY_IDS:
            _, body2 = post_form(
                "https://www.track-trace.com/bol/select",
                {"number": bl_number, "shipper": TT_BOL_COMPANY_IDS[carrier]},
            )
            # direct carrier form ka URL nikalo (e.g. COSCO cargoTracking)
            m = re.search(
                r'<form\s+action="([^"]+)"[^>]*>.*?name="trackingType".*?name="number"',
                body2, re.S | re.I)
            direct_url = None
            if m:
                direct_url = html.unescape(m.group(1))
                # hidden fields joro
                fields = re.findall(
                    r'<input\s+name="([^"]+)"\s+value="([^"]*)"', body2)
                if fields:
                    qs = urllib.parse.urlencode(
                        {k: v for k, v in fields})
                    direct_url = direct_url + "?" + qs
            res = parse_tracktrace(body2, final_url)
            if direct_url:
                res["direct_url"] = direct_url
            return res
    except Exception as e:
        return {"error": f"Could not reach track-trace.com: {e}"}
    return parse_tracktrace(body, final_url)


def track_container_tracktrace(ctn_number):
    """track-trace.com par container tracking."""
    try:
        final_url, body = post_form("https://www.track-trace.com/container",
                                   {"number": ctn_number})
    except Exception as e:
        return {"error": f"Could not reach track-trace.com: {e}"}
    return parse_tracktrace(body, final_url)


# ============================================================
# LAYER 4: Vessel live tracking (VesselFinder — curl se kaam karta hai)
# Jab vessel ka naam mil jaye (kisi bhi layer se), uski live
# position, destination aur ETA nikalo.
# ============================================================
def vessel_search(name):
    """VesselFinder par vessel dhoondo. Returns detail page URL ya None."""
    q = urllib.parse.quote(name)
    url = f"https://www.vesselfinder.com/vessels?name={q}"
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception:
        return None
    m = re.search(r'href="(/vessels/details/\d+)"', body)
    return ("https://www.vesselfinder.com" + m.group(1)) if m else None


def vessel_live_position(name):
    """Vessel ka live status: position, destination, ETA, speed."""
    detail_url = vessel_search(name)
    if not detail_url:
        # v51 (24 Oct): kuch feeder jahazon ke asal registered naam
        # ke aakhir mein number nahi hota — BL par "RONG HANG 268"
        # likha hota hai, VesselFinder par sirf "RONG HANG" milta
        # hai. Number hata kar ek aur koshish karo.
        base = re.sub(r"\s+\d+\s*$", "", (name or "").strip())
        if base and base != name:
            detail_url = vessel_search(base)
            if detail_url:
                name = base
    if not detail_url:
        return {"found": False, "note": f"'{name}' was not found on VesselFinder."}
    try:
        req = urllib.request.Request(detail_url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach VesselFinder: {e}"}
    text = clean_text(body)
    info = {"found": True, "source": "VesselFinder", "vessel": name,
            "url": detail_url}
    m = re.search(r"Destination\s+([^,]+?),\s*([A-Za-z ]+?)\s*ETA:\s*([^(]+)",
                  text)
    if m:
        info["destination"] = f"{m.group(1).strip()}, {m.group(2).strip()}"
        info["eta"] = m.group(3).strip()
    m = re.search(r"speed of ([\d.]+) knots", text)
    if m:
        info["speed"] = f"{m.group(1)} knots"
    m = re.search(r"Navigation Status\s+([A-Za-z ]+?)(?:\s{2,}|$)", text)
    if m:
        info["nav_status"] = m.group(1).strip()
    m = re.search(r"Position Received\s+([^(]+?)(?:\s{2,}|$)", text)
    if m:
        info["position_time"] = m.group(1).strip()[:60]
    if len(info) <= 3:
        info["found"] = False
        info["note"] = "Vessel found, but no live data could be extracted."
    return info


# ---- Vessel Schedule layer (v113 WIP, 4 Nov 2026) ----
# Emkay aur RTW jaisi lines ki apni website tracking nahi deti,
# lekin un ka cargo Maersk-service ke jahazon par chalta hai aur
# un jahazon ke port calls ShipsGo Service Finder par public
# hain. Ye layer jahaz ke guzre hue + aane wale port calls se
# shipment ki asal harkat nikaalti hai: origin (Mombasa) se
# rawangi ki tareekh aur Karachi / Port Qasim pahunchnay ki
# mutawaqqa tareekh. Ye sirf ANDAZA/schedule hai — terminal ka
# saboot (VIR / discharge) hamesha is par jeet-ta hai, is liye
# ye layer sirf tab chalti hai jab kisi terminal ne record na
# paya ho, aur discharge/gate-out/holds ko kabhi nahi chhuti.

_SG_MONTHS = {m: i + 1 for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])}


def _sg_date(s):
    """'28 to 29 Oct 2026' / '19 Oct 2026' -> (start, end) dates."""
    m = re.search(r"(?:(\d{1,2})\s+to\s+)?(\d{1,2})\s+"
                  r"([A-Z][a-z]{2})[a-z]*\s+(\d{4})", s or "")
    if not m:
        return None, None
    try:
        import datetime as _dt
        mon = _SG_MONTHS[m.group(3)]
        end = _dt.date(int(m.group(4)), mon, int(m.group(2)))
        start = (_dt.date(int(m.group(4)), mon, int(m.group(1)))
                 if m.group(1) else end)
        return start, end
    except Exception:
        return None, None


def _sg_fmt(d):
    return d.strftime("%d %b %Y") if d else None


def _sg_table_after(html, heading):
    """Heading ke baad pehli <table> ki rows -> cell-text lists."""
    i = html.find(heading)
    if i < 0:
        return []
    j = html.find("<table", i)
    if j < 0:
        return []
    k = html.find("</table>", j)
    seg = html[j:k if k > j else j + 20000]
    rows = []
    for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", seg, re.S):
        cells = []
        for td in re.findall(r"<td[^>]*>(.*?)</td>", tr, re.S):
            t = clean_text(td)
            t = re.sub(r"\s+", " ", t).strip()
            cells.append(t)
        if cells and any(cells):
            rows.append(cells)
    return rows


def track_vessel_schedule(vessel_name):
    """ShipsGo Service Finder se jahaz ke port calls.

    Returns {found, vessel, calls: [{port, code, kind, d1, d2,
    voyage}], source, url} — kind: 'recent' | 'upcoming'.
    """
    name = (vessel_name or "").strip()
    if not name:
        return {"found": False, "note": "No vessel name."}
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    url = f"https://service-finder.shipsgo.com/vessels/{slug}"
    body = None
    last_err = None
    import http.client as _hc
    for _try in range(3):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=25) as resp:
                url = resp.geturl() or url
                try:
                    raw = resp.read()
                except _hc.IncompleteRead as _ir:
                    raw = _ir.partial or b""
                    # adhoora page bhi chalega agar dono port-call
                    # tables us mein aa gayi hon — warna retry.
                    _txt = raw.decode("utf-8", "replace")
                    if "Recent Port Calls" not in _txt \
                            or "Upcoming Port Calls" not in _txt:
                        raise
                    body = _txt
                    break
                body = raw.decode("utf-8", "replace")
            break
        except Exception as e:
            last_err = e
    if body is None:
        return {"found": False,
                "error": f"Could not reach ShipsGo: {last_err}"}
    return _parse_vessel_schedule(body, name, url)


def _parse_vessel_schedule(body, name, url):
    calls = []
    for heading, kind in (("Recent Port Calls", "recent"),
                          ("Upcoming Port Calls", "upcoming")):
        for cells in _sg_table_after(body, heading):
            if len(cells) < 2:
                continue
            # Table ki asal shakal: [Port+code, date, voyage] —
            # port cell mein naam aur UN/LOCODE (5 harf) sath
            # aate hain ("Mundra INMUN").
            date_cell = next((c for c in cells
                              if re.search(r"\d{4}", c)), "")
            d1, d2 = _sg_date(date_cell)
            if not d1:
                continue
            _pcell = cells[0]
            _m = re.match(r"^(.*?)\s+([A-Z]{5})$", _pcell)
            if _m:
                port, code = _m.group(1), _m.group(2)
            else:
                port, code = _pcell, ""
            voy = ""
            for c in cells:
                if c not in (_pcell, date_cell) and \
                        re.fullmatch(r"[0-9A-Za-z]{3,7}", c):
                    voy = c
                    break
            calls.append({"port": port, "code": code, "kind": kind,
                          "d1": d1, "d2": d2, "voyage": voy})
    if not calls:
        return {"found": False,
                "note": f"No port calls listed for '{name}' on ShipsGo."}
    return {"found": True, "source": "ShipsGo (vessel schedule)",
            "vessel": name.upper(), "url": url, "calls": calls}


def parse_tracktrace(body, final_url):
    text = clean_text(body)
    low = text.lower()
    result = {"source": "track-trace.com", "url": final_url}

    # carrier site frame block karti hai — direct link se kaam chalega
    if "can not be displayed in a frame" in low:
        result["found"] = False
        result["deferred"] = True
        m = re.search(r"show\s+(.+?)\s+results without frame", text, re.I)
        carrier_name = m.group(1).strip() if m else "carrier"
        result["note"] = (f"{carrier_name}'s site cannot be shown in a frame — "
                          "please use the direct link below.")
        return result

    # v51 (24 Oct): kuch carriers (Maersk) track-trace par sirf
    # frame mein aate hain — un ke page par upar wala jumla NAHI
    # hota, lekin frame-src mein carrier ka seedha deep link hota
    # hai (maersk.com/tracking/<BL>). Pehle ye pehchana hi nahi
    # jata tha aur app jhoota "no readable record" kehta tha.
    mf = re.search(r'frame-src="(https?://[^"]+)"', body or "", re.I)
    if mf:
        result["found"] = False
        result["deferred"] = True
        result["direct_url"] = html.unescape(mf.group(1))
        mg = re.search(r"Getting results from\s+(.+?)(?:\s+Hide|\s*$)",
                       text, re.I)
        cname = mg.group(1).strip() if mg else "The carrier"
        result["note"] = (f"{cname}'s site cannot be shown in a frame — "
                          "please use the direct link below.")
        return result

    # na-mila wale cases
    if "no known tracking" in low or "not found" in low or "no result" in low:
        result["found"] = False
        # carrier hint nikalne ki koshish
        m = re.search(r"No known tracking services for prefix\s*([A-Z]+)", text, re.I)
        if m:
            result["note"] = f"Prefix {m.group(1)} did not match any known carrier."
        else:
            # aam ghalti ka paigham
            m2 = re.search(r"(.{0,120}(not found|no result).{0,120})", text, re.I)
            result["note"] = m2.group(1).strip() if m2 else "No record found."
        return result

    # company selection page = koi asal data nahi (manual select chahiye)
    if ("please select the company" in low
            or "selecting company manually" in low
            or "is unknown to us" in low):
        result["found"] = False
        result["note"] = ("The carrier could not be auto-detected — the "
                          "company must be selected manually in a browser.")
        return result

    # fields nikalne ki koshish (labels mukhtalif ho sakte hain).
    # SABOOT lazmi hai: sirf page mil jana "found" nahi — track-trace
    # ka khaali search page bhi pehle found ban jata tha aur us ke
    # madad-wale alfaaz pol/pod ban jate thay (jhooti tasalli).
    for label, keys in [
        ("vessel", ["vessel", "ship"]),
        ("voyage", ["voyage"]),
        ("pol", ["port of loading", "origin", "from"]),
        ("pod", ["port of discharge", "destination", "to"]),
        ("eta", ["eta", "estimated arrival", "arrival"]),
        ("etd", ["etd", "estimated departure", "departure"]),
        ("status", ["status"]),
    ]:
        for k in keys:
            m = re.search(re.escape(k) + r"\s*[:\-]?\s*([A-Z0-9][^|<>]{1,60})", text, re.I)
            if m:
                val = m.group(1).strip()
                # vessel: sirf tab jab asal jahaz ka naam lage (page ka kachra nahi)
                if label == "vessel" and not looks_like_vessel(val):
                    continue
                result[label] = val
                break
    # kachra values saaf karo: form/madad ke alfaaz data nahi hain
    BOILER = ("track", "insert", "option", "direct?", "remove",
              "select", "format", "automatically", "here,",
              "should have", "number from url")
    for k in ("pol", "pod", "eta", "etd", "status", "voyage"):
        v = str(result.get(k) or "")
        if v and any(b in v.lower() for b in BOILER):
            result.pop(k, None)
    # asal saboot: jahaz ka naam, ya tareekh jaisi ETA/ETD, ya
    # containers, ya pehchani hui status — in ke baghair NOT found
    import datetime as _dt
    def _is_date(v):
        try:
            _dt.datetime.strptime(str(v).strip()[:11].title(),
                                  "%d %b %Y")
            return True
        except Exception:
            return bool(re.search(
                r"\b(19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b",
                str(v or "")))
    evidence = bool(result.get("vessel")
                    or result.get("containers")
                    or _is_date(result.get("eta"))
                    or _is_date(result.get("etd"))
                    or re.search(r"loaded|discharged|departed|arrived|"
                                 r"received|gate|delivered|vessel",
                                 str(result.get("status") or ""),
                                 re.I))
    if not evidence:
        result["found"] = False
        result["note"] = ("track-trace did not return a readable "
                          "record for this number.")
        for k in ("vessel", "voyage", "pol", "pod", "eta", "etd",
                  "status"):
            result.pop(k, None)
        return result
    result["raw_snippet"] = text[:600]
    return result


def looks_like_vessel(name):
    """Kya ye asal vessel ka naam lagta hai? Page navigation ka kachra nahi."""
    if not name or len(name) < 3 or len(name) > 40:
        return False
    low = name.lower()
    # page/UI ke aam alfaz hon to vessel nahi
    junk = ["tracking", "track", "click", "here", "close", "recent", "search",
            "select", "menu", "page", "home", "back", "show", "hide", "more",
            "detect", "company", "based", "result", "option", "http", "www"]
    if any(j in low for j in junk):
        return False
    # kam az kam ek bara harf se shuru hone wala lafz ho
    if not re.search(r"[A-Z]{2,}", name):
        return False
    return True


# Pattern wale BL formats jo 4-huroof prefix table mein nahi aa
# sakte (24 Oct 2026, v51). Sab Yousuf ki BL photos aur 22 Oct ki
# research se verified hain. In ke baghair Wan Hai ka BL
# 142G513366 "not found" aaya tha jab ke Wan Hai ki site par us
# ka record maujood tha — pehchan hi nahi hui thi.
_BL_PATTERNS = [
    (r"\d{3}G[A-Z0-9]\d{5,6}", "Wan Hai"),       # 142G513366, 025G... aur 051GA16585 (2 Nov 2026: G ke baad harf wala Indonesia format, us ki BL copy se)
    (r"\d{9}", "Maersk"),                          # bare 9-rakam BL
    (r"S\d{9}", "Yang Ming"),                      # S43.../S49... (YMJA)
    (r"MCL[A-Z]{3}\d{8,10}", "Monter Container Line"),  # MCLSUB26104308
    (r"HAICB\d{8,9}", "RCL"),                      # HAICB26009612
    (r"SGS\d{4}SIN[A-Z0-9]*", "SeaGem Shipping"),   # SGS5314SINKHI
]


def identify_carrier(bl_number):
    prefix = bl_number[:4].upper()
    carrier = CARRIERS.get(prefix)
    if not carrier:
        u = (bl_number or "").upper()
        for pat, name in _BL_PATTERNS:
            if re.fullmatch(pat, u):
                carrier = name
                break
    return prefix, carrier


def norm(s):
    """Number saaf karo: space/dash hatao, uppercase.
    Seekha hua pakka format (Yousuf, 5 Nov 2026): Emkay ka
    BL hamesha EMKAYMBAKHI + 5 digits hota hai. 'I' ko '1'
    parh liya jaye to EMKAYMBAKH + 6 digits ban jate hain —
    wo shakal asal ho hi nahi sakti, is liye dekhte hi
    asal shakal par lao. Ye wohi darwaza hai jis se har
    number tracking mein ghusta hai."""
    out = re.sub(r"[\s\-]", "", (s or "")).upper()
    _m = re.fullmatch(r"EMKAYMBAKH1(\d{5})", out)
    if _m:
        out = "EMKAYMBAKHI" + _m.group(1)
    return out


_LINE_CANON = {
    "EVERGREEN": "Evergreen", "MAERSK": "Maersk", "MSC": "MSC",
    "MEDITERRANEAN SHIPPING": "MSC", "COSCO": "COSCO Shipping",
    "CMA CGM": "CMA CGM", "HAPAG": "Hapag-Lloyd", "ONE": "ONE",
    "OCEAN NETWORK": "ONE", "OOCL": "OOCL",
    "ORIENT OVERSEAS": "OOCL", "YANG MING": "Yang Ming",
    "ZIM": "ZIM", "WAN HAI": "Wan Hai", "EMKAY": "Emkay Line",
    "EM KAY": "Emkay Line", "PIL": "Pacific International Lines",
    "PACIFIC INTERNATIONAL": "Pacific International Lines",
    "HMM": "HMM", "HYUNDAI": "HMM", "KMTC": "KMTC",
    "SINOKOR": "Sinokor", "HEUNG-A": "Heung-A",
    "SITC": "SITC", "RCL": "RCL",
    "REGIONAL CONTAINER": "RCL", "INTERASIA": "Interasia Lines",
    "GOLD STAR": "Gold Star Line", "SAMUDERA": "Samudera",
    "ARKAS": "Arkas Line", "TURKON": "Turkon Line",
}


def _canon_line(line):
    """Terminal/QICT ki 'Shipping Line' ko mashhoor naam mein
    badlo — 'EVERGREEN MARINE' -> 'Evergreen'."""
    u = (line or "").upper()
    for k, v in _LINE_CANON.items():
        if k in u:
            return v
    return (line or "").strip().title() or None


# ---- Traqo Ocean: API layer (v56) ----
# Sirf TAB chalti hai jab (a) Settings mein Traqo API key ho aur
# (b) tamam muft layers naakaam ho chuki hon — kyunke free plan
# mein har NAYA reference 4 monthly tracks mein se 1 slot khata
# hai (usi reference ki dobara query muft hai). API contract
# Developer page se verified (24 Oct 2026): base
# https://traqocontainer.com/api/v1, header
# "Authorization: Bearer <key>", ?sealine=XX param.
TRAQO_BASE = "https://traqocontainer.com/api/v1"
_TRAQO_SEALINE = {
    "maersk": "MAEU", "msc": "MSCU", "cma": "CMDU",
    "hapag": "HLCU", "cosco": "COSU", "evergreen": "EGLV",
    "yang ming": "YMLU", "one": "ONEY", "ocean network": "ONEY",
    "zim": "ZIMU", "pil": "PILU", "hmm": "HMMU",
    "oocl": "OOLU", "kmtc": "KMTC", "wan hai": "WHLC",
}


def _traqo_sealine(carrier_name):
    u = (carrier_name or "").lower()
    for k, v in _TRAQO_SEALINE.items():
        if k in u:
            return v
    return None


def _traqo_date(s):
    """'2026-11-10 00:00:00' / '2026-11-10' -> '10 Nov 2026'."""
    import datetime as _dt
    s = str(s or "").strip()
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if not m:
        return s
    try:
        return _dt.date(int(m.group(1)), int(m.group(2)),
                        int(m.group(3))).strftime("%d %b %Y")
    except Exception:
        return s


def track_traqo(ref, is_container, carrier_name, api_key):
    """Traqo Ocean API se ek BL/container ka record. Hamesha
    {found, ...} deta hai; HTTP/plan ki rukawatein note mein
    imandari se likhi jati hain. Kabhi raise nahi karta."""
    import json as _json
    key = str(api_key or "").strip()
    if not key or not ref:
        return {"found": False, "note": "No Traqo API key saved."}
    kind = "container" if is_container else "bl"
    url = f"{TRAQO_BASE}/{kind}/{urllib.parse.quote(str(ref).strip())}"
    sl = _traqo_sealine(carrier_name)
    if sl:
        url += f"?sealine={sl}"
    req = urllib.request.Request(url, headers={
        **UA, "Authorization": f"Bearer {key}",
        "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            payload = _json.loads(r.read().decode("utf-8",
                                                  errors="replace"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {"found": False, "note":
                    "Traqo: API key was not accepted — check the "
                    "key in Settings."}
        if e.code == 402:
            return {"found": False, "note":
                    "Traqo: this month's 4 free tracks are used "
                    "up (they reset monthly)."}
        if e.code == 404:
            return {"found": False, "note":
                    "Traqo has no record for this number."}
        if e.code == 429:
            return {"found": False, "note":
                    "Traqo rate limit reached — try again later."}
        return {"found": False, "note": f"Traqo returned HTTP {e.code}."}
    except Exception as e:
        return {"found": False, "note": f"Traqo could not be reached ({e})."}
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not data:
        return {"found": False, "note":
                "Traqo returned no shipment data for this number."}
    res = {"found": True, "source": "Traqo (API)"}
    raw_status = str(data.get("status") or "").strip()
    eta = _traqo_date(data.get("eta"))
    status = raw_status.replace("_", " ").title() if raw_status else ""
    # Events: asal API shape events_table hai (24 Oct 2026 ko
    # live response se verified) — har event mein date, location,
    # event_code, vessel, voyage, is_actual hota hai. Latest
    # event = sab se taaza ASAL (is_actual) event; mustaqbil ke
    # events schedule hain, khabar nahi.
    _EV_LABEL = {"DEPA": "Vessel departed", "ARRI": "Vessel arrived",
                 "LOAD": "Loaded on vessel", "DISC": "Discharged",
                 "GTIN": "Gate in", "GTOU": "Gate out",
                 "CEP": "Container received at terminal",
                 "VAT": "Vessel arrived", "VDT": "Vessel departed",
                 "VAD": "Vessel arrived at destination",
                 "DLVR": "Delivered", "EMRT": "Empty returned"}
    events = (data.get("events_table") or data.get("events")
              or data.get("milestones") or [])
    evs = [e for e in events if isinstance(e, dict)] \
        if isinstance(events, list) else []
    def _ev_key(e):
        return str(e.get("date") or e.get("event_date")
                   or e.get("timestamp") or "")
    evs.sort(key=_ev_key)
    actual = [e for e in evs
              if e.get("is_actual") in (1, True, "1", "true")]
    last_ev = actual[-1] if actual else (evs[-1] if evs else None)
    voyage = None
    if last_ev:
        code = str(last_ev.get("event_code") or "").upper()
        label = _EV_LABEL.get(code) or code or "Event"
        loc = str(last_ev.get("location") or "")
        when = _traqo_date(last_ev.get("date")
                            or last_ev.get("timestamp"))
        txt = f"{label} — {loc}" if loc else label
        if not actual:
            txt += " (expected)"
        res["latest_event"] = f"{txt} ({when})" if when else txt
        if last_ev.get("voyage"):
            voyage = str(last_ev["voyage"])
    if status and eta:
        res["status"] = f"{status} — ETA {eta}"
    elif status:
        res["status"] = status
    if eta:
        res["eta"] = eta
    if data.get("origin"):
        res["pol"] = str(data["origin"])
    if data.get("destination"):
        res["pod"] = str(data["destination"])
    if data.get("sealine_name"):
        res["line"] = str(data["sealine_name"])
    # Containers: asal shape containers_table[].container_number
    ctns = []
    for c in (data.get("containers_table") or data.get("containers")
              or []):
        if isinstance(c, str):
            ctns.append(c)
        elif isinstance(c, dict):
            n = (c.get("container_number") or c.get("number")
                 or c.get("containerNumber") or c.get("id"))
            if n:
                ctns.append(str(n))
    if not ctns and is_container:
        ctns = [str(ref)]
    if ctns:
        res["containers"] = ctns
    # Vessel: vessels_table mein is_current wali row asal jahaz
    # hai; voyage current vessel ke kisi event se lo.
    vessel = data.get("vessel") or data.get("vessel_name")
    if not vessel:
        vs = data.get("vessels_table") or data.get("vessels") or []
        rows = [v for v in vs if isinstance(v, dict)] \
            if isinstance(vs, list) else []
        cur = [v for v in rows
               if v.get("is_current") in (1, True, "1", "true")]
        pick = cur[-1] if cur else (rows[-1] if rows else None)
        if pick:
            vessel = (pick.get("vessel") or pick.get("name")
                      or pick.get("vessel_name"))
    if vessel:
        res["vessel"] = str(vessel)
        if not voyage:
            for e in evs:
                if e.get("vessel") == vessel and e.get("voyage"):
                    voyage = str(e["voyage"])
                    break
    if data.get("voyage"):
        voyage = str(data["voyage"])
    if voyage:
        res["voyage"] = voyage
    return res


def status_text_stage(status):
    """Status TEXT ka lifecycle stage (sirf text — fields ka saboot
    is mein shamil nahi):
    0 unknown/expected · 1 raste mein · 2 terminal par ·
    3 discharged (hold bhi yahin — dabba terminal par hi hota hai) ·
    4 gate out / released · 5 delivered / empty returned."""
    st = (status or "").lower()
    if "delivered" in st or "returned empty" in st \
            or "empty returned" in st:
        return 5
    if "gate out" in st or "gate-out" in st or "released" in st:
        return 4
    if "discharg" in st or "hold" in st:
        return 3
    if "arrived" in st or "berthed" in st or "at qict" in st \
            or "at kgtl" in st or "karachi terminal" in st:
        return 2
    if "in transit" in st or "at sea" in st or "departed" in st \
            or "loaded on vessel" in st:
        return 1
    return 0


def status_stage(result):
    """Result ka asal lifecycle stage: status text + sakht saboot
    fields (gate_out ki tareekh, position OUT, truck delivered,
    discharge_time). 'Expected…'/'entry only' wale text ko stage 1
    se upar nahi jane dete — lekin asal fields hamesha jeette hain.
    Merge (server._merge_result) aur status reconciliation dono
    isi ek map ko istemal karte hain."""
    r = result or {}
    st = (r.get("status") or "").lower()
    stage = status_text_stage(st)
    if st.startswith("expected") or "entry only" in st \
            or "no active shipment" in st:
        stage = min(stage, 1)
    if r.get("discharge_time"):
        stage = max(stage, 3)
    if r.get("gate_out"):
        stage = max(stage, 4)
    pos = (r.get("position") or "").strip().upper()
    if pos in ("OUT", "GATE OUT", "GATE-OUT"):
        stage = max(stage, 4)
    if (r.get("truck") or "").strip().lower() == "delivered":
        stage = max(stage, 5)
    if r.get("returned"):
        stage = max(stage, 5)
    return stage


def vir_terminal(vir):
    """VIR number se terminal ka pakka naam — user ka pakka usool
    hai ke terminal ka naam hamesha VIR se hoga (PKBQMQICT_… =
    QICT, PKKHIKICT_… = KICT, PKKHISAPT_… = SAPT, PKKHIKGTL_… =
    KGTL). VIR mein koi code na mile to None."""
    v = str(vir or "").upper()
    for code in ("QICT", "KICT", "SAPT", "KGTL"):
        if code in v:
            return code
    return None


_DEPARTED_RE = re.compile(
    r"departed[^.]*?(\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4})", re.I)


def departed_date(text):
    """Status text ke andar chhupi carrier-confirmed departed
    tareekh ('departed Shekou 09 Oct 2026') — mile to wohi
    tareekh, warna None."""
    md = _DEPARTED_RE.search(str(text or ""))
    return md.group(1) if md else None


def _fix_terminal_identity(res):
    """v96 data-audit round 2, FIX A: terminal ki pehchan VIR se
    hai. Fresh synthesis ki koi layer apne andaze par terminal
    nahi badal sakti jab result ka apna VIR kuch aur kehta ho
    (Pattern B: QICT VIR PKBQMQICT_030826132505 ke sath Karachi
    container layer ne SAPT likh diya tha). Terminal khaali ho
    to VIR se bhar do — naam hamesha VIR se hi ayega."""
    vt = vir_terminal(res.get("vir"))
    if not vt:
        return
    term = (res.get("terminal") or "").strip()
    if term in ("KICT", "SAPT", "QICT", "KGTL"):
        if term != vt:
            res["terminal"] = vt
    elif not term:
        res["terminal"] = vt


def _capture_departed(res):
    """v96 data-audit round 2, FIX B: departed ki pakki tareekh
    status text se nikal kar apne 'departed' field mein mehfooz
    karo — kal ko status text 'Arrived' ban jaye to bhi tareekh
    na mite (COAU6468022200/6468022890/6468005230 par re-track
    ne '09 Oct 2026' mita di thi)."""
    if not res.get("departed"):
        d = departed_date(res.get("status"))
        if d:
            res["departed"] = d


def _reconcile_status(res):
    """track_all ka aakhri marhala (v96 data-audit fix): assemble
    hue result ka status TEXT usi result ke sakht saboot se milao.
    Layers apni tartib mein status overwrite karti hain — aakhri
    likhne wali layer hamesha sab se mazboot nahi hoti (masalan
    QICT by-container ki 'Discharged at QICT' usi result ke
    position=OUT + truck=delivered ko nazar-andaz kar deti thi —
    269665315). Saboot text se aage ho to text ko saboot tak
    UTHAO; text kabhi peeche nahi jata, aur 'hold' wale status ko
    haath nahi lagta (hold ek alert halat hai, stage dawa nahi)."""
    if not res:
        return res
    # FIX A/B pehle: terminal ki pehchan (VIR) aur departed
    # tareekh ki hifazat hold wale record par bhi laagu hai —
    # stage wala hisaab baad mein, hold ko wahan chhorte hain.
    _fix_terminal_identity(res)
    _capture_departed(res)
    st = res.get("status") or ""
    if "hold" in st.lower():
        return res
    # v99: band-cycle (cycle_closed) result ka status
    # terminal ke band record se bana hai — reconcile ke
    # paas is se behtar field saboot hai hi nahi (na
    # discharge, na gate_out field); sirf 'returned'
    # flag se stage 5 bana kar text ko 'Delivered' par
    # uthana wohi saboot dobara gin-na hoga. Status
    # waisa hi rehne do jo terminal record kehta hai.
    if res.get("cycle_closed"):
        return res
    # v99 takraar arbitration: result ka apna POSITION field
    # (terminal ka seedha data field) yard kehta ho, status
    # text Delivered/Gate-out ka dawa kare (text stage >= 4)
    # aur gate_out ki tareekh mojood na ho to ye usi source
    # ke do fields ki takraar hai — mojoodgi wala field
    # jeet-ta hai, synthesis ka text nahi
    # (MBAQITS8502261016: QICT BL-Inquiry ki synthesis
    # 'Released — Delivered' kehti thi lekin usi record ka
    # POSITION 'IN YARD' tha — dabba asal mein yard mein hi
    # tha. Ye koi inference nahi: terminal ka apna field
    # hai, is liye Ctr-Inq ke discharge-only saboot ke
    # baghair bhi ye arbitration sach par rakhta hai, aur
    # re-track par ghalat record khud sudhar jata hai.)
    if "yard" in (res.get("position") or "").lower() \
            and status_text_stage(st) >= 4 \
            and not res.get("gate_out"):
        term = (res.get("terminal") or "").strip()
        res["status"] = f"Discharged at {term}" if term \
            else "Discharged"
        # truck ka 'delivered' dawa bhi isi takraar mein
        # rad — warna status_stage use stage-5 saboot bana
        # kar text ko neeche dobara 'Delivered' utha de ga.
        # Rad ki nishani bhi likho (veto wali hi tombstone)
        # taake merge purane record se use zinda na kare
        # jab ye correction qayam ho.
        if (res.get("truck") or "").strip().lower() == "delivered":
            res.pop("truck", None)
            _rj = list(res.get("_rejected_fields") or [])
            if "truck" not in _rj:
                _rj.append("truck")
            res["_rejected_fields"] = _rj
        return res
    # v99fix (d): 'Gate out'/'Delivered' ka TEXT apne
    # sakht saboot ke baghair ek khaali dawa hai — text
    # stage fields ke stage se aage ho to text saboot ki
    # satah par wapas aayega (COAU6468022200: ghost record
    # se 'Gate out' text ban gaya tha, gate_out ki tareekh
    # kabhi thi hi nahi — andaruni tazad). 'Released'
    # wala text is rule se bahar hai: release ek alag
    # terminal halat hai (QICT ka standing), gate-out ka
    # dawa nahi — use discharge par girana ghalat hoga.
    _stl = st.lower()
    if ("gate out" in _stl or "gate-out" in _stl
            or "delivered" in _stl) \
            and status_text_stage(st) >= 4:
        _fs = 0
        if res.get("discharge_time"):
            _fs = max(_fs, 3)
        if res.get("gate_out"):
            _fs = max(_fs, 4)
        _posu = (res.get("position") or "").strip().upper()
        if _posu in ("OUT", "GATE OUT", "GATE-OUT"):
            _fs = max(_fs, 4)
        if (res.get("truck") or "").strip().lower() == "delivered":
            _fs = max(_fs, 5)
        if res.get("returned"):
            _fs = max(_fs, 5)
        if _fs < status_text_stage(st):
            term = (res.get("terminal") or "").strip()
            if _fs >= 4:
                res["status"] = "Gate out"
            elif _fs >= 3:
                res["status"] = (f"Discharged at {term}" if term
                                 else "Discharged")
            elif term == "QICT":
                res["status"] = "At QICT terminal (Port Qasim)"
            elif term:
                res["status"] = f"Arrived at {term} terminal (Karachi)"
            else:
                res["status"] = "Arrived"
            return res
    ev = status_stage(res)
    if ev <= status_text_stage(st):
        return res
    term = (res.get("terminal") or "").strip()
    if ev >= 5:
        res["status"] = "Released — Delivered"
    elif ev >= 4:
        res["status"] = "Gate out"
    elif ev >= 3:
        res["status"] = f"Discharged at {term}" if term else "Discharged"
    return res


def _ctn_evidence_add(ev_map, ctn, leg):
    """Ek by-container leg ke result ko us container ke saboot
    mein badlo (v96 proof-run fix). Do kism ka saboot:
    'out' — dabba yard se nikal chuka (gate_out ki tareekh,
    position OUT, KGTL ka 'Departed', ya agle safar par
    'Loaded on Vessel'); 'in_yard' — dabba
    terminal ke yard mein hai aur gate-out ka koi saboot nahi
    (discharge huwa hai, ya position/status yard/at-terminal
    kehta hai). 'expected' (dabba abhi raste mein hai) wali
    entry saboot nahi — wo dabbe ki mojoodgi hi sabit nahi
    karti. Ek hi container par kai legs hon to 'out' jeet-ta
    hai: discharge gate-out se pehle ki halat hai, is liye
    discharge wali entry gate-out wali tasdeeq ko kaat nahi
    sakti. v99: 'discharge_only' nishan wali leg (QICT
    Ctr-Inq — gate-out/position ka field hai hi nahi) ka
    discharge akela kabhi 'in_yard' nahi banta."""
    if not ctn or not leg or not leg.get("found") \
            or leg.get("expected"):
        return
    st = (leg.get("status") or "").lower()
    pos = (leg.get("position") or "").strip()
    posu = pos.upper()
    g = leg.get("gate_out")
    # 'Loaded on Vessel' bhi yard se nikalne ka saboot hai:
    # dabba agle safar par load ho chuka ho to us ka purana
    # discharge record mojooda yard ki halat nahi raha
    # (269665315: QICT discharge ke baad dabba SAPT se agle
    # safar par load huwa — wahan veto lagta to asal Delivered
    # record kharab ho jata).
    out = bool(g and str(g).strip()) \
        or posu in ("OUT", "GATE OUT", "GATE-OUT") \
        or pos.lower() == "departed" \
        or "loaded on vessel" in st \
        or "loaded on vessel" in pos.lower() \
        or "gate out" in st or "gate-out" in st \
        or "delivered" in st or "empty returned" in st \
        or "returned empty" in st
    in_yard = False
    if not out:
        if leg.get("discharge_only"):
            # v99 (investigation fix 1): ye leg gate-out /
            # position dekh hi nahi sakti (QICT Ctr-Inq) — is
            # ka discharge record gate-out ke baad bhi hamesha
            # waisa hi rehta hai, is liye discharge_time ya
            # 'Discharged' text yard ka saboot NAHI ban sakte.
            # Sirf leg ke apne position field ki seedhi yard
            # sighting chalegi (Ctr-Inq par wo hoti hi nahi).
            in_yard = "yard" in pos.lower()
        else:
            in_yard = bool(leg.get("discharge_time")) \
                or "yard" in pos.lower() or "discharg" in st \
                or "hold" in st \
                or st.startswith(("at qict", "at kgtl", "at kict",
                                  "at sapt"))
    if not out and not in_yard:
        return
    e = ev_map.setdefault(ctn, {"out": False, "in_yard": False,
                                "virs": set(), "status": "",
                                "position": ""})
    if leg.get("vir"):
        e["virs"].add(str(leg["vir"]).strip().upper())
    if out:
        e["out"] = True
        e["in_yard"] = False
    elif not e["out"]:
        e["in_yard"] = True
        if leg.get("status"):
            e["status"] = leg["status"]
        if pos:
            e["position"] = pos


def _term_ts_full(s):
    """Stamp ko POORE timestamp (waqt ke sath) mein parse
    karo -> (datetime, precise) ya None. Sirf tareekh mile
    to wo din adhi-raat hai aur precise=False — muqabla
    karne wale ko ye farq maloom hona chahiye (usi din ki
    wapsi din-wale hisaab se kabhi rad nahi hogi)."""
    s = str(s or "").strip()
    if not s:
        return None
    k = _term_gate_key(s)
    if k != datetime.min:
        return (k, bool(re.search(r"\d{1,2}[:.]\d{2}", s)))
    d = _term_date(s)
    if d:
        try:
            return (datetime.strptime(d, "%d %b %Y"), False)
        except Exception:
            pass
    pd = _parse_det_date(s)
    if pd:
        return (datetime(pd.year, pd.month, pd.day), False)
    return None


def _ts_after(a, b):
    """a (wapsi ka stamp) b (anchor) ke BAAD hai? Dono ke
    paas waqt ho to sakht muqabla (ghante bhi ginne
    jayenge); warna din ki satah: wapsi ka din anchor ke
    din se pehle nahi hona chahiye — usi din gate-out ke
    chand ghante baad ki wapsi asal wapsi hai (OOLU2337916330:
    gate-out 09:36, wapsi 18:23 usi din; MEDUT1385110:
    completion 03:51, wapsi 16:59 usi din — v99 ka din-wala
    hisaab in dono ko rad kar deta tha)."""
    if a is None or b is None:
        return False
    (ad, ap), (bd, bp) = a, b
    if ap and bp:
        return ad > bd
    return ad.date() >= bd.date()


def derive_empty_return(res):
    """Empty-return derivation — EK mapping, har choke
    point par (v99fix, Phase-1 fail 30 Oct 2026).

    v99 (user ka hukm): khaali dabbe ki wapsi terminal ke
    container record mein darj hoti hai — Hutchison
    (KICT/SAPT) history rows mein STATUS='EM' wali row.
    Pehle flow ye kabhi nahi likhta tha (data audit s3:
    terminal par return mojood hote hue bhi records ka
    'returned' khaali rehta tha). v99 mein derivation
    sirf track_all ke aakhir mein tazi result par chalti
    thi aur din-ki-satah ke muqable se usi-din ki wapsi
    rad ho jati thi (MEDUT1385110: EM row record mein
    thi, returned phir bhi na bana). Ab yehi function
    server ke record-finalize (merge) par bhi chalta hai:
    STORED terminal_rows mein EM row ho to wapsi wahan
    se bhi banti hai — saboot jis run mein bhi aaya ho,
    derivation har finalize par hoti hai.

    Usool:
    - EM row usi dabbe ke APNE gate-out ke baad ki ho
      (anchor: us dabbe ki rows ka gate-out, warna
      shipment gate_out, warna discharge) — muqabla
      poore timestamp se, din se nahi.
    - Ya import cycle ki EM-derived gate_in (gate_out
      ke baad wali) — lekin wo gate_in NAHI jo kisi
      export (XM/XF) row ki gate-in se wazeh ho: wo
      dabbe ke AGLE safar ki ibtida hai, is BL ki wapsi
      nahi (025G773374 / BALCMBKHI2600923 par sabit).
    - Tareekh hamesha terminal ki apni hogi — ghari
      hui kabhi nahi. Pehle se returned ho to haath
      nahi lagta. Presumption (2+ din wala andaza,
      server._lifecycle) is se alag hai aur asal saboot
      ke aage hamesha peeche rehta hai."""
    if not res or res.get("returned"):
        return False
    rows = [r for r in (res.get("terminal_rows") or [])
            if isinstance(r, dict)]
    own = {str(c).strip() for c in (res.get("containers") or [])
           if c}

    def _own_row(row):
        return not own or str(
            row.get("CONTAINER NO") or "").strip() in own

    ship_go = _term_ts_full(res.get("gate_out"))
    ship_dis = _term_ts_full(res.get("discharge_time"))
    best = None
    for row in rows:
        if not _own_row(row):
            continue
        if str(row.get("STATUS") or "").strip().upper() != "EM":
            continue
        when_raw = row.get("DISCHARGING TIME") \
            or row.get("GATE In TIME") or ""
        t = _term_ts_full(when_raw)
        if t is None:
            continue
        ctn = str(row.get("CONTAINER NO") or "").strip()
        own_go = None
        for r2 in rows:
            if str(r2.get("CONTAINER NO") or "").strip() != ctn:
                continue
            g = _term_ts_full(r2.get("GATE OUT TIME"))
            if g and (own_go is None or g[0] > own_go[0]):
                own_go = g
        anchor = own_go or ship_go or ship_dis
        if anchor is not None and not _ts_after(t, anchor):
            continue  # wapsi gate-out se pehle ki nahi sakti
        if best is None or t[0] < best[0]:
            best = (t[0], str(when_raw))
    if best is None:
        gi_raw = res.get("empty_gate_in") or res.get("gate_in")
        gi = _term_ts_full(gi_raw)
        if gi and ship_go and res.get("discharge_time") \
                and _ts_after(gi, ship_go):
            explained = False
            for row in rows:
                if str(row.get("STATUS") or "").strip().upper() \
                        in _EXPORT_ROW_STATUS:
                    rt = _term_ts_full(row.get("GATE In TIME"))
                    if rt and rt[0] == gi[0]:
                        explained = True
                        break
            if not explained:
                # v99fix3: QICT export saboot bhi gate_in
                # ki wazeh hai — terminal_rows null hon to
                # bhi ye gate_in agle safar ki ibtida hai,
                # wapsi nahi.
                _qi = _term_ts_full(res.get("qict_export_in"))
                if _qi is not None and _qi[0] == gi[0]:
                    explained = True
            if not explained:
                best = (gi[0], str(gi_raw))
    if best:
        res["returned"] = True
        res["returned_date"] = best[1]
        return True
    return False


def _settle_empty_return(res, allow_load_derive=True):
    """Empty-return ka EK choke point (v99fix2, Phase-2
    defect MBAQITS8502261016).

    Masla ye nahi tha ke derive_empty_return mein XM/XF
    guard nahi tha — guard tha, lekin us tak saboot hi
    nahi pahunchta tha: Layer 3d absorb XF-only leg ki
    row is liye gira deta tha ke us leg ka terminal
    khaali tha, aur merge purani (legacy) gate_in ko
    baghair us ki wazeh karne wali rows ke aage barha
    deta tha. Natija: XF export gate-in 'returned' ban
    gayi, jabke us ki tareekh to XF row ki gate-in thi.

    Is liye har returned-faisla YAHIN se guzarta hai —
    v99fix3 se QICT cycle_closed writer bhi returned
    nahi likhta (sirf export-cycle saboot deta hai) —
    koi aur function terminal saboot se returned nahi
    likhta, aur Hutchison gate_in ko ye chhoota hi
    nahi:
    1. RETRACT: pehle se darj returned jhoota sabit ho
       (us ki tareekh kisi XF/XM row ki gate-in ya QICT
       export In Time se second-tak mile, aur us dabbe
       ki koi EM row na ho) to use saaf karo — warna
       ghalat returned merge ki stickiness se hamesha
       zinda rehta.
    2. DERIVE: phir aam derivation (EM row, ya
       ghair-export row se wazeh na hone wali gate_in).
    v99fix4 (Fix Round 4): QICT export-LOAD derivation
    bhi yahin hai — dabba export cargo ban kar jahaz
    par LOAD ho chuka ho (qict_export_load) to khaali
    dabba carrier ki hirasat mein wapis aaye baghair
    load ho hi nahi sakta tha: wapsi SABIT hai, lekin
    QICT wapsi ki tareekh record nahi karta, is liye
    returned_date hamesha None rahe gi aur nishan
    returned_basis='export_reload' lage ga. Gate-in
    akeli (baghair load) kabhi wapsi nahi — 1016 usi
    par False rehta hai. Basis wali wapsi ki
    retraction symmetry bhi yahin hai: saboot (EM row
    ya load) taze result mein na ho to ye True bhi
    retract hota hai, aur EM row aa jaye to tareekh
    wali asal wapsi is ki jagah leti hai.
    allow_load_derive: merge par band-cycle anchor
    (_cc_ok) na ho to load-derivation band rehti hai —
    ajnabi cycle ka saboot doosre record par nayi
    wapsi nahi bana sakta (retraction phir bhi hoti
    hai). track_all ke taze result par anchor ki
    zaroorat nahi — saboot usi record ke apne dabbe
    ka hota hai.
    Dono call sites yahi function chalati hain:
    track_all ka aakhir (_apply_empty_return) aur
    server._merge_result (record-finalize)."""
    if not res:
        return False
    changed = False
    if res.get("returned") and res.get("returned_date"):
        rd = _term_ts_full(res["returned_date"])
        if rd is not None:
            rows = [r for r in (res.get("terminal_rows") or [])
                    if isinstance(r, dict)]
            own = {str(c).strip()
                   for c in (res.get("containers") or []) if c}

            def _own_row(row):
                return not own or str(
                    row.get("CONTAINER NO") or "").strip() in own

            xf_match = False
            em_any = False
            for row in rows:
                if not _own_row(row):
                    continue
                st = str(row.get("STATUS") or "").strip().upper()
                if st == "EM":
                    em_any = True
                elif st in _EXPORT_ROW_STATUS:
                    rt = _term_ts_full(row.get("GATE In TIME"))
                    if rt and rt[0] == rd[0]:
                        xf_match = True
            # v99fix3: QICT route — terminal_rows null
            # hoti hain, is liye XF row kabhi nahi mile
            # gi. Is ke bajaye record par maujood
            # export-cycle saboot (qict_export_in, fresh
            # Layer 3c se aaya) se muqabla: returned_date
            # wahi export In Time ho to ye wahi ghalat
            # wapsi hai. EM row ho to wapsi asal hai —
            # retraction tab bhi nahi hogi.
            qict_match = False
            _qi = _term_ts_full(res.get("qict_export_in"))
            if _qi is not None and rd is not None \
                    and _qi[0] == rd[0]:
                qict_match = True
            if (xf_match or qict_match) and not em_any:
                res["returned"] = False
                res.pop("returned_date", None)
                changed = True
    # v99fix4: basis (export_reload) wali derived wapsi
    # ki retraction symmetry — ye True sirf apne saboot
    # ke sath zinda rehta hai. Load ghayb ho to retract;
    # EM row aa gayi ho to bhi ye shakl jaati hai taake
    # aam derivation tareekh wali asal wapsi bana sake.
    if res.get("returned") \
            and res.get("returned_basis") == "export_reload" \
            and not res.get("returned_date"):
        _rows4 = [r for r in (res.get("terminal_rows") or [])
                  if isinstance(r, dict)]
        _own4 = {str(c).strip()
                 for c in (res.get("containers") or []) if c}
        _em4 = any(
            str(r.get("STATUS") or "").strip().upper() == "EM"
            and (not _own4 or str(
                r.get("CONTAINER NO") or "").strip() in _own4)
            for r in _rows4)
        if _em4 or not str(res.get("qict_export_load")
                           or "").strip():
            res["returned"] = False
            res.pop("returned_basis", None)
            changed = True
    if derive_empty_return(res):
        changed = True
    # v99fix4: QICT export-LOAD derivation — EM ke baad
    # bhi returned na bana ho aur record ke paas export
    # Load Time ka saboot ho to wapsi sabit hai (dabba
    # khaali wapis aaye baghair export load nahi hota),
    # tareekh NAHI hai (QICT wapsi ki tareekh nahi deta)
    # — gate-in ya load ka waqt wapsi ki tareekh kabhi
    # nahi banta. Record-level saboot sirf tab jab
    # dabba EK hi ho: zyada dabbon par ye scalar saboot
    # kis dabbe ka hai, tay nahi — wahan flip nahi hota.
    if allow_load_derive and not res.get("returned"):
        _ld4 = str(res.get("qict_export_load") or "").strip()
        _ct4 = [c for c in (res.get("containers") or []) if c]
        if _ld4 and len(_ct4) <= 1:
            res["returned"] = True
            res.pop("returned_date", None)
            res["returned_basis"] = "export_reload"
            changed = True
    return changed


def _apply_empty_return(res):
    """track_all ke aakhir mein tazi result par derivation
    (v99 se); asal kaam _settle_empty_return ka hai, jo
    server ke finalize par bhi chalta hai."""
    if res:
        _settle_empty_return(res)
    return res


def _apply_container_veto(res, ev_map):
    """v96 proof-run fix (case 3, MBAQITS8502261016): BL-level
    leg ka 'Delivered/OUT' dawa usi run ke by-container saboot
    ke aage nahi tik sakta. QICT ki BL-inquiry ne jhoota
    'Released — Delivered' + truck delivered keh diya tha,
    jabke by-container leg (Ctr-Inq) usi cycle ka discharge
    dikha rahi thi aur gate-out ka koi saboot nahi tha — dabba
    asal mein yard mein tha. Merge ka stage guard sirf
    downgrade rokta hai; ye ghalat UPGRADE wahan se guzar
    jata tha. Usool:
    - Veto sirf TAB jab kisi apne container ka POSITIVE yard
      saboot ho. Koi by-container saboot hi na ho to dawa
      barqarar — asal Delivered (269665315) par by-container
      record tha hi nahi, is liye wahan veto lag hi nahi sakta.
    - Saboot usi cycle ka ho: VIR dono taraf ho aur alag ho
      to wo doosre safar ka record hai — veto nahi.
    - By-container leg gate-out/OUT ki tasdeeq kar de to dawa
      barqarar (genuine case mehfooz).
    - Kuch dabbe out aur kuch yard mein (ya kuch par saboot
      hi nahi) hon to shipment 'Partially discharged' hai —
      na poori Delivered, na poori Discharged."""
    if not res:
        return res
    ev = {c: dict(e) for c, e in (ev_map or {}).items()}
    # terminal_rows bhi per-container saboot hain (Hutchison
    # history rows + KGTL grid — dono current cycle par
    # filtered hokar aate hain).
    for row in res.get("terminal_rows") or []:
        if not isinstance(row, dict):
            continue
        c = (row.get("CONTAINER NO") or "").strip()
        if not c:
            continue
        # Tareekh PARSE karke dekho: terminal khaali gate-out
        # par 'N/A' likhta hai — wo string mojood hona gate-out
        # ka saboot nahi (269665315 ki SAPT row par yahi 'N/A'
        # veto ko ghalat rok raha tha).
        g = _term_date(str(row.get("GATE OUT TIME") or ""))
        d = _term_date(str(row.get("DISCHARGING TIME") or ""))
        loc = (row.get("LOCATION") or "").strip().lower()
        e = ev.setdefault(c, {"out": False, "in_yard": False,
                              "virs": set(), "status": "",
                              "position": ""})
        if g or loc == "departed":
            e["out"] = True
            e["in_yard"] = False
        elif (d or loc == "in yard") and not e["out"]:
            e["in_yard"] = True
    if not ev:
        return res
    if status_stage(res) < 4:
        return res  # gate-out/delivered ka dawa hai hi nahi
    rvir = str(res.get("vir") or "").strip().upper()

    def _same_cycle(e):
        return not e["virs"] or not rvir or rvir in e["virs"]

    own = [c for c in (res.get("containers") or []) if c in ev]
    covered = [c for c in own if _same_cycle(ev[c])]
    in_yard = [c for c in covered
               if ev[c]["in_yard"] and not ev[c]["out"]]
    if not in_yard:
        return res
    out_ok = [c for c in covered if ev[c]["out"]]
    # Dawa khatam karo: truck 'delivered' aur shipment-level
    # gate_out (jo hamesha SAB dabbon ke out hone par lagta
    # hai) hata do — in ke rehte _reconcile_status jhooti
    # text ko dobara utha deta.
    # v99 (investigation fix 3): jo fields veto RAD karta hai
    # un ki fehrist bhi likho — _merge_result inhein purane
    # record se zinda NAHI kare ga jab ye correction qayam
    # rahe (warna card 'Discharged' ke sath 'Gate pass:
    # delivered' jaisi khud-takrari dikhata hai).
    _rejected = list(res.get("_rejected_fields") or [])
    if (res.get("truck") or "").strip().lower() == "delivered":
        res.pop("truck", None)
        if "truck" not in _rejected:
            _rejected.append("truck")
    if res.pop("gate_out", None) is not None \
            and "gate_out" not in _rejected:
        _rejected.append("gate_out")
    if _rejected:
        res["_rejected_fields"] = _rejected
    st_now = res.get("status") or ""
    hold = "hold" in st_now.lower()
    all_in = len(in_yard) == len(res.get("containers") or []) \
        and not out_ok
    if all_in:
        if not hold:
            ev_st = ev[in_yard[0]].get("status") or ""
            term = (res.get("terminal") or "").strip()
            res["status"] = ev_st or (
                f"Discharged at {term}" if term else "Discharged")
        _p = ev[in_yard[0]].get("position") or ""
        if "yard" in _p.lower():
            res["position"] = _p
        elif (res.get("position") or "").strip().upper() in (
                "OUT", "GATE OUT", "GATE-OUT"):
            # Sirf usi OUT dawe ki jagah yard likho jo veto
            # ho raha hai (MBAQITS8502261016 wala asal case:
            # BL leg ka jhoota OUT).
            res["position"] = "In Yard"
            # v99 (investigation fix 2): ye 'In Yard' veto ki
            # apni inference hai, kisi terminal field se nahi
            # aaya — is par provenance ka nishan lagao.
            # server ka merge guard (_own_cycle_correction)
            # is nishan wale position ko azaad terminal
            # saboot kabhi nahi mane ga: engine apna banaya
            # huwa saboot khud paish karke final record ko
            # peeche nahi kar sakta (EMKAYMBAKHI59055,
            # 30 Oct 2026 wala downgrade isi se huwa tha).
            res["position_via"] = "veto"
        # v98 (S2, EMKAYMBAKHI59055): position KHAALI ho to
        # 'In Yard' kabhi MAT gharo. QICT gate-out ke baad
        # BL-mode khaali ho jati hai aur Ctr-Inq hamesha ke
        # liye sirf discharge dikhati rehti hai — us khaali
        # jagah par ghara huwa 'In Yard' server ke merge
        # guard (_own_cycle_correction) ko jhoota yard
        # saboot de kar asal Delivered record ko
        # 'Discharged' par peeche dhakel deta tha
        # (29 Oct 2026, 17:40 wali status change).
    else:
        if not hold:
            res["status"] = "Partially discharged"
        if (res.get("position") or "").strip().upper() in (
                "OUT", "GATE OUT", "GATE-OUT"):
            res["position"] = "In Yard"
            # v99 fix 2: oper wali hi provenance — ye 'In
            # Yard' bhi veto ki inference hai, terminal
            # field nahi.
            res["position_via"] = "veto"
    return res


def _union_rows(existing, new_rows):
    """Terminal rows ka UNION — ek leg ki rows doosri leg
    ki rows ko kabhi nahi dabateen. Har dabbe ki history
    record ka saboot hai (EM rows, gate-out stamps);
    BL-mode ki listing rows par container-mode ki history
    rows chipkana replace karna nahi hai (v99fix:
    MEDUT1385110 mein 3d absorb ne BL rows daba kar
    sirf pehle dabbe ki rows chhor di theen). Dedupe pid
    se; pid na ho (KGTL grid) to row ki shakal se."""
    def _key(r):
        if not isinstance(r, dict):
            return None
        pid = r.get("pid")
        if pid:
            return ("pid", str(pid))
        return ("shape", str(r.get("CONTAINER NO") or ""),
                str(r.get("STATUS") or r.get("LOCATION") or ""),
                str(r.get("DISCHARGING TIME") or ""),
                str(r.get("GATE OUT TIME") or ""),
                str(r.get("GATE In TIME") or ""))

    seen = set()
    out_rows = []
    for r in list(existing or []) + list(new_rows or []):
        k = _key(r)
        if k is None or k in seen:
            continue
        seen.add(k)
        out_rows.append(r)
    return out_rows


def track_all(bl=None, ctn=None, vessel_name=None, progress_cb=None,
              carrier_hint=None, traqo_key=None, known_containers=None,
              known_vessel=None):
    """Structured tracking — GUI aur CLI dono ke liye.
    progress_cb(layer_name, status, detail) — status: running/done/fail
    Returns: dict with carrier, layers[], result{}, contacts{}
    """
    def prog(name, status, detail=""):
        if progress_cb:
            progress_cb(name, status, detail)

    out = {"carrier": None, "prefix": None, "layers": [], "result": {},
           "contacts": None, "tried": []}

    # Vessel-only mode
    if vessel_name:
        prog("Layer 4 — VesselFinder", "running", vessel_name)
        r = vessel_live_position(vessel_name)
        out["layers"].append({"name": "Layer 4 — VesselFinder",
                              "status": "done" if r.get("found") else "fail",
                              "detail": vessel_name})
        if r.get("found"):
            out["result"] = r
        prog("Layer 4 — VesselFinder",
             "done" if r.get("found") else "fail", "")
        return out

    if bl:
        bl = norm(bl)
    # Layer 0: carrier identify
    prog("Layer 0 — Carrier identification", "running")
    lookup = bl or ctn
    prefix, carrier = identify_carrier(lookup) if lookup else (None, None)
    # UI se manual carrier chuna gaya ho aur prefix se pehchan na
    # ho payi ho, to wahi hint asal tracking mein istemal karo —
    # pehle hint sirf naam badalta tha, talaash nahi (v29 fix).
    if not carrier and carrier_hint:
        carrier = carrier_hint
    out["carrier"] = carrier
    out["prefix"] = prefix
    # v51: pehchan "record mila" NAHI hoti — is layer ko meta mark
    # karo taake UI ka "x found a record" count is se na barhe
    # (24 Oct: Wan Hai BL par count "1 found" dikha jab ke asal
    # record ek bhi nahi mila tha). Status bhi ab sach bolega:
    # carrier na pehchana jaye to fail.
    out["layers"].append({"name": "Layer 0 — Carrier identification",
                         "status": "done" if carrier else "fail",
                         "meta": True,
                         "detail": f"{carrier} (prefix {prefix})" if carrier
                         else f"Unknown (prefix {prefix})"})
    prog("Layer 0 — Carrier identification",
         "done" if carrier else "fail")

    # Forwarder contact (agar hai)
    if carrier in FORWARDER_CONTACTS:
        out["contacts"] = FORWARDER_CONTACTS[carrier]

    got_vessel = None
    # v96 proof-run fix: by-container legs ka saboot saath saath
    # jama karo — aakhir mein _apply_container_veto BL-level ke
    # jhoote Delivered dawe ko isi se parakhe gi.
    ctn_ev = {}

    # Layer 1: carrier direct API
    api_fn = CARRIER_APIS.get(carrier) if (carrier and bl) else None
    # Sirf-digits wala 12-rakam number: Evergreen ke BL ka number
    # hissa itna hi hota hai (EGLV + 12 digits) — ShipmentLink se
    # seedha jaanch lo, mile to carrier Evergreen pakka.
    sl_fallback = False
    cosco_fallback = False
    if not api_fn and bl and re.fullmatch(r"\d{12}", bl):
        api_fn = track_shipmentlink_bl
        sl_fallback = True
    elif not api_fn and bl and re.fullmatch(r"\d{10}", bl):
        # 10-rakam ka sirf-number COSCO ke BL ka number hissa hota
        # hai (COAU/COSU + 10 digits) — 21 Oct ko 6470875561 isi
        # liye chhoot gaya tha; COSCO API khud record de to pakka.
        api_fn = track_cosco_api
        cosco_fallback = True
    if api_fn:
        lname = (f"Layer 1 — {carrier} direct API" if not sl_fallback
                 else "Layer 1 — Evergreen ShipmentLink")
        prog(lname, "running")
        out["tried"].append(lname)
        r = api_fn(bl)
        ok = bool(r.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r.get("note") or r.get("error") or "")[:100]})
        if ok:
            if sl_fallback and not out.get("carrier"):
                out["carrier"] = "Evergreen"
            if cosco_fallback and not out.get("carrier"):
                out["carrier"] = "COSCO Shipping"
            out["result"].update({k: r[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "containers", "terminal",
                                  "discharge_time", "source",
                                  "activity_date", "weight",
                                  "size_type") if k in r})
            got_vessel = r.get("vessel")
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")
        if not ok and not r.get("error"):
            # F-09 fix (v46 audit): the carrier API answered but had no
            # record — track-trace used to be skipped entirely for
            # API carriers. Try it as a fallback before moving on.
            lname2 = "Layer 1b — track-trace.com (BL)"
            prog(lname2, "running")
            out["tried"].append(lname2)
            r2t = track_bol_tracktrace(bl, carrier)
            ok2 = bool(r2t.get("found"))
            out["layers"].append(
                {"name": lname2, "status": "done" if ok2 else "fail",
                 "detail": (r2t.get("note") or r2t.get("error") or "")[:100]})
            if ok2:
                out["result"].update({k: r2t[k] for k in
                                      ("vessel", "voyage", "pol", "pod",
                                       "eta", "etd", "status", "containers",
                                       "terminal", "discharge_time",
                                       "source", "activity_date", "weight",
                                       "size_type") if k in r2t})
                got_vessel = r2t.get("vessel") or got_vessel
            prog(lname2, "done" if ok2 else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")
    elif bl:
        # Layer 2: track-trace BL
        lname = "Layer 2 — track-trace.com (BL)"
        prog(lname, "running")
        out["tried"].append(lname)
        r = track_bol_tracktrace(bl, carrier)
        ok = bool(r.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r.get("note") or r.get("error") or "")[:100]})
        if ok:
            out["result"].update({k: r[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "source") if k in r})
            got_vessel = r.get("vessel")
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2b: container
    if ctn:
        capi_fn = CARRIER_CONTAINER_APIS.get(carrier) if carrier else None
        lname = (f"Layer 2 — {carrier} container API" if capi_fn
                 else "Layer 2 — track-trace.com (container)")
        prog(lname, "running")
        out["tried"].append(lname)
        r2 = capi_fn(ctn) if capi_fn else track_container_tracktrace(ctn)
        ok = bool(r2.get("found"))
        _ctn_evidence_add(ctn_ev, ctn, r2)
        if not ok and r2.get("empty_container"):
            out["result"].update({
                "status": ("No active shipment — this container is "
                           "in COSCO's system (it may be empty or an "
                           "old record)"),
                "source": "COSCO API", "containers": [ctn]})
            ok = True
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r2.get("note") or r2.get("error") or "")[:100]})
        if ok and not got_vessel:
            got_vessel = r2.get("vessel")
            out["result"].update({k: r2[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "source", "position",
                                  "size_type", "weight",
                                  "containers") if k in r2})
            if r2.get("location") and not out["result"].get("position"):
                out["result"]["position"] = r2["location"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2c: Emkay container search (extra chance — NVOCC cargo)
    if ctn and not out["result"].get("vessel"):
        lname = "Layer 2 — Emkay Line (container)"
        prog(lname, "running")
        out["tried"].append(lname)
        r3 = track_emkay_container_api(ctn)
        ok = bool(r3.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r3.get("note") or r3.get("error") or "")[:100]})
        if ok:
            if not out.get("carrier"):
                out["carrier"] = "Emkay Line"
            out["result"].update({k: r3[k] for k in
                                 ("vessel", "voyage", "pol", "pod",
                                  "etd", "status", "source",
                                  "activity_date") if k in r3})
            got_vessel = r3.get("vessel") or got_vessel
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2d: Feeder Logistics — is ki apni tracking site sirf
    # browser se khulti hai (WebGui app); server-side data ka rasta
    # band hai. Guidance layer taake FRLS BL par "not found"
    # dead-end na bane — asal site ka 1-click rasta hamesha mile.
    if bl and carrier == "Feeder Logistics":
        lname = "Layer 2d — Feeder Logistics (manual check)"
        prog(lname, "running")
        out["tried"].append(lname)
        out["layers"].append({"name": lname, "status": "fail",
            "detail": "Feeder's own tracking site holds this BL — open the source link (the number is copied for you) and paste it there. Public, no login."})
        prog(lname, "fail", out["layers"][-1]["detail"])

    # v51 SPEED (24 Oct): Layer 3 (KICT/SAPT) aur Layer 3b (QICT)
    # ke raw jawab EK SATH (parallel) mangwao — dono sirf BL par
    # munhasir hain, aapas mein koi rabta nahi. Merge aage purani
    # serial tartib mein hi hota hai, is liye natija, precedence
    # aur layer lines bilkul purane jaisi rehti hain; sirf waqt
    # dono ke MAJWAH ki bajaye slow wale ke barabar ho jata hai
    # (ye jora pehle aksar 20-30 second kha jata tha).
    # Emkay / RTW cargo ONLY ever comes to QICT (Port Qasim)
    # — Karachi terminals (KICT/SAPT/KGTL) are never checked
    # for them, by BL or by container (Yousuf's standing rule).
    _qict_only = (carrier or "") in ("Emkay Line",
                                     "RTW Shipping Lines")
    _raw3 = _raw3b = _raw3e = None
    if bl:
        try:
            from concurrent.futures import ThreadPoolExecutor as _TPE
            with _TPE(max_workers=3) as _ex:
                _f3 = None if _qict_only else _ex.submit(
                    track_karachi_terminals, bl)
                _f3b = _ex.submit(track_qict_bl, bl)
                _f3e = None if _qict_only else _ex.submit(
                    track_kgtl_bl, bl)
                if _f3 is not None:
                    try:
                        _raw3 = _f3.result()
                    except Exception as _e:
                        _raw3 = {"found": False, "error": str(_e)}
                try:
                    _raw3b = _f3b.result()
                except Exception as _e:
                    _raw3b = {"found": False, "note": str(_e)}
                if _f3e is not None:
                    try:
                        _raw3e = _f3e.result()
                    except Exception as _e:
                        _raw3e = {"found": False, "note": str(_e)}
        except Exception:
            _raw3 = _raw3b = None

    # v99 precedence (truth table 30 Oct 2026): TERMINAL
    # ka discharge_time / position carrier layer ke stamps
    # par hamesha jeet-ta hai — COSCO ke discharge stamps
    # 1-2 din pehle ke nikle, aur APL CHONGQING trio par
    # berthing ka stamp discharge ban gaya tha. Pehla
    # terminal writer jeet-ta hai; terminalon ke darmiyan
    # bhi pehle wala hi pakka mana jayega.
    _term_dis = False
    _term_pos = False
    # v99fix (d): kisi terminal layer ne is record ko
    # asal mein paya ya nahi — carrier-discharge ki
    # tasdeeq wala rule (neeche, tail mein) isi par
    # munhasir hai.
    _term_found = False

    # Layer 3: Karachi terminals (KICT/SAPT) — har BL par, house BL bhi
    if bl and not _qict_only:
        lname = "Layer 3 — Karachi Terminal"
        prog(lname, "running")
        out["tried"].append(lname)
        rt = _raw3 if _raw3 is not None else track_karachi_terminals(bl)
        if rt.get("found"):
            _st, _wh = _stale_info(rt)
            if _st:
                rt = {"found": False, "note":
                      f"Karachi Terminal holds only an OLD record "
                      f"for this BL ({_wh}) — not counted as current."}
        ok = bool(rt.get("found"))
        out["layers"].append({"name": lname, "mode": "bl", "status": "done" if ok else "fail",
                              "detail": (f"{len(rt.get('containers',[]))} container(s)"
                                         + (f" at {rt['terminal']}"
                                            if rt.get('terminal') else "")
                                        ) if ok else (rt.get("note") or rt.get("error") or "")})
        if ok:
            _term_found = True
            _newct = [c.get("CONTAINER NO", "")
                      for c in rt["containers"]]
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + _newct if c]))
            if rt.get("terminal"):
                out["result"]["terminal"] = rt["terminal"]
            out["result"]["terminal_rows"] = rt["containers"]
            # terminal details se khaali fields bharo (carrier data ko priority)
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "discharge_time", "do_expiry", "position", "holds", "vir",
                      "weight", "commodity", "size_type", "custom_status",
                      "category", "gate_in", "gate_out", "owner"):
                if rt.get(k) and not out["result"].get(k):
                    out["result"][k] = rt[k]
            # v99 precedence: terminal ka discharge/position
            # carrier ke stamp par jeet-ta hai (oper dekho).
            if rt.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rt["discharge_time"]
                _term_dis = True
            if rt.get("position") and not _term_pos:
                out["result"]["position"] = rt["position"]
                _term_pos = True
            # discharge/gate-out terminal ki zameeni haqeeqat hai — status override
            if rt.get("status"):
                out["result"]["status"] = rt["status"]
            elif not out["result"].get("status"):
                # v112: "Arrived" ka status sirf asal pehchan
                # (VIR / discharge / terminal naam) par banta
                # hai — bare rows par kabhi nahi.
                if rt.get("vir") or rt.get("discharge_time") \
                        or rt.get("terminal"):
                    out["result"]["status"] = (
                        f"Arrived at {rt['terminal']} terminal (Karachi)"
                        if rt.get("terminal") else
                        "Arrived at Karachi terminal")
            if rt.get("source"):
                out["result"]["source"] = rt["source"]
            if rt.get("vessel") and not got_vessel:
                got_vessel = rt["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3b: QICT (DP World) — KICT/SAPT par na mile to (Emkay/RTW cargo)
    if bl:
        lname = "Layer 3b — QICT (DP World Karachi)"
        prog(lname, "running")
        out["tried"].append(lname)
        rq = _raw3b if _raw3b is not None else track_qict_bl(bl)
        if rq.get("found"):
            _st, _wh = _stale_info(rq)
            if _st:
                rq = {"found": False, "note":
                      f"QICT holds only an OLD record for this BL "
                      f"({_wh}) — not counted as current."}
        ok = bool(rq.get("found"))
        out["layers"].append({"name": lname, "mode": "bl", "status": "done" if ok else "fail",
                              "detail": (", ".join(rq.get("containers", []))
                                         if ok else rq.get("note", ""))})
        if ok:
            _term_found = True
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + list(rq["containers"]) if c]))
            if not out["result"].get("terminal"):
                out["result"]["terminal"] = "QICT"
            for k in ("vessel", "voyage", "discharge_time", "holds",
                      "vir", "line", "pod", "category", "truck", "gd_no"):
                if rq.get(k) and not out["result"].get(k):
                    out["result"][k] = rq[k]
            # v99 precedence: QICT ka discharge carrier ke
            # stamp par jeet-ta hai.
            if rq.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rq["discharge_time"]
                _term_dis = True
            # QICT is the ground truth for cargo sitting at QICT:
            # its standing/position override any older carrier status
            # (v28 audit fix — a stale "in transit" must not survive).
            if rq.get("status"):
                out["result"]["status"] = rq["status"]
            if rq.get("position"):
                out["result"]["position"] = rq["position"]
                _term_pos = True
            if rq.get("source"):
                out["result"]["source"] = rq["source"]
            if rq.get("vessel") and not got_vessel:
                got_vessel = rq["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3e: KGTL (Karachi Gateway Terminal — AD Ports, East
    # Wharf) — teesra Karachi terminal; v61 mein shamil, 25 Oct
    # 2026 ko asal BL par verified (ATA/VIR/container grid).
    if bl and not _qict_only:
        lname = "Layer 3e — KGTL (Karachi Gateway Terminal)"
        prog(lname, "running")
        out["tried"].append(lname)
        rg = _raw3e if _raw3e is not None else track_kgtl_bl(bl)
        if rg.get("found"):
            _st, _wh = _stale_info(rg)
            if _st:
                rg = {"found": False, "note":
                      f"KGTL holds only an OLD record for this BL "
                      f"({_wh}) — not counted as current."}
        ok = bool(rg.get("found"))
        out["layers"].append({"name": lname, "mode": "bl", "status": "done" if ok else "fail",
                              "detail": (", ".join(rg.get("containers", []))
                                         if ok else rg.get("note", ""))})
        if ok:
            _term_found = True
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + list(rg["containers"]) if c]))
            if not out["result"].get("terminal"):
                out["result"]["terminal"] = "KGTL"
            out["result"]["terminal_rows"] = _union_rows(
                out["result"].get("terminal_rows") or [],
                rg.get("terminal_rows") or [])
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "position", "holds", "vir", "weight", "commodity",
                      "size_type", "category"):
                if rg.get(k) and not out["result"].get(k):
                    out["result"][k] = rg[k]
            # v99 precedence: KGTL ka discharge bhi terminal
            # saboot hai — carrier stamp par jeet-ta hai.
            if rg.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rg["discharge_time"]
                _term_dis = True
            # v99 flip guard: KGTL ka 'Expected…' andaza kisi
            # terminal-confirmed status ko synthesis ke andar
            # bhi nahi daba sakta — expected sirf ETA deta
            # hai (server ke merge guard wala hi usool, yahan
            # engine ke andar).
            if rg.get("status") and not (
                    rg.get("expected")
                    and out["result"].get("status")
                    and "expected" not in
                    out["result"]["status"].lower()):
                out["result"]["status"] = rg["status"]
            if rg.get("expected"):
                out["result"]["expected"] = True
            if rg.get("source"):
                out["result"]["source"] = rg["source"]
            if rg.get("vessel") and not got_vessel:
                got_vessel = rg["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3c: QICT by container number — container-first searches,
    # and cargo the BL search could not place at a terminal.
    ctn_known = ctn or (out["result"].get("containers") or [None])[0]
    if not ctn_known and known_containers:
        # v99: dobara check par stored record ke containers
        # bhi container-legs ko do (26 Oct wala usool: har
        # re-search BL + tamam containers se) — warna jis
        # BL ka BL-Inquiry jawab band ho jaye (cycle closed
        # — EMKAYMBAKHI57984) wo record hamesha ke liye
        # purani halat mein atak jata hai, halanke us ke
        # dabbe ka terminal record sab kuch bata raha hota
        # hai.
        ctn_known = known_containers[0]
    # v51 SPEED: Layer 3c/3d (container wale terminal raste) bhi
    # parallel prefetch — merge purani tartib mein hi hoga.
    _raw3c = _raw3d = _raw3f = None
    if ctn_known:
        try:
            from concurrent.futures import ThreadPoolExecutor as _TPE2
            with _TPE2(max_workers=3) as _ex2:
                _f3c = _ex2.submit(track_qict_container_layer, ctn_known)
                _f3d = _ex2.submit(track_karachi_terminals_container,
                                   ctn_known)
                _f3f = _ex2.submit(track_kgtl_container, ctn_known)
                try:
                    _raw3c = _f3c.result()
                except Exception as _e:
                    _raw3c = {"found": False, "note": str(_e)}
                try:
                    _raw3d = _f3d.result()
                except Exception as _e:
                    _raw3d = {"found": False, "error": str(_e)}
                try:
                    _raw3f = _f3f.result()
                except Exception as _e:
                    _raw3f = {"found": False, "note": str(_e)}
        except Exception:
            _raw3c = _raw3d = None
    if ctn_known:
        lname = "Layer 3c — QICT (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rc = _raw3c if _raw3c is not None else track_qict_container_layer(ctn_known)
        if rc.get("found"):
            _st, _wh = _stale_info(rc)
            if _st:
                rc = {"found": False, "note":
                      f"QICT holds only an OLD record for this "
                      f"container ({_wh}) — not counted as current."}
            elif _prev_cycle(rc, out):
                rc = {"found": False, "note":
                      "QICT's record for this container is from "
                      "its previous voyage — not this shipment."}
        ok = bool(rc.get("found"))
        out["layers"].append({"name": lname, "mode": "container", "status": "done" if ok else "fail",
                              "detail": (rc.get("status", "") if ok
                                         else rc.get("note", ""))})
        if ok:
            _term_found = True
            _ctn_evidence_add(ctn_ev, ctn_known, rc)
            if not out["result"].get("containers"):
                out["result"]["containers"] = [ctn_known]
            if not out["result"].get("terminal"):
                out["result"]["terminal"] = "QICT"
            if rc.get("cycle_closed"):
                # v99fix3: dabba ab EXPORT cycle mein hai —
                # us cycle ka VIR/jahaz/voyage is BL ka NAHI
                # hai (identity fields bilkul nahi lene).
                # v99fix3 usool: export gate-in wapsi NAHI
                # hai — is liye cycle_closed result se
                # returned/returned_date KABHI nahi lene;
                # sirf export-cycle saboot (In/Load Time)
                # lo taake _settle purani ghalat returned
                # ko retract kar sake.
                out["result"]["cycle_closed"] = True
                if rc.get("qict_export_in"):
                    out["result"]["qict_export_in"] = \
                        rc["qict_export_in"]
                if rc.get("qict_export_load"):
                    out["result"]["qict_export_load"] = \
                        rc["qict_export_load"]
                if not out["result"].get("status"):
                    out["result"]["status"] = \
                        rc.get("status") or "Gate out"
            else:
                for k in ("vessel", "voyage", "discharge_time",
                          "holds", "vir", "line", "pod",
                          "gate_out", "truck"):
                    if rc.get(k) and not out["result"].get(k):
                        out["result"][k] = rc[k]
                # v99 precedence: terminal ka discharge /
                # position carrier stamp par jeet-ta hai.
                if rc.get("discharge_time") and not _term_dis:
                    out["result"]["discharge_time"] = \
                        rc["discharge_time"]
                    _term_dis = True
                if rc.get("position") and not _term_pos:
                    out["result"]["position"] = rc["position"]
                    _term_pos = True
                # v99 (investigation fix 4): by-container
                # leg ka status text BL leg ke status ko
                # andha-dhundh NAHI dabata — QICT Ctr-Inq ki
                # 'Discharged at QICT' gate-out ke baad bhi
                # hamesha rehti hai; wo sirf saboot hai,
                # faisla veto/reconcile ka hai. Text sirf
                # tab lo jab result ke paas status ho hi
                # nahi, leg HOLD ki khabar de rahi ho
                # (terminal ki hold halat kabhi dabni nahi
                # chahiye), ya leg ke paas gate_out ka
                # tareekh-wala saboot ho AUR maujooda status
                # us se kamzor ho (wo text nahi, terminal
                # ka record hai — lekin 'Delivered' jaisa
                # mazboot dawa us se dabta nahi).
                if rc.get("status") and (
                        not out["result"].get("status")
                        or "hold" in rc["status"].lower()
                        or (rc.get("gate_out")
                            and status_text_stage(
                                out["result"].get("status"))
                            < 4)):
                    out["result"]["status"] = rc["status"]
            if rc.get("expected"):
                out["result"]["expected"] = True
            if rc.get("source"):
                out["result"]["source"] = rc["source"]
            if rc.get("vessel") and not got_vessel:
                got_vessel = rc["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3d: Karachi Terminal by container number
    if ctn_known:
        lname = "Layer 3d — Karachi Terminal (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rd = _raw3d if _raw3d is not None else track_karachi_terminals_container(ctn_known)
        if rd.get("found"):
            _st, _wh = _stale_info(rd)
            if _st:
                rd = {"found": False, "note":
                      f"Karachi Terminal holds only an OLD record "
                      f"for this container ({_wh}) — not counted "
                      f"as current."}
            elif _prev_cycle(rd, out):
                rd = {"found": False, "note":
                      "The terminal's record for this container "
                      "is from its previous voyage — not this "
                      "shipment."}
        ok = bool(rd.get("found"))
        out["layers"].append({"name": lname, "mode": "container", "status": "done" if ok else "fail",
                              "detail": (f"{len(rd.get('containers',[]))} container(s)"
                                         + (f" at {rd['terminal']}"
                                            if rd.get('terminal') else "")
                                        ) if ok else (rd.get("note") or rd.get("error") or "")})
        if ok:
            _term_found = True
            _ctn_evidence_add(ctn_ev, ctn_known, rd)
            _newct = [c.get("CONTAINER NO", "")
                      for c in rd["containers"]]
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + _newct if c]))
            _rt = rd.get("terminal", "")
            # v99fix2: rows hamesha UNION — ye saboot hai,
            # terminal ke naam par munhasir nahi. XF-only
            # leg ka terminal khaali hota hai (koi detail
            # nahi — VIR hi nahi), is liye pehli shart par
            # us ki XF row hi ghayb ho jati thi; phir
            # merge par legacy gate_in ke samne us ki
            # wazahat (XF row) mojood na rehne se wahi
            # gate_in 'returned' ban jata tha
            # (MBAQITS8502261016, Phase 2). Terminal ka
            # naam sirf tab badle ga jab leg ne koi
            # terminal bataya ho (neeche wali shart).
            _had_rows = bool(out["result"].get("terminal_rows"))
            out["result"]["terminal_rows"] = _union_rows(
                out["result"].get("terminal_rows") or [],
                rd["containers"])
            if _rt and (not out["result"].get("terminal")
                        or out["result"]["terminal"] == _rt
                        or not _had_rows):
                out["result"]["terminal"] = _rt
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "discharge_time", "do_expiry", "position", "holds",
                      "vir", "weight", "commodity", "size_type",
                      "custom_status", "category", "gate_in", "gate_out",
                      "owner"):
                if rd.get(k) and not out["result"].get(k):
                    out["result"][k] = rd[k]
            # v99 precedence: terminal ka discharge/position
            # carrier stamp par jeet-ta hai.
            if rd.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rd["discharge_time"]
                _term_dis = True
            if rd.get("position") and not _term_pos:
                out["result"]["position"] = rd["position"]
                _term_pos = True
            if rd.get("status"):
                out["result"]["status"] = rd["status"]
            elif not out["result"].get("status"):
                # v112: bare rows (bina VIR/discharge/terminal)
                # par "Arrived" kabhi nahi banta.
                if rd.get("vir") or rd.get("discharge_time") \
                        or rd.get("terminal"):
                    out["result"]["status"] = (
                        f"Arrived at {rd['terminal']} terminal (Karachi)"
                        if rd.get("terminal") else
                        "Arrived at Karachi terminal")
            if rd.get("source"):
                out["result"]["source"] = rd["source"]
            if rd.get("vessel") and not got_vessel:
                got_vessel = rd["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3f: KGTL by container number — sirf tab jab koi
    # terminal abhi tak pehchana na gaya ho (KGTL ki zameeni
    # haqeeqat apne yard ke liye final hai, doosre terminal
    # ke record par kabhi override nahi).
    if ctn_known and not out["result"].get("terminal"):
        lname = "Layer 3f — KGTL (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rf = _raw3f if _raw3f is not None else track_kgtl_container(ctn_known)
        if rf.get("found"):
            _st, _wh = _stale_info(rf)
            if _st:
                rf = {"found": False, "note":
                      f"KGTL holds only an OLD record for this "
                      f"container ({_wh}) — not counted as current."}
        ok = bool(rf.get("found"))
        out["layers"].append({"name": lname, "mode": "container", "status": "done" if ok else "fail",
                              "detail": (rf.get("status", "") if ok
                                         else rf.get("note", ""))})
        if ok:
            _term_found = True
            _ctn_evidence_add(ctn_ev, ctn_known, rf)
            if not out["result"].get("containers"):
                out["result"]["containers"] = [ctn_known]
            out["result"]["terminal"] = "KGTL"
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "position", "holds", "vir", "weight", "commodity",
                      "size_type", "category"):
                if rf.get(k) and not out["result"].get(k):
                    out["result"][k] = rf[k]
            # v99 precedence: KGTL container leg ka
            # discharge bhi terminal saboot hai.
            if rf.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rf["discharge_time"]
                _term_dis = True
            if rf.get("status"):
                out["result"]["status"] = rf["status"]
            if rf.get("expected"):
                out["result"]["expected"] = True
            if rf.get("source"):
                out["result"]["source"] = rf["source"]
            if rf.get("vessel") and not got_vessel:
                got_vessel = rf["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # v99fix (b): har dabbe ki history lazmi hai. BL mode
    # sirf LISTING rows deta hai (har dabbe ki ek row —
    # bina STATUS/waqt ke); EM (empty-return) rows sirf
    # container mode ki history mein milti hain, aur
    # by-container legs (3c/3d/3f) sirf PEHLE dabbe par
    # chalti theen. Jis dabbe ki asal history rows jama
    # shuda rows mein na hon, us ki container-mode
    # history ab yahan mangwa kar UNION ki jati hai —
    # warna doosre dabbe ki wapsi hamesha ke liye ghayb
    # rehti thi (MEDUT1385110 ki CXDU1175597: rows store
    # hi nahi huween, 30 Oct 2026 Phase-1 fail).
    _all_ctns = list(dict.fromkeys(
        [c for c in (out["result"].get("containers") or []) if c]
        + [c for c in (known_containers or []) if c]))

    def _has_hist(_c):
        for _row in out["result"].get("terminal_rows") or []:
            if not isinstance(_row, dict):
                continue
            if str(_row.get("CONTAINER NO") or "").strip() != _c:
                continue
            if str(_row.get("STATUS") or "").strip() \
                    or _row.get("DISCHARGING TIME") \
                    or _row.get("GATE OUT TIME"):
                return True
        return False

    _missing = [c for c in _all_ctns
                if c != ctn_known and not _has_hist(c)]
    if _missing:
        lname = "Layer 3d+ — Karachi Terminal (remaining containers)"
        prog(lname, "running")
        out["tried"].append(lname)
        _done_c = []
        for _c in _missing:
            rx = track_karachi_terminals_container(_c)
            if rx.get("found"):
                _st, _wh = _stale_info(rx)
                if _st:
                    rx = {"found": False}
                elif _prev_cycle(rx, out):
                    rx = {"found": False}
            if not rx.get("found"):
                continue
            _done_c.append(_c)
            _term_found = True
            _ctn_evidence_add(ctn_ev, _c, rx)
            out["result"]["terminal_rows"] = _union_rows(
                out["result"].get("terminal_rows") or [],
                rx.get("containers") or [])
            if rx.get("terminal") \
                    and not out["result"].get("terminal"):
                out["result"]["terminal"] = rx["terminal"]
            for k in ("vessel", "voyage", "eta", "etd", "pol",
                      "pod", "discharge_time", "do_expiry",
                      "position", "holds", "vir", "weight",
                      "commodity", "size_type", "custom_status",
                      "category", "gate_in", "gate_out", "owner",
                      "empty_gate_in"):
                if rx.get(k) and not out["result"].get(k):
                    out["result"][k] = rx[k]
            # terminal precedence (v99 wala hi usool):
            # is leg ka discharge/position carrier stamp
            # par jeet-ta hai, pehle terminal writer ke
            # baad doosra nahi dabata.
            if rx.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rx["discharge_time"]
                _term_dis = True
            if rx.get("position") and not _term_pos:
                out["result"]["position"] = rx["position"]
                _term_pos = True
            # shipment gate_out = SAB dabbon ke out hone
            # ka waqt: completion leg ka gate_out baad ka
            # ho to wahi completion hai.
            _gx = _term_ts_full(rx.get("gate_out"))
            _gc = _term_ts_full(out["result"].get("gate_out"))
            if _gx and (not _gc or _gx[0] > _gc[0]):
                out["result"]["gate_out"] = rx["gate_out"]
            if rx.get("status") and (
                    not out["result"].get("status")
                    or status_text_stage(rx["status"])
                    > status_text_stage(
                        out["result"].get("status"))):
                out["result"]["status"] = rx["status"]
            if rx.get("source"):
                out["result"]["source"] = rx["source"]
            if rx.get("vessel") and not got_vessel:
                got_vessel = rx["vessel"]
        out["layers"].append({
            "name": lname,
            "mode": "container",
            "status": "done" if _done_c else "fail",
            "detail": (f"{len(_done_c)} container(s): "
                       + ", ".join(_done_c)) if _done_c
                      else "No terminal history for the "
                           "remaining containers."})
        prog(lname, "done" if _done_c else "fail",
             out["layers"][-1].get("detail", ""))

    # Terminal confirm: carrier ke POD mein terminal ka naam wazeh ho
    # (masalan "Karachi-South Asia Pakistan Terminals(SAPT)") to wahi
    # pakka saboot hai — andaza nahi lagana.
    if not out["result"].get("terminal"):
        _pod = (out["result"].get("pod") or "").upper()
        if "SAPT" in _pod or "SOUTH ASIA PAKISTAN" in _pod:
            out["result"]["terminal"] = "SAPT"
        elif "KICT" in _pod or "KARACHI INTERNATIONAL" in _pod:
            out["result"]["terminal"] = "KICT"

    # Layer 3g: Hutchison Portal (KICT/SAPT ka naya nBIS system).
    # 27 Oct 2026 saboot: FRLSUBKHI276826 purane KICT enquiry par
    # "not found" tha jab ke naye portal par poora record (vessel,
    # berthing, ETA, holds) maujood tha — purana system pre-arrival
    # records dikha hi nahi sakta. Portal ka data-service bahar ke
    # seedhe calls ke liye band hai, is liye ye guidance layer hai:
    # har Karachi search ke sath portal ka pakka 1-click rasta,
    # taake "not found" kabhi dead-end na ho.
    if (bl or ctn) and not _qict_only:
        lname = "Layer 3g — Hutchison Portal KICT/SAPT (manual check)"
        prog(lname, "running")
        out["tried"].append(lname)
        out["layers"].append({"name": lname, "mode": "manual", "status": "fail",
            "detail": "New Hutchison portal (KICT + SAPT) — pre-arrival records appear here before the old enquiry can see them. Open the source link (the number is copied for you), pick the port, Public Function, Container Inquiry. Public, no login."})
        prog(lname, "fail", out["layers"][-1]["detail"])

    # Layer 4: vessel live
    if got_vessel and looks_like_vessel(got_vessel):
        lname = f"Layer 4 — VesselFinder ({got_vessel})"
        prog(lname, "running")
        out["tried"].append(lname)
        rv = vessel_live_position(got_vessel)
        ok = bool(rv.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": rv.get("destination", "")})
        if ok:
            for k in ("destination", "speed"):
                if k in rv:
                    out["result"][k] = rv[k]
            if rv.get("url"):
                out["result"]["vf_url"] = rv["url"]
            # Vessel-level ETA only while the cargo is still at sea —
            # never for discharged / released / delivered / held cargo.
            st_now = (out["result"].get("status") or "").lower()
            completed = bool(out["result"].get("discharge_time")) or any(
                w in st_now for w in ("discharg", "released", "delivered",
                                      "gate out", "on hold"))
            if rv.get("eta") and not out["result"].get("eta") and not completed:
                out["result"]["eta"] = rv["eta"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 4b: Vessel Schedule (ShipsGo) — Emkay / RTW jaisi
    # lines ke liye jin ki apni tracking website nahi deti.
    # Sirf tab: jahaz maloom ho, kisi terminal ne record na
    # paya ho, discharge na ho, aur mojooda status kamzor ho.
    # Schedule sirf khaali jaghein bharta hai (rawangi, ETA,
    # status text) — terminal saboot ko kabhi nahi chhuta.
    _sched_vessel = got_vessel or known_vessel
    _cur_status = out["result"].get("status") or ""
    _pol_txt = (out["result"].get("pol") or "").upper()
    _sched_carrier = (out.get("carrier") in
                      ("Emkay Line", "RTW Shipping Lines")
                      or "MOMBASA" in _pol_txt)
    if bl and _sched_vessel and looks_like_vessel(_sched_vessel) \
            and not _term_found \
            and not out["result"].get("discharge_time") \
            and _sched_carrier \
            and (status_text_stage(_cur_status) == 0
                 or "in progress" in _cur_status.lower()):
        lname = f"Layer 4b — Vessel Schedule (ShipsGo) ({_sched_vessel})"
        prog(lname, "running")
        out["tried"].append(lname)
        rs = track_vessel_schedule(_sched_vessel)
        ok = bool(rs.get("found"))
        _detail = (rs.get("note") or rs.get("error") or "")[:120]
        if ok:
            calls = rs["calls"]
            _voy = re.sub(r"[^A-Z0-9]", "",
                          (out["result"].get("voyage") or "").upper())
            _origin = "MOMBASA"
            if _pol_txt:
                _origin = re.split(r"[,\s]", _pol_txt.strip())[0] \
                    or "MOMBASA"
            _dep = None
            for c in calls:
                if c["kind"] == "recent" and _origin in \
                        c["port"].upper():
                    _dep = c
                    if not _voy or not c.get("voyage") or \
                            re.sub(r"[^A-Z0-9]", "",
                                   c["voyage"].upper()) == _voy:
                        break
            _dest = None
            # Yousuf ka pakka usool (5 Nov 2026): Emkay / RTW
            # sirf QICT (Port Qasim) ate hain — in ke liye ETA
            # sirf Port Qasim wali call se, Karachi se kabhi nahi.
            _qict_only = out.get("carrier") in \
                ("Emkay Line", "RTW Shipping Lines")
            for c in calls:
                if c["kind"] != "upcoming":
                    continue
                if _qict_only:
                    _is_dest = c["code"] == "PKBQM" or \
                        "PORT QASIM" in c["port"].upper()
                else:
                    _is_dest = c["code"] in ("PKBQM", "PKKHI") or \
                        "PORT QASIM" in c["port"].upper() or \
                        c["port"].upper() == "KARACHI"
                if _is_dest:
                    # Record ki voyage maloom ho to ETA sirf
                    # USI voyage ki call se — agle rotation ki
                    # call is cargo ki ETA nahi hoti.
                    if _voy and c.get("voyage") and \
                            re.sub(r"[^A-Z0-9]", "",
                                   c["voyage"].upper()) != _voy:
                        continue
                    _dest = c
                    break
            _ts_port = None
            if not _dest and _dep:
                # Transshipment port = rawangi ke baad jahaz ki
                # pehli asal call (recent list se) — aane wali
                # calls is cargo ki nahi ho sakti.
                _after = [c for c in calls
                          if c["kind"] == "recent"
                          and c["d1"] >= _dep["d2"]
                          and _origin not in c["port"].upper()]
                if _after:
                    _ts_port = min(_after,
                                   key=lambda c: c["d1"])["port"]
            _res = out["result"]
            _dep_str = _sg_fmt(_dep["d2"]) if _dep else None
            _eta_str = _sg_fmt(_dest["d1"]) if _dest else None
            if _dep_str and not _res.get("etd"):
                _res["etd"] = _dep_str
            if _eta_str and not _res.get("eta"):
                _res["eta"] = _eta_str
            if _dep and not _res.get("pol"):
                _res["pol"] = _dep["port"].title()
            if _dest and not _res.get("pod"):
                _res["pod"] = _dest["port"].title()
            if not _res.get("vessel"):
                _res["vessel"] = rs["vessel"]
            _res["vessel_calls"] = [
                f"{c['port']} — {_sg_fmt(c['d1'])}"
                + (f" to {_sg_fmt(c['d2'])}"
                   if c['d2'] != c['d1'] else "")
                + (f" (voy {c['voyage']})" if c.get("voyage") else "")
                for c in calls[:8]]
            if not _res.get("source"):
                _res["source"] = rs["source"]
            if _dep_str:
                _new_status = (f"In transit — departed "
                               f"{_dep['port'].title()} {_dep_str}")
                if not _dest and _ts_port:
                    _new_status += f" · via {_ts_port.title()}"
                _res["status"] = _new_status
            elif _eta_str:
                _res["status"] = (f"In transit — expected "
                                  f"{_dest['port'].title()} {_eta_str}")
            _detail = " · ".join(x for x in [
                f"departed {_dep['port'].title()} {_dep_str}"
                if _dep_str else "",
                f"expected {_dest['port'].title()} {_eta_str}"
                if _eta_str else "",
                f"via {_ts_port.title()}"
                if (not _dest and _ts_port) else ""] if x)[:160] \
                or f"{len(calls)} port calls"
        out["layers"].append({"name": lname,
                              "status": "done" if ok else "fail",
                              "detail": _detail})
        prog(lname, "done" if ok else "fail", _detail)

    # containers kabhi dohre nahi (terminal kabhi ek hi container
    # ki kai rows bhejta hai — MCLSUB26104308 par pakra gaya)
    if out["result"].get("containers"):
        out["result"]["containers"] = list(
            dict.fromkeys(out["result"]["containers"]))
    # prefix se pehchan na hui ho lekin kisi layer ne asal
    # shipping line bata di ho, to wahi carrier hai
    if not out.get("carrier") and out["result"].get("line"):
        out["carrier"] = _canon_line(out["result"]["line"])

    # Layer 5 — Traqo (API): aakhri rasta, sirf tab jab key ho
    # aur tamam muft layers ke baad bhi koi record na mila ho
    # (free plan: har naya reference 1 monthly slot khata hai,
    # is liye pehle kabhi nahi).
    if traqo_key and not out["result"] and (bl or ctn):
        lname = "Layer 5 — Traqo (API)"
        prog(lname, "running")
        out["tried"].append(lname)
        rt = track_traqo(bl or ctn, bool(ctn and not bl),
                         out.get("carrier") or carrier_hint, traqo_key)
        ok = bool(rt.get("found"))
        out["layers"].append({
            "name": lname, "status": "done" if ok else "fail",
            "detail": (rt.get("latest_event") or rt.get("status")
                       or rt.get("note") or "") if ok
                      else (rt.get("note") or "")})
        if ok:
            out["result"] = {k: v for k, v in rt.items()
                              if k not in ("found", "note")}
            if rt.get("line") and not out.get("carrier"):
                out["carrier"] = _canon_line(rt["line"])
        prog(lname, "done" if ok else "fail",
             out["layers"][-1].get("detail", ""))

    # v99fix (d): carrier-only discharge stamp ki
    # tasdeeq. Terminal (KICT/SAPT/QICT — ye teenon
    # discharge stamp dete hain jab discharge hoti hai)
    # is record ko apne current VIR par rakhta hai
    # lekin dabbe ki discharge NAHI dikhata, to carrier
    # ka stamp discharge NAHI mana jayega — APL
    # CHONGQING trio par wohi stamp (29-Oct 15:00)
    # berthing ka waqt tha; do dabbon ki asal discharge
    # terminal ne di (wo precedence se jeet gayi), teesre
    # (COAU6468022200) ki terminal par hai hi nahi, is
    # liye wahan stamp 'unclaimed' rahe ga. Merge ko
    # 'discharge_unconfirmed' nishan milta hai taake
    # purana stamp merge se zinda na ho. Terminal
    # discharge mojood ho to ye rule lagta hi nahi
    # (_term_dis). KGTL is se bahar hai: us ke layers
    # discharge_time field dete hi nahi, un ki khamoshi
    # saboot nahi ban sakti.
    _res = out["result"]
    if _res.get("discharge_time") and not _term_dis \
            and _term_found \
            and vir_terminal(_res.get("vir")) \
            in ("KICT", "SAPT", "QICT"):
        _res.pop("discharge_time", None)
        _res["discharge_unconfirmed"] = True
        if status_text_stage(_res.get("status")) == 3 \
                and "hold" not in (_res.get("status") or "").lower():
            _t = _res.get("terminal") \
                or vir_terminal(_res.get("vir"))
            _res["status"] = (
                "At QICT terminal (Port Qasim)" if _t == "QICT"
                else f"Arrived at {_t} terminal (Karachi)" if _t
                else "Arrived")
    # v99: terminal rows mein empty-return ka saboot ho to
    # result par darj karo (flow pehle ye kabhi nahi likhta
    # tha) — veto/reconcile se pehle, taake is run ka har
    # hisaab asal wapsi ko dekhe.
    _apply_empty_return(out["result"])
    # v96 proof-run fix: pehle by-container saboot ka veto —
    # kisi apne container ka pakka yard saboot ho to BL-level
    # ka Delivered/OUT dawa pehle khatam karo, warna
    # _reconcile_status usi jhoote saboot (truck/OUT) se text
    # ko dobara 'Delivered' utha de gi (MBAQITS8502261016).
    _apply_container_veto(out["result"], ctn_ev)
    # v96: status text ko result ke apne saboot se milao — koi
    # layer apne se mazboot saboot ko purani kamzor text se na
    # daba de (269665315: 'Discharged' + OUT + truck delivered).
    _reconcile_status(out["result"])
    if _qict_only:
        # Emkay/RTW: the container's Karachi-side rows still
        # merge silently above (an export-leg row is real
        # evidence for the empty-return derivation), but an
        # EMPTY Karachi/KGTL container check is not shown —
        # this cargo only ever comes to QICT.
        def _kr_line(l):
            nm = l.get("name") or ""
            return (("Karachi Terminal" in nm or "KGTL" in nm)
                    and "(by container)" in nm
                    or "remaining containers" in nm)
        out["layers"] = [l for l in out["layers"]
                         if not (_kr_line(l)
                                 and l.get("status") != "done")]
        _drop = {l.get("name") for l in out["layers"]}
        out["tried"] = [t for t in out["tried"]
                        if not (("Karachi Terminal" in t
                                 or "KGTL" in t)
                                and "container" in t
                                and t not in _drop)]
    return out


def main():
    args = sys.argv[1:]
    ctn = None
    # -c / --container: sirf container number diya gaya (BL ke baghair)
    # -v / --vessel: sirf vessel ka naam (live position/ETA)
    vessel_only = False
    if args and args[0] in ("-c", "--container"):
        if len(args) < 2:
            print("Usage: python3 bl-track.py -c <CONTAINER_NUMBER>")
            sys.exit(1)
        ctn = norm(args[1]); bl = None
    elif args and args[0] in ("-v", "--vessel"):
        if len(args) < 2:
            print("Usage: python3 bl-track.py -v <VESSEL_NAME>")
            sys.exit(1)
        vessel_only = True
        vessel_name = " ".join(args[1:])
    else:
        if not args:
            print("Usage: python3 bl-track.py <BL_NUMBER> [CONTAINER_NUMBER]")
            print("       python3 bl-track.py -c <CONTAINER_NUMBER>")
            print("       python3 bl-track.py -v <VESSEL_NAME>")
            sys.exit(1)
        bl = norm(args[0])
        ctn = norm(args[1]) if len(args) > 1 else None

    # Standalone vessel tracking (Layer 4 direct)
    if vessel_only:
        print(f"Vessel    : {vessel_name}")
        print("-" * 50)
        print("\n[Layer 4] VesselFinder — live position...")
        report_result(vessel_live_position(vessel_name))
        return

    print(f"BL Number : {bl}" if bl else "BL Number : (Not Given)")
    if ctn:
        print(f"Container : {ctn}")
    print("-" * 50)

    tried = []   # kaun se raste try kiye — end mein summary ke liye
    got_vessel = None

    # Layer 0: Carrier pehchano (foran, offline) — BL se, warna container se
    prefix, carrier = identify_carrier(bl) if bl else identify_carrier(ctn)
    if carrier:
        print(f"Carrier   : {carrier}  (prefix {prefix})")
    else:
        print(f"Carrier   : Unknown (prefix {prefix} not in the list)")

    # Forwarder jiska online tracking na ho: pehle online try karo,
    # na mile to contact do (haar mat mano)
    forwarder_contact = FORWARDER_CONTACTS.get(carrier)
    if forwarder_contact and carrier == "RTW Shipping Lines":
        # RTW: online tracking nahi — seedha contact, lekin pehle
        # aggregators ek baar try karo (Layer 2 neeche chalega)
        pass  # neeche normal flow, end mein contact summary mein

    # Layer 1: Carrier ka direct API (sab se tez aur sahi — ~1 second)
    api_fn = CARRIER_APIS.get(carrier) if (carrier and bl) else None
    r = {}
    if api_fn:
        print(f"\n[Layer 1] {carrier} direct API...")
        tried.append(f"Layer 1 ({carrier} API)")
        r = api_fn(bl)
        report_result(r)
        if r.get("found"):
            got_vessel = r.get("vessel")
    elif bl:
        # Layer 2: track-trace se BL tracking (carrier API na ho to)
        print("\n[Layer 2] track-trace.com — BL tracking...")
        tried.append("Layer 2 (track-trace BL)")
        r = track_bol_tracktrace(bl, carrier)
        report_result(r)
        if r.get("found"):
            got_vessel = r.get("vessel")

    # Layer 2b: Container tracking — pehle carrier API, phir track-trace
    if ctn:
        capi_fn = CARRIER_CONTAINER_APIS.get(carrier) if carrier else None
        if capi_fn:
            print(f"\n[Layer 2] {carrier} container API...")
            tried.append(f"Layer 2 ({carrier} container API)")
            r2 = capi_fn(ctn)
        else:
            print("\n[Layer 2] track-trace.com — Container tracking...")
            tried.append("Layer 2 (track-trace container)")
            r2 = track_container_tracktrace(ctn)
        report_result(r2)
        if r2.get("found") and not got_vessel:
            got_vessel = r2.get("vessel")

    # Layer 4: Vessel live tracking — agar vessel ka naam mil gaya
    if got_vessel:
        print(f"\n[Layer 4] VesselFinder — {got_vessel} live position...")
        tried.append(f"Layer 4 (VesselFinder: {got_vessel})")
        report_result(vessel_live_position(got_vessel))

    # Kabhi haar nahi mano — summary: kya try kiya, agla rasta kya hai
    print("\n" + "=" * 50)
    print("SUMMARY — ye raste try kiye:")
    for t in tried:
        print(f"  - {t}")
    print("\nAgla rasta (browser se — Layer 1b/3):")
    direct = r.get("direct_url") if isinstance(r, dict) else None
    lookup_num = bl or ctn
    print(f"  - Carrier site: {direct or direct_tracking_url(carrier, lookup_num)}")
    print("  - Karachi ports (container/BL enquiry):")
    print("      KICT: https://www.kictl.com/Enquiries?is=ContainerBLEnquiry")
    print("      SAPT: https://www.sapt.com.pk/Enquiries?is=ContainerBLEnquiry")
    # Forwarder contact (agar online na mile to)
    fc = FORWARDER_CONTACTS.get(carrier)
    if fc:
        print(f"\n  - {carrier} — direct contact (no online tracking):")
        print(f"      Phone: {fc['phone']} | Email: {fc['email']}")
        print(f"      {fc['note']}")
    print("  (open in a browser — bot-blocked sites open there)")


def direct_tracking_url(carrier, bl_number):
    """Carrier ke hisab se pre-filled tracking URL (1-click)."""
    if carrier == "COSCO Shipping":
        return ("https://elines.coscoshipping.com/ebusiness/cargoTracking"
                f"?trackingType=BILLOFLADING&number={bl_number}")
    if carrier == "OOCL":
        # 19 Oct 2026: Traqo OOCL track karta hai (oocl.com bot-blocked hai)
        return (f"https://traqocontainer.com/track/bl/{bl_number}"
                f"?carrier=OOLU")
    return CARRIER_TRACK_URL.get(carrier,
                                 "https://www.track-trace.com/")


def multi_source_urls(carrier, bl_number):
    """Multiple third-party + carrier URLs — user khud 1-click mein khole."""
    urls = []
    # 1. Carrier ki asal site (original)
    orig = CARRIER_TRACK_URL.get(carrier)
    if orig:
        urls.append(("🏢 Carrier Official", orig))
    # 2. Traqo (OOCL verified, aur bhi carriers)
    code = {"OOCL": "OOLU", "Maersk": "MAEU",
            "COSCO Shipping": "COSU"}.get(carrier, "")
    if code:
        urls.append(("🔍 Traqo", f"https://traqocontainer.com/track/bl/"
                     f"{bl_number}?carrier={code}"))
    # 3. track-trace
    urls.append(("🔍 track-trace", "https://www.track-trace.com/bol"))
    # 4. GoComet
    urls.append(("🔍 GoComet",
                 "https://www.gocomet.com/online-container-tracking"))
    return urls


def report_result(r):
    if "error" in r:
        print(f"    !! {r['error']}")
        return
    if r.get("deferred"):
        print(f"    -- {r.get('note','')}")
        return
    if not r.get("found"):
        print(f"    -- no record found. {r.get('note','')}")
        return
    print("    >> RECORD FOUND")
    for k in ["vessel", "voyage", "pol", "pod", "etd", "eta", "status",
              "destination", "speed", "nav_status", "position_time",
              "containerNumberStatus", "location"]:
        if k in r:
            label = {"nav_status": "NAV_STATUS",
                     "position_time": "POS_TIME"}.get(k, k.upper())
            print(f"    {label:8}: {r[k]}")
    if "raw_snippet" in r and len(r) <= 4:
        print(f"    Detail: {r['raw_snippet'][:300]}")


if __name__ == "__main__":
    main()
