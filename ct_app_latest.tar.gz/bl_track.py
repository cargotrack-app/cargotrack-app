#!/usr/bin/env python3
"""
bl-track.py — fast BL / Container tracking (no browser, in seconds).

Usage:
    python3 bl-track.py <BL_NUMBER> [CONTAINER_NUMBER]

Work:
  1. Identifies the carrier from the BL prefix (offline, instantly)
  2. Fetches tracking over HTTP from track-trace.com (no browser opens)
  3. Prints vessel, voyage, ETA, status
  4. If not found, gives a direct tracking link (see it yourself in 1 click)

For a House BL, also give the container number — that enables tracking.
"""

import re
import sys
import time
import html
import urllib.request
import urllib.parse
import http.cookiejar
from datetime import datetime

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

# Evergreen's own tracking site (ShipmentLink)
SL_URL = "https://ct.shipmentlink.com/servlet/TDB1_CargoTracking.do"

# ---- Carrier prefix table (first 4 letters of the BL number) ----
# 19 Oct 2026 correction: the "COAU = COSCO" mapping was based on a weak blog
# source — the official COSCO code is COSU. COAU was removed, because a wrong carrier
# identification made the tool query the wrong system.
CARRIERS = {
    "MAEU": "Maersk", "MSKU": "Maersk", "MRKU": "Maersk", "MCCQ": "Maersk (MCC)",
    "SEGU": "Maersk (Safmarine)", "SUDU": "Maersk (Hamburg Süd)",
    "COSU": "COSCO Shipping",
    # COSCO container prefixes (different from the BL COSU/COAU)
    "CSNU": "COSCO Shipping", "CSGU": "COSCO Shipping",
    "MSCU": "MSC (Mediterranean Shipping)", "MEDU": "MSC (Mediterranean Shipping)",
    "MCLU": "MSC (Mediterranean Shipping)",
    "EGHU": "Evergreen",
    # EGLV: the actual prefix of Evergreen BLs (21 Oct 2026 — caught from Yousuf's
    # BL EGLV070600248927: the list only had EGHU,
    # which is a container prefix, so an Evergreen BL was never identified
    # at all and "not found" was returned).
    "EGLV": "Evergreen",
    # Evergreen container prefixes (different from the BL EGLV)
    "EGSU": "Evergreen", "EMCU": "Evergreen", "EITU": "Evergreen",
    "CMAU": "CMA CGM",
    "HLCU": "Hapag-Lloyd",
    "OOLU": "OOCL",
    "ONEU": "ONE (Ocean Network Express)", "TLLU": "ONE", "KKFU": "ONE",
    "YMLU": "Yang Ming",
    "WHLC": "Wan Hai",
    "ZIMU": "ZIM",
    "HMMU": "HMM (Hyundai Merchant Marine)",
    "PILU": "PIL (Pacific International Lines)",
    "ESLU": "Evergreen (subsidiary)",
    # MBAQ = RTW Shipping Lines (19 Oct 2026: Yousuf explained)
    # "the RTW Shipping Lines BL is the MBA one" — and this is a MASTER BL,
    # not a house BL (Yousuf's clarification). It was previously labelled incorrectly.
    "MBAQ": "RTW Shipping Lines",
    # EMKA/EMKAY = Emkay Line, Karachi NVOCC (since 2008, 132 ports)
    # Tracking: emkayline.com/trackbyblno.php?txt_bl_no={BL} (GET, verified 19 Oct 2026)
    "EMKA": "Emkay Line", "EMKY": "Emkay Line",
    # COAU: 20 Oct 2026 VERIFIED — Yousuf showed a COAU BL tracked on COSCO's own site;
    # the COSCO API returns a record on the digits-only number (6468005230).
    # (On 19 Oct the full COAU form returned "no record".)
    "COAU": "COSCO Shipping",
    # --- 19 Oct 2026: Yousuf's 10 shipping lines (from logos) ---
    # (MAEU/YMLU/WHLC are already above — F-24: duplicate keys removed)
    "YMLY": "Yang Ming",
    "WANU": "Wan Hai",
    "STAR": "Star Lines",
    "BALT": "Baltic Lines",
    "NGSS": "New Golden Sea",
    "PELU": "Prolog Express Line", "PEL": "Prolog Express Line",
    # EMAS = EM-A Shipping (Karachi forwarder). Yousuf's own house BL
    # EMASUBKHI37726 (shared 12 Oct 2026) was on their letterhead —
    # "SUBKHI" = sub-BL, Karachi. Identify a BL with this prefix immediately.
    "EMAS": "EM-A Shipping",
    # --- 24 Oct 2026 (v51): prefixes learned from Yousuf's 43 BL photos
    # that were missing from this table. Because of their absence, many BLs
    # were never identified (the biggest: Wan Hai's 142G
    # pattern — it is in _BL_PATTERNS below because it is not a 4-letter
    # prefix).
    "KMTC": "KMTC",
    "YMJA": "Yang Ming",
    "SSLS": "Samudera",
    "FRLS": "Feeder Logistics",
    # Star Lines BLs start with "STS" + port code
    # (STSCMBALKHI9113) — the "STAR"-only key never matched them.
    # PEL BLs start with "PELM" (PELMSASUBKHI030926) —
    # the old 3-letter "PEL" key was dead in the 4-letter lookup.
    "STSC": "Star Lines",
    "PELM": "Prolog Express Line",
}

# Forwarder contacts — contact them when online tracking is not available
# (phone/email verified where noted)
FORWARDER_CONTACTS = {
    "RTW Shipping Lines": {
        "phone": "+92 324 3333888",
        "whatsapp": "+254 701 137 728",
        "email": "info@rtwsl.com",
        "web": "https://www.rtwsl.com/",
        # 19 Oct 2026 verified: rtwsl.com homepage + web search — no public
        # tracking portal (the homepage only has marketing pages; "Cargo
        # tracking" is only a service bullet). This BL will be tracked by direct contact.
        # NOTE: phone/whatsapp numbers came from 19 Oct research — on the site
        # contact details were not openly available, so first confirm by call/WhatsApp
        # that this is indeed RTW's number.
        "note": "The MBA prefix belongs to this carrier (master BL). Their website has no online tracking — please contact them directly.",
    },
    "EM-A Shipping": {
        "phone": "(021) 32601355-58-59",
        "email": "info@emashipping.com",
        "web": "https://www.emashipping.com/",
        "note": "Karachi freight forwarder (house BL). Ask them for the master BL or the container number.",
    },
}

# track-trace.com BOL company IDs (data-id values, verified 19 Oct 2026)
# POST /bol/select with number + shipper=<id> gives direct tracking
# NOTE: the 349 BOL list has APL (the container list had MSC) — keep them separate!
# NOTE: MSC is not present in the BOL list at all; track-trace says
# "we can not integrate Mediterranean Shipping completely due to technical reasons"
TT_BOL_COMPANY_IDS = {
    "Maersk": "347",
    "COSCO Shipping": "358",
    "Evergreen": "345",
    "CMA CGM": "351",
    "Hapag-Lloyd": "352",
    "OOCL": "354",
    "ONE (Ocean Network Express)": "355",
    "Yang Ming": "360",
    "Wan Hai": "370",
    # F-07 fix (v46 audit): "ZIM" was mapped to "360" — that is Yang
    # Ming's track-trace company id, so ZIM BLs were queried against
    # the WRONG company. ZIM's real track-trace id is unverified, so
    # the entry is removed: no query beats a wrong-company query.
    "HMM (Hyundai Merchant Marine)": "361",
    "PIL (Pacific International Lines)": "489",
}
# MSC automated tracking NOT supported (bot-block + no public API + track-trace no integration)
NO_AUTO_TRACK = {"MSC (Mediterranean Shipping)"}

CARRIER_TRACK_URL = {
    "Maersk": "https://www.maersk.com/tracking/",
    "COSCO Shipping": "https://elines.coscoshipping.com/ebusiness/cargotracking",
    "MSC (Mediterranean Shipping)": "https://www.msc.com/en/track-a-shipment",
    "Evergreen": SL_URL,
    "CMA CGM": "https://www.cma-cgm.com/ebusiness/tracking",
    "Hapag-Lloyd": "https://www.hapag-lloyd.com/en/online-business/track/track-by-booking-solution.html",
    "OOCL": "https://www.oocl.com/eng/ourservices/eservices/cargotracking/Pages/cargotracking.aspx",
    "ONE (Ocean Network Express)": "https://ecomm.one-line.com/one-ecom/manage-shipment/cargo-tracking",
    "Yang Ming": "https://www.yangming.com/e-service/track_trace/track_trace.aspx",
    "Wan Hai": "https://www.wanhai.com/views/tracing/tracing",
    "ZIM": "https://www.zim.com/cargo-tracking",
    "HMM (Hyundai Merchant Marine)": "https://www.hmm21.com/e-service/general/cargo-tracking",
    "PIL (Pacific International Lines)": "https://www.pilship.com/en-pil-track-and-trace/134.html",
    # --- 19 Oct 2026: Yousuf's smaller lines (tracking via website/forwarder) ---
    "Emkay Line": "https://emkayline.com/#tracking",
    "Star Lines": "https://www.track-trace.com/",
    "Baltic Lines": "https://www.track-trace.com/",
    "New Golden Sea": "https://www.track-trace.com/",
    "Prolog Express Line": "https://www.track-trace.com/",
    "RTW Shipping Lines": "https://www.track-trace.com/",
}


def clean_text(html_text):
    t = re.sub(r"<script.*?</script>", "", html_text, flags=re.S | re.I)
    t = re.sub(r"<style.*?</style>", "", t, flags=re.S | re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    t = html.unescape(t)
    return re.sub(r"\s+", " ", t).strip()


def post_form(url, data, timeout=30):
    req = urllib.request.Request(
        url,
        data=urllib.parse.urlencode(data).encode(),
        headers={**UA, "Content-Type": "application/x-www-form-urlencoded"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        final = r.geturl()
        body = r.read().decode("utf-8", errors="replace")
    return final, body


def get_json(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        import json
        return json.loads(r.read().decode("utf-8", errors="replace"))


# ---- Evergreen: ShipmentLink (their own tracking site) ----


def _sl_date(s):
    """'OCT-26-2026' -> '26 Oct 2026'."""
    m = re.match(r"([A-Za-z]{3})-(\d{2})-(\d{4})", (s or "").strip())
    if not m:
        return ""
    try:
        return datetime(int(m.group(3)),
                        datetime.strptime(m.group(1).title(), "%b").month,
                        int(m.group(2))).strftime("%d %b %Y")
    except Exception:
        return ""


def _sl_city(v):
    """'SINGAPORE (SG)' -> 'Singapore'."""
    v = re.sub(r"\s*\([A-Z]{2}\)\s*$", "", (v or "").strip())
    return v.title()


def _sl_split_voyage(vv):
    """'NORTHERN PRACTISE 51W' -> ('NORTHERN PRACTISE', '51W')."""
    m = re.match(r"^(.*?)\s+(\d{2,4}[A-Z]{0,2})$", (vv or "").strip())
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return (vv or "").strip(), ""


_SL_LABELS = ("Place of Receipt|Container Count|Port of Loading|"
              "Gross Weight|Port of Discharge|Measurement|"
              "Place of Delivery|Manifest Quantity|"
              "OCP Final Destination|Estimated On Board Date|"
              "Service Mode|Cut Off")


def _sl_field(text, label):
    m = re.search(re.escape(label) + r"\s+(.+?)(?=\s+(?:"
                  + _SL_LABELS + r")\b|$)", text)
    return m.group(1).strip() if m else ""


def _parse_shipmentlink_bl(body):
    """Parse the ShipmentLink BL result page. 'Basic
    Information' appears only on a real result — on a wrong number
    the page comes back empty; that is the mark of found."""
    text = clean_text(body)
    if "Basic Information" not in text:
        return {"found": False,
                "note": ("No record of this BL was found in "
                         "Evergreen's system.")}
    out = {"found": True, "source": "Evergreen ShipmentLink",
           "direct_url": SL_URL}
    m = re.search(r"Vessel Voyage on B/L\s+(.+?)\s+Estimated Date "
                  r"of Arrival", text)
    if m:
        out["vessel"], out["voyage"] = _sl_split_voyage(m.group(1))
    m = re.search(r"Estimated Date of Arrival at Destination\s*:\s*"
                  r"([A-Z]{3}-\d{2}-\d{4})", text)
    if m:
        out["eta"] = _sl_date(m.group(1))
    pol = _sl_field(text, "Port of Loading")
    pod = _sl_field(text, "Port of Discharge")
    if pol:
        out["pol"] = _sl_city(pol)
    if pod:
        out["pod"] = _sl_city(pod)
    w = _sl_field(text, "Gross Weight")
    if w:
        out["weight"] = re.sub(r"\.000\s*", " ", w).strip()
    etd = _sl_field(text, "Estimated On Board Date")
    if etd:
        out["etd"] = _sl_date(etd)
    # Container table: number, size and actual status from the first row
    m = re.search(r"VGM Current Status Date\s+([A-Z]{4}\d{7})\s+"
                  r"(\S+)\s+\S+\s+FCL/FCL\s+.*?KGS\s+(.+?)\s+"
                  r"([A-Z]{3}-\d{2}-\d{4})\s+Click Container", text)
    if m:
        out["containers"] = [m.group(1)]
        out["size_type"] = m.group(2)
        out["status"] = m.group(3).strip()
    else:
        ctns = re.findall(r"\b[A-Z]{4}\d{7}\b", text)
        if ctns:
            out["containers"] = list(dict.fromkeys(ctns))
        out["status"] = "In transit"
    return out


def track_shipmentlink_bl(bl_number):
    """BL tracking on Evergreen's own site (ShipmentLink) —
    verified live on 21 Oct 2026 on EGLV070600248927. The site takes
    only the (digits) part of the number; we strip the EGLV prefix."""
    digits = norm(bl_number)
    if digits.startswith("EGLV"):
        digits = digits[4:]
    try:
        _, body = post_form(SL_URL, {"TYPE": "BL", "BL": digits,
                                     "SEL": "s_bl", "NO": digits},
                            timeout=45)
    except Exception as e:
        return {"error": f"Could not reach ShipmentLink: {e}"}
    return _parse_shipmentlink_bl(body)


def _parse_shipmentlink_container(body, ctn_number):
    text = clean_text(body)
    if ctn_number not in text or "Estimated Date of Arrival" not in text:
        return {"found": False,
                "note": ("No record of this container was found in "
                         "Evergreen's system.")}
    out = {"found": True, "source": "Evergreen ShipmentLink",
           "direct_url": SL_URL, "containers": [ctn_number]}
    m = re.search(r"on B/L\s+(.+?)\s+Estimated Date of Arrival", text)
    if m:
        out["vessel"], out["voyage"] = _sl_split_voyage(m.group(1))
    m = re.search(r"Estimated Date of Arrival\s*:\s*"
                  r"([A-Z]{3}-\d{2}-\d{4})", text)
    if m:
        out["eta"] = _sl_date(m.group(1))
    m = re.search(re.escape(ctn_number) +
                  r"\s+(\S+)\s+([A-Z]{3}-\d{2}-\d{4})\s+(.+?)\s+"
                  r"([A-Z][A-Z ]+\([A-Z]{2}\))\s", text)
    if m:
        out["size_type"] = m.group(1)
        out["status"] = (f"{m.group(3).strip()} at "
                         f"{_sl_city(m.group(4))}")
        out["position"] = _sl_city(m.group(4))
    return out


def track_shipmentlink_container(ctn_number):
    """Container tracking on ShipmentLink (TYPE=CNTR)."""
    try:
        _, body = post_form(SL_URL, {"TYPE": "CNTR", "CNTR": ctn_number,
                                     "SEL": "s_cntr", "NO": ctn_number},
                            timeout=45)
    except Exception as e:
        return {"error": f"Could not reach ShipmentLink: {e}"}
    return _parse_shipmentlink_container(body, ctn_number)


# ---- Carrier-specific direct APIs (verified 19 Oct 2026) ----
def _cosco_date(s):
    """'2026-10-26 08:00' -> '26 Oct 2026'."""
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", (s or "").strip())
    if not m:
        return ""
    try:
        return datetime(int(m.group(1)), int(m.group(2)),
                        int(m.group(3))).strftime("%d %b %Y")
    except Exception:
        return ""


def track_cosco_api(bl_number):
    """COSCO's public cargo tracking API — without a browser.
    20 Oct 2026 fix: COAU BLs match inside using digits only
    (COAU6468005230 -> 6468005230), and trackingPath is a dict.
    The real vessel/ETA/status is built from legs (actualShipment)."""
    base = "https://elines.coscoshipping.com/ebtracking/public/bill"
    candidates = [bl_number]
    digits = re.sub(r"\D", "", bl_number)
    if digits and digits != bl_number:
        candidates.append(digits)
    content = None
    last_err = None
    responded = False
    for cand in candidates:
        try:
            data = get_json(f"{base}/{urllib.parse.quote(cand)}")
            responded = True
        except Exception as e:
            # F-10 fix (v46 audit): a failure on the full form must not
            # skip the digits-only candidate — that is the form that
            # actually resolves COAU BLs. Try every candidate first.
            last_err = e
            continue
        c = (data.get("data") or {}).get("content") or {}
        if c.get("isbillOfLadingExist"):
            content = c
            break
    if not content and not responded and last_err is not None:
        return {"error": f"Could not reach the COSCO API: {last_err}"}
    if not content:
        return {"found": False,
                "note": "No record of this BL was found in COSCO's system."}
    out = {"found": True, "source": "COSCO API"}
    tp = content.get("trackingPath") or {}
    pod_raw = ""
    if isinstance(tp, dict):
        pod_raw = tp.get("pod") or ""
        if "SAPT" in pod_raw:
            out["terminal"] = "SAPT"
        elif "KICT" in pod_raw:
            out["terminal"] = "KICT"
        elif "QICT" in pod_raw or "DP World" in pod_raw:
            out["terminal"] = "QICT"
        out["pol"] = (tp.get("fromCity") or "").split(",")[0].strip()
        out["pod"] = (tp.get("toCity") or "").split(",")[0].strip()
    legs = content.get("actualShipment") or content.get("actualShipmentPic") or []
    legs = [l for l in legs if l.get("vesselName")]
    if legs:
        first, last = legs[0], legs[-1]
        if not out.get("pol"):
            out["pol"] = first.get("portOfLoading", "")
        if not out.get("pod"):
            out["pod"] = last.get("portOfDischarge", "")
        out["vessel"] = last.get("vesselName", "")
        out["voyage"] = last.get("voyageNo", "")
        out["eta"] = _cosco_date(last.get("estimatedDateOfArrival"))
        if last.get("actualDischargeDate"):
            out["status"] = "Discharged"
            out["discharge_time"] = last["actualDischargeDate"]
        elif last.get("actualArrivalDate"):
            out["status"] = "Arrived"
        elif last.get("actualDepartureDate"):
            out["status"] = (f"In transit — departed "
                              f"{last.get('portOfLoading','')} "
                              f"{_cosco_date(last['actualDepartureDate'])}")
        # v96 FIX B: departed date in its own field too — tomorrow if
        # the status becomes 'Arrived'/'Discharged', this confirmed
        # date must still not be erased from the record.
        if last.get("actualDepartureDate"):
            out["departed"] = _cosco_date(last["actualDepartureDate"])
    ct = content.get("cargoTrackingContainer") or []
    ctns = [c.get("cntrNum") for c in ct if c.get("cntrNum")]
    if ctns:
        out["containers"] = ctns
    return out


def track_cosco_container_api(ctn_number):
    """COSCO's public container status API."""
    base = "https://elines.coscoshipping.com/ebtracking/public/container/status"
    try:
        data = get_json(f"{base}/{urllib.parse.quote(ctn_number)}")
    except Exception as e:
        return {"error": f"Could not reach the COSCO API: {e}"}
    items = (data.get("data") or {}).get("content") or []
    # remove empty (null) records
    live = [x for x in items if x.get("transportation") or x.get("pol")
            or x.get("pod") or x.get("location")]
    if not live:
        if items:
            return {"found": False, "empty_container": True,
                    "note": ("This container exists in COSCO's system but is not on "
                             "an active shipment — it may be empty or an old record.")}
        return {"found": False,
                "note": "No record of this container was found in COSCO's system."}
    v = live[0]
    return {"found": True, "source": "COSCO API",
            "vessel": v.get("transportation"), "pol": v.get("pol"),
            "pod": v.get("pod"), "eta": v.get("podEta"),
            "status": v.get("containerNumberStatus"),
            "location": v.get("location")}


def track_emkay_api(bl_number):
    """Emkay Line tracking (simple GET — emkayline.com)."""
    url = (f"https://emkayline.com/trackbyblno.php?txt_bl_no="
           f"{urllib.parse.quote(bl_number)}")
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach the Emkay website: {e}"}
    text = clean_text(body)
    # extract table rows (after the header)
    # format: CONTAINER NO. | LAST ACTIVITY | ACTIVITY DATE | Description
    rows = re.findall(
        r"<tr>(?!.*<th)(.*?)</tr>", body, re.S | re.I)
    data_rows = []
    for row in rows:
        cells = [clean_text(c).strip()
                 for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        cells = [c for c in cells if c]
        if cells:
            data_rows.append(cells)
    if not data_rows:
        return {"found": False,
                "note": ("No activity record for this BL in Emkay's system — "
                         "the BL number may be incorrect, or the shipment "
                         "has not been entered yet."),
                "direct_url": url}
    # first row: container, last activity, date, description
    r0 = data_rows[0]
    # NOTE: Emkay's table columns are CONTAINER | LAST ACTIVITY |
    # ACTIVITY DATE | DESCRIPTION — the date is the last-activity
    # date, NOT an ETA. Never label it as ETA (v28 audit fix).
    return {"found": True, "source": "Emkay Line",
            "direct_url": url,
            "status": r0[1] if len(r0) > 1 else "",
            "activity_date": r0[2] if len(r0) > 2 else "",
            "raw_snippet": " | ".join(r0)}


def track_emkay_container_api(ctn_number):
    """Emkay Line container tracking (trackbycno.php) — 20 Oct 2026 verified.
    Table: BL No | VESSEL | VOYAGE | LAST ACTIVITY | ACTIVITY DATE | REMARKS
    On a non-Emkay container the table comes back empty — safe extra layer."""
    url = (f"https://emkayline.com/trackbycno.php?txt_container_no="
           f"{urllib.parse.quote(ctn_number)}")
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach the Emkay website: {e}"}
    rows = re.findall(r"<tr>(?!.*<th)(.*?)</tr>", body, re.S | re.I)
    data_rows = []
    for row in rows:
        cells = [clean_text(c).strip()
                 for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        cells = [c for c in cells if c]
        if cells:
            data_rows.append(cells)
    if not data_rows:
        return {"found": False,
                "note": "No record of this container in Emkay's system.",
                "direct_url": url}
    r0 = data_rows[0]
    # Columns: BL | VESSEL | VOYAGE | LAST ACTIVITY | ACTIVITY DATE —
    # the last column is an activity date, NOT an ETA (v28 audit fix).
    return {"found": True, "source": "Emkay Line (container)",
            "direct_url": url,
            "bl_ref": r0[0] if len(r0) > 0 else "",
            "vessel": r0[1] if len(r0) > 1 else "",
            "voyage": r0[2] if len(r0) > 2 else "",
            "status": r0[3] if len(r0) > 3 else "",
            "activity_date": r0[4] if len(r0) > 4 else "",
            "raw_snippet": " | ".join(r0)}


_TERM_LABELS = ["Owner", "BL/ Shipping Bill No.", "Container No.",
    "Container Size/Type", "Category", "Status", "Vessel Voyage", "VIR No",
    "ETA", "ETD", "Discharge Time", "Load Time", "DO Issuance Date",
    "DO Expiry Date", "Gate In Time", "Gate Out Time", "Origin", "Destination",
    "Custom Seal No.", "Line Seal No.", "Security Seal No.", "Other Seal No.",
    "Custom Status", "Current Position", "Commodity", "Weight", "Weighment",
    "Scanning", "Present Holds"]


def _term_date(s):
    """'04-OCT-26 04.00.00 PM' or '13-OCT-2026 16:59' -> '04 Oct 2026'."""
    m = re.match(r"(\d{1,2})-([A-Za-z]{3})-(\d{2,4})", (s or "").strip())
    if not m:
        return ""
    try:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        return datetime(y, datetime.strptime(m.group(2).title(), "%b").month,
                        int(m.group(1))).strftime("%d %b %Y")
    except Exception:
        return ""


def _parse_term_details(body):
    """label->value dict from ContainerDetails HTML (skip N/A ones)."""
    cells = [clean_text(c).strip()
             for c in re.findall(r"<td[^>]*>(.*?)</td>", body, re.S | re.I)]
    out = {}
    for i, c in enumerate(cells):
        if c in _TERM_LABELS and i + 1 < len(cells):
            v = cells[i + 1]
            if v and v not in ("N/A", "/") and v not in _TERM_LABELS:
                out[c] = v
    return out


def _term_fetch_details(opener, host, bu, hdr, rows):
    """ContainerDetails for the first 6 history rows (2 tries each —
    the terminal site often returns an empty template). v99fix:
    cap 3 -> 6 so the listing rows of BLs with more containers (one
    stub per container) all get details — earlier the 4th+
    container's discharge/gate-out was left out of the count."""
    got = []
    for row in rows[:6]:
        pid = row.get("pid")
        if not pid:
            continue
        for _try in range(2):
            try:
                data = urllib.parse.urlencode(
                    {"cntrPK": pid, "BU": bu}).encode()
                req = urllib.request.Request(
                    f"{host}/Enquiries/ContainerDetails", data=data,
                    headers=hdr)
                dbody = opener.open(req, timeout=45).read().decode(
                    "utf-8", "replace")
                d = _parse_term_details(dbody)
                if d:
                    # v99: the detail keeps its source row's identity
                    # with it — the EM (empty-return) cycle's
                    # details are not included in the discharge/gate-out
                    # count (see _term_apply_details), and duplicate
                    # rows of the same container are counted
                    # as a single unit.
                    d["_ctn"] = row.get("CONTAINER NO", "")
                    d["_row_status"] = row.get("STATUS", "")
                    d["_row_gate_out"] = \
                        row.get("GATE OUT TIME", "") or ""
                    d["_row_discharge"] = \
                        row.get("DISCHARGING TIME", "") or ""
                    got.append(d)
                    break
            except Exception:
                pass
            time.sleep(1)
        time.sleep(0.6)
    return got


def _term_gate_key(s):
    """Turn the gate-out stamp into a datetime for ordering —
    a shipment's gate_out is the time ALL containers went out
    (the very last one), so the max is needed
    . If unparseable, datetime.min (while a real parsed
    stamp exists, a fake one will never become the max)."""
    s = str(s or "").strip()
    for fmt in ("%d-%b-%y %I.%M.%S %p", "%d-%b-%Y %H:%M",
                "%d-%b-%y %H:%M", "%d-%b-%Y %I:%M %p"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    d = _term_date(s)
    if d:
        try:
            return datetime.strptime(d, "%d %b %Y")
        except Exception:
            pass
    return datetime.min


def _term_apply_details(out, details):
    """Map parsed ContainerDetails onto the result dict. The terminal
    name comes ONLY from the VIR number (PKKHIKICT / PKKHISAPT) —
    never a combined label, never a guess.

    v99fix derivation discipline (truth table / Phase-1 fail,
    30 Oct 2026):
    - Export-cycle (XM/XF) details do not take part in any field
      — that is the record of the container's next voyage.
    - All fields will come from the IMPORT detail (d0 = first import detail)
      ; the EM detail is only for proof of the return.
    - Position only when that same detail holds an
      EVENT stamp (discharge / gate-out) of its cycle — without an event
      the position is a leftover from the previous cycle
      (COAU6468022200's 'Loaded on Vessel': the container had not
      even been discharged; the position was from the Jun voyage).
    - The import detail's 'Gate In Time' is the empty container's
      return stamp (in the import cycle, apart from this,
      there is no other gate-in) — save it with the 'empty_gate_in'
      marker (OOLU2337916330)."""
    def _row_st(d):
        return (d.get("_row_status") or "").strip().upper()

    usable = [d for d in details
              if _row_st(d) not in _EXPORT_ROW_STATUS]
    if not usable:
        return out
    imp = [d for d in usable if _row_st(d) != "EM"]
    if not imp:
        imp = list(usable)
    d0 = imp[0]
    vv = d0.get("Vessel Voyage", "")
    if " / " in vv:
        out["vessel"], out["voyage"] = [x.strip() for x in vv.split(" / ", 1)]
    elif vv:
        out["vessel"] = vv
    out["eta"] = _term_date(d0.get("ETA", ""))
    out["etd"] = _term_date(d0.get("ETD", ""))
    out["pol"] = d0.get("Origin", "")
    out["pod"] = d0.get("Destination", "")
    vir = ""
    for d in imp + usable:
        if d.get("VIR No"):
            vir = d["VIR No"]
            break
    if "KICT" in vir:
        out["terminal"] = "KICT"
    elif "SAPT" in vir:
        out["terminal"] = "SAPT"
    out["vir"] = vir
    # position event-anchored: only if the detail has this cycle's
    # discharge or gate-out stamp is its position
    # considered to belong to this cycle (see above).
    _anchored = any(_term_date(d0.get(k) or "") for k in
                    ("Discharge Time", "Gate Out Time",
                     "_row_discharge", "_row_gate_out"))
    out["position"] = d0.get("Current Position", "") \
        if _anchored else ""
    out["holds"] = d0.get("Present Holds", "")
    out["do_expiry"] = _term_date(d0.get("DO Expiry Date", ""))
    out["owner"] = d0.get("Owner", "")
    out["weight"] = d0.get("Weight", "")
    out["commodity"] = d0.get("Commodity", "")
    out["size_type"] = d0.get("Container Size/Type", "")
    out["custom_status"] = d0.get("Custom Status", "")
    out["category"] = d0.get("Category", "")
    out["gate_in"] = d0.get("Gate In Time", "")
    # the first actual gate-in of the import cycle = the empty return's
    # terminal stamp (with a provenance marker).
    for d in usable:
        _gi = d.get("Gate In Time") or ""
        if _gi and _term_date(_gi):
            out["empty_gate_in"] = _gi
            break
    # v99 (truth table 30 Oct 2026): discharge/gate-out
    # the count will be based only on IMPORT cycle details —
    # if details of the EM (empty-return) cycle were included
    # in this count, even a fully gate-out shipment would
    # become 'Partially discharged' and the actual
    # gate_out would disappear (MEDUT1383412: all three
    # containers out + returned, yet still 'Partially'). And duplicate
    # history rows of the same container (MCLSUB26104308:
    # one container, two discharge rows — one with gate-out,
    # one without) are ONE unit: either one's discharge /
    # gate_out is proof for that container; the empty row
    # cannot cancel it.
    # imp is already built at the start of the function above
    # (usable = non-export details; imp = the non-EM ones among them,
    # otherwise all usable).
    _units = {}
    for _i, d in enumerate(imp):
        _units.setdefault(d.get("_ctn") or f"#{_i}", []).append(d)

    def _pick(ds, key, rowkey):
        # v99fix (d): only a stamp that PARSES is proof —
        # the terminal writes 'N/A' for an empty gate-out;
        # that string used to create a 'Gate out' status
        # even though a gate_out date never existed
        # (internal contradiction in COAU6468022200: status 'Gate
        # out', gate_out NULL).
        for d in ds:
            if _term_date(d.get(key) or ""):
                return d[key]
        for d in ds:
            if _term_date(d.get(rowkey) or ""):
                return d[rowkey]
        return ""

    dis = [_pick(ds, "Discharge Time", "_row_discharge")
           for ds in _units.values()]
    out["discharge_time"] = dis[0] if dis else ""
    if dis and all(dis):
        out["status"] = "Discharged"
    elif any(dis):
        out["status"] = "Partially discharged"
    gate = [_pick(ds, "Gate Out Time", "_row_gate_out")
            for ds in _units.values()]
    if gate and all(gate):
        out["status"] = "Gate out"
        # the shipment's gate_out = gate-out of the last container
        # (MEDUT1385110: the first container's stamp being applied
        # caused the second container's 29-Oct gate-out to be hidden
        # ).
        out["gate_out"] = max(gate, key=_term_gate_key)
    return out


def _term_history(host, bu, params):
    """One terminal session: enquiry page (affinity cookie) ->
    ContainerHistory. Returns (opener, hdr, rows) or an error dict."""
    hdr = {**UA, "X-Requested-With": "XMLHttpRequest",
           "Referer": f"{host}/Enquiries?is=ContainerBLEnquiry"}
    try:
        cj = http.cookiejar.CookieJar()
        op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(cj))
        req = urllib.request.Request(
            f"{host}/Enquiries/ContainerBLEnquiry", headers=hdr)
        op.open(req, timeout=30).read()
        q = urllib.parse.urlencode(params)
        req = urllib.request.Request(
            f"{host}/Enquiries/ContainerHistory?{q}", headers=hdr)
        body = op.open(req, timeout=30).read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": str(e)}
    m = re.search(r'"_jsonArray":"((?:\\.|[^"\\])*)"', body)
    if not m:
        # the page arrived but had no data section at all — the site
        # was busy or no session was created. This is NOT proof that "no record
        # exists"; calling it an error is the honest thing to do
        # (the 17:11 mistake: on an empty response the app had declared both
        # containers Not found).
        return {"error": "terminal returned a page without data"}
    try:
        import json as _json
        rows = _json.loads(_json.loads('"' + m.group(1) + '"'))
    except Exception:
        return {"error": "terminal data could not be read"}
    if not isinstance(rows, list):
        return {"error": "terminal data could not be read"}
    rows = [r for r in rows
            if isinstance(r, dict) and r.get("CONTAINER NO")
            and r["CONTAINER NO"] != "N/A"]
    if not rows:
        return {"found": False}
    return (op, hdr, rows)


def _term_row_ts(row):
    """The latest date (datetime) of a history row — for cycle
    identification. If no date is found, None."""
    best = None
    for k in ("DISCHARGING TIME", "GATE OUT TIME", "GATE In TIME",
              "LOADING TIME"):
        d = _term_date(row.get(k) or "")
        if d:
            try:
                dt = datetime.strptime(d, "%d %b %Y")
            except Exception:
                continue
            if best is None or dt > best:
                best = dt
    return best


def _term_current_rows(rows):
    """A container's history also contains ghost rows from the PREVIOUS voyage
    (for example a 2024 row alongside a 2026 record) — they spoiled both the count and
    the status (a gate-out shipment would become 'Partially
    discharged'). Keep only the rows of the CURRENT cycle:
    those within 150 days of the latest row; for a container with no
    dated row at all, keep its rows exactly as they are."""
    by_ctn = {}
    for r in rows:
        by_ctn.setdefault(r.get("CONTAINER NO", ""), []).append(r)
    keep = []
    for ctn, rs in by_ctn.items():
        dated = [(r, _term_row_ts(r)) for r in rs]
        dated = [(r, t) for r, t in dated if t is not None]
        if not dated:
            keep.extend(rs)
            continue
        newest = max(t for _, t in dated)
        keep.extend(r for r, t in dated
                    if (newest - t).days <= 150)
    return keep or rows


# v99fix: STATUS codes of history rows — XM/XF are rows of the container's
# NEXT (export) cycle. Their details can never become proof for this import
# BL (COAU6468022200: there was only a
# Jun-2026 XM row, and from its details a 'Loaded on Vessel'
# position and a 'Gate out' status on 'N/A' had been created).
_EXPORT_ROW_STATUS = {"XM", "XF"}


def _term_finish(host, bu, hdr, op, rows):
    rows = _term_current_rows(rows)
    out = {"found": True, "terminal": "", "containers": rows,
           "source": "Karachi Terminal (Hutchison Ports)"}
    # v99: fetch details of IMPORT (IF) rows first — EM
    # (empty-return) row details show the empty container back
    # in the yard, not the import cycle's
    # position/discharge (if they arrived first,
    # a complete shipment would become 'Partially discharged'
    # — MEDUT1383412, truth table 30 Oct 2026).
    rows = sorted(rows, key=lambda r: (
        (r.get("STATUS") or "").strip().upper() == "EM"))
    # v99fix: details of export-cycle (XM/XF) rows are never
    # fetched — that is the container's next life, not this BL's.
    # Rows remain in the stored record (as proof),
    # but they do not take part in the derivation.
    det_rows = [r for r in rows
                if (r.get("STATUS") or "").strip().upper()
                not in _EXPORT_ROW_STATUS]
    details = _term_fetch_details(op, host, bu, hdr, det_rows)
    if len(details) > 1:
        # belt-and-braces: details that do not match the VIR of the earlier (existing) record
        # are from the ghost cycle — excluded from the count.
        # v99fix: the anchor is always the VIR of the IMPORT detail
        # (the EM detail's VIR may also be from the next cycle).
        vir0 = ""
        for d in details:
            if (d.get("_row_status") or "").strip().upper() != "EM" \
                    and d.get("VIR No"):
                vir0 = d["VIR No"]
                break
        if not vir0:
            vir0 = details[0].get("VIR No", "")
        if vir0:
            same = [d for d in details if d.get("VIR No") == vir0]
            if same:
                details = same
    if not any(d.get("Vessel Voyage") or d.get("ETA") for d in details):
        try:
            cj2 = http.cookiejar.CookieJar()
            op2 = urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(cj2))
            req = urllib.request.Request(
                f"{host}/Enquiries/ContainerBLEnquiry", headers=hdr)
            op2.open(req, timeout=30).read()
            details2 = _term_fetch_details(op2, host, bu, hdr, det_rows)
            if any(d.get("Vessel Voyage") or d.get("ETA")
                   for d in details2) or (details2 and not details):
                details = details2
        except Exception:
            pass
    # v112 (Yousuf, 4 Nov): without a VIR, no Karachi record
    # becomes current. A result with bare rows has no
    # discharge/eta/vir date, so all the
    # old-record guards (_stale_info/_prev_cycle) were blind
    # and the July-2026 EXPORT row (CBHU5680350)
    # had become "Arrived at Karachi terminal". Rule:
    # export-only rows, or those whose last movement is 30+ days
    # old and no VIR detail was built — are simply not
    # found; a clear note will go in the layer (the QICT behaviour).
    if not any((d.get("VIR No") or "").strip() for d in details):
        import datetime as _dtv
        _rows = out.get("containers") or []
        _exp_only = bool(_rows) and all(
            (r.get("STATUS") or "").strip().upper()
            in _EXPORT_ROW_STATUS for r in _rows)
        _ts = [t for t in (_term_row_ts(r) for r in _rows)
               if t is not None]
        _newest = max(_ts) if _ts else None
        if isinstance(_newest, _dtv.datetime):
            _newest = _newest.date()
        _old = (_newest is not None and
                (_dtv.date.today() - _newest).days > 30)
        if _exp_only or _old:
            _when = (_newest.strftime("%d %b %Y")
                     if _newest else "an unknown date")
            return {"found": False,
                    "note": (f"Karachi terminal holds only an "
                             f"OLD record for this number (last "
                             f"activity {_when}) — from a "
                             f"previous trip. Not counted as a "
                             f"current record.")}
        out["no_vir"] = True
    if details:
        _term_apply_details(out, details)
    return out


def _term_history_retry(host, bu, params, tries=3):
    """On error, retry _term_history again with a fresh session —
    the terminal site often gives an empty answer on the first try
    and gives the record on the second."""
    r = {"error": "no attempt made"}
    for i in range(tries):
        r = _term_history(host, bu, params)
        if isinstance(r, tuple) or not r.get("error"):
            return r
        if i < tries - 1:
            time.sleep(2)
    return r


def track_terminal_bl(bl_number, host, bu):
    """Hutchison terminal (KICT/SAPT) full enquiry by BL number —
    verified 20 Oct 2026. One cookie session: enquiry page ->
    ContainerHistory (method=B) -> ContainerDetails per container."""
    r = _term_history_retry(host, bu, {"cntrNum": "",
                                       "BL": f"{bl_number}_1",
                                       "method": "B", "pTId": bu})
    if not isinstance(r, tuple):
        return r
    op, hdr, rows = r
    return _term_finish(host, bu, hdr, op, rows)


def track_terminal_container(ctn_number, host, bu):
    """Same terminal enquiry by CONTAINER number (method=C) —
    history step verified live 20 Oct 2026: it returns the same
    _jsonArray rows (with pid), so details work identically."""
    r = _term_history_retry(host, bu, {"cntrNum": ctn_number,
                                       "BL": "", "method": "C",
                                       "pTId": bu})
    if not isinstance(r, tuple):
        return r
    op, hdr, rows = r
    return _term_finish(host, bu, hdr, op, rows)


TERMINAL_HOSTS = [("KICT", "https://www.kictl.com"),
                  ("SAPT", "https://www.sapt.com.pk")]


def track_karachi_terminals(bl_number):
    """Try each Hutchison host in turn. The two hosts share one
    database, but the details call is unreliable: if the first host
    finds the containers yet returns no details (no vessel / ETA /
    discharge), the second host is tried as well and the richest
    result wins."""
    best = {"found": False}
    saw_error = False
    stale_note = ""
    for bu, host in TERMINAL_HOSTS:
        r = track_terminal_bl(bl_number, host, bu)
        if r.get("found"):
            _st, _wh = _stale_info(r)
            if _st:
                # v54: at the terminal, this number has only an OLD
                # record (from the previous voyage — container
                # numbers are reused). Making it this
                # shipment's result is wrong; at QICT
                # this guard already existed, here it was missing
                # (on CAIU4648550, the Jul 2023 record came into the 2026
                # BL's result).
                stale_note = (
                    f"Karachi terminal holds only an OLD record "
                    f"for this BL ({_wh}) — from a previous trip. "
                    f"Container numbers are reused, so this is "
                    f"not counted as a current record.")
                continue
            if r.get("vessel") or r.get("eta") or r.get("discharge_time"):
                return r
            if not best.get("found"):
                best = r
        elif r.get("error"):
            saw_error = True
    if not best.get("found"):
        # F-01 fix (v46 audit): a clean no-record from both hosts used to
        # leave NO note at all -> the layer showed an empty detail. The
        # note must say which case it actually was.
        if stale_note:
            best["note"] = stale_note
        elif saw_error:
            best["note"] = "The Karachi terminal sites did not respond."
        else:
            best["note"] = "No record at KICT or SAPT for this BL."
    return best


def track_karachi_terminals_container(ctn_number):
    """Container-number version of track_karachi_terminals: both
    Hutchison hosts share one database; richest result wins."""
    best = {"found": False}
    saw_error = False
    stale_note = ""
    for bu, host in TERMINAL_HOSTS:
        r = track_terminal_container(ctn_number, host, bu)
        if r.get("found"):
            _st, _wh = _stale_info(r)
            if _st:
                # v54: the same guard as for BL, on the container route too
                # (the Jul 2023 record had come through this very route).
                stale_note = (
                    f"Karachi terminal holds only an OLD record "
                    f"for this container ({_wh}) — from a "
                    f"previous trip. Container numbers are "
                    f"reused, so this is not counted as a "
                    f"current record.")
                continue
            if r.get("vessel") or r.get("eta") or r.get("discharge_time"):
                return r
            if not best.get("found"):
                best = r
        elif r.get("error"):
            saw_error = True
        elif "OLD record" in (r.get("note") or ""):
            # v112: the old-record note from _term_finish
            # must not disappear in the picker — the "without telling"
            # mistake used to originate right here.
            if not stale_note:
                stale_note = r["note"]
    if not best.get("found"):
        if stale_note:
            best["note"] = stale_note
        elif saw_error:
            best["note"] = "The Karachi terminal sites did not respond."
        else:
            best["note"] = "No record at KICT or SAPT for this container."
    return best


QICT_API = "https://lfs.qict.com.pk/API/api/ds/v1/BL-Inquiry"


def track_qict_bl(bl_number):
    """QICT (DP World Karachi) public BL inquiry — 20 Oct 2026 verified.
    It is the public API of their own website (lfs.qict.com.pk); Emkay/RTW
    -type NVOCC cargo is often found here. The API is slow (~25s), so
    2 attempts are made. The response is double-encoded JSON."""
    import json as _json
    payload = urllib.parse.urlencode({
        "blno": bl_number, "UserID": "Test", "Password": "Test123",
        "Cellno": "123456"}).encode()
    # QICT's server is flaky: it often answers with an EMPTY body when
    # busy, which must never be read as "not found". Retry on empty
    # answers as well as on errors — only a real row ends the loop.
    rows = None
    for _try in range(4):
        try:
            req = urllib.request.Request(QICT_API, data=payload, headers={
                **UA, "Referer": "https://lfs.qict.com.pk/",
                "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                raw = resp.read().decode("utf-8", "replace").strip()
            parsed = _json.loads(raw) if raw else ""
            if isinstance(parsed, str):
                parsed = _json.loads(parsed) if parsed else []
            if parsed:
                rows = parsed
                break
        except Exception:
            pass
        time.sleep(2.5)
    if not rows:
        return {"found": False,
                "note": "No record was returned by QICT on this check."}
    r0 = rows[0]
    # Aggregate across ALL container rows (v28 audit fix): a BL with
    # several containers must not inherit the first row's standing
    # when another container is on hold or still in the yard.
    standings = [(r.get("STANDING") or "").strip().upper() for r in rows]
    trucks = [(r.get("TRUCK_IN_YARD") or "").strip().lower() for r in rows]
    positions = {(r.get("POSITION") or "").strip() for r in rows}
    positions.discard("")
    if "HOLD" in standings:
        status = "On hold at QICT"
    elif standings and all(x == "RELEASED" for x in standings) \
            and all(t == "delivered" for t in trucks if t):
        status = "Released — Delivered"
    elif standings and all(x == "RELEASED" for x in standings):
        status = "Released at QICT"
    elif standings[0]:
        status = f"At QICT — {standings[0].title()}"
    else:
        # v99: QICT is at Port Qasim, NOT at Karachi —
        # the terminal's city will also come from that same one truth.
        status = "At QICT terminal (Port Qasim)"
    position = (positions.pop() if len(positions) == 1
                else ("Multiple positions" if positions
                      else r0.get("POSITION", "")))
    truck = (trucks[0] if len(set(trucks)) == 1 else "")
    out = {"found": True, "terminal": "QICT", "source": "QICT (DP World)",
           "containers": [r.get("EQ_NBR") for r in rows if r.get("EQ_NBR")],
           "status": status, "position": position,
           "category": r0.get("CATEGORY", ""), "truck": truck,
           "gd_no": r0.get("GD_NO", ""),
           "qict_rows": rows}
    # container details (vessel, discharge, holds) before Ctr-Inq
    ctn0 = out["containers"][0] if out["containers"] else ""
    if ctn0:
        det = track_qict_container(ctn0)
        for k in ("vessel", "voyage", "discharge_time", "holds", "line",
                  "pod", "vir"):
            if det.get(k):
                out[k] = det[k]
    return out


QICT_CTR_API = "https://lfs.qict.com.pk/API/api/ds/v1/Ctr-Inq"


def track_qict_container(ctn_number):
    """QICT Ctr-Inq — full details of a container (vessel/voyage, discharge
    time, VIR, holds, shipping line). 20 Oct 2026 verified, fast (~1s)."""
    import json as _json
    payload = urllib.parse.urlencode({
        "ctrnbr": ctn_number, "UserID": "Test", "Password": "Test",
        "Cellno": "123456"}).encode()
    fields = {}
    for _try in range(2):
        try:
            req = urllib.request.Request(QICT_CTR_API, data=payload,
                headers={**UA, "Referer": "https://lfs.qict.com.pk/",
                         "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                raw = resp.read().decode("utf-8", "replace").strip()
            parsed = _json.loads(raw) if raw else ""
            if isinstance(parsed, str):
                parsed = _json.loads(parsed) if parsed else []
            fields = {i.get("FIELD_NAME", ""): i.get("FIELD_VALUE", "")
                      for i in (parsed or [])}
            if fields:
                break
        except Exception:
            fields = {}
        time.sleep(1.5)
    if not fields:
        return {}
    out = {"vessel": fields.get("Vessel", ""),
           "voyage": fields.get("Voyage", ""),
           "holds": fields.get("Hold Description", "").rstrip(","),
           "line": fields.get("Shipping Line", ""),
           "pod": fields.get("Port Of Discharge", ""),
           "vir": fields.get("VIR #", ""),
           "discharge_time": fields.get("Discharge Time", ""),
           # v99 (truth table 30 Oct 2026): these fields were always
           # present in the QICT response — the parser used to discard
           # them, so every QICT gate-out remained without a date
           # (EMKAYMBAKHI59055's gate-out
           # was recorded in 'Out Time' as 28-OCT-2026 00:12).
           # 'Out Time' itself is the terminal proof of gate-out;
           # Position/Truck are the actual fields of that same record.
           # On the EXPORT cycle, 'In Time' is the empty container's
           # return to the terminal (gate-in) and 'Load Time' is its
           # loading onto the vessel (EMKAYMBAKHI57984).
           # 'Empty Return Location' is ONLY the name of the
           # designated yard — NOT proof of return, so it
           # has deliberately not been taken here.
           "gate_out": fields.get("Out Time", ""),
           "position": fields.get("Position", ""),
           "truck": (fields.get("Truck In Yard", "")
                     or "").strip().lower(),
           "category": fields.get("Category", ""),
           "in_time": fields.get("In Time", ""),
           "load_time": fields.get("Load Time", "")}
    return {k: v for k, v in out.items() if v}


KGTL_URL = "https://www.kgtl.com.pk/en/online-tracking"


def _kgtl_search(term, radio):
    """KGTL (Karachi Gateway Terminal — AD Ports, East Wharf)
    public Online Tracking. It is ASP.NET WebForms: first the radio
    (rdioBL / rdioCon) postback, then the search POST — three
    requests, no login. On 25 Oct 2026, on a real BL/container,
    verified. It returns the response HTML; if the site is not found, None."""
    import http.cookiejar as _cj
    cj = _cj.CookieJar()
    op = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [("User-Agent", UA["User-Agent"])]

    def _fields(h):
        d = {}
        for n in ("__VIEWSTATE", "__VIEWSTATEGENERATOR",
                  "__EVENTVALIDATION"):
            m = re.search(rf'name="{n}"[^>]*value="([^"]*)"', h or "")
            d[n] = m.group(1) if m else ""
        return d

    try:
        h = op.open(KGTL_URL, timeout=30).read().decode("utf-8", "ignore")
        d = _fields(h)
        d.update({"__EVENTTARGET": radio, "__EVENTARGUMENT": "",
                  "radio": radio})
        h = op.open(urllib.request.Request(
            KGTL_URL, data=urllib.parse.urlencode(d).encode(),
            method="POST"), timeout=30).read().decode("utf-8", "ignore")
        d = _fields(h)
        d.update({"__EVENTTARGET": "", "__EVENTARGUMENT": "",
                  "txtSearch": term, "radio": radio,
                  "btnSearch": "Search"})
        return op.open(urllib.request.Request(
            KGTL_URL, data=urllib.parse.urlencode(d).encode(),
            method="POST"), timeout=30).read().decode("utf-8", "ignore")
    except Exception:
        return None


def _kgtl_span(html, sid):
    m = re.search(rf'id="{sid}"[^>]*>([^<]*)<', html or "")
    return m.group(1).strip() if m else ""


def _kgtl_activities(html):
    """KGTL container page's Activity table (Activity | Performed
    Time) as a list of {'activity': ..., 'time': ...}. The table has
    no grid id; it is found by its 'Activity' header cell."""
    acts = []
    m = re.search(r"<table[^>]*>(?:(?!</table>).)*?>Activity<.*?</table>",
                  html or "", re.S)
    if not m:
        return acts
    for tr in re.findall(r"<tr>(.*?)</tr>", m.group(0), re.S):
        tds = [re.sub(r"<[^>]+>", "", c).strip()
               for c in re.findall(r"<td>(.*?)</td>", tr, re.S)]
        if len(tds) >= 2 and tds[0] and tds[0].lower() != "activity":
            acts.append({"activity": tds[0], "time": tds[1]})
    return acts


# Tare (empty) weight ceilings by container size: a unit at or under
# this weight is carrying no cargo. 40ft high-cube tare is ~3,800 kg;
# the ceiling leaves margin for heavier reefers/tanks of the same size.
_KGTL_TARE_MAX = {"20": 3000, "40": 4500, "45": 4800}


def _kgtl_visit_kind(det):
    """Classify one KGTL container visit from ALL its fields together
    (the KGTL trace mapping — 6 Nov 2026, BL 142G512846):

    - 'import': the visit carries a VIR or a vessel — it belongs to a
      vessel cycle.
    - 'empty_storage': NO VIR and NO vessel, category 'Storage' (or a
      gate-in with no discharge event), and the weight is at tare
      level for the size. This is the EMPTY unit coming back by road
      after delivery — a NEW visit that REPLACES the import visit on
      KGTL's page. Reading it as the import record (its holds, its
      'In Yard') was the 142G512846 defect: the loaded unit had
      departed, the empty was back, and the record stayed
      'On hold — discharged, in yard' for ever.
    - 'unknown': anything else — no inference is made."""
    if (det.get("vir") or "").strip() or (det.get("vessel") or "").strip():
        return "import"
    acts = det.get("activities") or []
    names = {(a.get("activity") or "").strip().upper() for a in acts}
    wm = re.search(r"(\d[\d,]*)", str(det.get("weight") or ""))
    kg = int(wm.group(1).replace(",", "")) if wm else None
    size = str(det.get("size_type") or "")
    cap = _KGTL_TARE_MAX.get(size.strip().rstrip("'").strip(),
                             4500)
    tare = kg is not None and kg <= cap
    gated_in = "UNIT_IN_GATE" in names
    discharged = any("DISCHARGE" in n for n in names)
    if (det.get("category") or "").strip().lower() == "storage" \
            and tare and gated_in and not discharged:
        return "empty_storage"
    if gated_in and not discharged and tare:
        return "empty_storage"
    return "unknown"


def track_kgtl_bl(bl_number):
    """KGTL BL inquiry — BL panel (vessel, VIR, ATA/ATD) +
    container grid (number/size/yard state). First the container's
    details (holds, ETA, voyage) are also taken via the container route
    — the same method as the QICT BL layer."""
    html = _kgtl_search(bl_number, "rdioBL")
    if html is None:
        return {"found": False, "note": "The KGTL site did not respond."}
    if "Not found" in html or not _kgtl_span(html, "BLlblBLNbr"):
        return {"found": False,
                "note": "No record at KGTL for this BL."}
    rows = []
    gm = re.search(r'id="BLContainerGrid".*?</table>', html, re.S)
    if gm:
        for tr in re.findall(r"<tr>(.*?)</tr>", gm.group(0), re.S):
            tds = [re.sub(r"<[^>]+>", "", c).strip()
                   for c in re.findall(r"<td>(.*?)</td>", tr, re.S)]
            if len(tds) >= 3 and tds[0]:
                rows.append({"CONTAINER NO": tds[0], "SIZE": tds[1],
                             "LOCATION": tds[2]})
    containers = [r["CONTAINER NO"] for r in rows]
    states = [(r["LOCATION"] or "").strip().lower() for r in rows]
    ata = _kgtl_span(html, "BLlblATA")
    # KGTL trace mapping: the BL grid's per-container state is the
    # terminal's own word for that container's import cycle. 'Departed'
    # means the loaded unit has LEFT — gate-out evidence (KGTL gives
    # no date for it), not 'at terminal'.
    departed_all = bool(states) and all(x == "departed" for x in states)
    if states and all(x == "in yard" for x in states):
        status = "Discharged at KGTL — in yard"
    elif departed_all:
        status = "Gate out at KGTL"
    elif any(x == "in yard" for x in states):
        status = "Partially discharged at KGTL"
    elif ata:
        status = "At KGTL terminal (Karachi)"
    else:
        status = "Expected at KGTL (Karachi)"
    out = {"found": True, "terminal": "KGTL",
           "source": "KGTL (Karachi Gateway Terminal)",
           "containers": containers, "terminal_rows": rows,
           "status": status,
           "vessel": _kgtl_span(html, "BLlblVesselName"),
           "vir": _kgtl_span(html, "BLlblVIRNbr"),
           "release_code": _kgtl_span(html, "BLlblReleaseCode"),
           "ata": ata, "atd": _kgtl_span(html, "BLlblATD"),
           "pod": _kgtl_span(html, "BLlblDestination")}
    if status.startswith("Expected"):
        out["expected"] = True
    if departed_all:
        out["kgtl_departed"] = True
    if len(set(states)) == 1 and states:
        out["position"] = "OUT" if states[0] == "departed" \
            else rows[0]["LOCATION"]
    if containers:
        det = track_kgtl_container(containers[0])
        if det.get("found"):
            if det.get("visit_kind") == "empty_storage":
                # The container page now shows the NEXT visit (the
                # empty unit in storage). Its holds belong to the
                # empty unit, NOT to this import cycle — never lift
                # them as current holds; carry the visit as return
                # evidence instead.
                if det.get("holds"):
                    out["kgtl_empty_holds"] = det["holds"]
                if det.get("kgtl_empty_in"):
                    out["kgtl_empty_in"] = det["kgtl_empty_in"]
            else:
                for k in ("voyage", "eta", "etd", "pol", "holds",
                          "weight", "commodity", "size_type", "category"):
                    if det.get(k) and not out.get(k):
                        out[k] = det[k]
                if det.get("holds") and states and \
                        all(x == "in yard" for x in states):
                    out["status"] = "On hold at KGTL — discharged, in yard"
    return {k: v for k, v in out.items() if v or k in
            ("found", "terminal", "source", "containers",
             "terminal_rows", "status")}


def track_kgtl_container(ctn_number):
    """KGTL container inquiry — gives more detail than the BL:
    ETA/ETD, ATA/ATD, holds, ground date, voyage, weight.
    25 Oct 2026 verified (WHSU5010543)."""
    html = _kgtl_search(ctn_number, "rdioCon")
    if html is None:
        return {"found": False, "note": "The KGTL site did not respond."}
    if "Not found" in html or not _kgtl_span(html, "lblContainer"):
        return {"found": False,
                "note": "No record at KGTL for this container."}
    st = _kgtl_span(html, "lblStatus")
    ata = _kgtl_span(html, "lblATA")
    holds = _kgtl_span(html, "lblHolds")
    acts = _kgtl_activities(html)
    visit_probe = {"vir": _kgtl_span(html, "lblVIRNo"),
                   "vessel": _kgtl_span(html, "lblVessel"),
                   "category": _kgtl_span(html, "lblCategory"),
                   "weight": _kgtl_span(html, "lblWeight"),
                   "size_type": _kgtl_span(html, "lblSize"),
                   "activities": acts}
    vkind = _kgtl_visit_kind(visit_probe)
    if vkind == "empty_storage":
        # The unit on this page is the EMPTY container back in
        # storage after delivery — it was never discharged in this
        # visit, so no discharged/on-hold import status may be
        # claimed from it. Its gate-in time is the return evidence
        # (consumed by _settle_empty_return).
        status = "Empty at KGTL — in storage (returned)"
    elif holds and st.lower() == "in yard":
        # the container has been discharged, is in the yard AND is also
        # on hold — both facts in the status; writing only "on hold"
        # meant the milestone engine could not see the
        # discharge (caught in v61 live QA).
        status = "On hold at KGTL — discharged, in yard"
    elif holds:
        status = "On hold at KGTL"
    elif st.lower() == "in yard":
        status = "Discharged at KGTL — in yard"
    elif st:
        status = f"At KGTL — {st}"
    elif ata:
        status = "At KGTL terminal (Karachi)"
    else:
        status = "Expected at KGTL (Karachi)"
    out = {"found": True, "terminal": "KGTL",
           "source": "KGTL (Karachi Gateway Terminal)",
           "containers": [ctn_number], "status": status,
           "bl": _kgtl_span(html, "lblBLNbr"),
           "vessel": _kgtl_span(html, "lblVessel"),
           "voyage": _kgtl_span(html, "lblVoyage"),
           "vir": _kgtl_span(html, "lblVIRNo"),
           "eta": _kgtl_span(html, "lblETA"),
           "etd": _kgtl_span(html, "lblETD"),
           "ata": ata, "atd": _kgtl_span(html, "lblATD"),
           "pol": _kgtl_span(html, "lblPOL"),
           "pod": _kgtl_span(html, "lblPOD"),
           "holds": holds,
           "position": _kgtl_span(html, "lblPosition") or st,
           "weight": _kgtl_span(html, "lblWeight"),
           "commodity": _kgtl_span(html, "lblDescription"),
           "size_type": _kgtl_span(html, "lblSize"),
           "category": _kgtl_span(html, "lblCategory"),
           "ground_date": _kgtl_span(html, "lblGroundDate"),
           "released": _kgtl_span(html, "lblReleased"),
           "release_code": _kgtl_span(html, "lblReleaseCode"),
           "activities": acts,
           "visit_kind": vkind}
    if vkind == "empty_storage":
        for a in acts:
            if (a.get("activity") or "").strip().upper() == \
                    "UNIT_IN_GATE" and a.get("time"):
                out["kgtl_empty_in"] = a["time"]
    if status.startswith("Expected"):
        out["expected"] = True
    return {k: v for k, v in out.items() if v or k in
            ("found", "terminal", "source", "containers", "status")}


def _parse_det_date(s):
    """'18-OCT-26', '18 Oct 2026', '21 Nov 2022', '2026-10-18'
    -style dates — including 2-digit years (KICT often
    writes '18-OCT-26', which the old regex could not
    parse). If not found, None."""
    import datetime as _dt
    s = str(s or "")
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        try:
            return _dt.date(int(m.group(1)), int(m.group(2)),
                            int(m.group(3)))
        except Exception:
            return None
    m = re.search(r"(\d{1,2})[- ]([A-Za-z]{3})[A-Za-z]*[- ]"
                  r"(\d{4}|\d{2})\b", s)
    if not m:
        return None
    y = int(m.group(3))
    if y < 100:
        y = 2000 + y if y <= 69 else 1900 + y
    try:
        return _dt.datetime.strptime(
            f"{m.group(1)} {m.group(2)} {y}", "%d %b %Y").date()
    except Exception:
        return None


def _prev_cycle(res, out):
    """Does the container-mode record belong to this shipment's voyage or
    to the container's PREVIOUS voyage? A discharge/gate-out 45+ days behind
    this shipment's ETA from the line/vessel leg
    cannot possibly belong to this BL (caught on COAU6468022200:
    the container's old June cycle was turning the Oct in-transit BL
    into 'Gate out')."""
    eta = _parse_det_date((out.get("result") or {}).get("eta"))
    if not eta:
        return False
    evs = []
    for k in ("discharge_time", "gate_out"):
        d = _parse_det_date(res.get(k))
        if d:
            evs.append(d)
    if not evs:
        return False
    return (eta - max(evs)).days > 45


def _stale_info(det):
    """If the record's date is older than 150 days, (True, 'Nov 2022').
    Container numbers are reused — QICT sometimes returns the previous
    voyage's record (on CXDU1175597, a Nov 2022
    MSC JOANNA record was found, while the real voyage was in 2026).
    v54: the date is also taken from ETA besides discharge_time
    , 2-digit years also work, and the last 8 digits of the VIR
    are counted only when the year is plausible — KICT's
    VIR ('PKKHIKICT_121026100008') ends on a serial
    that was mistakenly read as year 0008 and a correct record
    would be declared old."""
    import datetime as _dt
    dates = []
    for key in ("discharge_time", "eta"):
        d = _parse_det_date(det.get(key))
        if d:
            dates.append(d)
    vir = str(det.get("vir") or "")
    m2 = re.search(r"(\d{2})(\d{2})(\d{4})\s*$", vir)
    if m2:
        try:
            d = _dt.date(int(m2.group(3)), int(m2.group(2)),
                         int(m2.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    # v55: QICT's VIR carries its own date itself —
    # 'PKBQMQICT_100226152301' = DDMMYY + HHMMSS (10 Feb 2026).
    # Even if Discharge/ETA are empty, the guard still gets this date;
    # the Feb 2026 previous-voyage details used to come out as 'At QICT terminal'
    # (BMOU2755409 / MOAU0774432).
    m3 = re.search(r"QICT_(\d{2})(\d{2})(\d{2})\d{6}\s*$", vir)
    if m3:
        try:
            _yy = int(m3.group(3))
            _yy = 2000 + _yy if _yy <= 69 else 1900 + _yy
            d = _dt.date(_yy, int(m3.group(2)), int(m3.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    # v61: KGTL's VIR also carries its own date —
    # 'PKKHIKGTL_101026105335' = DDMMYY + HHMMSS (10 Oct 2026).
    # A guard on one source must be on every source — without KGTL's
    # guard, its old records could also have appeared as new.
    m4 = re.search(r"KGTL_(\d{2})(\d{2})(\d{2})\d{6}\s*$", vir)
    if m4:
        try:
            _yy = int(m4.group(3))
            _yy = 2000 + _yy if _yy <= 69 else 1900 + _yy
            d = _dt.date(_yy, int(m4.group(2)), int(m4.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    if not dates:
        return (False, "")
    newest = max(dates)
    age = (_dt.date.today() - newest).days
    return (age > 150, newest.strftime("%b %Y"))


def track_qict_container_layer(ctn_number):
    """QICT as a primary layer for a bare container number: Ctr-Inq
    answers in ~1s with vessel, discharge, holds and VIR."""
    det = track_qict_container(ctn_number)
    if not det:
        return {"found": False,
                "note": "No record was returned by QICT on this check."}
    _stale, _when = _stale_info(det)
    if _stale:
        return {"found": False,
                "note": (f"QICT holds only an OLD record for this "
                         f"container ({_when}) — from a previous trip. "
                         "Container numbers are reused, so this is not "
                         "counted as a current record.")}
    if (det.get("category") or "").strip().upper() == "EXPORT" \
            and det.get("in_time"):
        # v99fix3 (30 Oct 2026, Phase-2 retest FAIL): ONE
        # rule, on both routes — an export gate-in is never
        # an empty return. The QICT row itself proves
        # this: Category EXPORT, Status FULL/LCL
        # (loaded export cargo, not an empty container),
        # Position Vessel + a later Load Time (the container
        # went loaded onto the vessel — an empty container returned
        # to the depot does not go onto a vessel as FULL cargo
        # ). This is the same form as the SAPT XF row (1016),
        # on which Fix Round 2 + Audit had
        # decided 'NOT a return'. The row for 57984
        # is also of this same form — so its returned
        # is also re-derived by this same rule (see
        # _settle_empty_return below). A return is proved only by an EM row;
        # QICT does not provide any structured
        # empty-return at all. In this situation, BL-Inquiry
        # becomes empty — this does not mean 'not
        # found', it means 'cycle complete'. Therefore
        # the writer does not write returned — only the closed-cycle
        # proof (export In/Load Time) is passed forward
        # so that _settle can recognise the old incorrect returned
        # and retract it. The export cycle's VIR/vessel/
        # voyage does not belong to this BL, so it will not go
        # forward from here.
        return {"found": True, "terminal": "QICT",
                "source": "QICT (DP World)",
                "containers": [ctn_number], "status": "Gate out",
                "cycle_closed": True,
                "qict_export_in": det["in_time"],
                "qict_export_load": det.get("load_time") or ""}
    if det.get("gate_out"):
        # v99: the parser now reads 'Out Time' — this leg can now
        # give firm information with the gate-out date.
        status = "Gate out"
    elif det.get("holds"):
        status = "On hold at QICT"
    elif det.get("discharge_time"):
        status = "Discharged at QICT"
    elif det.get("vir"):
        status = "At QICT terminal (Port Qasim)"
    else:
        # v54: an entry with only vessel/line is from QICT's EXPECTED
        # (inbound) list — the container has not yet
        # reached the terminal. Previously this also became "At QICT terminal",
        # which was plainly wrong information on the card
        # (HGMU1110890: the vessel CSTAR VOYAGER was still en route
        # and the card was saying "At QICT terminal").
        if det.get("vessel"):
            status = (f"Expected at QICT — on {det['vessel']}"
                      + (f" ({det['voyage']})"
                         if det.get("voyage") else "")
                      + ", still at sea")
        else:
            status = ("In QICT's system — entry only, nothing "
                      "further recorded yet")
    out = {"found": True, "terminal": "QICT", "source": "QICT (DP World)",
           "containers": [ctn_number], "status": status}
    if status.startswith(("Expected", "In QICT's system")):
        out["expected"] = True
    out.update(det)
    # v99 (investigation fix 1, corrected after
    # the truth table): the parser now reads Ctr-Inq's 'Out Time'
    # — if the leg has gate_out or position,
    # it can also prove the state after gate-out.
    # The marker is only when the leg has nothing from these:
    # such a leg can prove discharge,
    # but never the post-gate-out state — for this reason its
    # discharge will not be made into yard evidence by _ctn_evidence_add
    # (that record always stays exactly the same
    # even after gate-out).
    if not det.get("gate_out") and not det.get("position"):
        out["discharge_only"] = True
    return out


CARRIER_APIS = {
    "COSCO Shipping": track_cosco_api,
    "COSCO Shipping (unverified)": track_cosco_api,
    "Emkay Line": track_emkay_api,
    "Evergreen": track_shipmentlink_bl,
}

CARRIER_CONTAINER_APIS = {
    "COSCO Shipping": track_cosco_container_api,
    "Evergreen": track_shipmentlink_container,
}


def track_bol_tracktrace(bl_number, carrier=None):
    """BL tracking on track-trace.com.
    If the carrier is known, direct tracking via its company ID (fast and correct).
    Returns dict.
    """
    # MSC automated tracking is not supported — give a manual link immediately
    if carrier in NO_AUTO_TRACK:
        return {"found": False, "deferred": True,
                "direct_url": "https://www.msc.com/en/track-a-shipment",
                "note": (f"{carrier} does not allow automated tracking "
                         "(bot protection). Please enter the number on their "
                         "own tracking page using the link below.")}
    try:
        # Step 1: submit the BL (the config hidden field is mandatory)
        final_url, body = post_form(
            "https://www.track-trace.com/bol",
            {"number": bl_number, "config": "207400", "commit": "Track!"},
        )
        # Step 2: if the carrier is known, track directly through it
        if carrier and carrier in TT_BOL_COMPANY_IDS:
            _, body2 = post_form(
                "https://www.track-trace.com/bol/select",
                {"number": bl_number, "shipper": TT_BOL_COMPANY_IDS[carrier]},
            )
            # extract the direct carrier form URL (e.g. COSCO cargoTracking)
            m = re.search(
                r'<form\s+action="([^"]+)"[^>]*>.*?name="trackingType".*?name="number"',
                body2, re.S | re.I)
            direct_url = None
            if m:
                direct_url = html.unescape(m.group(1))
                # add the hidden fields
                fields = re.findall(
                    r'<input\s+name="([^"]+)"\s+value="([^"]*)"', body2)
                if fields:
                    qs = urllib.parse.urlencode(
                        {k: v for k, v in fields})
                    direct_url = direct_url + "?" + qs
            res = parse_tracktrace(body2, final_url)
            if direct_url:
                res["direct_url"] = direct_url
            return res
    except Exception as e:
        return {"error": f"Could not reach track-trace.com: {e}"}
    return parse_tracktrace(body, final_url)


def track_container_tracktrace(ctn_number):
    """Container tracking on track-trace.com."""
    try:
        final_url, body = post_form("https://www.track-trace.com/container",
                                   {"number": ctn_number})
    except Exception as e:
        return {"error": f"Could not reach track-trace.com: {e}"}
    return parse_tracktrace(body, final_url)


# ============================================================
# LAYER 4: Vessel live tracking (VesselFinder — works via curl)
# When the vessel name is found (from any layer), get its live
# position, destination and ETA.
# ============================================================
def vessel_search(name):
    """Find a vessel on VesselFinder. Returns detail page URL or None."""
    q = urllib.parse.quote(name)
    url = f"https://www.vesselfinder.com/vessels?name={q}"
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception:
        return None
    m = re.search(r'href="(/vessels/details/\d+)"', body)
    return ("https://www.vesselfinder.com" + m.group(1)) if m else None


def vessel_live_position(name):
    """The vessel's live status: position, destination, ETA, speed."""
    detail_url = vessel_search(name)
    if not detail_url:
        # v51 (24 Oct): the actual registered names of some feeder vessels
        # have no number at the end — the BL shows "RONG HANG 268"
        # written on it, while VesselFinder only has "RONG HANG".
        # Try once more after removing the number.
        base = re.sub(r"\s+\d+\s*$", "", (name or "").strip())
        if base and base != name:
            detail_url = vessel_search(base)
            if detail_url:
                name = base
    if not detail_url:
        return {"found": False, "note": f"'{name}' was not found on VesselFinder."}
    try:
        req = urllib.request.Request(detail_url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach VesselFinder: {e}"}
    text = clean_text(body)
    info = {"found": True, "source": "VesselFinder", "vessel": name,
            "url": detail_url}
    m = re.search(r"Destination\s+([^,]+?),\s*([A-Za-z ]+?)\s*ETA:\s*([^(]+)",
                  text)
    if m:
        info["destination"] = f"{m.group(1).strip()}, {m.group(2).strip()}"
        info["eta"] = m.group(3).strip()
    m = re.search(r"speed of ([\d.]+) knots", text)
    if m:
        info["speed"] = f"{m.group(1)} knots"
    m = re.search(r"Navigation Status\s+([A-Za-z ]+?)(?:\s{2,}|$)", text)
    if m:
        info["nav_status"] = m.group(1).strip()
    m = re.search(r"Position Received\s+([^(]+?)(?:\s{2,}|$)", text)
    if m:
        info["position_time"] = m.group(1).strip()[:60]
    if len(info) <= 3:
        info["found"] = False
        info["note"] = "Vessel found, but no live data could be extracted."
    return info


# ---- Vessel Schedule layer (v113 WIP, 4 Nov 2026) ----
# Lines like Emkay and RTW do not provide tracking on their own websites,
# but their cargo travels on Maersk-service vessels and
# those vessels' port calls are public on ShipsGo Service Finder.
# This layer, from the vessel's past + upcoming port calls,
# extracts the shipment's actual movement: from the origin (Mombasa)
# the departure date and the expected date of arrival at Karachi / Port Qasim.
# This is only an ESTIMATE/schedule — the terminal's
# proof (VIR / discharge) always wins over it, so
# this layer only runs when no terminal has found a record,
# and it never touches discharge/gate-out/holds.

_SG_MONTHS = {m: i + 1 for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])}


def _sg_date(s):
    """'28 to 29 Oct 2026' / '19 Oct 2026' -> (start, end) dates."""
    m = re.search(r"(?:(\d{1,2})\s+to\s+)?(\d{1,2})\s+"
                  r"([A-Z][a-z]{2})[a-z]*\s+(\d{4})", s or "")
    if not m:
        return None, None
    try:
        import datetime as _dt
        mon = _SG_MONTHS[m.group(3)]
        end = _dt.date(int(m.group(4)), mon, int(m.group(2)))
        start = (_dt.date(int(m.group(4)), mon, int(m.group(1)))
                 if m.group(1) else end)
        return start, end
    except Exception:
        return None, None


def _sg_fmt(d):
    return d.strftime("%d %b %Y") if d else None


def _sg_table_after(html, heading):
    """Rows of the first <table> after the heading -> cell-text lists."""
    i = html.find(heading)
    if i < 0:
        return []
    j = html.find("<table", i)
    if j < 0:
        return []
    k = html.find("</table>", j)
    seg = html[j:k if k > j else j + 20000]
    rows = []
    for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", seg, re.S):
        cells = []
        for td in re.findall(r"<td[^>]*>(.*?)</td>", tr, re.S):
            t = clean_text(td)
            t = re.sub(r"\s+", " ", t).strip()
            cells.append(t)
        if cells and any(cells):
            rows.append(cells)
    return rows


def track_vessel_schedule(vessel_name):
    """Port calls of the vessel from ShipsGo Service Finder.

    Returns {found, vessel, calls: [{port, code, kind, d1, d2,
    voyage}], source, url} — kind: 'recent' | 'upcoming'.
    """
    name = (vessel_name or "").strip()
    if not name:
        return {"found": False, "note": "No vessel name."}
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    url = f"https://service-finder.shipsgo.com/vessels/{slug}"
    body = None
    last_err = None
    import http.client as _hc
    for _try in range(3):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=25) as resp:
                url = resp.geturl() or url
                try:
                    raw = resp.read()
                except _hc.IncompleteRead as _ir:
                    raw = _ir.partial or b""
                    # an incomplete page will also work if both port-call
                    # tables have loaded in it — otherwise retry.
                    _txt = raw.decode("utf-8", "replace")
                    if "Recent Port Calls" not in _txt \
                            or "Upcoming Port Calls" not in _txt:
                        raise
                    body = _txt
                    break
                body = raw.decode("utf-8", "replace")
            break
        except Exception as e:
            last_err = e
    if body is None:
        return {"found": False,
                "error": f"Could not reach ShipsGo: {last_err}"}
    return _parse_vessel_schedule(body, name, url)


def _parse_vessel_schedule(body, name, url):
    calls = []
    for heading, kind in (("Recent Port Calls", "recent"),
                          ("Upcoming Port Calls", "upcoming")):
        for cells in _sg_table_after(body, heading):
            if len(cells) < 2:
                continue
            # The actual shape of the table: [Port+code, date, voyage] —
            # in the port cell the name and UN/LOCODE (5 letters) come
            # together ("Mundra INMUN").
            date_cell = next((c for c in cells
                              if re.search(r"\d{4}", c)), "")
            d1, d2 = _sg_date(date_cell)
            if not d1:
                continue
            _pcell = cells[0]
            _m = re.match(r"^(.*?)\s+([A-Z]{5})$", _pcell)
            if _m:
                port, code = _m.group(1), _m.group(2)
            else:
                port, code = _pcell, ""
            voy = ""
            for c in cells:
                if c not in (_pcell, date_cell) and \
                        re.fullmatch(r"[0-9A-Za-z]{3,7}", c):
                    voy = c
                    break
            calls.append({"port": port, "code": code, "kind": kind,
                          "d1": d1, "d2": d2, "voyage": voy})
    if not calls:
        return {"found": False,
                "note": f"No port calls listed for '{name}' on ShipsGo."}
    return {"found": True, "source": "ShipsGo (vessel schedule)",
            "vessel": name.upper(), "url": url, "calls": calls}


def parse_tracktrace(body, final_url):
    text = clean_text(body)
    low = text.lower()
    result = {"source": "track-trace.com", "url": final_url}

    # the carrier site blocks framing — a direct link will work
    if "can not be displayed in a frame" in low:
        result["found"] = False
        result["deferred"] = True
        m = re.search(r"show\s+(.+?)\s+results without frame", text, re.I)
        carrier_name = m.group(1).strip() if m else "carrier"
        result["note"] = (f"{carrier_name}'s site cannot be shown in a frame — "
                          "please use the direct link below.")
        return result

    # v51 (24 Oct): some carriers (Maersk) appear on track-trace only
    # in a frame — the sentence above is NOT present on their page,
    # but in the frame-src there is the carrier's direct deep link
    # (maersk.com/tracking/<BL>). Previously this was not recognized
    # at all and the app falsely said "no readable record".
    mf = re.search(r'frame-src="(https?://[^"]+)"', body or "", re.I)
    if mf:
        result["found"] = False
        result["deferred"] = True
        result["direct_url"] = html.unescape(mf.group(1))
        mg = re.search(r"Getting results from\s+(.+?)(?:\s+Hide|\s*$)",
                       text, re.I)
        cname = mg.group(1).strip() if mg else "The carrier"
        result["note"] = (f"{cname}'s site cannot be shown in a frame — "
                          "please use the direct link below.")
        return result

    # not-found cases
    if "no known tracking" in low or "not found" in low or "no result" in low:
        result["found"] = False
        # attempt to extract the carrier hint
        m = re.search(r"No known tracking services for prefix\s*([A-Z]+)", text, re.I)
        if m:
            result["note"] = f"Prefix {m.group(1)} did not match any known carrier."
        else:
            # common error message
            m2 = re.search(r"(.{0,120}(not found|no result).{0,120})", text, re.I)
            result["note"] = m2.group(1).strip() if m2 else "No record found."
        return result

    # company selection page = no actual data (manual select required)
    if ("please select the company" in low
            or "selecting company manually" in low
            or "is unknown to us" in low):
        result["found"] = False
        result["note"] = ("The carrier could not be auto-detected — the "
                          "company must be selected manually in a browser.")
        return result

    # attempt to extract fields (labels may vary).
    # EVIDENCE is mandatory: just getting a page is not "found" — track-trace's
    # empty search page also previously became found and its
    # help words became pol/pod (false reassurance).
    for label, keys in [
        ("vessel", ["vessel", "ship"]),
        ("voyage", ["voyage"]),
        ("pol", ["port of loading", "origin", "from"]),
        ("pod", ["port of discharge", "destination", "to"]),
        ("eta", ["eta", "estimated arrival", "arrival"]),
        ("etd", ["etd", "estimated departure", "departure"]),
        ("status", ["status"]),
    ]:
        for k in keys:
            m = re.search(re.escape(k) + r"\s*[:\-]?\s*([A-Z0-9][^|<>]{1,60})", text, re.I)
            if m:
                val = m.group(1).strip()
                # vessel: only when it looks like an actual vessel name (not page junk)
                if label == "vessel" and not looks_like_vessel(val):
                    continue
                result[label] = val
                break
    # clean junk values: form/help words are not data
    BOILER = ("track", "insert", "option", "direct?", "remove",
              "select", "format", "automatically", "here,",
              "should have", "number from url")
    for k in ("pol", "pod", "eta", "etd", "status", "voyage"):
        v = str(result.get(k) or "")
        if v and any(b in v.lower() for b in BOILER):
            result.pop(k, None)
    # actual evidence: vessel name, or a date-like ETA/ETD, or
    # containers, or a recognized status — without these NOT found
    import datetime as _dt
    def _is_date(v):
        try:
            _dt.datetime.strptime(str(v).strip()[:11].title(),
                                  "%d %b %Y")
            return True
        except Exception:
            return bool(re.search(
                r"\b(19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b",
                str(v or "")))
    evidence = bool(result.get("vessel")
                    or result.get("containers")
                    or _is_date(result.get("eta"))
                    or _is_date(result.get("etd"))
                    or re.search(r"loaded|discharged|departed|arrived|"
                                 r"received|gate|delivered|vessel",
                                 str(result.get("status") or ""),
                                 re.I))
    if not evidence:
        result["found"] = False
        result["note"] = ("track-trace did not return a readable "
                          "record for this number.")
        for k in ("vessel", "voyage", "pol", "pod", "eta", "etd",
                  "status"):
            result.pop(k, None)
        return result
    result["raw_snippet"] = text[:600]
    return result


def looks_like_vessel(name):
    """Does this look like a real vessel name? Not page navigation junk."""
    if not name or len(name) < 3 or len(name) > 40:
        return False
    low = name.lower()
    # if they are common page/UI words, it is not a vessel
    junk = ["tracking", "track", "click", "here", "close", "recent", "search",
            "select", "menu", "page", "home", "back", "show", "hide", "more",
            "detect", "company", "based", "result", "option", "http", "www"]
    if any(j in low for j in junk):
        return False
    # there must be at least one word starting with a capital letter
    if not re.search(r"[A-Z]{2,}", name):
        return False
    return True


# Pattern-based BL formats that cannot come in the 4-letter prefix table
# (24 Oct 2026, v51). All verified from Yousuf's BL photos and 22 Oct
# research. Without these, Wan Hai's BL
# 142G513366 came back "not found" even though on Wan Hai's site its
# record existed — it was simply not recognized.
_BL_PATTERNS = [
    (r"\d{3}G[A-Z0-9]\d{5,6}", "Wan Hai"),       # 142G513366, 025G... and 051GA16585 (2 Nov 2026: Indonesia format with a letter after G, from his BL copy)
    (r"\d{9}", "Maersk"),                          # plain 9-digit BL
    (r"S\d{9}", "Yang Ming"),                      # S43.../S49... (YMJA)
    (r"MCL[A-Z]{3}\d{8,10}", "Monter Container Line"),  # MCLSUB26104308
    (r"HAICB\d{8,9}", "RCL"),                      # HAICB26009612
    (r"SGS\d{4}SIN[A-Z0-9]*", "SeaGem Shipping"),   # SGS5314SINKHI
]


def identify_carrier(bl_number):
    prefix = bl_number[:4].upper()
    carrier = CARRIERS.get(prefix)
    if not carrier:
        u = (bl_number or "").upper()
        for pat, name in _BL_PATTERNS:
            if re.fullmatch(pat, u):
                carrier = name
                break
    return prefix, carrier


def norm(s):
    """Clean the number: remove spaces/dashes, uppercase.
    Learned confirmed format (Yousuf, 5 Nov 2026): Emkay's
    BL is always EMKAYMBAKHI + 5 digits. If 'I' is read as '1'
    it becomes EMKAYMBAKH + 6 digits —
    that form can never be real, so as soon as it is seen
    bring it to the real form. This is the same gateway every
    number passes through into tracking."""
    out = re.sub(r"[\s\-]", "", (s or "")).upper()
    _m = re.fullmatch(r"EMKAYMBAKH1(\d{5})", out)
    if _m:
        out = "EMKAYMBAKHI" + _m.group(1)
    return out


_LINE_CANON = {
    "EVERGREEN": "Evergreen", "MAERSK": "Maersk", "MSC": "MSC",
    "MEDITERRANEAN SHIPPING": "MSC", "COSCO": "COSCO Shipping",
    "CMA CGM": "CMA CGM", "HAPAG": "Hapag-Lloyd", "ONE": "ONE",
    "OCEAN NETWORK": "ONE", "OOCL": "OOCL",
    "ORIENT OVERSEAS": "OOCL", "YANG MING": "Yang Ming",
    "ZIM": "ZIM", "WAN HAI": "Wan Hai", "EMKAY": "Emkay Line",
    "EM KAY": "Emkay Line", "PIL": "Pacific International Lines",
    "PACIFIC INTERNATIONAL": "Pacific International Lines",
    "HMM": "HMM", "HYUNDAI": "HMM", "KMTC": "KMTC",
    "SINOKOR": "Sinokor", "HEUNG-A": "Heung-A",
    "SITC": "SITC", "RCL": "RCL",
    "REGIONAL CONTAINER": "RCL", "INTERASIA": "Interasia Lines",
    "GOLD STAR": "Gold Star Line", "SAMUDERA": "Samudera",
    "ARKAS": "Arkas Line", "TURKON": "Turkon Line",
}


def _canon_line(line):
    """Convert the Terminal/QICT 'Shipping Line' to a common name
    — 'EVERGREEN MARINE' -> 'Evergreen'."""
    u = (line or "").upper()
    for k, v in _LINE_CANON.items():
        if k in u:
            return v
    return (line or "").strip().title() or None


# ---- Traqo Ocean: API layer (v56) ----
# It only runs when (a) there is a Traqo API key in Settings and
# (b) all free layers have already failed — because on the free plan
# every NEW reference consumes 1 slot out of 4 monthly tracks
# (re-querying the same reference is free). API contract
# verified from the Developer page (24 Oct 2026): base
# https://traqocontainer.com/api/v1, header
# "Authorization: Bearer <key>", ?sealine=XX param.
TRAQO_BASE = "https://traqocontainer.com/api/v1"
_TRAQO_SEALINE = {
    "maersk": "MAEU", "msc": "MSCU", "cma": "CMDU",
    "hapag": "HLCU", "cosco": "COSU", "evergreen": "EGLV",
    "yang ming": "YMLU", "one": "ONEY", "ocean network": "ONEY",
    "zim": "ZIMU", "pil": "PILU", "hmm": "HMMU",
    "oocl": "OOLU", "kmtc": "KMTC", "wan hai": "WHLC",
}


def _traqo_sealine(carrier_name):
    u = (carrier_name or "").lower()
    for k, v in _TRAQO_SEALINE.items():
        if k in u:
            return v
    return None


def _traqo_date(s):
    """'2026-11-10 00:00:00' / '2026-11-10' -> '10 Nov 2026'."""
    import datetime as _dt
    s = str(s or "").strip()
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if not m:
        return s
    try:
        return _dt.date(int(m.group(1)), int(m.group(2)),
                        int(m.group(3))).strftime("%d %b %Y")
    except Exception:
        return s


def track_traqo(ref, is_container, carrier_name, api_key):
    """A record for one BL/container from the Traqo Ocean API. Always
    returns {found, ...}; HTTP/plan limitations are written in the note
    honestly. It never raises."""
    import json as _json
    key = str(api_key or "").strip()
    if not key or not ref:
        return {"found": False, "note": "No Traqo API key saved."}
    kind = "container" if is_container else "bl"
    url = f"{TRAQO_BASE}/{kind}/{urllib.parse.quote(str(ref).strip())}"
    sl = _traqo_sealine(carrier_name)
    if sl:
        url += f"?sealine={sl}"
    req = urllib.request.Request(url, headers={
        **UA, "Authorization": f"Bearer {key}",
        "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            payload = _json.loads(r.read().decode("utf-8",
                                                  errors="replace"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {"found": False, "note":
                    "Traqo: API key was not accepted — check the "
                    "key in Settings."}
        if e.code == 402:
            return {"found": False, "note":
                    "Traqo: this month's 4 free tracks are used "
                    "up (they reset monthly)."}
        if e.code == 404:
            return {"found": False, "note":
                    "Traqo has no record for this number."}
        if e.code == 429:
            return {"found": False, "note":
                    "Traqo rate limit reached — try again later."}
        return {"found": False, "note": f"Traqo returned HTTP {e.code}."}
    except Exception as e:
        return {"found": False, "note": f"Traqo could not be reached ({e})."}
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not data:
        return {"found": False, "note":
                "Traqo returned no shipment data for this number."}
    res = {"found": True, "source": "Traqo (API)"}
    raw_status = str(data.get("status") or "").strip()
    eta = _traqo_date(data.get("eta"))
    status = raw_status.replace("_", " ").title() if raw_status else ""
    # Events: the actual API shape is events_table (on 24 Oct 2026
    # verified from a live response) — each event has date, location,
    # event_code, vessel, voyage, is_actual. Latest
    # event = the most recent ACTUAL (is_actual) event; future
    # events are a schedule, not news.
    _EV_LABEL = {"DEPA": "Vessel departed", "ARRI": "Vessel arrived",
                 "LOAD": "Loaded on vessel", "DISC": "Discharged",
                 "GTIN": "Gate in", "GTOU": "Gate out",
                 "CEP": "Container received at terminal",
                 "VAT": "Vessel arrived", "VDT": "Vessel departed",
                 "VAD": "Vessel arrived at destination",
                 "DLVR": "Delivered", "EMRT": "Empty returned"}
    events = (data.get("events_table") or data.get("events")
              or data.get("milestones") or [])
    evs = [e for e in events if isinstance(e, dict)] \
        if isinstance(events, list) else []
    def _ev_key(e):
        return str(e.get("date") or e.get("event_date")
                   or e.get("timestamp") or "")
    evs.sort(key=_ev_key)
    actual = [e for e in evs
              if e.get("is_actual") in (1, True, "1", "true")]
    last_ev = actual[-1] if actual else (evs[-1] if evs else None)
    voyage = None
    if last_ev:
        code = str(last_ev.get("event_code") or "").upper()
        label = _EV_LABEL.get(code) or code or "Event"
        loc = str(last_ev.get("location") or "")
        when = _traqo_date(last_ev.get("date")
                            or last_ev.get("timestamp"))
        txt = f"{label} — {loc}" if loc else label
        if not actual:
            txt += " (expected)"
        res["latest_event"] = f"{txt} ({when})" if when else txt
        if last_ev.get("voyage"):
            voyage = str(last_ev["voyage"])
    if status and eta:
        res["status"] = f"{status} — ETA {eta}"
    elif status:
        res["status"] = status
    if eta:
        res["eta"] = eta
    if data.get("origin"):
        res["pol"] = str(data["origin"])
    if data.get("destination"):
        res["pod"] = str(data["destination"])
    if data.get("sealine_name"):
        res["line"] = str(data["sealine_name"])
    # Containers: actual shape containers_table[].container_number
    ctns = []
    for c in (data.get("containers_table") or data.get("containers")
              or []):
        if isinstance(c, str):
            ctns.append(c)
        elif isinstance(c, dict):
            n = (c.get("container_number") or c.get("number")
                 or c.get("containerNumber") or c.get("id"))
            if n:
                ctns.append(str(n))
    if not ctns and is_container:
        ctns = [str(ref)]
    if ctns:
        res["containers"] = ctns
    # Vessel: in vessels_table the is_current row is the actual vessel;
    # take the voyage from any event of the current vessel.
    vessel = data.get("vessel") or data.get("vessel_name")
    if not vessel:
        vs = data.get("vessels_table") or data.get("vessels") or []
        rows = [v for v in vs if isinstance(v, dict)] \
            if isinstance(vs, list) else []
        cur = [v for v in rows
               if v.get("is_current") in (1, True, "1", "true")]
        pick = cur[-1] if cur else (rows[-1] if rows else None)
        if pick:
            vessel = (pick.get("vessel") or pick.get("name")
                      or pick.get("vessel_name"))
    if vessel:
        res["vessel"] = str(vessel)
        if not voyage:
            for e in evs:
                if e.get("vessel") == vessel and e.get("voyage"):
                    voyage = str(e["voyage"])
                    break
    if data.get("voyage"):
        voyage = str(data["voyage"])
    if voyage:
        res["voyage"] = voyage
    return res


def status_text_stage(status):
    """Lifecycle stage of the status TEXT (text only — evidence from fields
    is not included in this):
    0 unknown/expected · 1 in transit · 2 at terminal ·
    3 discharged (hold is also here — the container is still at the terminal) ·
    4 gate out / released · 5 delivered / empty returned."""
    st = (status or "").lower()
    if "delivered" in st or "returned empty" in st \
            or "empty returned" in st:
        return 5
    if "gate out" in st or "gate-out" in st or "released" in st:
        return 4
    if "discharg" in st or "hold" in st:
        return 3
    if "arrived" in st or "berthed" in st or "at qict" in st \
            or "at kgtl" in st or "karachi terminal" in st:
        return 2
    if "in transit" in st or "at sea" in st or "departed" in st \
            or "loaded on vessel" in st:
        return 1
    return 0


def status_stage(result):
    """The result's actual lifecycle stage: status text + hard evidence
    fields (gate_out date, position OUT, truck delivered,
    discharge_time). 'Expected…'/'entry only' text is kept from going above stage 1
    — but the real fields always win.
    Both merge (server._merge_result) and status reconciliation
    use this one map."""
    r = result or {}
    st = (r.get("status") or "").lower()
    stage = status_text_stage(st)
    if st.startswith("expected") or "entry only" in st \
            or "no active shipment" in st:
        stage = min(stage, 1)
    if r.get("discharge_time"):
        stage = max(stage, 3)
    if r.get("gate_out"):
        stage = max(stage, 4)
    pos = (r.get("position") or "").strip().upper()
    if pos in ("OUT", "GATE OUT", "GATE-OUT"):
        stage = max(stage, 4)
    if (r.get("truck") or "").strip().lower() == "delivered":
        stage = max(stage, 5)
    if r.get("returned"):
        stage = max(stage, 5)
    return stage


def vir_terminal(vir):
    """The confirmed terminal name from the VIR number — the user's firm rule
    is that the terminal name will always come from the VIR (PKBQMQICT_… =
    QICT, PKKHIKICT_… = KICT, PKKHISAPT_… = SAPT, PKKHIKGTL_… =
    KGTL). If no code is found in the VIR, return None."""
    v = str(vir or "").upper()
    for code in ("QICT", "KICT", "SAPT", "KGTL"):
        if code in v:
            return code
    return None


_DEPARTED_RE = re.compile(
    r"departed[^.]*?(\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4})", re.I)


def departed_date(text):
    """The carrier-confirmed departed date hidden inside the status text
    ('departed Shekou 09 Oct 2026') — if found, that same
    date, otherwise None."""
    md = _DEPARTED_RE.search(str(text or ""))
    return md.group(1) if md else None


def _fix_terminal_identity(res):
    """v96 data-audit round 2, FIX A: the terminal's identity comes from the VIR
    itself. No layer of fresh synthesis can change the terminal on a guess
    when the result's own VIR says something else
    (Pattern B: with QICT VIR PKBQMQICT_030826132505, the Karachi
    container layer had written SAPT). If the terminal is empty
    fill it from the VIR — the name will always come from the VIR."""
    vt = vir_terminal(res.get("vir"))
    if not vt:
        return
    term = (res.get("terminal") or "").strip()
    if term in ("KICT", "SAPT", "QICT", "KGTL"):
        if term != vt:
            res["terminal"] = vt
    elif not term:
        res["terminal"] = vt


def _capture_departed(res):
    """v96 data-audit round 2, FIX B: extract the confirmed departed date
    from the status text and save it in its own 'departed' field
    — even if the status text later becomes 'Arrived', the date
    must not be erased (on COAU6468022200/6468022890/6468005230, a re-track
    had erased '09 Oct 2026')."""
    if not res.get("departed"):
        d = departed_date(res.get("status"))
        if d:
            res["departed"] = d


def _reconcile_status(res):
    """The final stage of track_all (v96 data-audit fix): reconcile the assembled
    result's status TEXT with the hard evidence of that same result.
    Layers overwrite the status in their own order — the last
    layer to write is not always the strongest (for example,
    QICT by-container's 'Discharged at QICT' was ignoring that same result's
    position=OUT + truck=delivered —
    269665315). If the evidence is ahead of the text, raise the text
    UP to the evidence; text never moves backwards, and 'hold' status
    is not touched (hold is an alert state, not a stage claim)."""
    if not res:
        return res
    # FIX A/B first: terminal identity (VIR) and departed
    # date protection also applies to a record on hold —
    # the stage calculation comes later, we leave the hold there.
    _fix_terminal_identity(res)
    _capture_departed(res)
    # v123: the Data Source label always follows the record's own
    # terminal. Layers overwrite 'source' in their run order, so a
    # QICT record could end up labelled 'Karachi Terminal
    # (Hutchison Ports)' when a later by-container layer found rows
    # (EMKAYMBAKHI57873: terminal QICT, source Karachi — the owner
    # spotted the contradiction in the detail card). Deriving it
    # here, at the one choke point every result passes through,
    # keeps source and terminal consistent for every record.
    _tsrc = {"QICT": "QICT (DP World)",
             "KICT": "Karachi Terminal (Hutchison Ports)",
             "SAPT": "Karachi Terminal (Hutchison Ports)",
             "KGTL": "KGTL (Karachi Gateway Terminal)"}
    if res.get("terminal") in _tsrc:
        res["source"] = _tsrc[res["terminal"]]
    st = res.get("status") or ""
    if "hold" in st.lower():
        return res
    # v99: the status of a closed-cycle (cycle_closed) result
    # was made from the terminal's closed record — reconcile has
    # no better field evidence than this (neither
    # discharge, nor a gate_out field); merely from the 'returned'
    # flag making stage 5 and raising the text to 'Delivered'
    # would be counting the same evidence twice. Status
    # should stay exactly as the terminal record says.
    if res.get("cycle_closed"):
        return res
    # v99 conflict arbitration: if the result's own POSITION field
    # (the terminal's direct data field) says yard, and the status
    # text claims Delivered/Gate-out (text stage >= 4)
    # and there is no gate_out date, then this is a conflict between two fields
    # of the same source — the presence field
    # wins, not the synthesis text
    # (MBAQITS8502261016: QICT BL-Inquiry's synthesis
    # said 'Released — Delivered' but that same record's
    # POSITION was 'IN YARD' — the container was actually in the yard
    # itself. This is not an inference: it is the terminal's own field,
    # so even without Ctr-Inq's discharge-only evidence
    # this arbitration keeps it truthful, and
    # on re-track the wrong record corrects itself.)
    if "yard" in (res.get("position") or "").lower() \
            and status_text_stage(st) >= 4 \
            and not res.get("gate_out"):
        term = (res.get("terminal") or "").strip()
        res["status"] = f"Discharged at {term}" if term \
            else "Discharged"
        # the truck's 'delivered' claim is also rejected in this conflict —
        # otherwise status_stage would make it stage-5 evidence
        # and raise the text further down back to 'Delivered'.
        # Also write the rejection marker (the veto's own tombstone)
        # so that merge does not revive it from the old record
        # while this correction stands.
        if (res.get("truck") or "").strip().lower() == "delivered":
            res.pop("truck", None)
            _rj = list(res.get("_rejected_fields") or [])
            if "truck" not in _rj:
                _rj.append("truck")
            res["_rejected_fields"] = _rj
        return res
    # v99fix (d): the TEXT of 'Gate out'/'Delivered' by itself
    # without hard evidence is an empty claim — if the text
    # stage is ahead of the stage fields, the text will return to the evidence
    # level (COAU6468022200: from a ghost record
    # a 'Gate out' text had been made, a gate_out date
    # never existed at all — an internal contradiction). 'Released'
    # text is outside this rule: release is a separate
    # terminal state (QICT's standing), not a gate-out
    # claim — dropping it to discharge would be wrong.
    _stl = st.lower()
    if ("gate out" in _stl or "gate-out" in _stl
            or "delivered" in _stl) \
            and status_text_stage(st) >= 4:
        _fs = 0
        if res.get("discharge_time"):
            _fs = max(_fs, 3)
        if res.get("gate_out"):
            _fs = max(_fs, 4)
        _posu = (res.get("position") or "").strip().upper()
        if _posu in ("OUT", "GATE OUT", "GATE-OUT"):
            _fs = max(_fs, 4)
        if (res.get("truck") or "").strip().lower() == "delivered":
            _fs = max(_fs, 5)
        if res.get("returned"):
            _fs = max(_fs, 5)
        if _fs < status_text_stage(st):
            term = (res.get("terminal") or "").strip()
            if _fs >= 4:
                res["status"] = "Gate out"
            elif _fs >= 3:
                res["status"] = (f"Discharged at {term}" if term
                                 else "Discharged")
            elif term == "QICT":
                res["status"] = "At QICT terminal (Port Qasim)"
            elif term:
                res["status"] = f"Arrived at {term} terminal (Karachi)"
            else:
                res["status"] = "Arrived"
            return res
    ev = status_stage(res)
    if ev <= status_text_stage(st):
        return res
    term = (res.get("terminal") or "").strip()
    if ev >= 5:
        res["status"] = "Released — Delivered"
    elif ev >= 4:
        res["status"] = "Gate out"
    elif ev >= 3:
        res["status"] = f"Discharged at {term}" if term else "Discharged"
    return res


def _ctn_evidence_add(ev_map, ctn, leg):
    """Convert a by-container leg result into evidence for that container
    (v96 proof-run fix). Two kinds of evidence:
    'out' — the container has left the yard (gate_out date,
    position OUT, KGTL's 'Departed', or on the next voyage
    'Loaded on Vessel'); 'in_yard' — the container
    is in the terminal yard and there is no gate-out evidence
    (it has been discharged, or position/status says yard/at-terminal
    ). An 'expected' entry (container still in transit) is
    not evidence — it does not even prove the container's
    presence. If one container has multiple legs, 'out' wins
    : discharge is a state before gate-out, therefore a
    discharge entry cannot override the gate-out confirmation
    . v99: discharge alone from a 'discharge_only' leg (QICT
    Ctr-Inq — there is no gate-out/position field at all)
    never becomes 'in_yard' on its own."""
    if not ctn or not leg or not leg.get("found") \
            or leg.get("expected"):
        return
    st = (leg.get("status") or "").lower()
    pos = (leg.get("position") or "").strip()
    posu = pos.upper()
    g = leg.get("gate_out")
    # 'Loaded on Vessel' is also evidence of leaving the yard:
    # if the container has been loaded on the next voyage, its old
    # discharge record no longer reflects the current yard state
    # (269665315: after QICT discharge the container was loaded at SAPT for the next
    # voyage — if a veto applied there, the actual Delivered
    # record would have been corrupted).
    out = bool(g and str(g).strip()) \
        or posu in ("OUT", "GATE OUT", "GATE-OUT") \
        or pos.lower() == "departed" \
        or "loaded on vessel" in st \
        or "loaded on vessel" in pos.lower() \
        or "gate out" in st or "gate-out" in st \
        or "delivered" in st or "empty returned" in st \
        or "returned empty" in st
    in_yard = False
    if not out:
        if leg.get("discharge_only"):
            # v99 (investigation fix 1): this leg cannot see gate-out /
            # position at all (QICT Ctr-Inq) — its
            # discharge record always stays the same even after gate-out,
            # so discharge_time or
            # 'Discharged' text CANNOT become evidence of the yard.
            # Only a direct yard sighting from the leg's own position field
            # will work (on Ctr-Inq it does not exist at all).
            in_yard = "yard" in pos.lower()
        else:
            in_yard = bool(leg.get("discharge_time")) \
                or "yard" in pos.lower() or "discharg" in st \
                or "hold" in st \
                or st.startswith(("at qict", "at kgtl", "at kict",
                                  "at sapt"))
    if not out and not in_yard:
        return
    e = ev_map.setdefault(ctn, {"out": False, "in_yard": False,
                                "virs": set(), "status": "",
                                "position": ""})
    if leg.get("vir"):
        e["virs"].add(str(leg["vir"]).strip().upper())
    if out:
        e["out"] = True
        e["in_yard"] = False
    elif not e["out"]:
        e["in_yard"] = True
        if leg.get("status"):
            e["status"] = leg["status"]
        if pos:
            e["position"] = pos


def _term_ts_full(s):
    """Parse the stamp as a FULL timestamp (with time)
    -> (datetime, precise) or None. If only a date is found
    that day is midnight and precise=False — the comparer
    must know this difference (a same-day
    return will never be rejected by day-level calculation)."""
    s = str(s or "").strip()
    if not s:
        return None
    k = _term_gate_key(s)
    if k != datetime.min:
        return (k, bool(re.search(r"\d{1,2}[:.]\d{2}", s)))
    d = _term_date(s)
    if d:
        try:
            return (datetime.strptime(d, "%d %b %Y"), False)
        except Exception:
            pass
    pd = _parse_det_date(s)
    if pd:
        return (datetime(pd.year, pd.month, pd.day), False)
    return None


def _ts_after(a, b):
    """Is a (return stamp) AFTER b (anchor)? If both
    have a time, use strict comparison (hours will also be counted
    ); otherwise day level: the return day must not be before the anchor
    day — a return a few hours after gate-out on the same day
    is a real return (OOLU2337916330:
    gate-out 09:36, return 18:23 same day; MEDUT1385110:
    completion 03:51, return 16:59 same day — v99's day-level
    calculation was rejecting both of these)."""
    if a is None or b is None:
        return False
    (ad, ap), (bd, bp) = a, b
    if ap and bp:
        return ad > bd
    return ad.date() >= bd.date()


def derive_empty_return(res):
    """Empty-return derivation — ONE mapping, at every choke
    point (v99fix, Phase-1 fail 30 Oct 2026).

    v99 (user's order): the empty container's return is recorded in the terminal
    container record — the STATUS='EM' row in Hutchison
    (KICT/SAPT) history rows.
    The earlier flow never wrote this (data audit s3:
    even when a return existed at the terminal, records'
    'returned' stayed empty). In v99 the derivation
    ran only at the end of track_all on the fresh result
    and same-day returns were rejected by day-level comparison
    (MEDUT1385110: the EM row was in the record,
    yet 'returned' was still not created). Now this same function
    also runs on the server's record-finalize (merge):
    if there is an EM row in STORED terminal_rows, the return
    is also derived from there — whatever run the evidence came in,
    derivation happens on every finalize.

    Rules:
    - The EM row must be after that container's OWN gate-out
      (anchor: that container's rows' gate-out, otherwise
      shipment gate_out, otherwise discharge) — comparison
      by full timestamp, not by day.
    - Or the import cycle's EM-derived gate_in (after gate_out
      ) — but NOT the gate_in that is explained by any
      export (XM/XF) row's gate-in: that is
      the start of the container's NEXT voyage, not this BL's return
      (proven on 025G773374 / BALCMBKHI2600923).
    - The date will always be the terminal's own — never
      fabricated. If already returned, it is not
      touched. Presumption (the 2+ day estimate,
      server._lifecycle) is separate from this and always stays behind
      real evidence."""
    if not res or res.get("returned"):
        return False
    rows = [r for r in (res.get("terminal_rows") or [])
            if isinstance(r, dict)]
    own = {str(c).strip() for c in (res.get("containers") or [])
           if c}

    def _own_row(row):
        return not own or str(
            row.get("CONTAINER NO") or "").strip() in own

    ship_go = _term_ts_full(res.get("gate_out"))
    ship_dis = _term_ts_full(res.get("discharge_time"))
    best = None
    for row in rows:
        if not _own_row(row):
            continue
        if str(row.get("STATUS") or "").strip().upper() != "EM":
            continue
        when_raw = row.get("DISCHARGING TIME") \
            or row.get("GATE In TIME") or ""
        t = _term_ts_full(when_raw)
        if t is None:
            continue
        ctn = str(row.get("CONTAINER NO") or "").strip()
        own_go = None
        for r2 in rows:
            if str(r2.get("CONTAINER NO") or "").strip() != ctn:
                continue
            g = _term_ts_full(r2.get("GATE OUT TIME"))
            if g and (own_go is None or g[0] > own_go[0]):
                own_go = g
        anchor = own_go or ship_go or ship_dis
        if anchor is not None and not _ts_after(t, anchor):
            continue  # a return cannot be before the gate-out
        if best is None or t[0] < best[0]:
            best = (t[0], str(when_raw))
    if best is None:
        gi_raw = res.get("empty_gate_in") or res.get("gate_in")
        gi = _term_ts_full(gi_raw)
        if gi and ship_go and res.get("discharge_time") \
                and _ts_after(gi, ship_go):
            explained = False
            for row in rows:
                if str(row.get("STATUS") or "").strip().upper() \
                        in _EXPORT_ROW_STATUS:
                    rt = _term_ts_full(row.get("GATE In TIME"))
                    if rt and rt[0] == gi[0]:
                        explained = True
                        break
            if not explained:
                # v99fix3: QICT export evidence is also clear as gate_in
                # — even if terminal_rows are null, then
                # too this gate_in is the start of the next voyage,
                # not a return.
                _qi = _term_ts_full(res.get("qict_export_in"))
                if _qi is not None and _qi[0] == gi[0]:
                    explained = True
            if not explained:
                best = (gi[0], str(gi_raw))
    if best:
        res["returned"] = True
        res["returned_date"] = best[1]
        return True
    return False


def _settle_empty_return(res, allow_load_derive=True):
    """The ONE choke point for empty-return (v99fix2, Phase-2
    defect MBAQITS8502261016).

    The problem was not that derive_empty_return had no XM/XF
    guard — there was a guard, but the evidence never
    reached it: Layer 3d absorb would drop an XF-only leg's
    row because that leg's terminal was
    empty, and merge would carry the old (legacy) gate_in forward
    without the rows that explain it.
    Result: the XF export gate-in became 'returned',
    even though its date was the XF row's gate-in date.

    That is why every returned decision passes THROUGH HERE —
    since v99fix3 the QICT cycle_closed writer also does not write returned
    (it only provides export-cycle evidence) —
    no other function writes returned from terminal evidence,
    and this does not touch Hutchison gate_in
    at all:
    1. RETRACT: if an already recorded returned is proven false
       (its date matches an XF/XM row's gate-in or QICT
       export In Time to the second, and that container
       has no EM row) then clear it — otherwise
       a wrong returned would live forever due to merge
       stickiness.
    2. DERIVE: then the normal derivation (EM row, or
       a gate_in not explained by a non-export row).
    v99fix4 (Fix Round 4): the QICT export-LOAD derivation
    is also here — if the container has been LOADed onto a vessel as export cargo
    (qict_export_load) then the empty
    container could not have been loaded without returning to the carrier's custody
    : the return is PROVEN, but
    QICT does not record the return date, so
    returned_date will always remain None and the marker
    returned_basis='export_reload' will be set. Gate-in
    alone (without load) is never a return — 1016 stays
    False on that alone. The retraction symmetry for basis-based returns
    is also here: evidence (EM row
    or load) if not in the fresh result, this True also
    gets retracted, and if an EM row arrives, the dated
    real return takes its place.
    allow_load_derive: on merge, if there is no closed-cycle anchor
    (_cc_ok), load-derivation stays disabled —
    evidence from a foreign cycle cannot create a new return on another record
    (retraction still happens
    ). On track_all's fresh result, no anchor is
    needed — the evidence belongs to that record's own container
    .
    Both call sites run this same function:
    the end of track_all (_apply_empty_return) and
    server._merge_result (record-finalize)."""
    if not res:
        return False
    changed = False
    if res.get("returned") and res.get("returned_date"):
        rd = _term_ts_full(res["returned_date"])
        if rd is not None:
            rows = [r for r in (res.get("terminal_rows") or [])
                    if isinstance(r, dict)]
            own = {str(c).strip()
                   for c in (res.get("containers") or []) if c}

            def _own_row(row):
                return not own or str(
                    row.get("CONTAINER NO") or "").strip() in own

            xf_match = False
            em_any = False
            for row in rows:
                if not _own_row(row):
                    continue
                st = str(row.get("STATUS") or "").strip().upper()
                if st == "EM":
                    em_any = True
                elif st in _EXPORT_ROW_STATUS:
                    rt = _term_ts_full(row.get("GATE In TIME"))
                    if rt and rt[0] == rd[0]:
                        xf_match = True
            # v99fix3: QICT route — terminal_rows null
            # occur, therefore an XF row will never be found.
            # Instead, compare with the evidence present on the record
            # for the export-cycle (qict_export_in, fresh
            # from Layer 3c): if returned_date
            # is that same export In Time, then this is that same wrong
            # return. If there is an EM row, the return is actual —
            # even then no retraction will happen.
            qict_match = False
            _qi = _term_ts_full(res.get("qict_export_in"))
            if _qi is not None and rd is not None \
                    and _qi[0] == rd[0]:
                qict_match = True
            if (xf_match or qict_match) and not em_any:
                res["returned"] = False
                res.pop("returned_date", None)
                changed = True
    # v99fix4: retraction symmetry for the basis (export_reload) derived return —
    # this True stays alive only with its own evidence.
    # If the load disappears, retract;
    # even if an EM row has arrived, this form goes away so that
    # the normal derivation can make the actual return with a date.
    if res.get("returned") \
            and res.get("returned_basis") == "export_reload" \
            and not res.get("returned_date"):
        _rows4 = [r for r in (res.get("terminal_rows") or [])
                  if isinstance(r, dict)]
        _own4 = {str(c).strip()
                 for c in (res.get("containers") or []) if c}
        _em4 = any(
            str(r.get("STATUS") or "").strip().upper() == "EM"
            and (not _own4 or str(
                r.get("CONTAINER NO") or "").strip() in _own4)
            for r in _rows4)
        if _em4 or not str(res.get("qict_export_load")
                           or "").strip():
            res["returned"] = False
            res.pop("returned_basis", None)
            changed = True
    if derive_empty_return(res):
        changed = True
    # KGTL storage-return derivation (6 Nov 2026, BL 142G512846):
    # KGTL's container page shows only the CURRENT visit. When that
    # visit is a VIR-less Storage entry at tare weight with a
    # UNIT_IN_GATE activity, the loaded unit has been delivered and
    # the empty has come back by road — the gate-in time IS the
    # return date (KGTL publishes it, unlike QICT's load). The
    # evidence field (kgtl_empty_in) is produced only by the KGTL
    # trace mapping (_kgtl_visit_kind), and the same single-container
    # guard as the QICT load applies. Retraction symmetry mirrors
    # export_reload: if the evidence disappears, the claim goes.
    if res.get("returned") \
            and res.get("returned_basis") == "kgtl_storage_return" \
            and not str(res.get("kgtl_empty_in") or "").strip():
        res["returned"] = False
        res.pop("returned_basis", None)
        res.pop("returned_date", None)
        changed = True
    if allow_load_derive and not res.get("returned"):
        _ki = str(res.get("kgtl_empty_in") or "").strip()
        _ctk = [c for c in (res.get("containers") or []) if c]
        if _ki and len(_ctk) <= 1:
            res["returned"] = True
            res["returned_date"] = _ki
            res["returned_basis"] = "kgtl_storage_return"
            changed = True
    # v99fix4: QICT export-LOAD derivation — even after EM,
    # it must not have already become returned, and if the record has export
    # Load Time evidence, then the return is proven (the container
    # cannot be export-loaded without coming back empty),
    # there is NO date (QICT does not give a return date)
    # — the gate-in or load time never becomes
    # the return date. Record-level evidence applies only when
    # there is only ONE container: with multiple containers, this scalar evidence
    # cannot be determined to belong to which container — no flip happens there.
    if allow_load_derive and not res.get("returned"):
        _ld4 = str(res.get("qict_export_load") or "").strip()
        _ct4 = [c for c in (res.get("containers") or []) if c]
        if _ld4 and len(_ct4) <= 1:
            res["returned"] = True
            res.pop("returned_date", None)
            res["returned_basis"] = "export_reload"
            changed = True
    return changed


def _apply_empty_return(res):
    """Derivation on the fresh result at the end of track_all
    (since v99); the real work is done by _settle_empty_return, which
    also runs on the server's finalize."""
    if res:
        _settle_empty_return(res)
    return res


def _apply_container_veto(res, ev_map):
    """v96 proof-run fix (case 3, MBAQITS8502261016): BL-level
    leg's 'Delivered/OUT' claim cannot survive the same run's by-container evidence.
    QICT's BL-inquiry had falsely
    said 'Released — Delivered' + truck delivered,
    while the by-container leg (Ctr-Inq) was showing discharge for the same cycle
    and there was no gate-out evidence — the container
    was actually in the yard. Merge's stage guard only
    blocks downgrades; this wrong UPGRADE was passing through
    there. Rules:
    - Veto ONLY when one of its own containers has POSITIVE yard
      evidence. If there is no by-container evidence at all, the claim
      stands — a real Delivered (269665315) had no by-container
      record at all, so no veto can apply there.
    - Evidence must be from the same cycle: if VIRs exist on both sides and differ
      it is another voyage's record — no veto.
    - If the by-container leg confirms gate-out/OUT, the claim
      stands (genuine case is safe).
    - If some containers are out and some are in the yard (or some have no evidence
      at all) the shipment is 'Partially discharged' —
      neither fully Delivered, nor fully Discharged."""
    if not res:
        return res
    ev = {c: dict(e) for c, e in (ev_map or {}).items()}
    # terminal_rows are also per-container evidence (Hutchison
    # history rows + KGTL grid — both arrive filtered
    # to the current cycle).
    for row in res.get("terminal_rows") or []:
        if not isinstance(row, dict):
            continue
        c = (row.get("CONTAINER NO") or "").strip()
        if not c:
            continue
        # Check by PARSING the date: on an empty gate-out, the terminal
        # writes 'N/A' — the presence of that string is not evidence
        # of a gate-out (on 269665315's SAPT row, this same 'N/A'
        # was wrongly blocking the veto).
        g = _term_date(str(row.get("GATE OUT TIME") or ""))
        d = _term_date(str(row.get("DISCHARGING TIME") or ""))
        loc = (row.get("LOCATION") or "").strip().lower()
        e = ev.setdefault(c, {"out": False, "in_yard": False,
                              "virs": set(), "status": "",
                              "position": ""})
        if g or loc == "departed":
            e["out"] = True
            e["in_yard"] = False
        elif (d or loc == "in yard") and not e["out"]:
            e["in_yard"] = True
    if not ev:
        return res
    if status_stage(res) < 4:
        return res  # there is no gate-out/delivered claim at all
    rvir = str(res.get("vir") or "").strip().upper()

    def _same_cycle(e):
        return not e["virs"] or not rvir or rvir in e["virs"]

    own = [c for c in (res.get("containers") or []) if c in ev]
    covered = [c for c in own if _same_cycle(ev[c])]
    in_yard = [c for c in covered
               if ev[c]["in_yard"] and not ev[c]["out"]]
    if not in_yard:
        return res
    out_ok = [c for c in covered if ev[c]["out"]]
    # End the claim: remove the truck 'delivered' and the shipment-level
    # gate_out (which is always set only when ALL containers are out) —
    # while these remain, _reconcile_status revives the false
    # text again.
    # v99 (investigation fix 3): also write the list of the fields that the veto
    # REJECTS — _merge_result will NOT revive them from the old
    # record while this correction stands
    # (otherwise the card shows contradictions like 'Discharged' with 'Gate pass:
    # delivered').
    _rejected = list(res.get("_rejected_fields") or [])
    if (res.get("truck") or "").strip().lower() == "delivered":
        res.pop("truck", None)
        if "truck" not in _rejected:
            _rejected.append("truck")
    if res.pop("gate_out", None) is not None \
            and "gate_out" not in _rejected:
        _rejected.append("gate_out")
    if _rejected:
        res["_rejected_fields"] = _rejected
    st_now = res.get("status") or ""
    hold = "hold" in st_now.lower()
    all_in = len(in_yard) == len(res.get("containers") or []) \
        and not out_ok
    if all_in:
        if not hold:
            ev_st = ev[in_yard[0]].get("status") or ""
            term = (res.get("terminal") or "").strip()
            res["status"] = ev_st or (
                f"Discharged at {term}" if term else "Discharged")
        _p = ev[in_yard[0]].get("position") or ""
        if "yard" in _p.lower():
            res["position"] = _p
        elif (res.get("position") or "").strip().upper() in (
                "OUT", "GATE OUT", "GATE-OUT"):
            # Write 'yard' only in place of the OUT claim that is being vetoed
            # (the real case of MBAQITS8502261016:
            # the BL leg's false OUT).
            res["position"] = "In Yard"
            # v99 (investigation fix 2): this 'In Yard' is the veto's
            # own inference, it did not come from any terminal field
            # — mark it with a provenance marker.
            # The server's merge guard (_own_cycle_correction)
            # will never treat a position bearing this mark as independent terminal
            # evidence: the engine cannot, by presenting evidence it fabricated
            # itself, push the final record
            # backwards (EMKAYMBAKHI59055,
            # the 30 Oct 2026 downgrade happened from exactly this).
            res["position_via"] = "veto"
        # v98 (S2, EMKAYMBAKHI59055): if the position is EMPTY,
        # NEVER fabricate 'In Yard'. After a QICT gate-out,
        # BL-mode becomes empty and Ctr-Inq forever
        # only keeps showing the discharge — a fabricated 'In Yard' placed in that
        # empty place gave the server's merge
        # guard (_own_cycle_correction) false yard
        # evidence, and pushed the real Delivered record
        # back to 'Discharged'
        # (29 Oct 2026, the 17:40 status change).
    else:
        if not hold:
            res["status"] = "Partially discharged"
        if (res.get("position") or "").strip().upper() in (
                "OUT", "GATE OUT", "GATE-OUT"):
            res["position"] = "In Yard"
            # v99 fix 2: the same provenance as above — this 'In
            # Yard' is also the veto's inference, not a terminal
            # field.
            res["position_via"] = "veto"
    return res


def _union_rows(existing, new_rows):
    """UNION of terminal rows — one leg's rows never suppress another leg's
    rows. Every container's history
    is evidence for the record (EM rows, gate-out stamps);
    attaching container-mode history rows onto BL-mode listing rows
    is not replacing them (v99fix:
    in MEDUT1385110, 3d absorb suppressed BL rows and
    left only the first container's rows). Dedupe by pid;
    if there is no pid (KGTL grid), dedupe by the row's shape."""
    def _key(r):
        if not isinstance(r, dict):
            return None
        pid = r.get("pid")
        if pid:
            return ("pid", str(pid))
        return ("shape", str(r.get("CONTAINER NO") or ""),
                str(r.get("STATUS") or r.get("LOCATION") or ""),
                str(r.get("DISCHARGING TIME") or ""),
                str(r.get("GATE OUT TIME") or ""),
                str(r.get("GATE In TIME") or ""))

    seen = set()
    out_rows = []
    for r in list(existing or []) + list(new_rows or []):
        k = _key(r)
        if k is None or k in seen:
            continue
        seen.add(k)
        out_rows.append(r)
    return out_rows


def track_all(bl=None, ctn=None, vessel_name=None, progress_cb=None,
              carrier_hint=None, traqo_key=None, known_containers=None,
              known_vessel=None):
    """Structured tracking — for both GUI and CLI.
    progress_cb(layer_name, status, detail) — status: running/done/fail
    Returns: dict with carrier, layers[], result{}, contacts{}
    """
    def prog(name, status, detail=""):
        if progress_cb:
            progress_cb(name, status, detail)

    out = {"carrier": None, "prefix": None, "layers": [], "result": {},
           "contacts": None, "tried": []}

    # Vessel-only mode
    if vessel_name:
        prog("Layer 4 — VesselFinder", "running", vessel_name)
        r = vessel_live_position(vessel_name)
        out["layers"].append({"name": "Layer 4 — VesselFinder",
                              "status": "done" if r.get("found") else "fail",
                              "detail": vessel_name})
        if r.get("found"):
            out["result"] = r
        prog("Layer 4 — VesselFinder",
             "done" if r.get("found") else "fail", "")
        return out

    if bl:
        bl = norm(bl)
    # Layer 0: carrier identify
    prog("Layer 0 — Carrier identification", "running")
    lookup = bl or ctn
    prefix, carrier = identify_carrier(lookup) if lookup else (None, None)
    # If a carrier was manually selected in the UI and identification by prefix
    # could not be made, use that same hint in the actual tracking —
    # earlier the hint only changed the name, not the search (v29 fix).
    if not carrier and carrier_hint:
        carrier = carrier_hint
    out["carrier"] = carrier
    out["prefix"] = prefix
    # v51: identification is NOT "record found" — mark this layer as meta
    # so that the UI's "x found a record" count does not increase from it
    # (24 Oct: on a Wan Hai BL the count showed "1 found" when in fact
    # not a single record had been found). The status will now also tell the truth:
    # if the carrier is not identified, it fails.
    out["layers"].append({"name": "Layer 0 — Carrier identification",
                         "status": "done" if carrier else "fail",
                         "meta": True,
                         "detail": f"{carrier} (prefix {prefix})" if carrier
                         else f"Unknown (prefix {prefix})"})
    prog("Layer 0 — Carrier identification",
         "done" if carrier else "fail")

    # Forwarder contact (if any)
    if carrier in FORWARDER_CONTACTS:
        out["contacts"] = FORWARDER_CONTACTS[carrier]

    got_vessel = None
    # v96 proof-run fix: collect the by-container legs' evidence alongside
    # as you go — at the end, _apply_container_veto will test the BL-level
    # false Delivered claim against exactly this.
    ctn_ev = {}

    # Layer 1: carrier direct API
    api_fn = CARRIER_APIS.get(carrier) if (carrier and bl) else None
    # A numbers-only 12-digit number: the number part of an Evergreen BL
    # is exactly this much (EGLV + 12 digits) — check it directly
    # via ShipmentLink; if found, the carrier is confirmed as Evergreen.
    sl_fallback = False
    cosco_fallback = False
    if not api_fn and bl and re.fullmatch(r"\d{12}", bl):
        api_fn = track_shipmentlink_bl
        sl_fallback = True
    elif not api_fn and bl and re.fullmatch(r"\d{10}", bl):
        # A 10-digit numbers-only number is the number part of a COSCO BL
        # (COAU/COSU + 10 digits) — on 21 Oct, 6470875561 was missed for
        # this very reason; if the COSCO API itself returns a record, it is confirmed.
        api_fn = track_cosco_api
        cosco_fallback = True
    if api_fn:
        lname = (f"Layer 1 — {carrier} direct API" if not sl_fallback
                 else "Layer 1 — Evergreen ShipmentLink")
        prog(lname, "running")
        out["tried"].append(lname)
        r = api_fn(bl)
        ok = bool(r.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r.get("note") or r.get("error") or "")[:100]})
        if ok:
            if sl_fallback and not out.get("carrier"):
                out["carrier"] = "Evergreen"
            if cosco_fallback and not out.get("carrier"):
                out["carrier"] = "COSCO Shipping"
            out["result"].update({k: r[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "containers", "terminal",
                                  "discharge_time", "source",
                                  "activity_date", "weight",
                                  "size_type") if k in r})
            got_vessel = r.get("vessel")
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")
        if not ok and not r.get("error"):
            # F-09 fix (v46 audit): the carrier API answered but had no
            # record — track-trace used to be skipped entirely for
            # API carriers. Try it as a fallback before moving on.
            lname2 = "Layer 1b — track-trace.com (BL)"
            prog(lname2, "running")
            out["tried"].append(lname2)
            r2t = track_bol_tracktrace(bl, carrier)
            ok2 = bool(r2t.get("found"))
            out["layers"].append(
                {"name": lname2, "status": "done" if ok2 else "fail",
                 "detail": (r2t.get("note") or r2t.get("error") or "")[:100]})
            if ok2:
                out["result"].update({k: r2t[k] for k in
                                      ("vessel", "voyage", "pol", "pod",
                                       "eta", "etd", "status", "containers",
                                       "terminal", "discharge_time",
                                       "source", "activity_date", "weight",
                                       "size_type") if k in r2t})
                got_vessel = r2t.get("vessel") or got_vessel
            prog(lname2, "done" if ok2 else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")
    elif bl:
        # Layer 2: track-trace BL
        lname = "Layer 2 — track-trace.com (BL)"
        prog(lname, "running")
        out["tried"].append(lname)
        r = track_bol_tracktrace(bl, carrier)
        ok = bool(r.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r.get("note") or r.get("error") or "")[:100]})
        if ok:
            out["result"].update({k: r[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "source") if k in r})
            got_vessel = r.get("vessel")
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2b: container
    if ctn:
        capi_fn = CARRIER_CONTAINER_APIS.get(carrier) if carrier else None
        lname = (f"Layer 2 — {carrier} container API" if capi_fn
                 else "Layer 2 — track-trace.com (container)")
        prog(lname, "running")
        out["tried"].append(lname)
        r2 = capi_fn(ctn) if capi_fn else track_container_tracktrace(ctn)
        ok = bool(r2.get("found"))
        _ctn_evidence_add(ctn_ev, ctn, r2)
        if not ok and r2.get("empty_container"):
            out["result"].update({
                "status": ("No active shipment — this container is "
                           "in COSCO's system (it may be empty or an "
                           "old record)"),
                "source": "COSCO API", "containers": [ctn]})
            ok = True
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r2.get("note") or r2.get("error") or "")[:100]})
        if ok and not got_vessel:
            got_vessel = r2.get("vessel")
            out["result"].update({k: r2[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "source", "position",
                                  "size_type", "weight",
                                  "containers") if k in r2})
            if r2.get("location") and not out["result"].get("position"):
                out["result"]["position"] = r2["location"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2c: Emkay container search (extra chance — NVOCC cargo)
    if ctn and not out["result"].get("vessel"):
        lname = "Layer 2 — Emkay Line (container)"
        prog(lname, "running")
        out["tried"].append(lname)
        r3 = track_emkay_container_api(ctn)
        ok = bool(r3.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r3.get("note") or r3.get("error") or "")[:100]})
        if ok:
            if not out.get("carrier"):
                out["carrier"] = "Emkay Line"
            out["result"].update({k: r3[k] for k in
                                 ("vessel", "voyage", "pol", "pod",
                                  "etd", "status", "source",
                                  "activity_date") if k in r3})
            got_vessel = r3.get("vessel") or got_vessel
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2d: Feeder Logistics — its own tracking site only
    # opens via the browser (WebGui app); the server-side data route
    # is closed. A guidance layer so that "not found" on an FRLS BL
    # does not become a dead-end — the real site's 1-click route is always there.
    if bl and carrier == "Feeder Logistics":
        lname = "Layer 2d — Feeder Logistics (manual check)"
        prog(lname, "running")
        out["tried"].append(lname)
        out["layers"].append({"name": lname, "status": "fail",
            "detail": "Feeder's own tracking site holds this BL — open the source link (the number is copied for you) and paste it there. Public, no login."})
        prog(lname, "fail", out["layers"][-1]["detail"])

    # v51 SPEED (24 Oct): Layer 3 (KICT/SAPT) and Layer 3b (QICT)
    # fetch the raw responses TOGETHER (in parallel) — both depend only on the BL,
    # they have no relation to each other. The merge ahead still happens in the old
    # serial order, so the result, precedence
    # and layer lines remain exactly as before; only the time
    # becomes equal to the slower one instead of the SUM of both
    # (this pair previously often used to take 20-30 seconds).
    # Emkay / RTW cargo ONLY ever comes to QICT (Port Qasim)
    # — Karachi terminals (KICT/SAPT/KGTL) are never checked
    # for them, by BL or by container (Yousuf's standing rule).
    _qict_only = (carrier or "") in ("Emkay Line",
                                     "RTW Shipping Lines")
    _raw3 = _raw3b = _raw3e = None
    if bl:
        try:
            from concurrent.futures import ThreadPoolExecutor as _TPE
            with _TPE(max_workers=3) as _ex:
                _f3 = None if _qict_only else _ex.submit(
                    track_karachi_terminals, bl)
                _f3b = _ex.submit(track_qict_bl, bl)
                _f3e = None if _qict_only else _ex.submit(
                    track_kgtl_bl, bl)
                if _f3 is not None:
                    try:
                        _raw3 = _f3.result()
                    except Exception as _e:
                        _raw3 = {"found": False, "error": str(_e)}
                try:
                    _raw3b = _f3b.result()
                except Exception as _e:
                    _raw3b = {"found": False, "note": str(_e)}
                if _f3e is not None:
                    try:
                        _raw3e = _f3e.result()
                    except Exception as _e:
                        _raw3e = {"found": False, "note": str(_e)}
        except Exception:
            _raw3 = _raw3b = None

    # v99 precedence (truth table 30 Oct 2026): TERMINAL
    # its discharge_time / position, over the carrier layer's stamps,
    # always wins — COSCO's discharge stamps
    # turned out to be 1-2 days earlier, and on the APL CHONGQING trio
    # the berthing stamp had become the discharge. The first
    # terminal writer wins; among terminals too,
    # the earlier one will be treated as confirmed.
    _term_dis = False
    _term_pos = False
    # v99fix (d): whether any terminal layer actually
    # found this record or not — the carrier-discharge
    # confirmation rule (below, in the tail) depends
    # on exactly this.
    _term_found = False

    # Layer 3: Karachi terminals (KICT/SAPT) — on every BL, house BLs too
    if bl and not _qict_only:
        lname = "Layer 3 — Karachi Terminal"
        prog(lname, "running")
        out["tried"].append(lname)
        rt = _raw3 if _raw3 is not None else track_karachi_terminals(bl)
        if rt.get("found"):
            _st, _wh = _stale_info(rt)
            if _st:
                rt = {"found": False, "note":
                      f"Karachi Terminal holds only an OLD record "
                      f"for this BL ({_wh}) — not counted as current."}
        ok = bool(rt.get("found"))
        out["layers"].append({"name": lname, "mode": "bl", "status": "done" if ok else "fail",
                              "detail": (f"{len(rt.get('containers',[]))} container(s)"
                                         + (f" at {rt['terminal']}"
                                            if rt.get('terminal') else "")
                                        ) if ok else (rt.get("note") or rt.get("error") or "")})
        if ok:
            _term_found = True
            _newct = [c.get("CONTAINER NO", "")
                      for c in rt["containers"]]
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + _newct if c]))
            if rt.get("terminal"):
                out["result"]["terminal"] = rt["terminal"]
            out["result"]["terminal_rows"] = rt["containers"]
            # fill empty fields from terminal details (giving priority to carrier data)
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "discharge_time", "do_expiry", "position", "holds", "vir",
                      "weight", "commodity", "size_type", "custom_status",
                      "category", "gate_in", "gate_out", "owner"):
                if rt.get(k) and not out["result"].get(k):
                    out["result"][k] = rt[k]
            # v99 precedence: the terminal's discharge/position
            # wins over the carrier's stamp (see above).
            if rt.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rt["discharge_time"]
                _term_dis = True
            if rt.get("position") and not _term_pos:
                out["result"]["position"] = rt["position"]
                _term_pos = True
            # discharge/gate-out is the terminal's ground reality — status override
            if rt.get("status"):
                out["result"]["status"] = rt["status"]
            elif not out["result"].get("status"):
                # v112: the "Arrived" status is built only on real identification
                # (VIR / discharge / terminal name)
                # — never on bare rows.
                if rt.get("vir") or rt.get("discharge_time") \
                        or rt.get("terminal"):
                    out["result"]["status"] = (
                        f"Arrived at {rt['terminal']} terminal (Karachi)"
                        if rt.get("terminal") else
                        "Arrived at Karachi terminal")
            if rt.get("source"):
                out["result"]["source"] = rt["source"]
            if rt.get("vessel") and not got_vessel:
                got_vessel = rt["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3b: QICT (DP World) — if not found at KICT/SAPT (Emkay/RTW cargo)
    if bl:
        lname = "Layer 3b — QICT (DP World Karachi)"
        prog(lname, "running")
        out["tried"].append(lname)
        rq = _raw3b if _raw3b is not None else track_qict_bl(bl)
        if rq.get("found"):
            _st, _wh = _stale_info(rq)
            if _st:
                rq = {"found": False, "note":
                      f"QICT holds only an OLD record for this BL "
                      f"({_wh}) — not counted as current."}
        ok = bool(rq.get("found"))
        out["layers"].append({"name": lname, "mode": "bl", "status": "done" if ok else "fail",
                              "detail": (", ".join(rq.get("containers", []))
                                         if ok else rq.get("note", ""))})
        if ok:
            _term_found = True
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + list(rq["containers"]) if c]))
            if not out["result"].get("terminal"):
                out["result"]["terminal"] = "QICT"
            for k in ("vessel", "voyage", "discharge_time", "holds",
                      "vir", "line", "pod", "category", "truck", "gd_no"):
                if rq.get(k) and not out["result"].get(k):
                    out["result"][k] = rq[k]
            # v99 precedence: QICT's discharge wins over the carrier's
            # stamp.
            if rq.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rq["discharge_time"]
                _term_dis = True
            # QICT is the ground truth for cargo sitting at QICT:
            # its standing/position override any older carrier status
            # (v28 audit fix — a stale "in transit" must not survive).
            if rq.get("status"):
                out["result"]["status"] = rq["status"]
            if rq.get("position"):
                out["result"]["position"] = rq["position"]
                _term_pos = True
            if rq.get("source"):
                out["result"]["source"] = rq["source"]
            if rq.get("vessel") and not got_vessel:
                got_vessel = rq["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3e: KGTL (Karachi Gateway Terminal — AD Ports, East
    # Wharf) — the third Karachi terminal; added in v61, on 25 Oct
    # 2026 verified on a real BL (ATA/VIR/container grid).
    if bl and not _qict_only:
        lname = "Layer 3e — KGTL (Karachi Gateway Terminal)"
        prog(lname, "running")
        out["tried"].append(lname)
        rg = _raw3e if _raw3e is not None else track_kgtl_bl(bl)
        if rg.get("found"):
            _st, _wh = _stale_info(rg)
            if _st:
                rg = {"found": False, "note":
                      f"KGTL holds only an OLD record for this BL "
                      f"({_wh}) — not counted as current."}
        ok = bool(rg.get("found"))
        out["layers"].append({"name": lname, "mode": "bl", "status": "done" if ok else "fail",
                              "detail": (", ".join(rg.get("containers", []))
                                         if ok else rg.get("note", ""))})
        if ok:
            _term_found = True
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + list(rg["containers"]) if c]))
            if not out["result"].get("terminal"):
                out["result"]["terminal"] = "KGTL"
            out["result"]["terminal_rows"] = _union_rows(
                out["result"].get("terminal_rows") or [],
                rg.get("terminal_rows") or [])
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "position", "holds", "vir", "weight", "commodity",
                      "size_type", "category", "kgtl_empty_in",
                      "kgtl_departed", "kgtl_empty_holds", "release_code"):
                if rg.get(k) and not out["result"].get(k):
                    out["result"][k] = rg[k]
            # v99 precedence: KGTL's discharge is also terminal
            # evidence — it wins over the carrier stamp.
            if rg.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rg["discharge_time"]
                _term_dis = True
            # v99 flip guard: KGTL's 'Expected…' estimate, any
            # terminal-confirmed status, even inside the synthesis,
            # cannot suppress — expected only gives an ETA
            # (the same principle as the server's merge guard, here
            # inside the engine).
            if rg.get("status") and not (
                    rg.get("expected")
                    and out["result"].get("status")
                    and "expected" not in
                    out["result"]["status"].lower()):
                out["result"]["status"] = rg["status"]
            if rg.get("expected"):
                out["result"]["expected"] = True
            if rg.get("source"):
                out["result"]["source"] = rg["source"]
            if rg.get("vessel") and not got_vessel:
                got_vessel = rg["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3c: QICT by container number — container-first searches,
    # and cargo the BL search could not place at a terminal.
    ctn_known = ctn or (out["result"].get("containers") or [None])[0]
    if not ctn_known and known_containers:
        # v99: on re-check, also pass the stored record's containers
        # to the container-legs (the 26 Oct rule: every
        # re-search from BL + all containers) — otherwise a
        # BL whose BL-Inquiry response is shut off (cycle closed
        # — EMKAYMBAKHI57984) that record stays stuck forever
        # in its old state, even though its
        # container's terminal record is telling everything that
        # is.
        ctn_known = known_containers[0]
    # v51 SPEED: Layer 3c/3d (the container terminal routes) also
    # parallel prefetch — the merge will still be in the old order.
    _raw3c = _raw3d = _raw3f = None
    if ctn_known:
        try:
            from concurrent.futures import ThreadPoolExecutor as _TPE2
            with _TPE2(max_workers=3) as _ex2:
                _f3c = _ex2.submit(track_qict_container_layer, ctn_known)
                _f3d = _ex2.submit(track_karachi_terminals_container,
                                   ctn_known)
                _f3f = _ex2.submit(track_kgtl_container, ctn_known)
                try:
                    _raw3c = _f3c.result()
                except Exception as _e:
                    _raw3c = {"found": False, "note": str(_e)}
                try:
                    _raw3d = _f3d.result()
                except Exception as _e:
                    _raw3d = {"found": False, "error": str(_e)}
                try:
                    _raw3f = _f3f.result()
                except Exception as _e:
                    _raw3f = {"found": False, "note": str(_e)}
        except Exception:
            _raw3c = _raw3d = None
    if ctn_known:
        lname = "Layer 3c — QICT (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rc = _raw3c if _raw3c is not None else track_qict_container_layer(ctn_known)
        if rc.get("found"):
            _st, _wh = _stale_info(rc)
            if _st:
                rc = {"found": False, "note":
                      f"QICT holds only an OLD record for this "
                      f"container ({_wh}) — not counted as current."}
            elif _prev_cycle(rc, out):
                rc = {"found": False, "note":
                      "QICT's record for this container is from "
                      "its previous voyage — not this shipment."}
        ok = bool(rc.get("found"))
        out["layers"].append({"name": lname, "mode": "container", "status": "done" if ok else "fail",
                              "detail": (rc.get("status", "") if ok
                                         else rc.get("note", ""))})
        if ok:
            _term_found = True
            _ctn_evidence_add(ctn_ev, ctn_known, rc)
            if not out["result"].get("containers"):
                out["result"]["containers"] = [ctn_known]
            if not out["result"].get("terminal"):
                out["result"]["terminal"] = "QICT"
            if rc.get("cycle_closed"):
                # v99fix3: the container is now in the EXPORT cycle —
                # that cycle's VIR/vessel/voyage does NOT belong to this BL
                # (do not take the identity fields at all).
                # v99fix3 rule: export gate-in is NOT a return
                # — therefore from a cycle_closed result
                # never take returned/returned_date;
                # take only the export-cycle evidence (In/Load Time)
                # so that _settle can retract the old incorrect returned
                # claim.
                out["result"]["cycle_closed"] = True
                if rc.get("qict_export_in"):
                    out["result"]["qict_export_in"] = \
                        rc["qict_export_in"]
                if rc.get("qict_export_load"):
                    out["result"]["qict_export_load"] = \
                        rc["qict_export_load"]
                if not out["result"].get("status"):
                    out["result"]["status"] = \
                        rc.get("status") or "Gate out"
            else:
                for k in ("vessel", "voyage", "discharge_time",
                          "holds", "vir", "line", "pod",
                          "gate_out", "truck"):
                    if rc.get(k) and not out["result"].get(k):
                        out["result"][k] = rc[k]
                # v99 precedence: the terminal's discharge /
                # position wins over the carrier stamp.
                if rc.get("discharge_time") and not _term_dis:
                    out["result"]["discharge_time"] = \
                        rc["discharge_time"]
                    _term_dis = True
                if rc.get("position") and not _term_pos:
                    out["result"]["position"] = rc["position"]
                    _term_pos = True
                # v99 (investigation fix 4): by-container
                # the leg's status text does not blindly suppress
                # the BL leg's status — QICT Ctr-Inq's
                # 'Discharged at QICT' even after gate-out
                # always remains; it is only evidence,
                # the decision is veto/reconcile's. Take the text only
                # when the result has no status at
                # all, the leg is reporting a HOLD
                # (the terminal's hold state should never be suppressed
                # ), or the leg has gate_out
                # evidence with a date AND the current status
                # is weaker than it (that is not text, the terminal's
                # record it is — but a strong claim like 'Delivered'
                # is not suppressed by it).
                if rc.get("status") and (
                        not out["result"].get("status")
                        or "hold" in rc["status"].lower()
                        or (rc.get("gate_out")
                            and status_text_stage(
                                out["result"].get("status"))
                            < 4)):
                    out["result"]["status"] = rc["status"]
            if rc.get("expected"):
                out["result"]["expected"] = True
            if rc.get("source"):
                out["result"]["source"] = rc["source"]
            if rc.get("vessel") and not got_vessel:
                got_vessel = rc["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3d: Karachi Terminal by container number
    if ctn_known:
        lname = "Layer 3d — Karachi Terminal (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rd = _raw3d if _raw3d is not None else track_karachi_terminals_container(ctn_known)
        if rd.get("found"):
            _st, _wh = _stale_info(rd)
            if _st:
                rd = {"found": False, "note":
                      f"Karachi Terminal holds only an OLD record "
                      f"for this container ({_wh}) — not counted "
                      f"as current."}
            elif _prev_cycle(rd, out):
                rd = {"found": False, "note":
                      "The terminal's record for this container "
                      "is from its previous voyage — not this "
                      "shipment."}
        ok = bool(rd.get("found"))
        out["layers"].append({"name": lname, "mode": "container", "status": "done" if ok else "fail",
                              "detail": (f"{len(rd.get('containers',[]))} container(s)"
                                         + (f" at {rd['terminal']}"
                                            if rd.get('terminal') else "")
                                        ) if ok else (rd.get("note") or rd.get("error") or "")})
        if ok:
            _term_found = True
            _ctn_evidence_add(ctn_ev, ctn_known, rd)
            _newct = [c.get("CONTAINER NO", "")
                      for c in rd["containers"]]
            _oldct = out["result"].get("containers") or []
            out["result"]["containers"] = list(dict.fromkeys(
                [c for c in _oldct + _newct if c]))
            _rt = rd.get("terminal", "")
            # v99fix2: rows are always UNION — this is evidence,
            # not dependent on the terminal's name. An XF-only
            # leg's terminal is empty (no detail
            # at all — no VIR itself), so on the first condition
            # its XF row itself used to disappear; then
            # in the merge, in front of the legacy gate_in, its
            # explanation (XF row) being absent, that same
            # gate_in would become 'returned'
            # (MBAQITS8502261016, Phase 2). The terminal's
            # name will change only when the leg has stated
            # a terminal (the condition below).
            _had_rows = bool(out["result"].get("terminal_rows"))
            out["result"]["terminal_rows"] = _union_rows(
                out["result"].get("terminal_rows") or [],
                rd["containers"])
            if _rt and (not out["result"].get("terminal")
                        or out["result"]["terminal"] == _rt
                        or not _had_rows):
                out["result"]["terminal"] = _rt
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "discharge_time", "do_expiry", "position", "holds",
                      "vir", "weight", "commodity", "size_type",
                      "custom_status", "category", "gate_in", "gate_out",
                      "owner"):
                if rd.get(k) and not out["result"].get(k):
                    out["result"][k] = rd[k]
            # v99 precedence: the terminal's discharge/position
            # wins over the carrier stamp.
            if rd.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rd["discharge_time"]
                _term_dis = True
            if rd.get("position") and not _term_pos:
                out["result"]["position"] = rd["position"]
                _term_pos = True
            if rd.get("status"):
                out["result"]["status"] = rd["status"]
            elif not out["result"].get("status"):
                # v112: on bare rows (without VIR/discharge/terminal)
                # "Arrived" is never formed.
                if rd.get("vir") or rd.get("discharge_time") \
                        or rd.get("terminal"):
                    out["result"]["status"] = (
                        f"Arrived at {rd['terminal']} terminal (Karachi)"
                        if rd.get("terminal") else
                        "Arrived at Karachi terminal")
            if rd.get("source"):
                out["result"]["source"] = rd["source"]
            if rd.get("vessel") and not got_vessel:
                got_vessel = rd["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3f: KGTL by container number — only when no
    # terminal has been identified yet (KGTL's ground
    # truth is final for its own yard, another terminal's
    # record is never overridden).
    if ctn_known and not out["result"].get("terminal"):
        lname = "Layer 3f — KGTL (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rf = _raw3f if _raw3f is not None else track_kgtl_container(ctn_known)
        if rf.get("found"):
            _st, _wh = _stale_info(rf)
            if _st:
                rf = {"found": False, "note":
                      f"KGTL holds only an OLD record for this "
                      f"container ({_wh}) — not counted as current."}
        ok = bool(rf.get("found"))
        out["layers"].append({"name": lname, "mode": "container", "status": "done" if ok else "fail",
                              "detail": (rf.get("status", "") if ok
                                         else rf.get("note", ""))})
        if ok:
            _term_found = True
            _ctn_evidence_add(ctn_ev, ctn_known, rf)
            if not out["result"].get("containers"):
                out["result"]["containers"] = [ctn_known]
            out["result"]["terminal"] = "KGTL"
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "position", "holds", "vir", "weight", "commodity",
                      "size_type", "category", "kgtl_empty_in"):
                if rf.get(k) and not out["result"].get(k):
                    out["result"][k] = rf[k]
            # v99 precedence: the KGTL container leg's
            # discharge is also terminal evidence.
            if rf.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rf["discharge_time"]
                _term_dis = True
            if rf.get("status"):
                out["result"]["status"] = rf["status"]
            if rf.get("expected"):
                out["result"]["expected"] = True
            if rf.get("source"):
                out["result"]["source"] = rf["source"]
            if rf.get("vessel") and not got_vessel:
                got_vessel = rf["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # v99fix (b): every container's history is mandatory. BL mode
    # gives only LISTING rows (one row for each container —
    # without STATUS/time); EM (empty-return) rows are only
    # found in the container mode history, and
    # by-container legs (3c/3d/3f) ran only on the FIRST
    # container. A container whose real history rows are not
    # among the collected rows, its container-mode
    # history is now fetched here and UNIONed —
    # otherwise the other container's return would remain missing forever
    # (MEDUT1385110's CXDU1175597: rows were not stored
    # at all, 30 Oct 2026 Phase-1 fail).
    _all_ctns = list(dict.fromkeys(
        [c for c in (out["result"].get("containers") or []) if c]
        + [c for c in (known_containers or []) if c]))

    def _has_hist(_c):
        for _row in out["result"].get("terminal_rows") or []:
            if not isinstance(_row, dict):
                continue
            if str(_row.get("CONTAINER NO") or "").strip() != _c:
                continue
            if str(_row.get("STATUS") or "").strip() \
                    or _row.get("DISCHARGING TIME") \
                    or _row.get("GATE OUT TIME"):
                return True
        return False

    _missing = [c for c in _all_ctns
                if c != ctn_known and not _has_hist(c)]
    if _missing:
        lname = "Layer 3d+ — Karachi Terminal (remaining containers)"
        prog(lname, "running")
        out["tried"].append(lname)
        _done_c = []
        for _c in _missing:
            rx = track_karachi_terminals_container(_c)
            if rx.get("found"):
                _st, _wh = _stale_info(rx)
                if _st:
                    rx = {"found": False}
                elif _prev_cycle(rx, out):
                    rx = {"found": False}
            if not rx.get("found"):
                continue
            _done_c.append(_c)
            _term_found = True
            _ctn_evidence_add(ctn_ev, _c, rx)
            out["result"]["terminal_rows"] = _union_rows(
                out["result"].get("terminal_rows") or [],
                rx.get("containers") or [])
            if rx.get("terminal") \
                    and not out["result"].get("terminal"):
                out["result"]["terminal"] = rx["terminal"]
            for k in ("vessel", "voyage", "eta", "etd", "pol",
                      "pod", "discharge_time", "do_expiry",
                      "position", "holds", "vir", "weight",
                      "commodity", "size_type", "custom_status",
                      "category", "gate_in", "gate_out", "owner",
                      "empty_gate_in"):
                if rx.get(k) and not out["result"].get(k):
                    out["result"][k] = rx[k]
            # terminal precedence (the same rule as v99):
            # this leg's discharge/position over the carrier stamp
            # wins, after the first terminal writer
            # a second does not override it.
            if rx.get("discharge_time") and not _term_dis:
                out["result"]["discharge_time"] = rx["discharge_time"]
                _term_dis = True
            if rx.get("position") and not _term_pos:
                out["result"]["position"] = rx["position"]
                _term_pos = True
            # shipment gate_out = the time all containers go out
            # : if the completion leg's gate_out is later,
            # that is the completion.
            _gx = _term_ts_full(rx.get("gate_out"))
            _gc = _term_ts_full(out["result"].get("gate_out"))
            if _gx and (not _gc or _gx[0] > _gc[0]):
                out["result"]["gate_out"] = rx["gate_out"]
            if rx.get("status") and (
                    not out["result"].get("status")
                    or status_text_stage(rx["status"])
                    > status_text_stage(
                        out["result"].get("status"))):
                out["result"]["status"] = rx["status"]
            if rx.get("source"):
                out["result"]["source"] = rx["source"]
            if rx.get("vessel") and not got_vessel:
                got_vessel = rx["vessel"]
        out["layers"].append({
            "name": lname,
            "mode": "container",
            "status": "done" if _done_c else "fail",
            "detail": (f"{len(_done_c)} container(s): "
                       + ", ".join(_done_c)) if _done_c
                      else "No terminal history for the "
                           "remaining containers."})
        prog(lname, "done" if _done_c else "fail",
             out["layers"][-1].get("detail", ""))

    # Terminal confirm: if the terminal name is clear in the carrier's POD
    # (for example "Karachi-South Asia Pakistan Terminals(SAPT)") then that
    # is solid evidence — do not guess.
    if not out["result"].get("terminal"):
        _pod = (out["result"].get("pod") or "").upper()
        if "SAPT" in _pod or "SOUTH ASIA PAKISTAN" in _pod:
            out["result"]["terminal"] = "SAPT"
        elif "KICT" in _pod or "KARACHI INTERNATIONAL" in _pod:
            out["result"]["terminal"] = "KICT"

    # Layer 3g: Hutchison Portal (KICT/SAPT's new nBIS system).
    # 27 Oct 2026 evidence: FRLSUBKHI276826 on the old KICT enquiry
    # was "not found" while on the new portal the full record (vessel,
    # berthing, ETA, holds) was present — the old system
    # cannot show pre-arrival records at all. The portal's data-service is closed to outside
    # direct calls, so this is a guidance layer:
    # with every Karachi search, the portal's confirmed 1-click route,
    # so that "not found" is never a dead-end.
    if (bl or ctn) and not _qict_only:
        lname = "Layer 3g — Hutchison Portal KICT/SAPT (manual check)"
        prog(lname, "running")
        out["tried"].append(lname)
        out["layers"].append({"name": lname, "mode": "manual", "status": "fail",
            "detail": "New Hutchison portal (KICT + SAPT) — pre-arrival records appear here before the old enquiry can see them. Open the source link (the number is copied for you), pick the port, Public Function, Container Inquiry. Public, no login."})
        prog(lname, "fail", out["layers"][-1]["detail"])

    # Layer 4: vessel live
    if got_vessel and looks_like_vessel(got_vessel):
        lname = f"Layer 4 — VesselFinder ({got_vessel})"
        prog(lname, "running")
        out["tried"].append(lname)
        rv = vessel_live_position(got_vessel)
        ok = bool(rv.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": rv.get("destination", "")})
        if ok:
            for k in ("destination", "speed"):
                if k in rv:
                    out["result"][k] = rv[k]
            if rv.get("url"):
                out["result"]["vf_url"] = rv["url"]
            # Vessel-level ETA only while the cargo is still at sea —
            # never for discharged / released / delivered / held cargo.
            st_now = (out["result"].get("status") or "").lower()
            completed = bool(out["result"].get("discharge_time")) or any(
                w in st_now for w in ("discharg", "released", "delivered",
                                      "gate out", "on hold"))
            if rv.get("eta") and not out["result"].get("eta") and not completed:
                out["result"]["eta"] = rv["eta"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 4b: Vessel Schedule (ShipsGo) — Emkay / RTW jaisi
    # for lines whose own tracking website does not provide it.
    # Only when: the vessel is known, no terminal has found
    # a record, there is no discharge, and the current status is weak.
    # The schedule only fills empty places (departure, ETA,
    # status text) — it never touches terminal evidence.
    _sched_vessel = got_vessel or known_vessel
    _cur_status = out["result"].get("status") or ""
    _pol_txt = (out["result"].get("pol") or "").upper()
    _sched_carrier = (out.get("carrier") in
                      ("Emkay Line", "RTW Shipping Lines")
                      or "MOMBASA" in _pol_txt)
    if bl and _sched_vessel and looks_like_vessel(_sched_vessel) \
            and not _term_found \
            and not out["result"].get("discharge_time") \
            and _sched_carrier \
            and (status_text_stage(_cur_status) == 0
                 or "in progress" in _cur_status.lower()):
        lname = f"Layer 4b — Vessel Schedule (ShipsGo) ({_sched_vessel})"
        prog(lname, "running")
        out["tried"].append(lname)
        rs = track_vessel_schedule(_sched_vessel)
        ok = bool(rs.get("found"))
        _detail = (rs.get("note") or rs.get("error") or "")[:120]
        if ok:
            calls = rs["calls"]
            _voy = re.sub(r"[^A-Z0-9]", "",
                          (out["result"].get("voyage") or "").upper())
            _origin = "MOMBASA"
            if _pol_txt:
                _origin = re.split(r"[,\s]", _pol_txt.strip())[0] \
                    or "MOMBASA"
            _dep = None
            for c in calls:
                if c["kind"] == "recent" and _origin in \
                        c["port"].upper():
                    _dep = c
                    if not _voy or not c.get("voyage") or \
                            re.sub(r"[^A-Z0-9]", "",
                                   c["voyage"].upper()) == _voy:
                        break
            _dest = None
            # Yousuf's firm rule (5 Nov 2026): Emkay / RTW
            # come only to QICT (Port Qasim) — for them ETA
            # only from the Port Qasim call, never from Karachi.
            _qict_only = out.get("carrier") in \
                ("Emkay Line", "RTW Shipping Lines")
            for c in calls:
                if c["kind"] != "upcoming":
                    continue
                if _qict_only:
                    _is_dest = c["code"] == "PKBQM" or \
                        "PORT QASIM" in c["port"].upper()
                else:
                    _is_dest = c["code"] in ("PKBQM", "PKKHI") or \
                        "PORT QASIM" in c["port"].upper() or \
                        c["port"].upper() == "KARACHI"
                if _is_dest:
                    # If the record's voyage is known, ETA only
                    # from THAT voyage's call — the next rotation's
                    # call is not this cargo's ETA.
                    if _voy and c.get("voyage") and \
                            re.sub(r"[^A-Z0-9]", "",
                                   c["voyage"].upper()) != _voy:
                        continue
                    _dest = c
                    break
            _ts_port = None
            if not _dest and _dep:
                # Transshipment port = after departure, the vessel's
                # first actual call (from the recent list) — upcoming
                # calls cannot belong to this cargo.
                _after = [c for c in calls
                          if c["kind"] == "recent"
                          and c["d1"] >= _dep["d2"]
                          and _origin not in c["port"].upper()]
                if _after:
                    _ts_port = min(_after,
                                   key=lambda c: c["d1"])["port"]
            _res = out["result"]
            _dep_str = _sg_fmt(_dep["d2"]) if _dep else None
            _eta_str = _sg_fmt(_dest["d1"]) if _dest else None
            if _dep_str and not _res.get("etd"):
                _res["etd"] = _dep_str
            if _eta_str and not _res.get("eta"):
                _res["eta"] = _eta_str
            if _dep and not _res.get("pol"):
                _res["pol"] = _dep["port"].title()
            if _dest and not _res.get("pod"):
                _res["pod"] = _dest["port"].title()
            if not _res.get("vessel"):
                _res["vessel"] = rs["vessel"]
            _res["vessel_calls"] = [
                f"{c['port']} — {_sg_fmt(c['d1'])}"
                + (f" to {_sg_fmt(c['d2'])}"
                   if c['d2'] != c['d1'] else "")
                + (f" (voy {c['voyage']})" if c.get("voyage") else "")
                for c in calls[:8]]
            if not _res.get("source"):
                _res["source"] = rs["source"]
            if _dep_str:
                _new_status = (f"In transit — departed "
                               f"{_dep['port'].title()} {_dep_str}")
                if not _dest and _ts_port:
                    _new_status += f" · via {_ts_port.title()}"
                _res["status"] = _new_status
            elif _eta_str:
                _res["status"] = (f"In transit — expected "
                                  f"{_dest['port'].title()} {_eta_str}")
            _detail = " · ".join(x for x in [
                f"departed {_dep['port'].title()} {_dep_str}"
                if _dep_str else "",
                f"expected {_dest['port'].title()} {_eta_str}"
                if _eta_str else "",
                f"via {_ts_port.title()}"
                if (not _dest and _ts_port) else ""] if x)[:160] \
                or f"{len(calls)} port calls"
        out["layers"].append({"name": lname,
                              "status": "done" if ok else "fail",
                              "detail": _detail})
        prog(lname, "done" if ok else "fail", _detail)

    # containers are never duplicated (the terminal sometimes sends one container's
    # many rows — caught on MCLSUB26104308)
    if out["result"].get("containers"):
        out["result"]["containers"] = list(
            dict.fromkeys(out["result"]["containers"]))
    # if not identified from the prefix but some layer has stated the actual
    # shipping line, then that is the carrier
    if not out.get("carrier") and out["result"].get("line"):
        out["carrier"] = _canon_line(out["result"]["line"])

    # Layer 5 — Traqo (API): the last route, only when there is a key
    # and even after all free layers no record has been found
    # (free plan: every new reference consumes 1 monthly slot,
    # therefore never earlier).
    if traqo_key and not out["result"] and (bl or ctn):
        lname = "Layer 5 — Traqo (API)"
        prog(lname, "running")
        out["tried"].append(lname)
        rt = track_traqo(bl or ctn, bool(ctn and not bl),
                         out.get("carrier") or carrier_hint, traqo_key)
        ok = bool(rt.get("found"))
        out["layers"].append({
            "name": lname, "status": "done" if ok else "fail",
            "detail": (rt.get("latest_event") or rt.get("status")
                       or rt.get("note") or "") if ok
                      else (rt.get("note") or "")})
        if ok:
            out["result"] = {k: v for k, v in rt.items()
                              if k not in ("found", "note")}
            if rt.get("line") and not out.get("carrier"):
                out["carrier"] = _canon_line(rt["line"])
        prog(lname, "done" if ok else "fail",
             out["layers"][-1].get("detail", ""))

    # v99fix (d): verification of a carrier-only discharge stamp.
    # A terminal (KICT/SAPT/QICT — all three of these
    # give a discharge stamp when discharge happens)
    # keeps this record on its current VIR
    # but does NOT show the container's discharge, then the carrier's
    # stamp will NOT be counted as discharge — on the APL
    # CHONGQING trio that same stamp (29-Oct 15:00)
    # was the berthing time; two containers' actual discharge
    # was given by the terminal (it won by precedence), the third
    # (COAU6468022200) is not on the terminal at all, so
    # there the stamp will remain 'unclaimed'. The merge
    # gets a 'discharge_unconfirmed' mark so that
    # an old stamp does not survive the merge. If terminal
    # discharge is present then this rule does not apply at all
    # (_term_dis). KGTL is outside this: its layers
    # do not give a discharge_time field at all, their silence
    # cannot become evidence.
    _res = out["result"]
    if _res.get("discharge_time") and not _term_dis \
            and _term_found \
            and vir_terminal(_res.get("vir")) \
            in ("KICT", "SAPT", "QICT"):
        _res.pop("discharge_time", None)
        _res["discharge_unconfirmed"] = True
        if status_text_stage(_res.get("status")) == 3 \
                and "hold" not in (_res.get("status") or "").lower():
            _t = _res.get("terminal") \
                or vir_terminal(_res.get("vir"))
            _res["status"] = (
                "At QICT terminal (Port Qasim)" if _t == "QICT"
                else f"Arrived at {_t} terminal (Karachi)" if _t
                else "Arrived")
    # v99: if the terminal rows contain empty-return evidence,
    # record it on the result (the flow never used to write this
    # before) — before veto/reconcile, so that every calculation
    # in this run sees the actual return.
    _apply_empty_return(out["result"])
    # v96 proof-run fix: first the veto from by-container evidence —
    # if any own container has solid yard evidence, first clear the BL-level
    # Delivered/OUT claim, otherwise
    # _reconcile_status will raise the text back to 'Delivered' from that same
    # false evidence (truck/OUT) (MBAQITS8502261016).
    _apply_container_veto(out["result"], ctn_ev)
    # v96: match the status text to the result's own evidence — no
    # layer should suppress stronger evidence with older weaker text
    # (269665315: 'Discharged' + OUT + truck delivered).
    _reconcile_status(out["result"])
    if _qict_only:
        # Emkay/RTW: the container's Karachi-side rows still
        # merge silently above (an export-leg row is real
        # evidence for the empty-return derivation), but an
        # EMPTY Karachi/KGTL container check is not shown —
        # this cargo only ever comes to QICT.
        def _kr_line(l):
            nm = l.get("name") or ""
            return (("Karachi Terminal" in nm or "KGTL" in nm)
                    and "(by container)" in nm
                    or "remaining containers" in nm)
        out["layers"] = [l for l in out["layers"]
                         if not (_kr_line(l)
                                 and l.get("status") != "done")]
        _drop = {l.get("name") for l in out["layers"]}
        out["tried"] = [t for t in out["tried"]
                        if not (("Karachi Terminal" in t
                                 or "KGTL" in t)
                                and "container" in t
                                and t not in _drop)]
    return out


def main():
    args = sys.argv[1:]
    ctn = None
    # -c / --container: only a container number was given (without a BL)
    # -v / --vessel: only the vessel name (live position/ETA)
    vessel_only = False
    if args and args[0] in ("-c", "--container"):
        if len(args) < 2:
            print("Usage: python3 bl-track.py -c <CONTAINER_NUMBER>")
            sys.exit(1)
        ctn = norm(args[1]); bl = None
    elif args and args[0] in ("-v", "--vessel"):
        if len(args) < 2:
            print("Usage: python3 bl-track.py -v <VESSEL_NAME>")
            sys.exit(1)
        vessel_only = True
        vessel_name = " ".join(args[1:])
    else:
        if not args:
            print("Usage: python3 bl-track.py <BL_NUMBER> [CONTAINER_NUMBER]")
            print("       python3 bl-track.py -c <CONTAINER_NUMBER>")
            print("       python3 bl-track.py -v <VESSEL_NAME>")
            sys.exit(1)
        bl = norm(args[0])
        ctn = norm(args[1]) if len(args) > 1 else None

    # Standalone vessel tracking (Layer 4 direct)
    if vessel_only:
        print(f"Vessel    : {vessel_name}")
        print("-" * 50)
        print("\n[Layer 4] VesselFinder — live position...")
        report_result(vessel_live_position(vessel_name))
        return

    print(f"BL Number : {bl}" if bl else "BL Number : (Not Given)")
    if ctn:
        print(f"Container : {ctn}")
    print("-" * 50)

    tried = []   # which routes were tried — for the summary at the end
    got_vessel = None

    # Layer 0: Identify the carrier (instantly, offline) — from the BL, otherwise from the container
    prefix, carrier = identify_carrier(bl) if bl else identify_carrier(ctn)
    if carrier:
        print(f"Carrier   : {carrier}  (prefix {prefix})")
    else:
        print(f"Carrier   : Unknown (prefix {prefix} not in the list)")

    # Forwarder with no online tracking: try online first,
    # if not found, give the contact (do not give up)
    forwarder_contact = FORWARDER_CONTACTS.get(carrier)
    if forwarder_contact and carrier == "RTW Shipping Lines":
        # RTW: no online tracking — contact directly, but first
        # try the aggregators once (Layer 2 will run below)
        pass  # normal flow below, contact at the end in the summary

    # Layer 1: The carrier's direct API (fastest and most accurate — ~1 second)
    api_fn = CARRIER_APIS.get(carrier) if (carrier and bl) else None
    r = {}
    if api_fn:
        print(f"\n[Layer 1] {carrier} direct API...")
        tried.append(f"Layer 1 ({carrier} API)")
        r = api_fn(bl)
        report_result(r)
        if r.get("found"):
            got_vessel = r.get("vessel")
    elif bl:
        # Layer 2: BL tracking via track-trace (if there is no carrier API)
        print("\n[Layer 2] track-trace.com — BL tracking...")
        tried.append("Layer 2 (track-trace BL)")
        r = track_bol_tracktrace(bl, carrier)
        report_result(r)
        if r.get("found"):
            got_vessel = r.get("vessel")

    # Layer 2b: Container tracking — first the carrier API, then track-trace
    if ctn:
        capi_fn = CARRIER_CONTAINER_APIS.get(carrier) if carrier else None
        if capi_fn:
            print(f"\n[Layer 2] {carrier} container API...")
            tried.append(f"Layer 2 ({carrier} container API)")
            r2 = capi_fn(ctn)
        else:
            print("\n[Layer 2] track-trace.com — Container tracking...")
            tried.append("Layer 2 (track-trace container)")
            r2 = track_container_tracktrace(ctn)
        report_result(r2)
        if r2.get("found") and not got_vessel:
            got_vessel = r2.get("vessel")

    # Layer 4: Vessel live tracking — if the vessel name was found
    if got_vessel:
        print(f"\n[Layer 4] VesselFinder — {got_vessel} live position...")
        tried.append(f"Layer 4 (VesselFinder: {got_vessel})")
        report_result(vessel_live_position(got_vessel))

    # Never give up — summary: what was tried, what the next route is
    print("\n" + "=" * 50)
    print("SUMMARY — ye raste try kiye:")
    for t in tried:
        print(f"  - {t}")
    print("\nAgla rasta (browser se — Layer 1b/3):")
    direct = r.get("direct_url") if isinstance(r, dict) else None
    lookup_num = bl or ctn
    print(f"  - Carrier site: {direct or direct_tracking_url(carrier, lookup_num)}")
    print("  - Karachi ports (container/BL enquiry):")
    print("      KICT: https://www.kictl.com/Enquiries?is=ContainerBLEnquiry")
    print("      SAPT: https://www.sapt.com.pk/Enquiries?is=ContainerBLEnquiry")
    # Forwarder contact (if not found online)
    fc = FORWARDER_CONTACTS.get(carrier)
    if fc:
        print(f"\n  - {carrier} — direct contact (no online tracking):")
        print(f"      Phone: {fc['phone']} | Email: {fc['email']}")
        print(f"      {fc['note']}")
    print("  (open in a browser — bot-blocked sites open there)")


def direct_tracking_url(carrier, bl_number):
    """Pre-filled tracking URL by carrier (1-click)."""
    if carrier == "COSCO Shipping":
        return ("https://elines.coscoshipping.com/ebusiness/cargoTracking"
                f"?trackingType=BILLOFLADING&number={bl_number}")
    if carrier == "OOCL":
        # 19 Oct 2026: Traqo tracks OOCL (oocl.com is bot-blocked)
        return (f"https://traqocontainer.com/track/bl/{bl_number}"
                f"?carrier=OOLU")
    return CARRIER_TRACK_URL.get(carrier,
                                 "https://www.track-trace.com/")


def multi_source_urls(carrier, bl_number):
    """Multiple third-party + carrier URLs — the user opens them in 1-click."""
    urls = []
    # 1. The carrier's original site (original)
    orig = CARRIER_TRACK_URL.get(carrier)
    if orig:
        urls.append(("🏢 Carrier Official", orig))
    # 2. Traqo (OOCL verified, and more carriers)
    code = {"OOCL": "OOLU", "Maersk": "MAEU",
            "COSCO Shipping": "COSU"}.get(carrier, "")
    if code:
        urls.append(("🔍 Traqo", f"https://traqocontainer.com/track/bl/"
                     f"{bl_number}?carrier={code}"))
    # 3. track-trace
    urls.append(("🔍 track-trace", "https://www.track-trace.com/bol"))
    # 4. GoComet
    urls.append(("🔍 GoComet",
                 "https://www.gocomet.com/online-container-tracking"))
    return urls


def report_result(r):
    if "error" in r:
        print(f"    !! {r['error']}")
        return
    if r.get("deferred"):
        print(f"    -- {r.get('note','')}")
        return
    if not r.get("found"):
        print(f"    -- no record found. {r.get('note','')}")
        return
    print("    >> RECORD FOUND")
    for k in ["vessel", "voyage", "pol", "pod", "etd", "eta", "status",
              "destination", "speed", "nav_status", "position_time",
              "containerNumberStatus", "location"]:
        if k in r:
            label = {"nav_status": "NAV_STATUS",
                     "position_time": "POS_TIME"}.get(k, k.upper())
            print(f"    {label:8}: {r[k]}")
    if "raw_snippet" in r and len(r) <= 4:
        print(f"    Detail: {r['raw_snippet'][:300]}")


if __name__ == "__main__":
    main()
