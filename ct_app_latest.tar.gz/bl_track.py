#!/usr/bin/env python3
"""
bl-track.py — tez BL / Container tracking (bina browser ke, secondon mein).

Usage:
    python3 bl-track.py <BL_NUMBER> [CONTAINER_NUMBER]

Kaam:
  1. BL prefix se carrier pehchanta hai (offline, foran)
  2. track-trace.com se HTTP par tracking nikalta hai (browser nahi khulta)
  3. Vessel, voyage, ETA, status print karta hai
  4. Na mile to seedha tracking link de deta hai (1 click mein khud dekh lo)

House BL ho to container number bhi do — us se tracking ho jati hai.
"""

import re
import sys
import time
import html
import urllib.request
import urllib.parse
import http.cookiejar
from datetime import datetime

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

# Evergreen ki apni tracking site (ShipmentLink)
SL_URL = "https://ct.shipmentlink.com/servlet/TDB1_CargoTracking.do"

# ---- Carrier prefix table (BL number ke shuru ke 4 harf) ----
# 19 Oct 2026 correction: "COAU = COSCO" wali mapping ek kamzor blog source par
# thi — official COSCO code COSU hai. COAU hata diya gaya, kyunke ghalat carrier
# pehchan se tool ghalat system query karta tha.
CARRIERS = {
    "MAEU": "Maersk", "MSKU": "Maersk", "MRKU": "Maersk", "MCCQ": "Maersk (MCC)",
    "SEGU": "Maersk (Safmarine)", "SUDU": "Maersk (Hamburg Süd)",
    "COSU": "COSCO Shipping",
    # COSCO ke container prefixes (BL wale COSU/COAU se alag)
    "CSNU": "COSCO Shipping", "CSGU": "COSCO Shipping",
    "MSCU": "MSC (Mediterranean Shipping)", "MEDU": "MSC (Mediterranean Shipping)",
    "MCLU": "MSC (Mediterranean Shipping)",
    "EGHU": "Evergreen",
    # EGLV: Evergreen ke BL ka asal prefix (21 Oct 2026 — Yousuf ke
    # BL EGLV070600248927 par pakra gaya: list mein sirf EGHU tha,
    # jo container prefix hai, is liye Evergreen BL kabhi pehchana
    # hi nahi gaya aur "not found" aa jata tha).
    "EGLV": "Evergreen",
    # Evergreen ke container prefixes (BL wale EGLV se alag)
    "EGSU": "Evergreen", "EMCU": "Evergreen", "EITU": "Evergreen",
    "CMAU": "CMA CGM",
    "HLCU": "Hapag-Lloyd",
    "OOLU": "OOCL",
    "ONEU": "ONE (Ocean Network Express)", "TLLU": "ONE", "KKFU": "ONE",
    "YMLU": "Yang Ming",
    "WHLC": "Wan Hai",
    "ZIMU": "ZIM",
    "HMMU": "HMM (Hyundai Merchant Marine)",
    "PILU": "PIL (Pacific International Lines)",
    "ESLU": "Evergreen (subsidiary)",
    # MBAQ = RTW Shipping Lines (19 Oct 2026: Yousuf ne bataya)
    # "rtw shipping lines ka bl hota hy mba wala" — aur ye MASTER BL hai,
    # house BL nahi (Yousuf ki wazahat). Pehle ghalat label lagaya tha.
    "MBAQ": "RTW Shipping Lines",
    # EMKA/EMKAY = Emkay Line, Karachi NVOCC (2008 se, 132 ports)
    # Tracking: emkayline.com/trackbyblno.php?txt_bl_no={BL} (GET, verified 19 Oct 2026)
    "EMKA": "Emkay Line", "EMKY": "Emkay Line",
    # COAU: 20 Oct 2026 VERIFIED — Yousuf ne COSCO ki apni site par COAU BL
    # track karke dikhaya; COSCO API digits-only number (6468005230) par
    # record deta hai. (19 Oct ko full COAU form par "no record" aaya tha.)
    "COAU": "COSCO Shipping",
    # --- 19 Oct 2026: Yousuf ki 10 shipping lines (logos se) ---
    # (MAEU/YMLU/WHLC upar pehle se hain — F-24: duplicate keys hataye)
    "YMLY": "Yang Ming",
    "WANU": "Wan Hai",
    "STAR": "Star Lines",
    "BALT": "Baltic Lines",
    "NGSS": "New Golden Sea",
    "PELU": "Prolog Express Line", "PEL": "Prolog Express Line",
    # EMAS = EM-A Shipping (Karachi forwarder). Yousuf ka apna house BL
    # EMASUBKHI37726 (shared 12 Oct 2026) inhi ke letterhead par tha —
    # "SUBKHI" = sub-BL, Karachi. Is prefix ka BL aate hi foran pehchano.
    "EMAS": "EM-A Shipping",
    # --- 24 Oct 2026 (v51): Yousuf ki 43 BL photos se seekhe hue
    # prefix jo is table mein reh gaye thay. In ki kami se kai BL
    # pehchane hi nahi jate thay (sab se bara: Wan Hai ka 142G
    # pattern — neeche _BL_PATTERNS mein hai kyunke wo 4-huroof
    # prefix nahi hai).
    "KMTC": "KMTC",
    "YMJA": "Yang Ming",
    "SSLS": "Samudera",
    "FRLS": "Feeder Logistics",
    # Star Lines ke BL "STS" + port code se shuru hote hain
    # (STSCMBALKHI9113) — sirf "STAR" wala key in par kabhi match
    # nahi hota tha. PEL ke BL "PELM" se (PELMSASUBKHI030926) —
    # purana 3-huroof "PEL" key 4-huroof lookup mein marr gaya tha.
    "STSC": "Star Lines",
    "PELM": "Prolog Express Line",
}

# Forwarder contacts — jab online tracking na ho to in se rabta
# (phone/email verified jahan likha hai)
FORWARDER_CONTACTS = {
    "RTW Shipping Lines": {
        "phone": "+92 324 3333888",
        "whatsapp": "+254 701 137 728",
        "email": "info@rtwsl.com",
        "web": "https://www.rtwsl.com/",
        # 19 Oct 2026 verified: rtwsl.com homepage + web search — koi public
        # tracking portal nahi (homepage par sirf marketing pages; "Cargo
        # tracking" sirf service bullet hai). Ye BL direct rabte se track hoga.
        # NOTE: phone/whatsapp numbers 19 Oct ki research se aaye — site par
        # contact details openly nahi mile, is liye pehle call/WhatsApp par
        # confirm kar lena ke ye RTW ka hi number hai.
        "note": "The MBA prefix belongs to this carrier (master BL). Their website has no online tracking — please contact them directly.",
    },
    "EM-A Shipping": {
        "phone": "(021) 32601355-58-59",
        "email": "info@emashipping.com",
        "web": "https://www.emashipping.com/",
        "note": "Karachi freight forwarder (house BL). Ask them for the master BL or the container number.",
    },
}

# track-trace.com BOL company IDs (data-id values, verified 19 Oct 2026)
# POST /bol/select with number + shipper=<id> se direct tracking milta hai
# NOTE: 349 BOL list mein APL hai (container list mein MSC tha) — alag rakho!
# NOTE: MSC BOL list mein maujood hi nahi; track-trace kehta hai
# "we can not integrate Mediterranean Shipping completely due to technical reasons"
TT_BOL_COMPANY_IDS = {
    "Maersk": "347",
    "COSCO Shipping": "358",
    "Evergreen": "345",
    "CMA CGM": "351",
    "Hapag-Lloyd": "352",
    "OOCL": "354",
    "ONE (Ocean Network Express)": "355",
    "Yang Ming": "360",
    "Wan Hai": "370",
    # F-07 fix (v46 audit): "ZIM" was mapped to "360" — that is Yang
    # Ming's track-trace company id, so ZIM BLs were queried against
    # the WRONG company. ZIM's real track-trace id is unverified, so
    # the entry is removed: no query beats a wrong-company query.
    "HMM (Hyundai Merchant Marine)": "361",
    "PIL (Pacific International Lines)": "489",
}
# MSC automated tracking supported NAHI (bot-block + no public API + track-trace no integration)
NO_AUTO_TRACK = {"MSC (Mediterranean Shipping)"}

CARRIER_TRACK_URL = {
    "Maersk": "https://www.maersk.com/tracking/",
    "COSCO Shipping": "https://elines.coscoshipping.com/ebusiness/cargotracking",
    "MSC (Mediterranean Shipping)": "https://www.msc.com/en/track-a-shipment",
    "Evergreen": SL_URL,
    "CMA CGM": "https://www.cma-cgm.com/ebusiness/tracking",
    "Hapag-Lloyd": "https://www.hapag-lloyd.com/en/online-business/track/track-by-booking-solution.html",
    "OOCL": "https://www.oocl.com/eng/ourservices/eservices/cargotracking/Pages/cargotracking.aspx",
    "ONE (Ocean Network Express)": "https://ecomm.one-line.com/one-ecom/manage-shipment/cargo-tracking",
    "Yang Ming": "https://www.yangming.com/e-service/track_trace/track_trace.aspx",
    "Wan Hai": "https://www.wanhai.com/views/tracing/tracing",
    "ZIM": "https://www.zim.com/cargo-tracking",
    "HMM (Hyundai Merchant Marine)": "https://www.hmm21.com/e-service/general/cargo-tracking",
    "PIL (Pacific International Lines)": "https://www.pilship.com/en-pil-track-and-trace/134.html",
    # --- 19 Oct 2026: Yousuf ki chhoti lines (tracking via website/forwarder) ---
    "Emkay Line": "https://emkayline.com/#tracking",
    "Star Lines": "https://www.track-trace.com/",
    "Baltic Lines": "https://www.track-trace.com/",
    "New Golden Sea": "https://www.track-trace.com/",
    "Prolog Express Line": "https://www.track-trace.com/",
    "RTW Shipping Lines": "https://www.track-trace.com/",
}


def clean_text(html_text):
    t = re.sub(r"<script.*?</script>", "", html_text, flags=re.S | re.I)
    t = re.sub(r"<style.*?</style>", "", t, flags=re.S | re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    t = html.unescape(t)
    return re.sub(r"\s+", " ", t).strip()


def post_form(url, data, timeout=30):
    req = urllib.request.Request(
        url,
        data=urllib.parse.urlencode(data).encode(),
        headers={**UA, "Content-Type": "application/x-www-form-urlencoded"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        final = r.geturl()
        body = r.read().decode("utf-8", errors="replace")
    return final, body


def get_json(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        import json
        return json.loads(r.read().decode("utf-8", errors="replace"))


# ---- Evergreen: ShipmentLink (un ki apni tracking site) ----


def _sl_date(s):
    """'OCT-26-2026' -> '26 Oct 2026'."""
    m = re.match(r"([A-Za-z]{3})-(\d{2})-(\d{4})", (s or "").strip())
    if not m:
        return ""
    try:
        return datetime(int(m.group(3)),
                        datetime.strptime(m.group(1).title(), "%b").month,
                        int(m.group(2))).strftime("%d %b %Y")
    except Exception:
        return ""


def _sl_city(v):
    """'SINGAPORE (SG)' -> 'Singapore'."""
    v = re.sub(r"\s*\([A-Z]{2}\)\s*$", "", (v or "").strip())
    return v.title()


def _sl_split_voyage(vv):
    """'NORTHERN PRACTISE 51W' -> ('NORTHERN PRACTISE', '51W')."""
    m = re.match(r"^(.*?)\s+(\d{2,4}[A-Z]{0,2})$", (vv or "").strip())
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return (vv or "").strip(), ""


_SL_LABELS = ("Place of Receipt|Container Count|Port of Loading|"
              "Gross Weight|Port of Discharge|Measurement|"
              "Place of Delivery|Manifest Quantity|"
              "OCP Final Destination|Estimated On Board Date|"
              "Service Mode|Cut Off")


def _sl_field(text, label):
    m = re.search(re.escape(label) + r"\s+(.+?)(?=\s+(?:"
                  + _SL_LABELS + r")\b|$)", text)
    return m.group(1).strip() if m else ""


def _parse_shipmentlink_bl(body):
    """ShipmentLink BL result page ko parse karo. 'Basic
    Information' asal result par hi hota hai — ghalat number par
    page khaali aata hai, wahi found ki pehchan hai."""
    text = clean_text(body)
    if "Basic Information" not in text:
        return {"found": False,
                "note": ("No record of this BL was found in "
                         "Evergreen's system.")}
    out = {"found": True, "source": "Evergreen ShipmentLink",
           "direct_url": SL_URL}
    m = re.search(r"Vessel Voyage on B/L\s+(.+?)\s+Estimated Date "
                  r"of Arrival", text)
    if m:
        out["vessel"], out["voyage"] = _sl_split_voyage(m.group(1))
    m = re.search(r"Estimated Date of Arrival at Destination\s*:\s*"
                  r"([A-Z]{3}-\d{2}-\d{4})", text)
    if m:
        out["eta"] = _sl_date(m.group(1))
    pol = _sl_field(text, "Port of Loading")
    pod = _sl_field(text, "Port of Discharge")
    if pol:
        out["pol"] = _sl_city(pol)
    if pod:
        out["pod"] = _sl_city(pod)
    w = _sl_field(text, "Gross Weight")
    if w:
        out["weight"] = re.sub(r"\.000\s*", " ", w).strip()
    etd = _sl_field(text, "Estimated On Board Date")
    if etd:
        out["etd"] = _sl_date(etd)
    # Container table: pehli row se number, size aur asal status
    m = re.search(r"VGM Current Status Date\s+([A-Z]{4}\d{7})\s+"
                  r"(\S+)\s+\S+\s+FCL/FCL\s+.*?KGS\s+(.+?)\s+"
                  r"([A-Z]{3}-\d{2}-\d{4})\s+Click Container", text)
    if m:
        out["containers"] = [m.group(1)]
        out["size_type"] = m.group(2)
        out["status"] = m.group(3).strip()
    else:
        ctns = re.findall(r"\b[A-Z]{4}\d{7}\b", text)
        if ctns:
            out["containers"] = list(dict.fromkeys(ctns))
        out["status"] = "In transit"
    return out


def track_shipmentlink_bl(bl_number):
    """Evergreen ki apni site (ShipmentLink) par BL tracking —
    21 Oct 2026 verified live EGLV070600248927 par. Site number ka
    sirf hissa (digits) leti hai; EGLV prefix hum hata dete hain."""
    digits = norm(bl_number)
    if digits.startswith("EGLV"):
        digits = digits[4:]
    try:
        _, body = post_form(SL_URL, {"TYPE": "BL", "BL": digits,
                                     "SEL": "s_bl", "NO": digits},
                            timeout=45)
    except Exception as e:
        return {"error": f"Could not reach ShipmentLink: {e}"}
    return _parse_shipmentlink_bl(body)


def _parse_shipmentlink_container(body, ctn_number):
    text = clean_text(body)
    if ctn_number not in text or "Estimated Date of Arrival" not in text:
        return {"found": False,
                "note": ("No record of this container was found in "
                         "Evergreen's system.")}
    out = {"found": True, "source": "Evergreen ShipmentLink",
           "direct_url": SL_URL, "containers": [ctn_number]}
    m = re.search(r"on B/L\s+(.+?)\s+Estimated Date of Arrival", text)
    if m:
        out["vessel"], out["voyage"] = _sl_split_voyage(m.group(1))
    m = re.search(r"Estimated Date of Arrival\s*:\s*"
                  r"([A-Z]{3}-\d{2}-\d{4})", text)
    if m:
        out["eta"] = _sl_date(m.group(1))
    m = re.search(re.escape(ctn_number) +
                  r"\s+(\S+)\s+([A-Z]{3}-\d{2}-\d{4})\s+(.+?)\s+"
                  r"([A-Z][A-Z ]+\([A-Z]{2}\))\s", text)
    if m:
        out["size_type"] = m.group(1)
        out["status"] = (f"{m.group(3).strip()} at "
                         f"{_sl_city(m.group(4))}")
        out["position"] = _sl_city(m.group(4))
    return out


def track_shipmentlink_container(ctn_number):
    """ShipmentLink par container tracking (TYPE=CNTR)."""
    try:
        _, body = post_form(SL_URL, {"TYPE": "CNTR", "CNTR": ctn_number,
                                     "SEL": "s_cntr", "NO": ctn_number},
                            timeout=45)
    except Exception as e:
        return {"error": f"Could not reach ShipmentLink: {e}"}
    return _parse_shipmentlink_container(body, ctn_number)


# ---- Carrier-specific direct APIs (verified 19 Oct 2026) ----
def _cosco_date(s):
    """'2026-10-26 08:00' -> '26 Oct 2026'."""
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", (s or "").strip())
    if not m:
        return ""
    try:
        return datetime(int(m.group(1)), int(m.group(2)),
                        int(m.group(3))).strftime("%d %b %Y")
    except Exception:
        return ""


def track_cosco_api(bl_number):
    """COSCO ka public cargo tracking API — bina browser ke.
    20 Oct 2026 fix: COAU wale BL andar sirf digits se milte hain
    (COAU6468005230 -> 6468005230), aur trackingPath ek dict hota hai.
    Legs (actualShipment) se asal vessel/ETA/status banta hai."""
    base = "https://elines.coscoshipping.com/ebtracking/public/bill"
    candidates = [bl_number]
    digits = re.sub(r"\D", "", bl_number)
    if digits and digits != bl_number:
        candidates.append(digits)
    content = None
    last_err = None
    responded = False
    for cand in candidates:
        try:
            data = get_json(f"{base}/{urllib.parse.quote(cand)}")
            responded = True
        except Exception as e:
            # F-10 fix (v46 audit): a failure on the full form must not
            # skip the digits-only candidate — that is the form that
            # actually resolves COAU BLs. Try every candidate first.
            last_err = e
            continue
        c = (data.get("data") or {}).get("content") or {}
        if c.get("isbillOfLadingExist"):
            content = c
            break
    if not content and not responded and last_err is not None:
        return {"error": f"Could not reach the COSCO API: {last_err}"}
    if not content:
        return {"found": False,
                "note": "No record of this BL was found in COSCO's system."}
    out = {"found": True, "source": "COSCO API"}
    tp = content.get("trackingPath") or {}
    pod_raw = ""
    if isinstance(tp, dict):
        pod_raw = tp.get("pod") or ""
        if "SAPT" in pod_raw:
            out["terminal"] = "SAPT"
        elif "KICT" in pod_raw:
            out["terminal"] = "KICT"
        elif "QICT" in pod_raw or "DP World" in pod_raw:
            out["terminal"] = "QICT"
        out["pol"] = (tp.get("fromCity") or "").split(",")[0].strip()
        out["pod"] = (tp.get("toCity") or "").split(",")[0].strip()
    legs = content.get("actualShipment") or content.get("actualShipmentPic") or []
    legs = [l for l in legs if l.get("vesselName")]
    if legs:
        first, last = legs[0], legs[-1]
        if not out.get("pol"):
            out["pol"] = first.get("portOfLoading", "")
        if not out.get("pod"):
            out["pod"] = last.get("portOfDischarge", "")
        out["vessel"] = last.get("vesselName", "")
        out["voyage"] = last.get("voyageNo", "")
        out["eta"] = _cosco_date(last.get("estimatedDateOfArrival"))
        if last.get("actualDischargeDate"):
            out["status"] = "Discharged"
            out["discharge_time"] = last["actualDischargeDate"]
        elif last.get("actualArrivalDate"):
            out["status"] = "Arrived"
        elif last.get("actualDepartureDate"):
            out["status"] = (f"In transit — departed "
                              f"{last.get('portOfLoading','')} "
                              f"{_cosco_date(last['actualDepartureDate'])}")
    ct = content.get("cargoTrackingContainer") or []
    ctns = [c.get("cntrNum") for c in ct if c.get("cntrNum")]
    if ctns:
        out["containers"] = ctns
    return out


def track_cosco_container_api(ctn_number):
    """COSCO ka public container status API."""
    base = "https://elines.coscoshipping.com/ebtracking/public/container/status"
    try:
        data = get_json(f"{base}/{urllib.parse.quote(ctn_number)}")
    except Exception as e:
        return {"error": f"Could not reach the COSCO API: {e}"}
    items = (data.get("data") or {}).get("content") or []
    # khaali (null) records hatao
    live = [x for x in items if x.get("transportation") or x.get("pol")
            or x.get("pod") or x.get("location")]
    if not live:
        if items:
            return {"found": False, "empty_container": True,
                    "note": ("This container exists in COSCO's system but is not on "
                             "an active shipment — it may be empty or an old record.")}
        return {"found": False,
                "note": "No record of this container was found in COSCO's system."}
    v = live[0]
    return {"found": True, "source": "COSCO API",
            "vessel": v.get("transportation"), "pol": v.get("pol"),
            "pod": v.get("pod"), "eta": v.get("podEta"),
            "status": v.get("containerNumberStatus"),
            "location": v.get("location")}


def track_emkay_api(bl_number):
    """Emkay Line ka tracking (simple GET — emkayline.com)."""
    url = (f"https://emkayline.com/trackbyblno.php?txt_bl_no="
           f"{urllib.parse.quote(bl_number)}")
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach the Emkay website: {e}"}
    text = clean_text(body)
    # table rows nikalo (header ke baad)
    # format: CONTAINER NO. | LAST ACTIVITY | ACTIVITY DATE | Description
    rows = re.findall(
        r"<tr>(?!.*<th)(.*?)</tr>", body, re.S | re.I)
    data_rows = []
    for row in rows:
        cells = [clean_text(c).strip()
                 for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        cells = [c for c in cells if c]
        if cells:
            data_rows.append(cells)
    if not data_rows:
        return {"found": False,
                "note": ("No activity record for this BL in Emkay's system — "
                         "the BL number may be incorrect, or the shipment "
                         "has not been entered yet."),
                "direct_url": url}
    # pehli row: container, last activity, date, description
    r0 = data_rows[0]
    # NOTE: Emkay's table columns are CONTAINER | LAST ACTIVITY |
    # ACTIVITY DATE | DESCRIPTION — the date is the last-activity
    # date, NOT an ETA. Never label it as ETA (v28 audit fix).
    return {"found": True, "source": "Emkay Line",
            "direct_url": url,
            "status": r0[1] if len(r0) > 1 else "",
            "activity_date": r0[2] if len(r0) > 2 else "",
            "raw_snippet": " | ".join(r0)}


def track_emkay_container_api(ctn_number):
    """Emkay Line container tracking (trackbycno.php) — 20 Oct 2026 verified.
    Table: BL No | VESSEL | VOYAGE | LAST ACTIVITY | ACTIVITY DATE | REMARKS
    Non-Emkay container par table khaali aati hai — safe extra layer."""
    url = (f"https://emkayline.com/trackbycno.php?txt_container_no="
           f"{urllib.parse.quote(ctn_number)}")
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach the Emkay website: {e}"}
    rows = re.findall(r"<tr>(?!.*<th)(.*?)</tr>", body, re.S | re.I)
    data_rows = []
    for row in rows:
        cells = [clean_text(c).strip()
                 for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        cells = [c for c in cells if c]
        if cells:
            data_rows.append(cells)
    if not data_rows:
        return {"found": False,
                "note": "No record of this container in Emkay's system.",
                "direct_url": url}
    r0 = data_rows[0]
    # Columns: BL | VESSEL | VOYAGE | LAST ACTIVITY | ACTIVITY DATE —
    # the last column is an activity date, NOT an ETA (v28 audit fix).
    return {"found": True, "source": "Emkay Line (container)",
            "direct_url": url,
            "bl_ref": r0[0] if len(r0) > 0 else "",
            "vessel": r0[1] if len(r0) > 1 else "",
            "voyage": r0[2] if len(r0) > 2 else "",
            "status": r0[3] if len(r0) > 3 else "",
            "activity_date": r0[4] if len(r0) > 4 else "",
            "raw_snippet": " | ".join(r0)}


_TERM_LABELS = ["Owner", "BL/ Shipping Bill No.", "Container No.",
    "Container Size/Type", "Category", "Status", "Vessel Voyage", "VIR No",
    "ETA", "ETD", "Discharge Time", "Load Time", "DO Issuance Date",
    "DO Expiry Date", "Gate In Time", "Gate Out Time", "Origin", "Destination",
    "Custom Seal No.", "Line Seal No.", "Security Seal No.", "Other Seal No.",
    "Custom Status", "Current Position", "Commodity", "Weight", "Weighment",
    "Scanning", "Present Holds"]


def _term_date(s):
    """'04-OCT-26 04.00.00 PM' ya '13-OCT-2026 16:59' -> '04 Oct 2026'."""
    m = re.match(r"(\d{1,2})-([A-Za-z]{3})-(\d{2,4})", (s or "").strip())
    if not m:
        return ""
    try:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        return datetime(y, datetime.strptime(m.group(2).title(), "%b").month,
                        int(m.group(1))).strftime("%d %b %Y")
    except Exception:
        return ""


def _parse_term_details(body):
    """ContainerDetails HTML se label->value dict (N/A wale skip)."""
    cells = [clean_text(c).strip()
             for c in re.findall(r"<td[^>]*>(.*?)</td>", body, re.S | re.I)]
    out = {}
    for i, c in enumerate(cells):
        if c in _TERM_LABELS and i + 1 < len(cells):
            v = cells[i + 1]
            if v and v not in ("N/A", "/") and v not in _TERM_LABELS:
                out[c] = v
    return out


def _term_fetch_details(opener, host, bu, hdr, rows):
    """ContainerDetails for the first 3 history rows (2 tries each —
    the terminal site often returns an empty template)."""
    got = []
    for row in rows[:3]:
        pid = row.get("pid")
        if not pid:
            continue
        for _try in range(2):
            try:
                data = urllib.parse.urlencode(
                    {"cntrPK": pid, "BU": bu}).encode()
                req = urllib.request.Request(
                    f"{host}/Enquiries/ContainerDetails", data=data,
                    headers=hdr)
                dbody = opener.open(req, timeout=45).read().decode(
                    "utf-8", "replace")
                d = _parse_term_details(dbody)
                if d:
                    got.append(d)
                    break
            except Exception:
                pass
            time.sleep(1)
        time.sleep(0.6)
    return got


def _term_apply_details(out, details):
    """Map parsed ContainerDetails onto the result dict. The terminal
    name comes ONLY from the VIR number (PKKHIKICT / PKKHISAPT) —
    never a combined label, never a guess."""
    d0 = details[0]
    vv = d0.get("Vessel Voyage", "")
    if " / " in vv:
        out["vessel"], out["voyage"] = [x.strip() for x in vv.split(" / ", 1)]
    elif vv:
        out["vessel"] = vv
    out["eta"] = _term_date(d0.get("ETA", ""))
    out["etd"] = _term_date(d0.get("ETD", ""))
    out["pol"] = d0.get("Origin", "")
    out["pod"] = d0.get("Destination", "")
    vir = ""
    for d in details:
        if d.get("VIR No"):
            vir = d["VIR No"]
            break
    if "KICT" in vir:
        out["terminal"] = "KICT"
    elif "SAPT" in vir:
        out["terminal"] = "SAPT"
    out["vir"] = vir
    out["position"] = d0.get("Current Position", "")
    out["holds"] = d0.get("Present Holds", "")
    out["do_expiry"] = _term_date(d0.get("DO Expiry Date", ""))
    out["owner"] = d0.get("Owner", "")
    out["weight"] = d0.get("Weight", "")
    out["commodity"] = d0.get("Commodity", "")
    out["size_type"] = d0.get("Container Size/Type", "")
    out["custom_status"] = d0.get("Custom Status", "")
    out["category"] = d0.get("Category", "")
    out["gate_in"] = d0.get("Gate In Time", "")
    dis = [d.get("Discharge Time", "") for d in details]
    out["discharge_time"] = dis[0] if dis else ""
    if dis and all(dis):
        out["status"] = "Discharged"
    elif any(dis):
        out["status"] = "Partially discharged"
    gate = [d.get("Gate Out Time", "") for d in details]
    if gate and all(gate):
        out["status"] = "Gate out"
        out["gate_out"] = gate[0]
    return out


def _term_history(host, bu, params):
    """One terminal session: enquiry page (affinity cookie) ->
    ContainerHistory. Returns (opener, hdr, rows) or an error dict."""
    hdr = {**UA, "X-Requested-With": "XMLHttpRequest",
           "Referer": f"{host}/Enquiries?is=ContainerBLEnquiry"}
    try:
        cj = http.cookiejar.CookieJar()
        op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(cj))
        req = urllib.request.Request(
            f"{host}/Enquiries/ContainerBLEnquiry", headers=hdr)
        op.open(req, timeout=30).read()
        q = urllib.parse.urlencode(params)
        req = urllib.request.Request(
            f"{host}/Enquiries/ContainerHistory?{q}", headers=hdr)
        body = op.open(req, timeout=30).read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": str(e)}
    m = re.search(r'"_jsonArray":"((?:\\.|[^"\\])*)"', body)
    if not m:
        # page aaya lekin us mein data wala hissa hi nahi — site
        # busy/masroof thi ya session na bana. Ye "record nahi
        # hai" ka saboot NAHI hai; error kehna hi imandari hai
        # (17:11 wali ghalti: khaali jawab par app ne dono
        # containers ko Not found keh diya tha).
        return {"error": "terminal returned a page without data"}
    try:
        import json as _json
        rows = _json.loads(_json.loads('"' + m.group(1) + '"'))
    except Exception:
        return {"error": "terminal data could not be read"}
    if not isinstance(rows, list):
        return {"error": "terminal data could not be read"}
    rows = [r for r in rows
            if isinstance(r, dict) and r.get("CONTAINER NO")
            and r["CONTAINER NO"] != "N/A"]
    if not rows:
        return {"found": False}
    return (op, hdr, rows)


def _term_finish(host, bu, hdr, op, rows):
    out = {"found": True, "terminal": "", "containers": rows,
           "source": "Karachi Terminal (Hutchison Ports)"}
    details = _term_fetch_details(op, host, bu, hdr, rows)
    if not any(d.get("Vessel Voyage") or d.get("ETA") for d in details):
        try:
            cj2 = http.cookiejar.CookieJar()
            op2 = urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(cj2))
            req = urllib.request.Request(
                f"{host}/Enquiries/ContainerBLEnquiry", headers=hdr)
            op2.open(req, timeout=30).read()
            details2 = _term_fetch_details(op2, host, bu, hdr, rows)
            if any(d.get("Vessel Voyage") or d.get("ETA")
                   for d in details2) or (details2 and not details):
                details = details2
        except Exception:
            pass
    if details:
        _term_apply_details(out, details)
    return out


def _term_history_retry(host, bu, params, tries=3):
    """_term_history ko error par fresh session ke sath dobara
    try karo — terminal ki site aksar pehli koshish par khaali
    jawab deti hai aur dosri par record de deti hai."""
    r = {"error": "no attempt made"}
    for i in range(tries):
        r = _term_history(host, bu, params)
        if isinstance(r, tuple) or not r.get("error"):
            return r
        if i < tries - 1:
            time.sleep(2)
    return r


def track_terminal_bl(bl_number, host, bu):
    """Hutchison terminal (KICT/SAPT) full enquiry by BL number —
    verified 20 Oct 2026. One cookie session: enquiry page ->
    ContainerHistory (method=B) -> ContainerDetails per container."""
    r = _term_history_retry(host, bu, {"cntrNum": "",
                                       "BL": f"{bl_number}_1",
                                       "method": "B", "pTId": bu})
    if not isinstance(r, tuple):
        return r
    op, hdr, rows = r
    return _term_finish(host, bu, hdr, op, rows)


def track_terminal_container(ctn_number, host, bu):
    """Same terminal enquiry by CONTAINER number (method=C) —
    history step verified live 20 Oct 2026: it returns the same
    _jsonArray rows (with pid), so details work identically."""
    r = _term_history_retry(host, bu, {"cntrNum": ctn_number,
                                       "BL": "", "method": "C",
                                       "pTId": bu})
    if not isinstance(r, tuple):
        return r
    op, hdr, rows = r
    return _term_finish(host, bu, hdr, op, rows)


TERMINAL_HOSTS = [("KICT", "https://www.kictl.com"),
                  ("SAPT", "https://www.sapt.com.pk")]


def track_karachi_terminals(bl_number):
    """Try each Hutchison host in turn. The two hosts share one
    database, but the details call is unreliable: if the first host
    finds the containers yet returns no details (no vessel / ETA /
    discharge), the second host is tried as well and the richest
    result wins."""
    best = {"found": False}
    saw_error = False
    stale_note = ""
    for bu, host in TERMINAL_HOSTS:
        r = track_terminal_bl(bl_number, host, bu)
        if r.get("found"):
            _st, _wh = _stale_info(r)
            if _st:
                # v54: terminal par is number ka sirf PURANA
                # record hai (pichle safar ka — container
                # number dobara istemal hote hain). Use is
                # shipment ka result banana ghalat hai; QICT
                # par ye rok pehle se thi, yahan reh gayi thi
                # (CAIU4648550 par Jul 2023 ka record 2026 ke
                # BL ke result mein aa gaya tha).
                stale_note = (
                    f"Karachi terminal holds only an OLD record "
                    f"for this BL ({_wh}) — from a previous trip. "
                    f"Container numbers are reused, so this is "
                    f"not counted as a current record.")
                continue
            if r.get("vessel") or r.get("eta") or r.get("discharge_time"):
                return r
            if not best.get("found"):
                best = r
        elif r.get("error"):
            saw_error = True
    if not best.get("found"):
        # F-01 fix (v46 audit): a clean no-record from both hosts used to
        # leave NO note at all -> the layer showed an empty detail. The
        # note must say which case it actually was.
        if stale_note:
            best["note"] = stale_note
        elif saw_error:
            best["note"] = "The Karachi terminal sites did not respond."
        else:
            best["note"] = "No record at KICT or SAPT for this BL."
    return best


def track_karachi_terminals_container(ctn_number):
    """Container-number version of track_karachi_terminals: both
    Hutchison hosts share one database; richest result wins."""
    best = {"found": False}
    saw_error = False
    stale_note = ""
    for bu, host in TERMINAL_HOSTS:
        r = track_terminal_container(ctn_number, host, bu)
        if r.get("found"):
            _st, _wh = _stale_info(r)
            if _st:
                # v54: BL wali hi rok, container raste par bhi
                # (isi raste se Jul 2023 wala record aaya tha).
                stale_note = (
                    f"Karachi terminal holds only an OLD record "
                    f"for this container ({_wh}) — from a "
                    f"previous trip. Container numbers are "
                    f"reused, so this is not counted as a "
                    f"current record.")
                continue
            if r.get("vessel") or r.get("eta") or r.get("discharge_time"):
                return r
            if not best.get("found"):
                best = r
        elif r.get("error"):
            saw_error = True
    if not best.get("found"):
        if stale_note:
            best["note"] = stale_note
        elif saw_error:
            best["note"] = "The Karachi terminal sites did not respond."
        else:
            best["note"] = "No record at KICT or SAPT for this container."
    return best


QICT_API = "https://lfs.qict.com.pk/API/api/ds/v1/BL-Inquiry"


def track_qict_bl(bl_number):
    """QICT (DP World Karachi) ki public BL inquiry — 20 Oct 2026 verified.
    Un ki apni website (lfs.qict.com.pk) ka public API hai; Emkay/RTW
    jaise NVOCC cargo aksar yahin milta hai. API slow hai (~25s) is
    liye 2 koshishein. Response double-encoded JSON hota hai."""
    import json as _json
    payload = urllib.parse.urlencode({
        "blno": bl_number, "UserID": "Test", "Password": "Test123",
        "Cellno": "123456"}).encode()
    # QICT's server is flaky: it often answers with an EMPTY body when
    # busy, which must never be read as "not found". Retry on empty
    # answers as well as on errors — only a real row ends the loop.
    rows = None
    for _try in range(4):
        try:
            req = urllib.request.Request(QICT_API, data=payload, headers={
                **UA, "Referer": "https://lfs.qict.com.pk/",
                "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                raw = resp.read().decode("utf-8", "replace").strip()
            parsed = _json.loads(raw) if raw else ""
            if isinstance(parsed, str):
                parsed = _json.loads(parsed) if parsed else []
            if parsed:
                rows = parsed
                break
        except Exception:
            pass
        time.sleep(2.5)
    if not rows:
        return {"found": False,
                "note": "No record was returned by QICT on this check."}
    r0 = rows[0]
    # Aggregate across ALL container rows (v28 audit fix): a BL with
    # several containers must not inherit the first row's standing
    # when another container is on hold or still in the yard.
    standings = [(r.get("STANDING") or "").strip().upper() for r in rows]
    trucks = [(r.get("TRUCK_IN_YARD") or "").strip().lower() for r in rows]
    positions = {(r.get("POSITION") or "").strip() for r in rows}
    positions.discard("")
    if "HOLD" in standings:
        status = "On hold at QICT"
    elif standings and all(x == "RELEASED" for x in standings) \
            and all(t == "delivered" for t in trucks if t):
        status = "Released — Delivered"
    elif standings and all(x == "RELEASED" for x in standings):
        status = "Released at QICT"
    elif standings[0]:
        status = f"At QICT — {standings[0].title()}"
    else:
        status = "At QICT terminal (Karachi)"
    position = (positions.pop() if len(positions) == 1
                else ("Multiple positions" if positions
                      else r0.get("POSITION", "")))
    truck = (trucks[0] if len(set(trucks)) == 1 else "")
    out = {"found": True, "terminal": "QICT", "source": "QICT (DP World)",
           "containers": [r.get("EQ_NBR") for r in rows if r.get("EQ_NBR")],
           "status": status, "position": position,
           "category": r0.get("CATEGORY", ""), "truck": truck,
           "gd_no": r0.get("GD_NO", ""),
           "qict_rows": rows}
    # Ctr-Inq se pehle container ki tafseel (vessel, discharge, holds)
    ctn0 = out["containers"][0] if out["containers"] else ""
    if ctn0:
        det = track_qict_container(ctn0)
        for k in ("vessel", "voyage", "discharge_time", "holds", "line",
                  "pod", "vir"):
            if det.get(k):
                out[k] = det[k]
    return out


QICT_CTR_API = "https://lfs.qict.com.pk/API/api/ds/v1/Ctr-Inq"


def track_qict_container(ctn_number):
    """QICT Ctr-Inq — container ki poori tafseel (vessel/voyage, discharge
    time, VIR, holds, shipping line). 20 Oct 2026 verified, tez (~1s)."""
    import json as _json
    payload = urllib.parse.urlencode({
        "ctrnbr": ctn_number, "UserID": "Test", "Password": "Test",
        "Cellno": "123456"}).encode()
    fields = {}
    for _try in range(2):
        try:
            req = urllib.request.Request(QICT_CTR_API, data=payload,
                headers={**UA, "Referer": "https://lfs.qict.com.pk/",
                         "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                raw = resp.read().decode("utf-8", "replace").strip()
            parsed = _json.loads(raw) if raw else ""
            if isinstance(parsed, str):
                parsed = _json.loads(parsed) if parsed else []
            fields = {i.get("FIELD_NAME", ""): i.get("FIELD_VALUE", "")
                      for i in (parsed or [])}
            if fields:
                break
        except Exception:
            fields = {}
        time.sleep(1.5)
    if not fields:
        return {}
    out = {"vessel": fields.get("Vessel", ""),
           "voyage": fields.get("Voyage", ""),
           "holds": fields.get("Hold Description", "").rstrip(","),
           "line": fields.get("Shipping Line", ""),
           "pod": fields.get("Port Of Discharge", ""),
           "vir": fields.get("VIR #", ""),
           "discharge_time": fields.get("Discharge Time", "")}
    return {k: v for k, v in out.items() if v}


KGTL_URL = "https://www.kgtl.com.pk/en/online-tracking"


def _kgtl_search(term, radio):
    """KGTL (Karachi Gateway Terminal — AD Ports, East Wharf) ki
    public Online Tracking. ASP.NET WebForms hai: pehle radio
    (rdioBL / rdioCon) ka postback, phir search ka POST — teen
    talab, koi login nahi. 25 Oct 2026 ko asal BL/container par
    verified. Jawab ka HTML deta hai; site na mile to None."""
    import http.cookiejar as _cj
    cj = _cj.CookieJar()
    op = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [("User-Agent", UA["User-Agent"])]

    def _fields(h):
        d = {}
        for n in ("__VIEWSTATE", "__VIEWSTATEGENERATOR",
                  "__EVENTVALIDATION"):
            m = re.search(rf'name="{n}"[^>]*value="([^"]*)"', h or "")
            d[n] = m.group(1) if m else ""
        return d

    try:
        h = op.open(KGTL_URL, timeout=30).read().decode("utf-8", "ignore")
        d = _fields(h)
        d.update({"__EVENTTARGET": radio, "__EVENTARGUMENT": "",
                  "radio": radio})
        h = op.open(urllib.request.Request(
            KGTL_URL, data=urllib.parse.urlencode(d).encode(),
            method="POST"), timeout=30).read().decode("utf-8", "ignore")
        d = _fields(h)
        d.update({"__EVENTTARGET": "", "__EVENTARGUMENT": "",
                  "txtSearch": term, "radio": radio,
                  "btnSearch": "Search"})
        return op.open(urllib.request.Request(
            KGTL_URL, data=urllib.parse.urlencode(d).encode(),
            method="POST"), timeout=30).read().decode("utf-8", "ignore")
    except Exception:
        return None


def _kgtl_span(html, sid):
    m = re.search(rf'id="{sid}"[^>]*>([^<]*)<', html or "")
    return m.group(1).strip() if m else ""


def track_kgtl_bl(bl_number):
    """KGTL BL inquiry — BL panel (vessel, VIR, ATA/ATD) +
    container grid (number/size/yard state). Pehle container
    ki tafseel (holds, ETA, voyage) container wale raste se
    bhi li jati hai — QICT BL layer wala hi tareeqa."""
    html = _kgtl_search(bl_number, "rdioBL")
    if html is None:
        return {"found": False, "note": "The KGTL site did not respond."}
    if "Not found" in html or not _kgtl_span(html, "BLlblBLNbr"):
        return {"found": False,
                "note": "No record at KGTL for this BL."}
    rows = []
    gm = re.search(r'id="BLContainerGrid".*?</table>', html, re.S)
    if gm:
        for tr in re.findall(r"<tr>(.*?)</tr>", gm.group(0), re.S):
            tds = [re.sub(r"<[^>]+>", "", c).strip()
                   for c in re.findall(r"<td>(.*?)</td>", tr, re.S)]
            if len(tds) >= 3 and tds[0]:
                rows.append({"CONTAINER NO": tds[0], "SIZE": tds[1],
                             "LOCATION": tds[2]})
    containers = [r["CONTAINER NO"] for r in rows]
    states = [(r["LOCATION"] or "").strip().lower() for r in rows]
    ata = _kgtl_span(html, "BLlblATA")
    if states and all(x == "in yard" for x in states):
        status = "Discharged at KGTL — in yard"
    elif any(x == "in yard" for x in states):
        status = "Partially discharged at KGTL"
    elif ata:
        status = "At KGTL terminal (Karachi)"
    else:
        status = "Expected at KGTL (Karachi)"
    out = {"found": True, "terminal": "KGTL",
           "source": "KGTL (Karachi Gateway Terminal)",
           "containers": containers, "terminal_rows": rows,
           "status": status,
           "vessel": _kgtl_span(html, "BLlblVesselName"),
           "vir": _kgtl_span(html, "BLlblVIRNbr"),
           "ata": ata, "atd": _kgtl_span(html, "BLlblATD"),
           "pod": _kgtl_span(html, "BLlblDestination")}
    if status.startswith("Expected"):
        out["expected"] = True
    if len(set(states)) == 1 and states:
        out["position"] = rows[0]["LOCATION"]
    if containers:
        det = track_kgtl_container(containers[0])
        if det.get("found"):
            for k in ("voyage", "eta", "etd", "pol", "holds",
                      "weight", "commodity", "size_type", "category"):
                if det.get(k) and not out.get(k):
                    out[k] = det[k]
            if det.get("holds") and states and \
                    all(x == "in yard" for x in states):
                out["status"] = "On hold at KGTL — discharged, in yard"
    return {k: v for k, v in out.items() if v or k in
            ("found", "terminal", "source", "containers",
             "terminal_rows", "status")}


def track_kgtl_container(ctn_number):
    """KGTL container inquiry — BL se zyada tafseel deta hai:
    ETA/ETD, ATA/ATD, holds, ground date, voyage, weight.
    25 Oct 2026 verified (WHSU5010543)."""
    html = _kgtl_search(ctn_number, "rdioCon")
    if html is None:
        return {"found": False, "note": "The KGTL site did not respond."}
    if "Not found" in html or not _kgtl_span(html, "lblContainer"):
        return {"found": False,
                "note": "No record at KGTL for this container."}
    st = _kgtl_span(html, "lblStatus")
    ata = _kgtl_span(html, "lblATA")
    holds = _kgtl_span(html, "lblHolds")
    if holds and st.lower() == "in yard":
        # dabba discharge ho kar yard mein hai AUR hold par
        # bhi — dono haqeeqatein status mein; sirf "on hold"
        # likhne se milestone engine ko discharge nazar
        # nahi aata tha (v61 live QA mein pakra gaya).
        status = "On hold at KGTL — discharged, in yard"
    elif holds:
        status = "On hold at KGTL"
    elif st.lower() == "in yard":
        status = "Discharged at KGTL — in yard"
    elif st:
        status = f"At KGTL — {st}"
    elif ata:
        status = "At KGTL terminal (Karachi)"
    else:
        status = "Expected at KGTL (Karachi)"
    out = {"found": True, "terminal": "KGTL",
           "source": "KGTL (Karachi Gateway Terminal)",
           "containers": [ctn_number], "status": status,
           "bl": _kgtl_span(html, "lblBLNbr"),
           "vessel": _kgtl_span(html, "lblVessel"),
           "voyage": _kgtl_span(html, "lblVoyage"),
           "vir": _kgtl_span(html, "lblVIRNo"),
           "eta": _kgtl_span(html, "lblETA"),
           "etd": _kgtl_span(html, "lblETD"),
           "ata": ata, "atd": _kgtl_span(html, "lblATD"),
           "pol": _kgtl_span(html, "lblPOL"),
           "pod": _kgtl_span(html, "lblPOD"),
           "holds": holds,
           "position": _kgtl_span(html, "lblPosition") or st,
           "weight": _kgtl_span(html, "lblWeight"),
           "commodity": _kgtl_span(html, "lblDescription"),
           "size_type": _kgtl_span(html, "lblSize"),
           "category": _kgtl_span(html, "lblCategory"),
           "ground_date": _kgtl_span(html, "lblGroundDate")}
    if status.startswith("Expected"):
        out["expected"] = True
    return {k: v for k, v in out.items() if v or k in
            ("found", "terminal", "source", "containers", "status")}


def _parse_det_date(s):
    """'18-OCT-26', '18 Oct 2026', '21 Nov 2022', '2026-10-18'
    jaisi tareekhein parho — 2-rakmi saal bhi (KICT aksar
    '18-OCT-26' likhta hai, jo purani regex nahi parh pati
    thi). Na mile to None."""
    import datetime as _dt
    s = str(s or "")
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        try:
            return _dt.date(int(m.group(1)), int(m.group(2)),
                            int(m.group(3)))
        except Exception:
            return None
    m = re.search(r"(\d{1,2})[- ]([A-Za-z]{3})[A-Za-z]*[- ]"
                  r"(\d{4}|\d{2})\b", s)
    if not m:
        return None
    y = int(m.group(3))
    if y < 100:
        y = 2000 + y if y <= 69 else 1900 + y
    try:
        return _dt.datetime.strptime(
            f"{m.group(1)} {m.group(2)} {y}", "%d %b %Y").date()
    except Exception:
        return None


def _stale_info(det):
    """Record ki tareekh 150 din se purani ho to (True, 'Nov 2022').
    Container number dobara istemal hote hain — QICT kabhi pichle
    safar ka record de deta hai (CXDU1175597 par Nov 2022 ka
    MSC JOANNA record mila, jabke asal safar 2026 ka tha).
    v54: tareekh discharge_time ke ilawa ETA se bhi li jati
    hai, 2-rakmi saal bhi chalte hain, aur VIR ke aakhri 8
    digits sirf tab gine jate hain jab saal maqool ho — KICT
    ka VIR ('PKKHIKICT_121026100008') serial par khatam hota
    hai jo ghalti se saal 0008 parh leta tha aur sahi record
    ko purana qarar de deta."""
    import datetime as _dt
    dates = []
    for key in ("discharge_time", "eta"):
        d = _parse_det_date(det.get(key))
        if d:
            dates.append(d)
    vir = str(det.get("vir") or "")
    m2 = re.search(r"(\d{2})(\d{2})(\d{4})\s*$", vir)
    if m2:
        try:
            d = _dt.date(int(m2.group(3)), int(m2.group(2)),
                         int(m2.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    # v55: QICT ka VIR apni tareekh khud rakhta hai —
    # 'PKBQMQICT_100226152301' = DDMMYY + HHMMSS (10 Feb 2026).
    # Discharge/ETA khaali hon to bhi ye tareekh guard ko milti
    # hai; Feb 2026 ke pichle-safar wale det 'At QICT terminal'
    # ban kar nikal aate thay (BMOU2755409 / MOAU0774432).
    m3 = re.search(r"QICT_(\d{2})(\d{2})(\d{2})\d{6}\s*$", vir)
    if m3:
        try:
            _yy = int(m3.group(3))
            _yy = 2000 + _yy if _yy <= 69 else 1900 + _yy
            d = _dt.date(_yy, int(m3.group(2)), int(m3.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    # v61: KGTL ka VIR bhi apni tareekh rakhta hai —
    # 'PKKHIKGTL_101026105335' = DDMMYY + HHMMSS (10 Oct 2026).
    # Guard jis source par lage, har source par lage — KGTL
    # ke baghair is ke purane record bhi naye ban sakte thay.
    m4 = re.search(r"KGTL_(\d{2})(\d{2})(\d{2})\d{6}\s*$", vir)
    if m4:
        try:
            _yy = int(m4.group(3))
            _yy = 2000 + _yy if _yy <= 69 else 1900 + _yy
            d = _dt.date(_yy, int(m4.group(2)), int(m4.group(1)))
            if 2015 <= d.year <= _dt.date.today().year + 1:
                dates.append(d)
        except Exception:
            pass
    if not dates:
        return (False, "")
    newest = max(dates)
    age = (_dt.date.today() - newest).days
    return (age > 150, newest.strftime("%b %Y"))


def track_qict_container_layer(ctn_number):
    """QICT as a primary layer for a bare container number: Ctr-Inq
    answers in ~1s with vessel, discharge, holds and VIR."""
    det = track_qict_container(ctn_number)
    if not det:
        return {"found": False,
                "note": "No record was returned by QICT on this check."}
    _stale, _when = _stale_info(det)
    if _stale:
        return {"found": False,
                "note": (f"QICT holds only an OLD record for this "
                         f"container ({_when}) — from a previous trip. "
                         "Container numbers are reused, so this is not "
                         "counted as a current record.")}
    if det.get("holds"):
        status = "On hold at QICT"
    elif det.get("discharge_time"):
        status = "Discharged at QICT"
    elif det.get("vir"):
        status = "At QICT terminal (Karachi)"
    else:
        # v54: sirf vessel/line wali entry QICT ki EXPECTED
        # (inbound) list hoti hai — dabba abhi terminal par
        # NAHI pahuncha. Pehle ye bhi "At QICT terminal" ban
        # jata tha, jo card par seedhi ghalat maloomat thi
        # (HGMU1110890: jahaz CSTAR VOYAGER abhi raaste mein
        # tha aur card "At QICT terminal" keh raha tha).
        if det.get("vessel"):
            status = (f"Expected at QICT — on {det['vessel']}"
                      + (f" ({det['voyage']})"
                         if det.get("voyage") else "")
                      + ", still at sea")
        else:
            status = ("In QICT's system — entry only, nothing "
                      "further recorded yet")
    out = {"found": True, "terminal": "QICT", "source": "QICT (DP World)",
           "containers": [ctn_number], "status": status}
    if status.startswith(("Expected", "In QICT's system")):
        out["expected"] = True
    out.update(det)
    return out


CARRIER_APIS = {
    "COSCO Shipping": track_cosco_api,
    "COSCO Shipping (unverified)": track_cosco_api,
    "Emkay Line": track_emkay_api,
    "Evergreen": track_shipmentlink_bl,
}

CARRIER_CONTAINER_APIS = {
    "COSCO Shipping": track_cosco_container_api,
    "Evergreen": track_shipmentlink_container,
}


def track_bol_tracktrace(bl_number, carrier=None):
    """track-trace.com par BL tracking.
    Carrier maloom ho to us ki company ID se direct tracking (tez aur sahi).
    Returns dict.
    """
    # MSC automated tracking supported nahi — foran manual link do
    if carrier in NO_AUTO_TRACK:
        return {"found": False, "deferred": True,
                "direct_url": "https://www.msc.com/en/track-a-shipment",
                "note": (f"{carrier} does not allow automated tracking "
                         "(bot protection). Please enter the number on their "
                         "own tracking page using the link below.")}
    try:
        # Step 1: BL submit karo (config hidden field lazmi hai)
        final_url, body = post_form(
            "https://www.track-trace.com/bol",
            {"number": bl_number, "config": "207400", "commit": "Track!"},
        )
        # Step 2: agar carrier maloom hai to us se direct tracking
        if carrier and carrier in TT_BOL_COMPANY_IDS:
            _, body2 = post_form(
                "https://www.track-trace.com/bol/select",
                {"number": bl_number, "shipper": TT_BOL_COMPANY_IDS[carrier]},
            )
            # direct carrier form ka URL nikalo (e.g. COSCO cargoTracking)
            m = re.search(
                r'<form\s+action="([^"]+)"[^>]*>.*?name="trackingType".*?name="number"',
                body2, re.S | re.I)
            direct_url = None
            if m:
                direct_url = html.unescape(m.group(1))
                # hidden fields joro
                fields = re.findall(
                    r'<input\s+name="([^"]+)"\s+value="([^"]*)"', body2)
                if fields:
                    qs = urllib.parse.urlencode(
                        {k: v for k, v in fields})
                    direct_url = direct_url + "?" + qs
            res = parse_tracktrace(body2, final_url)
            if direct_url:
                res["direct_url"] = direct_url
            return res
    except Exception as e:
        return {"error": f"Could not reach track-trace.com: {e}"}
    return parse_tracktrace(body, final_url)


def track_container_tracktrace(ctn_number):
    """track-trace.com par container tracking."""
    try:
        final_url, body = post_form("https://www.track-trace.com/container",
                                   {"number": ctn_number})
    except Exception as e:
        return {"error": f"Could not reach track-trace.com: {e}"}
    return parse_tracktrace(body, final_url)


# ============================================================
# LAYER 4: Vessel live tracking (VesselFinder — curl se kaam karta hai)
# Jab vessel ka naam mil jaye (kisi bhi layer se), uski live
# position, destination aur ETA nikalo.
# ============================================================
def vessel_search(name):
    """VesselFinder par vessel dhoondo. Returns detail page URL ya None."""
    q = urllib.parse.quote(name)
    url = f"https://www.vesselfinder.com/vessels?name={q}"
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception:
        return None
    m = re.search(r'href="(/vessels/details/\d+)"', body)
    return ("https://www.vesselfinder.com" + m.group(1)) if m else None


def vessel_live_position(name):
    """Vessel ka live status: position, destination, ETA, speed."""
    detail_url = vessel_search(name)
    if not detail_url:
        # v51 (24 Oct): kuch feeder jahazon ke asal registered naam
        # ke aakhir mein number nahi hota — BL par "RONG HANG 268"
        # likha hota hai, VesselFinder par sirf "RONG HANG" milta
        # hai. Number hata kar ek aur koshish karo.
        base = re.sub(r"\s+\d+\s*$", "", (name or "").strip())
        if base and base != name:
            detail_url = vessel_search(base)
            if detail_url:
                name = base
    if not detail_url:
        return {"found": False, "note": f"'{name}' was not found on VesselFinder."}
    try:
        req = urllib.request.Request(detail_url, headers=UA)
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except Exception as e:
        return {"error": f"Could not reach VesselFinder: {e}"}
    text = clean_text(body)
    info = {"found": True, "source": "VesselFinder", "vessel": name,
            "url": detail_url}
    m = re.search(r"Destination\s+([^,]+?),\s*([A-Za-z ]+?)\s*ETA:\s*([^(]+)",
                  text)
    if m:
        info["destination"] = f"{m.group(1).strip()}, {m.group(2).strip()}"
        info["eta"] = m.group(3).strip()
    m = re.search(r"speed of ([\d.]+) knots", text)
    if m:
        info["speed"] = f"{m.group(1)} knots"
    m = re.search(r"Navigation Status\s+([A-Za-z ]+?)(?:\s{2,}|$)", text)
    if m:
        info["nav_status"] = m.group(1).strip()
    m = re.search(r"Position Received\s+([^(]+?)(?:\s{2,}|$)", text)
    if m:
        info["position_time"] = m.group(1).strip()[:60]
    if len(info) <= 3:
        info["found"] = False
        info["note"] = "Vessel found, but no live data could be extracted."
    return info


def parse_tracktrace(body, final_url):
    text = clean_text(body)
    low = text.lower()
    result = {"source": "track-trace.com", "url": final_url}

    # carrier site frame block karti hai — direct link se kaam chalega
    if "can not be displayed in a frame" in low:
        result["found"] = False
        result["deferred"] = True
        m = re.search(r"show\s+(.+?)\s+results without frame", text, re.I)
        carrier_name = m.group(1).strip() if m else "carrier"
        result["note"] = (f"{carrier_name}'s site cannot be shown in a frame — "
                          "please use the direct link below.")
        return result

    # v51 (24 Oct): kuch carriers (Maersk) track-trace par sirf
    # frame mein aate hain — un ke page par upar wala jumla NAHI
    # hota, lekin frame-src mein carrier ka seedha deep link hota
    # hai (maersk.com/tracking/<BL>). Pehle ye pehchana hi nahi
    # jata tha aur app jhoota "no readable record" kehta tha.
    mf = re.search(r'frame-src="(https?://[^"]+)"', body or "", re.I)
    if mf:
        result["found"] = False
        result["deferred"] = True
        result["direct_url"] = html.unescape(mf.group(1))
        mg = re.search(r"Getting results from\s+(.+?)(?:\s+Hide|\s*$)",
                       text, re.I)
        cname = mg.group(1).strip() if mg else "The carrier"
        result["note"] = (f"{cname}'s site cannot be shown in a frame — "
                          "please use the direct link below.")
        return result

    # na-mila wale cases
    if "no known tracking" in low or "not found" in low or "no result" in low:
        result["found"] = False
        # carrier hint nikalne ki koshish
        m = re.search(r"No known tracking services for prefix\s*([A-Z]+)", text, re.I)
        if m:
            result["note"] = f"Prefix {m.group(1)} did not match any known carrier."
        else:
            # aam ghalti ka paigham
            m2 = re.search(r"(.{0,120}(not found|no result).{0,120})", text, re.I)
            result["note"] = m2.group(1).strip() if m2 else "No record found."
        return result

    # company selection page = koi asal data nahi (manual select chahiye)
    if ("please select the company" in low
            or "selecting company manually" in low
            or "is unknown to us" in low):
        result["found"] = False
        result["note"] = ("The carrier could not be auto-detected — the "
                          "company must be selected manually in a browser.")
        return result

    # fields nikalne ki koshish (labels mukhtalif ho sakte hain).
    # SABOOT lazmi hai: sirf page mil jana "found" nahi — track-trace
    # ka khaali search page bhi pehle found ban jata tha aur us ke
    # madad-wale alfaaz pol/pod ban jate thay (jhooti tasalli).
    for label, keys in [
        ("vessel", ["vessel", "ship"]),
        ("voyage", ["voyage"]),
        ("pol", ["port of loading", "origin", "from"]),
        ("pod", ["port of discharge", "destination", "to"]),
        ("eta", ["eta", "estimated arrival", "arrival"]),
        ("etd", ["etd", "estimated departure", "departure"]),
        ("status", ["status"]),
    ]:
        for k in keys:
            m = re.search(re.escape(k) + r"\s*[:\-]?\s*([A-Z0-9][^|<>]{1,60})", text, re.I)
            if m:
                val = m.group(1).strip()
                # vessel: sirf tab jab asal jahaz ka naam lage (page ka kachra nahi)
                if label == "vessel" and not looks_like_vessel(val):
                    continue
                result[label] = val
                break
    # kachra values saaf karo: form/madad ke alfaaz data nahi hain
    BOILER = ("track", "insert", "option", "direct?", "remove",
              "select", "format", "automatically", "here,",
              "should have", "number from url")
    for k in ("pol", "pod", "eta", "etd", "status", "voyage"):
        v = str(result.get(k) or "")
        if v and any(b in v.lower() for b in BOILER):
            result.pop(k, None)
    # asal saboot: jahaz ka naam, ya tareekh jaisi ETA/ETD, ya
    # containers, ya pehchani hui status — in ke baghair NOT found
    import datetime as _dt
    def _is_date(v):
        try:
            _dt.datetime.strptime(str(v).strip()[:11].title(),
                                  "%d %b %Y")
            return True
        except Exception:
            return bool(re.search(
                r"\b(19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b",
                str(v or "")))
    evidence = bool(result.get("vessel")
                    or result.get("containers")
                    or _is_date(result.get("eta"))
                    or _is_date(result.get("etd"))
                    or re.search(r"loaded|discharged|departed|arrived|"
                                 r"received|gate|delivered|vessel",
                                 str(result.get("status") or ""),
                                 re.I))
    if not evidence:
        result["found"] = False
        result["note"] = ("track-trace did not return a readable "
                          "record for this number.")
        for k in ("vessel", "voyage", "pol", "pod", "eta", "etd",
                  "status"):
            result.pop(k, None)
        return result
    result["raw_snippet"] = text[:600]
    return result


def looks_like_vessel(name):
    """Kya ye asal vessel ka naam lagta hai? Page navigation ka kachra nahi."""
    if not name or len(name) < 3 or len(name) > 40:
        return False
    low = name.lower()
    # page/UI ke aam alfaz hon to vessel nahi
    junk = ["tracking", "track", "click", "here", "close", "recent", "search",
            "select", "menu", "page", "home", "back", "show", "hide", "more",
            "detect", "company", "based", "result", "option", "http", "www"]
    if any(j in low for j in junk):
        return False
    # kam az kam ek bara harf se shuru hone wala lafz ho
    if not re.search(r"[A-Z]{2,}", name):
        return False
    return True


# Pattern wale BL formats jo 4-huroof prefix table mein nahi aa
# sakte (24 Oct 2026, v51). Sab Yousuf ki BL photos aur 22 Oct ki
# research se verified hain. In ke baghair Wan Hai ka BL
# 142G513366 "not found" aaya tha jab ke Wan Hai ki site par us
# ka record maujood tha — pehchan hi nahi hui thi.
_BL_PATTERNS = [
    (r"\d{3}G\d{6,7}", "Wan Hai"),                # 142G513366, 025G...
    (r"\d{9}", "Maersk"),                          # bare 9-rakam BL
    (r"S\d{9}", "Yang Ming"),                      # S43.../S49... (YMJA)
    (r"MCL[A-Z]{3}\d{8,10}", "Monter Container Line"),  # MCLSUB26104308
    (r"HAICB\d{8,9}", "RCL"),                      # HAICB26009612
    (r"SGS\d{4}SIN[A-Z0-9]*", "SeaGem Shipping"),   # SGS5314SINKHI
]


def identify_carrier(bl_number):
    prefix = bl_number[:4].upper()
    carrier = CARRIERS.get(prefix)
    if not carrier:
        u = (bl_number or "").upper()
        for pat, name in _BL_PATTERNS:
            if re.fullmatch(pat, u):
                carrier = name
                break
    return prefix, carrier


def norm(s):
    """Number saaf karo: space/dash hatao, uppercase."""
    return re.sub(r"[\s\-]", "", s).upper()


_LINE_CANON = {
    "EVERGREEN": "Evergreen", "MAERSK": "Maersk", "MSC": "MSC",
    "MEDITERRANEAN SHIPPING": "MSC", "COSCO": "COSCO Shipping",
    "CMA CGM": "CMA CGM", "HAPAG": "Hapag-Lloyd", "ONE": "ONE",
    "OCEAN NETWORK": "ONE", "OOCL": "OOCL",
    "ORIENT OVERSEAS": "OOCL", "YANG MING": "Yang Ming",
    "ZIM": "ZIM", "WAN HAI": "Wan Hai", "EMKAY": "Emkay Line",
    "EM KAY": "Emkay Line", "PIL": "Pacific International Lines",
    "PACIFIC INTERNATIONAL": "Pacific International Lines",
    "HMM": "HMM", "HYUNDAI": "HMM", "KMTC": "KMTC",
    "SINOKOR": "Sinokor", "HEUNG-A": "Heung-A",
    "SITC": "SITC", "RCL": "RCL",
    "REGIONAL CONTAINER": "RCL", "INTERASIA": "Interasia Lines",
    "GOLD STAR": "Gold Star Line", "SAMUDERA": "Samudera",
    "ARKAS": "Arkas Line", "TURKON": "Turkon Line",
}


def _canon_line(line):
    """Terminal/QICT ki 'Shipping Line' ko mashhoor naam mein
    badlo — 'EVERGREEN MARINE' -> 'Evergreen'."""
    u = (line or "").upper()
    for k, v in _LINE_CANON.items():
        if k in u:
            return v
    return (line or "").strip().title() or None


# ---- Traqo Ocean: API layer (v56) ----
# Sirf TAB chalti hai jab (a) Settings mein Traqo API key ho aur
# (b) tamam muft layers naakaam ho chuki hon — kyunke free plan
# mein har NAYA reference 4 monthly tracks mein se 1 slot khata
# hai (usi reference ki dobara query muft hai). API contract
# Developer page se verified (24 Oct 2026): base
# https://traqocontainer.com/api/v1, header
# "Authorization: Bearer <key>", ?sealine=XX param.
TRAQO_BASE = "https://traqocontainer.com/api/v1"
_TRAQO_SEALINE = {
    "maersk": "MAEU", "msc": "MSCU", "cma": "CMDU",
    "hapag": "HLCU", "cosco": "COSU", "evergreen": "EGLV",
    "yang ming": "YMLU", "one": "ONEY", "ocean network": "ONEY",
    "zim": "ZIMU", "pil": "PILU", "hmm": "HMMU",
    "oocl": "OOLU", "kmtc": "KMTC", "wan hai": "WHLC",
}


def _traqo_sealine(carrier_name):
    u = (carrier_name or "").lower()
    for k, v in _TRAQO_SEALINE.items():
        if k in u:
            return v
    return None


def _traqo_date(s):
    """'2026-11-10 00:00:00' / '2026-11-10' -> '10 Nov 2026'."""
    import datetime as _dt
    s = str(s or "").strip()
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if not m:
        return s
    try:
        return _dt.date(int(m.group(1)), int(m.group(2)),
                        int(m.group(3))).strftime("%d %b %Y")
    except Exception:
        return s


def track_traqo(ref, is_container, carrier_name, api_key):
    """Traqo Ocean API se ek BL/container ka record. Hamesha
    {found, ...} deta hai; HTTP/plan ki rukawatein note mein
    imandari se likhi jati hain. Kabhi raise nahi karta."""
    import json as _json
    key = str(api_key or "").strip()
    if not key or not ref:
        return {"found": False, "note": "No Traqo API key saved."}
    kind = "container" if is_container else "bl"
    url = f"{TRAQO_BASE}/{kind}/{urllib.parse.quote(str(ref).strip())}"
    sl = _traqo_sealine(carrier_name)
    if sl:
        url += f"?sealine={sl}"
    req = urllib.request.Request(url, headers={
        **UA, "Authorization": f"Bearer {key}",
        "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            payload = _json.loads(r.read().decode("utf-8",
                                                  errors="replace"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {"found": False, "note":
                    "Traqo: API key was not accepted — check the "
                    "key in Settings."}
        if e.code == 402:
            return {"found": False, "note":
                    "Traqo: this month's 4 free tracks are used "
                    "up (they reset monthly)."}
        if e.code == 404:
            return {"found": False, "note":
                    "Traqo has no record for this number."}
        if e.code == 429:
            return {"found": False, "note":
                    "Traqo rate limit reached — try again later."}
        return {"found": False, "note": f"Traqo returned HTTP {e.code}."}
    except Exception as e:
        return {"found": False, "note": f"Traqo could not be reached ({e})."}
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not data:
        return {"found": False, "note":
                "Traqo returned no shipment data for this number."}
    res = {"found": True, "source": "Traqo (API)"}
    raw_status = str(data.get("status") or "").strip()
    eta = _traqo_date(data.get("eta"))
    status = raw_status.replace("_", " ").title() if raw_status else ""
    # Events: asal API shape events_table hai (24 Oct 2026 ko
    # live response se verified) — har event mein date, location,
    # event_code, vessel, voyage, is_actual hota hai. Latest
    # event = sab se taaza ASAL (is_actual) event; mustaqbil ke
    # events schedule hain, khabar nahi.
    _EV_LABEL = {"DEPA": "Vessel departed", "ARRI": "Vessel arrived",
                 "LOAD": "Loaded on vessel", "DISC": "Discharged",
                 "GTIN": "Gate in", "GTOU": "Gate out",
                 "CEP": "Container received at terminal",
                 "VAT": "Vessel arrived", "VDT": "Vessel departed",
                 "VAD": "Vessel arrived at destination",
                 "DLVR": "Delivered", "EMRT": "Empty returned"}
    events = (data.get("events_table") or data.get("events")
              or data.get("milestones") or [])
    evs = [e for e in events if isinstance(e, dict)] \
        if isinstance(events, list) else []
    def _ev_key(e):
        return str(e.get("date") or e.get("event_date")
                   or e.get("timestamp") or "")
    evs.sort(key=_ev_key)
    actual = [e for e in evs
              if e.get("is_actual") in (1, True, "1", "true")]
    last_ev = actual[-1] if actual else (evs[-1] if evs else None)
    voyage = None
    if last_ev:
        code = str(last_ev.get("event_code") or "").upper()
        label = _EV_LABEL.get(code) or code or "Event"
        loc = str(last_ev.get("location") or "")
        when = _traqo_date(last_ev.get("date")
                            or last_ev.get("timestamp"))
        txt = f"{label} — {loc}" if loc else label
        if not actual:
            txt += " (expected)"
        res["latest_event"] = f"{txt} ({when})" if when else txt
        if last_ev.get("voyage"):
            voyage = str(last_ev["voyage"])
    if status and eta:
        res["status"] = f"{status} — ETA {eta}"
    elif status:
        res["status"] = status
    if eta:
        res["eta"] = eta
    if data.get("origin"):
        res["pol"] = str(data["origin"])
    if data.get("destination"):
        res["pod"] = str(data["destination"])
    if data.get("sealine_name"):
        res["line"] = str(data["sealine_name"])
    # Containers: asal shape containers_table[].container_number
    ctns = []
    for c in (data.get("containers_table") or data.get("containers")
              or []):
        if isinstance(c, str):
            ctns.append(c)
        elif isinstance(c, dict):
            n = (c.get("container_number") or c.get("number")
                 or c.get("containerNumber") or c.get("id"))
            if n:
                ctns.append(str(n))
    if not ctns and is_container:
        ctns = [str(ref)]
    if ctns:
        res["containers"] = ctns
    # Vessel: vessels_table mein is_current wali row asal jahaz
    # hai; voyage current vessel ke kisi event se lo.
    vessel = data.get("vessel") or data.get("vessel_name")
    if not vessel:
        vs = data.get("vessels_table") or data.get("vessels") or []
        rows = [v for v in vs if isinstance(v, dict)] \
            if isinstance(vs, list) else []
        cur = [v for v in rows
               if v.get("is_current") in (1, True, "1", "true")]
        pick = cur[-1] if cur else (rows[-1] if rows else None)
        if pick:
            vessel = (pick.get("vessel") or pick.get("name")
                      or pick.get("vessel_name"))
    if vessel:
        res["vessel"] = str(vessel)
        if not voyage:
            for e in evs:
                if e.get("vessel") == vessel and e.get("voyage"):
                    voyage = str(e["voyage"])
                    break
    if data.get("voyage"):
        voyage = str(data["voyage"])
    if voyage:
        res["voyage"] = voyage
    return res


def track_all(bl=None, ctn=None, vessel_name=None, progress_cb=None,
              carrier_hint=None, traqo_key=None):
    """Structured tracking — GUI aur CLI dono ke liye.
    progress_cb(layer_name, status, detail) — status: running/done/fail
    Returns: dict with carrier, layers[], result{}, contacts{}
    """
    def prog(name, status, detail=""):
        if progress_cb:
            progress_cb(name, status, detail)

    out = {"carrier": None, "prefix": None, "layers": [], "result": {},
           "contacts": None, "tried": []}

    # Vessel-only mode
    if vessel_name:
        prog("Layer 4 — VesselFinder", "running", vessel_name)
        r = vessel_live_position(vessel_name)
        out["layers"].append({"name": "Layer 4 — VesselFinder",
                              "status": "done" if r.get("found") else "fail",
                              "detail": vessel_name})
        if r.get("found"):
            out["result"] = r
        prog("Layer 4 — VesselFinder",
             "done" if r.get("found") else "fail", "")
        return out

    # Layer 0: carrier identify
    prog("Layer 0 — Carrier identification", "running")
    lookup = bl or ctn
    prefix, carrier = identify_carrier(lookup) if lookup else (None, None)
    # UI se manual carrier chuna gaya ho aur prefix se pehchan na
    # ho payi ho, to wahi hint asal tracking mein istemal karo —
    # pehle hint sirf naam badalta tha, talaash nahi (v29 fix).
    if not carrier and carrier_hint:
        carrier = carrier_hint
    out["carrier"] = carrier
    out["prefix"] = prefix
    # v51: pehchan "record mila" NAHI hoti — is layer ko meta mark
    # karo taake UI ka "x found a record" count is se na barhe
    # (24 Oct: Wan Hai BL par count "1 found" dikha jab ke asal
    # record ek bhi nahi mila tha). Status bhi ab sach bolega:
    # carrier na pehchana jaye to fail.
    out["layers"].append({"name": "Layer 0 — Carrier identification",
                         "status": "done" if carrier else "fail",
                         "meta": True,
                         "detail": f"{carrier} (prefix {prefix})" if carrier
                         else f"Unknown (prefix {prefix})"})
    prog("Layer 0 — Carrier identification",
         "done" if carrier else "fail")

    # Forwarder contact (agar hai)
    if carrier in FORWARDER_CONTACTS:
        out["contacts"] = FORWARDER_CONTACTS[carrier]

    got_vessel = None

    # Layer 1: carrier direct API
    api_fn = CARRIER_APIS.get(carrier) if (carrier and bl) else None
    # Sirf-digits wala 12-rakam number: Evergreen ke BL ka number
    # hissa itna hi hota hai (EGLV + 12 digits) — ShipmentLink se
    # seedha jaanch lo, mile to carrier Evergreen pakka.
    sl_fallback = False
    cosco_fallback = False
    if not api_fn and bl and re.fullmatch(r"\d{12}", bl):
        api_fn = track_shipmentlink_bl
        sl_fallback = True
    elif not api_fn and bl and re.fullmatch(r"\d{10}", bl):
        # 10-rakam ka sirf-number COSCO ke BL ka number hissa hota
        # hai (COAU/COSU + 10 digits) — 21 Oct ko 6470875561 isi
        # liye chhoot gaya tha; COSCO API khud record de to pakka.
        api_fn = track_cosco_api
        cosco_fallback = True
    if api_fn:
        lname = (f"Layer 1 — {carrier} direct API" if not sl_fallback
                 else "Layer 1 — Evergreen ShipmentLink")
        prog(lname, "running")
        out["tried"].append(lname)
        r = api_fn(bl)
        ok = bool(r.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r.get("note") or r.get("error") or "")[:100]})
        if ok:
            if sl_fallback and not out.get("carrier"):
                out["carrier"] = "Evergreen"
            if cosco_fallback and not out.get("carrier"):
                out["carrier"] = "COSCO Shipping"
            out["result"].update({k: r[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "containers", "terminal",
                                  "discharge_time", "source",
                                  "activity_date", "weight",
                                  "size_type") if k in r})
            got_vessel = r.get("vessel")
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")
        if not ok and not r.get("error"):
            # F-09 fix (v46 audit): the carrier API answered but had no
            # record — track-trace used to be skipped entirely for
            # API carriers. Try it as a fallback before moving on.
            lname2 = "Layer 1b — track-trace.com (BL)"
            prog(lname2, "running")
            out["tried"].append(lname2)
            r2t = track_bol_tracktrace(bl, carrier)
            ok2 = bool(r2t.get("found"))
            out["layers"].append(
                {"name": lname2, "status": "done" if ok2 else "fail",
                 "detail": (r2t.get("note") or r2t.get("error") or "")[:100]})
            if ok2:
                out["result"].update({k: r2t[k] for k in
                                      ("vessel", "voyage", "pol", "pod",
                                       "eta", "etd", "status", "containers",
                                       "terminal", "discharge_time",
                                       "source", "activity_date", "weight",
                                       "size_type") if k in r2t})
                got_vessel = r2t.get("vessel") or got_vessel
            prog(lname2, "done" if ok2 else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")
    elif bl:
        # Layer 2: track-trace BL
        lname = "Layer 2 — track-trace.com (BL)"
        prog(lname, "running")
        out["tried"].append(lname)
        r = track_bol_tracktrace(bl, carrier)
        ok = bool(r.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r.get("note") or r.get("error") or "")[:100]})
        if ok:
            out["result"].update({k: r[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "source") if k in r})
            got_vessel = r.get("vessel")
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2b: container
    if ctn:
        capi_fn = CARRIER_CONTAINER_APIS.get(carrier) if carrier else None
        lname = (f"Layer 2 — {carrier} container API" if capi_fn
                 else "Layer 2 — track-trace.com (container)")
        prog(lname, "running")
        out["tried"].append(lname)
        r2 = capi_fn(ctn) if capi_fn else track_container_tracktrace(ctn)
        ok = bool(r2.get("found"))
        if not ok and r2.get("empty_container"):
            out["result"].update({
                "status": ("No active shipment — this container is "
                           "in COSCO's system (it may be empty or an "
                           "old record)"),
                "source": "COSCO API", "containers": [ctn]})
            ok = True
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r2.get("note") or r2.get("error") or "")[:100]})
        if ok and not got_vessel:
            got_vessel = r2.get("vessel")
            out["result"].update({k: r2[k] for k in
                                 ("vessel", "voyage", "pol", "pod", "eta",
                                  "etd", "status", "source", "position",
                                  "size_type", "weight",
                                  "containers") if k in r2})
            if r2.get("location") and not out["result"].get("position"):
                out["result"]["position"] = r2["location"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 2c: Emkay container search (extra chance — NVOCC cargo)
    if ctn and not out["result"].get("vessel"):
        lname = "Layer 2 — Emkay Line (container)"
        prog(lname, "running")
        out["tried"].append(lname)
        r3 = track_emkay_container_api(ctn)
        ok = bool(r3.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (r3.get("note") or r3.get("error") or "")[:100]})
        if ok:
            if not out.get("carrier"):
                out["carrier"] = "Emkay Line"
            out["result"].update({k: r3[k] for k in
                                 ("vessel", "voyage", "pol", "pod",
                                  "etd", "status", "source",
                                  "activity_date") if k in r3})
            got_vessel = r3.get("vessel") or got_vessel
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # v51 SPEED (24 Oct): Layer 3 (KICT/SAPT) aur Layer 3b (QICT)
    # ke raw jawab EK SATH (parallel) mangwao — dono sirf BL par
    # munhasir hain, aapas mein koi rabta nahi. Merge aage purani
    # serial tartib mein hi hota hai, is liye natija, precedence
    # aur layer lines bilkul purane jaisi rehti hain; sirf waqt
    # dono ke MAJWAH ki bajaye slow wale ke barabar ho jata hai
    # (ye jora pehle aksar 20-30 second kha jata tha).
    _raw3 = _raw3b = _raw3e = None
    if bl and not out["result"].get("containers"):
        try:
            from concurrent.futures import ThreadPoolExecutor as _TPE
            with _TPE(max_workers=3) as _ex:
                _f3 = _ex.submit(track_karachi_terminals, bl)
                _f3b = _ex.submit(track_qict_bl, bl)
                _f3e = _ex.submit(track_kgtl_bl, bl)
                try:
                    _raw3 = _f3.result()
                except Exception as _e:
                    _raw3 = {"found": False, "error": str(_e)}
                try:
                    _raw3b = _f3b.result()
                except Exception as _e:
                    _raw3b = {"found": False, "note": str(_e)}
                try:
                    _raw3e = _f3e.result()
                except Exception as _e:
                    _raw3e = {"found": False, "note": str(_e)}
        except Exception:
            _raw3 = _raw3b = None

    # Layer 3: Karachi terminals (KICT/SAPT) — har BL par, house BL bhi
    if bl and not out["result"].get("containers"):
        lname = "Layer 3 — Karachi Terminal"
        prog(lname, "running")
        out["tried"].append(lname)
        rt = _raw3 if _raw3 is not None else track_karachi_terminals(bl)
        ok = bool(rt.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (f"{len(rt.get('containers',[]))} container(s)"
                                         + (f" at {rt['terminal']}"
                                            if rt.get('terminal') else "")
                                        ) if ok else (rt.get("note") or rt.get("error") or "")})
        if ok:
            out["result"]["containers"] = [c.get("CONTAINER NO", "")
                                            for c in rt["containers"]]
            out["result"]["terminal"] = rt.get("terminal", "")
            out["result"]["terminal_rows"] = rt["containers"]
            # terminal details se khaali fields bharo (carrier data ko priority)
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "discharge_time", "do_expiry", "position", "holds", "vir",
                      "weight", "commodity", "size_type", "custom_status",
                      "category", "gate_in", "gate_out", "owner"):
                if rt.get(k) and not out["result"].get(k):
                    out["result"][k] = rt[k]
            # discharge/gate-out terminal ki zameeni haqeeqat hai — status override
            if rt.get("status"):
                out["result"]["status"] = rt["status"]
            elif not out["result"].get("status"):
                if rt.get("terminal"):
                    out["result"]["status"] = (
                        f"Arrived at {rt['terminal']} terminal (Karachi)")
                else:
                    out["result"]["status"] = "Arrived at Karachi terminal"
            if rt.get("source"):
                out["result"]["source"] = rt["source"]
            if rt.get("vessel") and not got_vessel:
                got_vessel = rt["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3b: QICT (DP World) — KICT/SAPT par na mile to (Emkay/RTW cargo)
    if bl and not out["result"].get("containers"):
        lname = "Layer 3b — QICT (DP World Karachi)"
        prog(lname, "running")
        out["tried"].append(lname)
        rq = _raw3b if _raw3b is not None else track_qict_bl(bl)
        if rq.get("found"):
            _st, _wh = _stale_info(rq)
            if _st:
                rq = {"found": False, "note":
                      f"QICT holds only an OLD record for this BL "
                      f"({_wh}) — not counted as current."}
        ok = bool(rq.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (", ".join(rq.get("containers", []))
                                         if ok else rq.get("note", ""))})
        if ok:
            out["result"]["containers"] = rq["containers"]
            out["result"]["terminal"] = "QICT"
            for k in ("vessel", "voyage", "discharge_time", "holds",
                      "vir", "line", "pod", "category", "truck", "gd_no"):
                if rq.get(k) and not out["result"].get(k):
                    out["result"][k] = rq[k]
            # QICT is the ground truth for cargo sitting at QICT:
            # its standing/position override any older carrier status
            # (v28 audit fix — a stale "in transit" must not survive).
            if rq.get("status"):
                out["result"]["status"] = rq["status"]
            if rq.get("position"):
                out["result"]["position"] = rq["position"]
            if rq.get("source"):
                out["result"]["source"] = rq["source"]
            if rq.get("vessel") and not got_vessel:
                got_vessel = rq["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3e: KGTL (Karachi Gateway Terminal — AD Ports, East
    # Wharf) — teesra Karachi terminal; v61 mein shamil, 25 Oct
    # 2026 ko asal BL par verified (ATA/VIR/container grid).
    if bl and not out["result"].get("containers"):
        lname = "Layer 3e — KGTL (Karachi Gateway Terminal)"
        prog(lname, "running")
        out["tried"].append(lname)
        rg = _raw3e if _raw3e is not None else track_kgtl_bl(bl)
        if rg.get("found"):
            _st, _wh = _stale_info(rg)
            if _st:
                rg = {"found": False, "note":
                      f"KGTL holds only an OLD record for this BL "
                      f"({_wh}) — not counted as current."}
        ok = bool(rg.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (", ".join(rg.get("containers", []))
                                         if ok else rg.get("note", ""))})
        if ok:
            out["result"]["containers"] = rg["containers"]
            out["result"]["terminal"] = "KGTL"
            out["result"]["terminal_rows"] = rg.get("terminal_rows", [])
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "position", "holds", "vir", "weight", "commodity",
                      "size_type", "category"):
                if rg.get(k) and not out["result"].get(k):
                    out["result"][k] = rg[k]
            if rg.get("status"):
                out["result"]["status"] = rg["status"]
            if rg.get("expected"):
                out["result"]["expected"] = True
            if rg.get("source"):
                out["result"]["source"] = rg["source"]
            if rg.get("vessel") and not got_vessel:
                got_vessel = rg["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3c: QICT by container number — container-first searches,
    # and cargo the BL search could not place at a terminal.
    ctn_known = ctn or (out["result"].get("containers") or [None])[0]
    # v51 SPEED: Layer 3c/3d (container wale terminal raste) bhi
    # parallel prefetch — merge purani tartib mein hi hoga.
    _raw3c = _raw3d = _raw3f = None
    if ctn_known and (not out["result"].get("discharge_time")
                      or not out["result"].get("containers")):
        try:
            from concurrent.futures import ThreadPoolExecutor as _TPE2
            with _TPE2(max_workers=3) as _ex2:
                _f3c = _ex2.submit(track_qict_container_layer, ctn_known)
                _f3d = _ex2.submit(track_karachi_terminals_container,
                                   ctn_known)
                _f3f = _ex2.submit(track_kgtl_container, ctn_known)
                try:
                    _raw3c = _f3c.result()
                except Exception as _e:
                    _raw3c = {"found": False, "note": str(_e)}
                try:
                    _raw3d = _f3d.result()
                except Exception as _e:
                    _raw3d = {"found": False, "error": str(_e)}
                try:
                    _raw3f = _f3f.result()
                except Exception as _e:
                    _raw3f = {"found": False, "note": str(_e)}
        except Exception:
            _raw3c = _raw3d = None
    if ctn_known and not out["result"].get("discharge_time"):
        lname = "Layer 3c — QICT (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rc = _raw3c if _raw3c is not None else track_qict_container_layer(ctn_known)
        ok = bool(rc.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (rc.get("status", "") if ok
                                         else rc.get("note", ""))})
        if ok:
            if not out["result"].get("containers"):
                out["result"]["containers"] = [ctn_known]
            if not out["result"].get("terminal"):
                out["result"]["terminal"] = "QICT"
            for k in ("vessel", "voyage", "discharge_time", "holds",
                      "vir", "line", "pod"):
                if rc.get(k) and not out["result"].get(k):
                    out["result"][k] = rc[k]
            if rc.get("status"):
                out["result"]["status"] = rc["status"]
            if rc.get("expected"):
                out["result"]["expected"] = True
            if rc.get("source"):
                out["result"]["source"] = rc["source"]
            if rc.get("vessel") and not got_vessel:
                got_vessel = rc["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3d: Karachi Terminal by container number
    if ctn_known and not out["result"].get("containers"):
        lname = "Layer 3d — Karachi Terminal (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rd = _raw3d if _raw3d is not None else track_karachi_terminals_container(ctn_known)
        ok = bool(rd.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (f"{len(rd.get('containers',[]))} container(s)"
                                         + (f" at {rd['terminal']}"
                                            if rd.get('terminal') else "")
                                        ) if ok else (rd.get("note") or rd.get("error") or "")})
        if ok:
            out["result"]["containers"] = [c.get("CONTAINER NO", "")
                                           for c in rd["containers"]]
            out["result"]["terminal"] = rd.get("terminal", "")
            out["result"]["terminal_rows"] = rd["containers"]
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "discharge_time", "do_expiry", "position", "holds",
                      "vir", "weight", "commodity", "size_type",
                      "custom_status", "category", "gate_in", "gate_out",
                      "owner"):
                if rd.get(k) and not out["result"].get(k):
                    out["result"][k] = rd[k]
            if rd.get("status"):
                out["result"]["status"] = rd["status"]
            elif not out["result"].get("status"):
                out["result"]["status"] = (
                    f"Arrived at {rd['terminal']} terminal (Karachi)"
                    if rd.get("terminal") else "Arrived at Karachi terminal")
            if rd.get("source"):
                out["result"]["source"] = rd["source"]
            if rd.get("vessel") and not got_vessel:
                got_vessel = rd["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Layer 3f: KGTL by container number — sirf tab jab koi
    # terminal abhi tak pehchana na gaya ho (KGTL ki zameeni
    # haqeeqat apne yard ke liye final hai, doosre terminal
    # ke record par kabhi override nahi).
    if ctn_known and not out["result"].get("terminal"):
        lname = "Layer 3f — KGTL (by container)"
        prog(lname, "running")
        out["tried"].append(lname)
        rf = _raw3f if _raw3f is not None else track_kgtl_container(ctn_known)
        if rf.get("found"):
            _st, _wh = _stale_info(rf)
            if _st:
                rf = {"found": False, "note":
                      f"KGTL holds only an OLD record for this "
                      f"container ({_wh}) — not counted as current."}
        ok = bool(rf.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": (rf.get("status", "") if ok
                                         else rf.get("note", ""))})
        if ok:
            if not out["result"].get("containers"):
                out["result"]["containers"] = [ctn_known]
            out["result"]["terminal"] = "KGTL"
            for k in ("vessel", "voyage", "eta", "etd", "pol", "pod",
                      "position", "holds", "vir", "weight", "commodity",
                      "size_type", "category"):
                if rf.get(k) and not out["result"].get(k):
                    out["result"][k] = rf[k]
            if rf.get("status"):
                out["result"]["status"] = rf["status"]
            if rf.get("expected"):
                out["result"]["expected"] = True
            if rf.get("source"):
                out["result"]["source"] = rf["source"]
            if rf.get("vessel") and not got_vessel:
                got_vessel = rf["vessel"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # Terminal confirm: carrier ke POD mein terminal ka naam wazeh ho
    # (masalan "Karachi-South Asia Pakistan Terminals(SAPT)") to wahi
    # pakka saboot hai — andaza nahi lagana.
    if not out["result"].get("terminal"):
        _pod = (out["result"].get("pod") or "").upper()
        if "SAPT" in _pod or "SOUTH ASIA PAKISTAN" in _pod:
            out["result"]["terminal"] = "SAPT"
        elif "KICT" in _pod or "KARACHI INTERNATIONAL" in _pod:
            out["result"]["terminal"] = "KICT"

    # Layer 4: vessel live
    if got_vessel and looks_like_vessel(got_vessel):
        lname = f"Layer 4 — VesselFinder ({got_vessel})"
        prog(lname, "running")
        out["tried"].append(lname)
        rv = vessel_live_position(got_vessel)
        ok = bool(rv.get("found"))
        out["layers"].append({"name": lname, "status": "done" if ok else "fail",
                              "detail": rv.get("destination", "")})
        if ok:
            for k in ("destination", "speed"):
                if k in rv:
                    out["result"][k] = rv[k]
            if rv.get("url"):
                out["result"]["vf_url"] = rv["url"]
            # Vessel-level ETA only while the cargo is still at sea —
            # never for discharged / released / delivered / held cargo.
            st_now = (out["result"].get("status") or "").lower()
            completed = bool(out["result"].get("discharge_time")) or any(
                w in st_now for w in ("discharg", "released", "delivered",
                                      "gate out", "on hold"))
            if rv.get("eta") and not out["result"].get("eta") and not completed:
                out["result"]["eta"] = rv["eta"]
        prog(lname, "done" if ok else "fail", out["layers"][-1].get("detail", "") if out["layers"] else "")

    # containers kabhi dohre nahi (terminal kabhi ek hi container
    # ki kai rows bhejta hai — MCLSUB26104308 par pakra gaya)
    if out["result"].get("containers"):
        out["result"]["containers"] = list(
            dict.fromkeys(out["result"]["containers"]))
    # prefix se pehchan na hui ho lekin kisi layer ne asal
    # shipping line bata di ho, to wahi carrier hai
    if not out.get("carrier") and out["result"].get("line"):
        out["carrier"] = _canon_line(out["result"]["line"])

    # Layer 5 — Traqo (API): aakhri rasta, sirf tab jab key ho
    # aur tamam muft layers ke baad bhi koi record na mila ho
    # (free plan: har naya reference 1 monthly slot khata hai,
    # is liye pehle kabhi nahi).
    if traqo_key and not out["result"] and (bl or ctn):
        lname = "Layer 5 — Traqo (API)"
        prog(lname, "running")
        out["tried"].append(lname)
        rt = track_traqo(bl or ctn, bool(ctn and not bl),
                         out.get("carrier") or carrier_hint, traqo_key)
        ok = bool(rt.get("found"))
        out["layers"].append({
            "name": lname, "status": "done" if ok else "fail",
            "detail": (rt.get("latest_event") or rt.get("status")
                       or rt.get("note") or "") if ok
                      else (rt.get("note") or "")})
        if ok:
            out["result"] = {k: v for k, v in rt.items()
                              if k not in ("found", "note")}
            if rt.get("line") and not out.get("carrier"):
                out["carrier"] = _canon_line(rt["line"])
        prog(lname, "done" if ok else "fail",
             out["layers"][-1].get("detail", ""))

    return out


def main():
    args = sys.argv[1:]
    ctn = None
    # -c / --container: sirf container number diya gaya (BL ke baghair)
    # -v / --vessel: sirf vessel ka naam (live position/ETA)
    vessel_only = False
    if args and args[0] in ("-c", "--container"):
        if len(args) < 2:
            print("Usage: python3 bl-track.py -c <CONTAINER_NUMBER>")
            sys.exit(1)
        ctn = norm(args[1]); bl = None
    elif args and args[0] in ("-v", "--vessel"):
        if len(args) < 2:
            print("Usage: python3 bl-track.py -v <VESSEL_NAME>")
            sys.exit(1)
        vessel_only = True
        vessel_name = " ".join(args[1:])
    else:
        if not args:
            print("Usage: python3 bl-track.py <BL_NUMBER> [CONTAINER_NUMBER]")
            print("       python3 bl-track.py -c <CONTAINER_NUMBER>")
            print("       python3 bl-track.py -v <VESSEL_NAME>")
            sys.exit(1)
        bl = norm(args[0])
        ctn = norm(args[1]) if len(args) > 1 else None

    # Standalone vessel tracking (Layer 4 direct)
    if vessel_only:
        print(f"Vessel    : {vessel_name}")
        print("-" * 50)
        print("\n[Layer 4] VesselFinder — live position...")
        report_result(vessel_live_position(vessel_name))
        return

    print(f"BL Number : {bl}" if bl else "BL Number : (nahi diya)")
    if ctn:
        print(f"Container : {ctn}")
    print("-" * 50)

    tried = []   # kaun se raste try kiye — end mein summary ke liye
    got_vessel = None

    # Layer 0: Carrier pehchano (foran, offline) — BL se, warna container se
    prefix, carrier = identify_carrier(bl) if bl else identify_carrier(ctn)
    if carrier:
        print(f"Carrier   : {carrier}  (prefix {prefix})")
    else:
        print(f"Carrier   : namaloom (prefix {prefix} list mein nahi)")

    # Forwarder jiska online tracking na ho: pehle online try karo,
    # na mile to contact do (haar mat mano)
    forwarder_contact = FORWARDER_CONTACTS.get(carrier)
    if forwarder_contact and carrier == "RTW Shipping Lines":
        # RTW: online tracking nahi — seedha contact, lekin pehle
        # aggregators ek baar try karo (Layer 2 neeche chalega)
        pass  # neeche normal flow, end mein contact summary mein

    # Layer 1: Carrier ka direct API (sab se tez aur sahi — ~1 second)
    api_fn = CARRIER_APIS.get(carrier) if (carrier and bl) else None
    r = {}
    if api_fn:
        print(f"\n[Layer 1] {carrier} direct API...")
        tried.append(f"Layer 1 ({carrier} API)")
        r = api_fn(bl)
        report_result(r)
        if r.get("found"):
            got_vessel = r.get("vessel")
    elif bl:
        # Layer 2: track-trace se BL tracking (carrier API na ho to)
        print("\n[Layer 2] track-trace.com — BL tracking...")
        tried.append("Layer 2 (track-trace BL)")
        r = track_bol_tracktrace(bl, carrier)
        report_result(r)
        if r.get("found"):
            got_vessel = r.get("vessel")

    # Layer 2b: Container tracking — pehle carrier API, phir track-trace
    if ctn:
        capi_fn = CARRIER_CONTAINER_APIS.get(carrier) if carrier else None
        if capi_fn:
            print(f"\n[Layer 2] {carrier} container API...")
            tried.append(f"Layer 2 ({carrier} container API)")
            r2 = capi_fn(ctn)
        else:
            print("\n[Layer 2] track-trace.com — Container tracking...")
            tried.append("Layer 2 (track-trace container)")
            r2 = track_container_tracktrace(ctn)
        report_result(r2)
        if r2.get("found") and not got_vessel:
            got_vessel = r2.get("vessel")

    # Layer 4: Vessel live tracking — agar vessel ka naam mil gaya
    if got_vessel:
        print(f"\n[Layer 4] VesselFinder — {got_vessel} live position...")
        tried.append(f"Layer 4 (VesselFinder: {got_vessel})")
        report_result(vessel_live_position(got_vessel))

    # Kabhi haar nahi mano — summary: kya try kiya, agla rasta kya hai
    print("\n" + "=" * 50)
    print("SUMMARY — ye raste try kiye:")
    for t in tried:
        print(f"  - {t}")
    print("\nAgla rasta (browser se — Layer 1b/3):")
    direct = r.get("direct_url") if isinstance(r, dict) else None
    lookup_num = bl or ctn
    print(f"  - Carrier site: {direct or direct_tracking_url(carrier, lookup_num)}")
    print("  - Karachi ports (container/BL enquiry):")
    print("      KICT: https://www.kictl.com/Enquiries?is=ContainerBLEnquiry")
    print("      SAPT: https://www.sapt.com.pk/Enquiries?is=ContainerBLEnquiry")
    # Forwarder contact (agar online na mile to)
    fc = FORWARDER_CONTACTS.get(carrier)
    if fc:
        print(f"\n  - {carrier} se direct rabta (online tracking nahi):")
        print(f"      Phone: {fc['phone']} | Email: {fc['email']}")
        print(f"      {fc['note']}")
    print("  (browser se kholo — bot-block wali sites wahan khul jati hain)")


def direct_tracking_url(carrier, bl_number):
    """Carrier ke hisab se pre-filled tracking URL (1-click)."""
    if carrier == "COSCO Shipping":
        return ("https://elines.coscoshipping.com/ebusiness/cargoTracking"
                f"?trackingType=BILLOFLADING&number={bl_number}")
    if carrier == "OOCL":
        # 19 Oct 2026: Traqo OOCL track karta hai (oocl.com bot-blocked hai)
        return (f"https://traqocontainer.com/track/bl/{bl_number}"
                f"?carrier=OOLU")
    return CARRIER_TRACK_URL.get(carrier,
                                 "https://www.track-trace.com/")


def multi_source_urls(carrier, bl_number):
    """Multiple third-party + carrier URLs — user khud 1-click mein khole."""
    urls = []
    # 1. Carrier ki asal site (original)
    orig = CARRIER_TRACK_URL.get(carrier)
    if orig:
        urls.append(("🏢 Carrier Official", orig))
    # 2. Traqo (OOCL verified, aur bhi carriers)
    code = {"OOCL": "OOLU", "Maersk": "MAEU",
            "COSCO Shipping": "COSU"}.get(carrier, "")
    if code:
        urls.append(("🔍 Traqo", f"https://traqocontainer.com/track/bl/"
                     f"{bl_number}?carrier={code}"))
    # 3. track-trace
    urls.append(("🔍 track-trace", "https://www.track-trace.com/bol"))
    # 4. GoComet
    urls.append(("🔍 GoComet",
                 "https://www.gocomet.com/online-container-tracking"))
    return urls


def report_result(r):
    if "error" in r:
        print(f"    !! {r['error']}")
        return
    if r.get("deferred"):
        print(f"    -- {r.get('note','')}")
        return
    if not r.get("found"):
        print(f"    -- record nahi mila. {r.get('note','')}")
        return
    print("    >> RECORD MILA")
    for k in ["vessel", "voyage", "pol", "pod", "etd", "eta", "status",
              "destination", "speed", "nav_status", "position_time",
              "containerNumberStatus", "location"]:
        if k in r:
            label = {"nav_status": "NAV_STATUS",
                     "position_time": "POS_TIME"}.get(k, k.upper())
            print(f"    {label:8}: {r[k]}")
    if "raw_snippet" in r and len(r) <= 4:
        print(f"    Detail: {r['raw_snippet'][:300]}")


if __name__ == "__main__":
    main()
