# CargoTrack tray launcher (Windows) — Shezi, 31 Oct 2026
# Kaali window ki jagah system tray (ghari ke pas) mein chhota icon.
#  - Bat file is ko pythonw se chalati hai (koi window nahi).
#  - Icon par click = browser mein Application; right-click = menu
#    (Application kholo / Band karo).
#  - Dobara bat chalane par purani chalti copy pehle band hoti hai,
#    phir nayi us ki jagah leti hai (restart jaisa bartao).
#  - Band karna sirf tray menu se ya laptop restart se; browser ka
#    tab band karne se Application band NAHI hoti.
import os, socket, subprocess, sys, time

BASE = os.path.dirname(os.path.abspath(__file__))
PORT = 8765
URL = "http://127.0.0.1:%d" % PORT
LOCK = os.path.join(BASE, "tray.lock")
LOGF = os.path.join(BASE, "tray_error.log")


def _log(msg):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + str(msg) + "\n")
    except Exception:
        pass


def port_busy():
    s = socket.socket()
    s.settimeout(0.4)
    try:
        return s.connect_ex(("127.0.0.1", PORT)) == 0
    finally:
        s.close()


def _taskkill(pid):
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       capture_output=True, timeout=10)
    except Exception as e:
        _log("taskkill %s: %s" % (pid, e))


def kill_old():
    """Purani chalti copy (tray ho ya window wali) ko band karo."""
    if os.name == "nt":
        try:
            old = int(open(LOCK, encoding="utf-8").read().strip())
            if old != os.getpid():
                _taskkill(old)
        except Exception:
            pass
        try:
            out = subprocess.run(["netstat", "-ano", "-p", "TCP"],
                                 capture_output=True, text=True, timeout=10).stdout
            for line in out.splitlines():
                if (":%d" % PORT) in line and "LISTENING" in line:
                    pid = line.split()[-1]
                    if pid.isdigit() and int(pid) != os.getpid():
                        _taskkill(int(pid))
        except Exception as e:
            _log("netstat: %s" % e)
    else:
        try:
            import signal as _sig
            old = int(open(LOCK, encoding="utf-8").read().strip())
            if old != os.getpid():
                os.kill(old, _sig.SIGTERM)
        except Exception:
            pass
    for _ in range(40):
        if not port_busy():
            break
        time.sleep(0.25)


def start_server():
    py = sys.executable
    if os.name == "nt" and py.lower().endswith("python.exe"):
        pyw = py[:-len("python.exe")] + "pythonw.exe"
        if os.path.exists(pyw):
            py = pyw
    return subprocess.Popen([py, os.path.join(BASE, "server.py")],
                            cwd=BASE, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)


def wait_up():
    for _ in range(60):
        if port_busy():
            return True
        time.sleep(0.25)
    return False


# ---------------------------------------------------------------- tray (Win32)
def run_tray(proc):
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    shell32 = ctypes.windll.shell32
    kernel32 = ctypes.windll.kernel32
    # 64-bit Windows par handle wapas karne wale functions ka restype
    # lazmi c_void_p rakho — default c_int HWND ko kaat deta hai aur
    # tray icon khamoshi se banta hi nahi (1 Nov ki parakh mein pakra).
    for _f in (user32.CreateWindowExW, kernel32.GetModuleHandleW,
               user32.LoadImageW, user32.LoadIconW, user32.CreatePopupMenu):
        try:
            _f.restype = ctypes.c_void_p
        except Exception:
            pass
    try:
        user32.DefWindowProcW.restype = ctypes.c_longlong
    except Exception:
        pass
    # Menu wale functions ke argtypes bhi pakke karo: HMENU (pointer)
    # default int mein kate to AppendMenu ghalat menu mein likhta hai
    # aur right-click par khaali safed dabba khulta hai, text nahi
    # (1 Nov ko Yousuf ne pichle version mein yehi dekha tha).
    try:
        user32.CreatePopupMenu.argtypes = []
        user32.AppendMenuW.argtypes = [ctypes.c_void_p, wintypes.UINT,
                                       ctypes.c_size_t, wintypes.LPCWSTR]
        user32.AppendMenuW.restype = wintypes.BOOL
        user32.TrackPopupMenu.argtypes = [ctypes.c_void_p, wintypes.UINT,
                                          ctypes.c_int, ctypes.c_int,
                                          ctypes.c_int, wintypes.HWND,
                                          ctypes.c_void_p]
        user32.TrackPopupMenu.restype = wintypes.UINT
        shell32.Shell_NotifyIconW.argtypes = [wintypes.DWORD, ctypes.c_void_p]
        shell32.Shell_NotifyIconW.restype = wintypes.BOOL
    except Exception:
        pass

    WM_USER = 0x0400
    TRAY_MSG = WM_USER + 1
    WM_RBUTTONUP = 0x0205
    WM_LBUTTONDBLCLK = 0x0203
    WM_DESTROY = 0x0002
    NIM_ADD, NIM_DELETE, NIM_MODIFY = 0, 2, 1
    NIF_MESSAGE, NIF_ICON, NIF_TIP, NIF_INFO = 1, 2, 4, 16
    ID_OPEN, ID_QUIT = 1, 2

    class WNDCLASS(ctypes.Structure):
        _fields_ = [("style", wintypes.UINT), ("lpfnWndProc", ctypes.c_void_p),
                    ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                    ("hInstance", wintypes.HINSTANCE), ("hIcon", wintypes.HICON),
                    ("hCursor", wintypes.HANDLE), ("hbrBackground", wintypes.HANDLE),
                    ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR)]

    class NOTIFYICONDATA(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("hWnd", wintypes.HWND),
                    ("uID", wintypes.UINT), ("uFlags", wintypes.UINT),
                    ("uCallbackMessage", wintypes.UINT), ("hIcon", wintypes.HICON),
                    ("szTip", wintypes.WCHAR * 128), ("dwState", wintypes.DWORD),
                    ("dwStateMask", wintypes.DWORD), ("szInfo", wintypes.WCHAR * 256),
                    ("uTimeoutOrVersion", wintypes.UINT), ("szInfoTitle", wintypes.WCHAR * 64),
                    ("dwInfoFlags", wintypes.DWORD), ("guidItem", ctypes.c_byte * 16),
                    ("hBalloonIcon", wintypes.HICON)]

    WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_longlong, wintypes.HWND, wintypes.UINT,
                                 wintypes.WPARAM, wintypes.LPARAM)
    state = {"quit": False}

    def show_menu(hwnd):
        menu = user32.CreatePopupMenu()
        if not menu:
            _log("CreatePopupMenu failed")
            return
        if not user32.AppendMenuW(menu, 0, ID_OPEN, "Open Application"):
            _log("AppendMenu Open failed")
        if not user32.AppendMenuW(menu, 0, ID_QUIT, "Quit CargoTrack"):
            _log("AppendMenu Quit failed")
        pt = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        user32.SetForegroundWindow(hwnd)
        cmd = user32.TrackPopupMenu(menu, 0x0100 | 0x0002, pt.x, pt.y, 0, hwnd, None)
        user32.PostMessageW(hwnd, 0x0000, 0, 0)  # WM_NULL — menu sahi band honay ke liye lazmi
        user32.DestroyMenu(menu)
        if cmd == ID_OPEN:
            import webbrowser
            webbrowser.open(URL)
        elif cmd == ID_QUIT:
            user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE

    def wndproc(hwnd, msg, wparam, lparam):
        if msg == TRAY_MSG:
            if lparam == WM_RBUTTONUP:
                show_menu(hwnd)
            elif lparam == WM_LBUTTONDBLCLK:
                import webbrowser
                webbrowser.open(URL)
            return 0
        if msg == 0x0010 or msg == WM_DESTROY:  # WM_CLOSE / WM_DESTROY
            state["quit"] = True
            user32.PostQuitMessage(0)
            return 0
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    _log("run_tray: start")
    hinst = kernel32.GetModuleHandleW(None)
    _wndproc_ref = WNDPROC(wndproc)  # reference zinda rakhna lazmi hai
    wc = WNDCLASS()
    wc.lpfnWndProc = ctypes.cast(_wndproc_ref, ctypes.c_void_p)
    wc.hInstance = hinst
    wc.lpszClassName = "CargoTrackTrayWnd"
    if not user32.RegisterClassW(ctypes.byref(wc)):
        _log("RegisterClassW returned 0 (class pehle se ho sakti hai)")
    # Message-only window (parent = HWND_MESSAGE): tray app ke liye
    # yehi sahi tareeqa hai — 0x0 overlapped window kuch Windows
    # par chhoti safed khirki ban kar dikh jata tha (Yousuf ne
    # pichle version mein yehi dekha tha).
    hwnd = user32.CreateWindowExW(0, "CargoTrackTrayWnd", "CargoTrack", 0,
                                  0, 0, 0, 0, ctypes.c_void_p(-3), None,
                                  hinst, None)
    _log("CreateWindowExW -> %r" % (hwnd,))
    if not hwnd:
        _log("window nahi bana — tray band")
        return

    ico = None
    ico_path = os.path.join(BASE, "static", "favicon_zip.ico")
    if os.path.exists(ico_path):
        ico = user32.LoadImageW(None, ico_path, 1, 16, 16, 0x00000010)
    _log("LoadImageW(%s) -> %r" % (ico_path, ico))
    if not ico:
        try:
            user32.LoadIconW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
            user32.LoadIconW.restype = ctypes.c_void_p
        except Exception:
            pass
        ico = user32.LoadIconW(None, ctypes.cast(32512, ctypes.c_wchar_p))
        _log("LoadIconW fallback -> %r" % (ico,))

    nid = NOTIFYICONDATA()
    nid.cbSize = ctypes.sizeof(NOTIFYICONDATA)
    nid.hWnd = hwnd
    nid.uID = 1
    nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
    nid.uCallbackMessage = TRAY_MSG
    nid.hIcon = ico
    nid.szTip = "CargoTrack — running"
    if not shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid)):
        _log("Shell_NotifyIcon NIM_ADD failed — tray icon nahi bana")
    else:
        _log("tray icon add ho gaya — message loop shuru")
    # Shuru ki khabar (balloon)
    nid.uFlags = NIF_INFO
    nid.szInfoTitle = "CargoTrack"
    nid.szInfo = "CargoTrack is running. Double-click this icon to open the application."
    nid.dwInfoFlags = 1
    shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(nid))

    msg = wintypes.MSG()
    while not state["quit"]:
        r = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
        if r <= 0:
            break
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))

    shell32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(nid))
    user32.DestroyWindow(hwnd)


def main():
    try:
        kill_old()
        proc = start_server()
        try:
            with open(LOCK, "w", encoding="utf-8") as f:
                f.write(str(os.getpid()))
        except Exception:
            pass
        wait_up()
        if os.name == "nt":
            try:
                run_tray(proc)
            except Exception as e:
                _log("run_tray failed: %r — server chalata rakha hai" % e)
                try:
                    proc.wait()
                except Exception:
                    pass
            finally:
                try:
                    proc.terminate()
                    proc.wait(timeout=5)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass
        else:
            # Windows ke baghair (parakh): server ko aage rakh kar chalao
            import signal as _sig
            def _bye(*_a):
                try:
                    proc.terminate()
                except Exception:
                    pass
                raise SystemExit(0)
            _sig.signal(_sig.SIGTERM, _bye)
            try:
                proc.wait()
            except KeyboardInterrupt:
                proc.terminate()
        try:
            os.remove(LOCK)
        except Exception:
            pass
    except Exception as e:
        _log("main: %r" % e)
        raise


if __name__ == "__main__":
    main()
