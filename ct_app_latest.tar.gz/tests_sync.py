# -*- coding: utf-8 -*-
"""CargoTrack Stage B (Sync) — two-instance live tests.

Do real copies of the app (hub + joined) alag ports/homes par
chala kar HTTP par hi chalaye jate hain — bilkul asal copies
ki tarah. Chalane ka tareeqa:
    python3 tests_sync.py
Har test PASS/FAIL print hota hai; aakhir mein gin-ti.
"""
import json, os, shutil, signal, subprocess, sys, time
import urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import threading

SRC = os.path.dirname(os.path.abspath(__file__))
ROOT = "/tmp/synctest"
HUB_PORT, CLI_PORT, RELAY_PORT = 8891, 8892, 8893
SECRET = "SECRET_DO_NOT_SYNC_123"
ok = fail = 0


def chk(label, cond, extra=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"PASS {label} {extra}")
    else:
        fail += 1
        print(f"FAIL {label} {extra}")


def http(port, path, payload=None, headers=None, method=None):
    url = f"http://127.0.0.1:{port}{path}"
    data = None
    hd = {"Content-Type": "application/json"}
    if headers:
        hd.update(headers)
    if payload is not None:
        data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers=hd,
                                 method=method or ("POST" if data else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode())
        except Exception:
            return e.code, {}
    except Exception as e:
        return None, {"error": str(e)}


def hist_path(home):
    return os.path.join(home, "CargoTrack_Data", "history.json")


def read_hist(home):
    try:
        d = json.load(open(hist_path(home)))
        return d["history"] if isinstance(d, dict) else d
    except Exception:
        return []


def write_hist(home, hist):
    json.dump(hist, open(hist_path(home), "w"), ensure_ascii=False)


def by_q(hist):
    return {h.get("query"): h for h in hist if h.get("query")}


def settings_path(home):
    return os.path.join(home, "CargoTrack_Data", "settings.json")


def read_settings(home):
    try:
        return json.load(open(settings_path(home)))
    except Exception:
        return {}


def write_settings(home, s):
    os.makedirs(os.path.dirname(settings_path(home)), exist_ok=True)
    json.dump(s, open(settings_path(home), "w"), ensure_ascii=False)


def mkrec(q, status, **kw):
    r = {"query": q, "mode": "bl", "found": True, "carrier": "Test Line",
         "time": "30/10 10:00", "checked_ts": time.time(),
         "attempt_ts": time.time(), "first_seen": "2026-10-30",
         "checklist": {}, "notes": "", "changes": [], "changed": False,
         "returned": False, "starred": False, "photo": "", "client": "",
         "amount": "", "received": "", "layers": [],
         "result": {"status": status, "vessel": "TEST VESSEL",
                    "voyage": "E101", "eta": "30 Oct 2026",
                    "containers": []}}
    for k, v in kw.items():
        if k == "result":
            r["result"].update(v)
        else:
            r[k] = v
    return r


# ---------------- logging relay (T9) ----------------
CAPTURED = []


class Relay(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _fwd(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n) if n else b""
        CAPTURED.append(("REQ", self.command, self.path,
                         body.decode("utf-8", "replace")))
        req = urllib.request.Request(
            f"http://127.0.0.1:{HUB_PORT}{self.path}", data=body or None,
            headers={"Content-Type": "application/json",
                     "X-Sync-Token": self.headers.get("X-Sync-Token") or "",
                     "X-Sync-Client": self.headers.get("X-Sync-Client") or "",
                     "X-Sync-Label": self.headers.get("X-Sync-Label") or ""},
            method=self.command)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                out, code = r.read(), r.status
        except urllib.error.HTTPError as e:
            out, code = e.read(), e.code
        CAPTURED.append(("RESP", self.command, self.path,
                         out.decode("utf-8", "replace")))
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    do_GET = _fwd
    do_POST = _fwd


def main():
    shutil.rmtree(ROOT, ignore_errors=True)
    os.makedirs(ROOT)
    apps, homes, procs = {}, {}, []
    for name, port in (("hub", HUB_PORT), ("cli", CLI_PORT)):
        app = os.path.join(ROOT, name + "_app")
        shutil.copytree(SRC, app, ignore=shutil.ignore_patterns(
            "__pycache__", "tests_sync.py"))
        src_py = open(os.path.join(app, "server.py")).read()
        assert "\nPORT = 8765" in src_py
        open(os.path.join(app, "server.py"), "w").write(
            src_py.replace("\nPORT = 8765", f"\nPORT = {port}"))
        home = os.path.join(ROOT, name + "_home")
        os.makedirs(home)
        # pehle se fake secrets — T9 inhein payloads mein dhoondhe ga
        write_settings(home, {"groq_key": SECRET, "ai_key": SECRET,
                              "mail_pass": SECRET, "traqo_key": SECRET})
        apps[name], homes[name] = app, home
    relay = ThreadingHTTPServer(("127.0.0.1", RELAY_PORT), Relay)
    threading.Thread(target=relay.serve_forever, daemon=True).start()
    logs = {}
    for name in ("hub", "cli"):
        env = dict(os.environ, HOME=homes[name])
        lf = open(os.path.join(ROOT, name + ".log"), "w")
        logs[name] = lf
        p = subprocess.Popen([sys.executable, "server.py"],
                             cwd=apps[name], env=env,
                             stdout=lf, stderr=subprocess.STDOUT)
        procs.append(p)
    try:
        for name, port in (("hub", HUB_PORT), ("cli", CLI_PORT)):
            up = False
            for _ in range(60):
                code, _j = http(port, "/api/version")
                if code == 200:
                    up = True
                    break
                time.sleep(1)
            chk(f"{name} server up", up)
        HUB, CLI = homes["hub"], homes["cli"]
        seed_n = len(read_hist(HUB))
        print(f"seed records per copy: {seed_n}")
        chk("dono copies par seed barabar",
            seed_n == len(read_hist(CLI)) and seed_n > 50)

        # ---------- T7 setup: join se pehle ikhtilaf ----------
        hub_h, cli_h = read_hist(HUB), read_hist(CLI)
        qs = [h["query"] for h in hub_h]
        qa, qb, qc = qs[0], qs[1], qs[2]
        b_orig_status = by_q(hub_h)[qb]["result"]["status"]
        # hub se C ghayab, client se A ghayab
        write_hist(HUB, [h for h in hub_h if h["query"] != qc])
        cli_mod = []
        for h in cli_h:
            if h["query"] == qa:
                continue
            if h["query"] == qb:  # B client par peeche (stage kam)
                h = json.loads(json.dumps(h))
                h["result"]["status"] = "In transit — TEST VESSEL (E101)"
                h["result"].pop("discharge_time", None)
                h["result"].pop("gate_out", None)
            cli_mod.append(h)
        # T5 wala record dono par aik jaisa (discharged, rank 5)
        t5 = mkrec("SYNCBL000005", "Discharged at QICT",
                   result={"discharge_time": "20-OCT-2026 10:00",
                           "vir": "PKBQMQICT_201026100000",
                           "terminal": "QICT"})
        write_hist(CLI, cli_mod + [t5])
        hub_h2 = read_hist(HUB)
        write_hist(HUB, hub_h2 + [json.loads(json.dumps(t5))])

        # ---------- hub banao + join ----------
        code, j = http(HUB_PORT, "/api/sync/make-hub", {})
        token = j.get("token") or ""
        chk("make-hub token mila", code == 200 and len(token) >= 16)
        chk("hub settings mein sirf hash",
            bool(read_settings(HUB).get("sync_token_hash"))
            and token not in json.dumps(read_settings(HUB)))
        code, j = http(CLI_PORT, "/api/sync/set-client",
                       {"hub_url": f"http://127.0.0.1:{RELAY_PORT}",
                        "token": token})
        chk("set-client join kamyab", code == 200 and j.get("ok"),
            f"({j.get('message') or j.get('error') or ''})")

        # ---------- T7: union merge ----------
        hq, cq = by_q(read_hist(HUB)), by_q(read_hist(CLI))
        chk("T7 dono par A+B+C maujood",
            all(q in hq and q in cq for q in (qa, qb, qc)),
            f"(hub {len(hq)}, cli {len(cq)})")
        chk("T7 B ka jeetne wala (hub) dono par",
            hq[qb]["result"]["status"] == b_orig_status
            and cq[qb]["result"]["status"] == b_orig_status)
        chk("T7 gin-ti barabar", len(hq) == len(cq))

        # ---------- T1: joined -> hub ----------
        r1 = mkrec("SYNCBL000001", "In transit — TEST VESSEL (E101)")
        ch = read_hist(CLI)
        write_hist(CLI, ch + [r1])
        http(CLI_PORT, "/api/sync/now", {})
        hq = by_q(read_hist(HUB))
        chk("T1 record hub par aya",
            "SYNCBL000001" in hq
            and hq["SYNCBL000001"]["result"]["status"]
            == r1["result"]["status"]
            and hq["SYNCBL000001"]["result"]["vessel"] == "TEST VESSEL")

        # ---------- T2: hub -> joined ----------
        r2 = mkrec("SYNCBL000002", "In transit — TEST VESSEL (E101)")
        hh = read_hist(HUB)
        write_hist(HUB, hh + [r2])
        http(CLI_PORT, "/api/sync/now", {})
        cq = by_q(read_hist(CLI))
        chk("T2 record joined par aya", "SYNCBL000002" in cq)

        # ---------- T3: delete + no resurrection ----------
        code, _j = http(CLI_PORT, "/api/history/delete",
                        {"query": "SYNCBL000001"})
        chk("T3 delete route ok", code == 200)
        http(CLI_PORT, "/api/sync/now", {})
        http(HUB_PORT, "/api/sync/now", {})
        http(CLI_PORT, "/api/sync/now", {})
        time.sleep(1)
        chk("T3 hub se bhi ghayab",
            "SYNCBL000001" not in by_q(read_hist(HUB)))
        chk("T3 dobara zinda nahi",
            "SYNCBL000001" not in by_q(read_hist(CLI)))

        # ---------- T4: offline edits ----------
        s = read_settings(CLI)
        good_url = s.get("sync_hub_url")
        s["sync_hub_url"] = "http://127.0.0.1:9999"
        write_settings(CLI, s)
        ch = read_hist(CLI)
        ch = ch + [mkrec("SYNCBL000004", "In transit — TEST VESSEL")]
        for h in ch:
            if h["query"] == qa:
                h["notes"] = "offline-note-xyz"
        write_hist(CLI, ch)
        code, j = http(CLI_PORT, "/api/sync/now", {})
        msg = ((j.get("sync") or {}).get("sync_last_msg") or "")
        chk("T4 offline par khamosh status", "offline" in msg.lower(),
            f"({msg})")
        s = read_settings(CLI)
        s["sync_hub_url"] = good_url
        write_settings(CLI, s)
        http(CLI_PORT, "/api/sync/now", {})
        hq = by_q(read_hist(HUB))
        chk("T4 offline record hub par pohch gaya",
            "SYNCBL000004" in hq)
        chk("T4 offline note bhi pohch gaya",
            hq.get(qa, {}).get("notes") == "offline-note-xyz")
        allq = [h["query"] for h in read_hist(HUB)]
        chk("T4 duplicate nahi bane", len(allq) == len(set(allq)))

        # ---------- T5: stage guard ----------
        hh = read_hist(HUB)
        for h in hh:
            if h["query"] == "SYNCBL000005":
                h["result"]["status"] = "Released — Delivered"
                h["result"]["gate_out"] = "25-OCT-2026 10:00"
        write_hist(HUB, hh)
        http(HUB_PORT, "/api/sync/now", {})   # hub stamp pass (naya ts)
        ch = read_hist(CLI)  # client par purana Discharged + naya edit
        for h in ch:
            if h["query"] == "SYNCBL000005":
                h["notes"] = "client-side edit"
        write_hist(CLI, ch)
        http(CLI_PORT, "/api/sync/now", {})
        hq, cq = by_q(read_hist(HUB)), by_q(read_hist(CLI))
        chk("T5 purana Discharged jeet nahi saka (hub)",
            "Delivered" in hq["SYNCBL000005"]["result"]["status"])
        chk("T5 purana Discharged jeet nahi saka (client)",
            "Delivered" in cq["SYNCBL000005"]["result"]["status"])
        # nayi durusti: returned (stage 8) client se
        ch = read_hist(CLI)
        for h in ch:
            if h["query"] == "SYNCBL000005":
                h["returned"] = True
        write_hist(CLI, ch)
        http(CLI_PORT, "/api/sync/now", {})
        hq = by_q(read_hist(HUB))
        chk("T5 nayi correction (returned) hub par",
            hq["SYNCBL000005"].get("returned") is True)

        # ---------- T6: profile sync ----------
        png = ("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUl"
               "EQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
        http(CLI_PORT, "/api/settings",
             {"profile_name": "Sync Test Name"})
        http(CLI_PORT, "/api/profile/photo",
             {"data": "data:image/png;base64," + png})
        http(CLI_PORT, "/api/sync/now", {})
        hs = read_settings(HUB)
        photo_f = os.path.join(HUB, "CargoTrack_Data",
                               "profile_photo.png")
        chk("T6 profile naam hub par",
            hs.get("profile_name") == "Sync Test Name")
        import base64
        chk("T6 profile photo hub par (wahi bytes)",
            os.path.exists(photo_f)
            and open(photo_f, "rb").read() == base64.b64decode(png))

        # ---------- T8: wrong token ----------
        code, _j = http(HUB_PORT, "/api/sync/push",
                        {"records": [], "tombstones": []},
                        headers={"X-Sync-Token": "wrong-token-xyz"})
        chk("T8 ghalat token push = 401", code == 401)
        code, _j = http(HUB_PORT, "/api/sync/pull?since=0", None,
                        headers={"X-Sync-Token": "wrong-token-xyz"},
                        method="GET")
        chk("T8 ghalat token pull = 401", code == 401)
        code, _j = http(HUB_PORT, "/api/sync/pull?since=0", None,
                        method="GET")
        chk("T8 baghair token = 401", code == 401)
        chk("T8 data hila nahi (gin-ti wahi)",
            len(read_hist(HUB)) == len(by_q(read_hist(HUB))))

        # ---------- T9: payload inspection ----------
        blob = "\n".join(c[3] for c in CAPTURED)
        chk("T9 relay ne sync traffic dekha", len(CAPTURED) >= 6,
            f"({len(CAPTURED)} messages)")
        chk("T9 kisi payload mein secret nahi", SECRET not in blob)
        chk("T9 sync_token_hash bhi leak nahi",
            str(read_settings(HUB).get("sync_token_hash")) not in blob)
    finally:
        for p in procs:
            try:
                p.send_signal(signal.SIGTERM)
            except Exception:
                pass
        for p in procs:
            try:
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        relay.shutdown()
    print(f"\nMAJMUA: {ok} PASS, {fail} FAIL")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
