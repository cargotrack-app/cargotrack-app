CargoTrack v65 — Shipment Tracking (Karachi terminals + major carriers)
====================================================
HOW TO RUN
1. Extract this ZIP into a NEW folder (delete the old version's folder).
2. Double-click "CargoTrack-v48.bat".
3. Keep the black console window open — the app runs inside it.
   Your browser opens automatically. If it does not, open:
   http://127.0.0.1:8765
4. Your shipments, photos and settings live OUTSIDE the app folder
   (in CargoTrack_Data next to your user folder), so upgrading to a
   new version never touches them.

ON YOUR PHONE
Put the phone and laptop on the same WiFi, then open the
"Phone" address printed in the console window (http://192.168.x.x:8765).

WHAT'S NEW IN v47 — fixes you asked for:
- WhatsApp and Delete buttons in the result now really work:
  WhatsApp opens with the shipment text ready (and copies it too);
  Delete asks in the app's own window, then removes the entry.
- Theme Studio rebuilt: only 6 presets, each completely different —
  Royal, Ocean, Emerald, Crimson, Midnight (a real dark theme) and
  Royal Gold. Animations are now a style: Off, Fade, Slide, Bounce,
  Glow. Buttons Square and Headings Plain now visibly work, and the
  Single colour choice is remembered after a restart.
- Heading bars everywhere are easy to read: solid text on the bar,
  no faint gradient letters (Logs, Dashboard, Recent — all fixed).
- Assistant: asking for a BL's status now gives a short text answer
  only — the big image card and the PDF report are made ONLY when
  you ask for them ("make an image", "make a PDF report"). When
  made, the card shows small and clean with a Download button.
- Assistant: new "Chat download" button saves the whole chat as a
  text file; every answer has a small Copy button; and when the AI
  is off you will see a clear notice instead of silent basic answers.
- Logos: BL rows now recognise the line from the number itself —
  Wan Hai, Yang Ming and Maersk numbers that showed a blank badge
  now show their real logos, and KMTC / BAL Container Line show
  their names with a proper badge.

WHAT'S NEW IN v46 — your 11 points:
- Top logo fixed: the stray mark beside the logo is gone.
- Photo scanning rebuilt: a pasted or picked photo is now read with
  a document-aware scanner — container numbers are verified by their
  ISO check digit (common OCR letter/digit mix-ups are repaired),
  seal numbers are recognised as seals and never mistaken for a BL,
  and one photo can queue several BL numbers at once (the first goes
  to the search box, the rest to the batch box). If the first read
  finds nothing, a second gentler read is tried automatically.
- Tracking progress now names its sources: every layer shows a
  "source" link to the site it was checked on, the running layer
  spins while it works, and finished layers show what they found.
- Bell redesigned: a clean round button with a proper count badge;
  alert text is lighter and easier to read.
- Carrier logos: result headers show the line's logo — and when the
  carrier is unknown, the terminal's logo instead of a blank badge.
  Emkay results carry a "Track on ShipsGo" button (1 credit for a
  new BL on ShipsGo; re-checks there are free).
- Clients section removed entirely, as ordered.
- Watch merged into the Dashboard, which also gained an
  "at a glance" strip: on-hold, arriving within 7 days, quiet for
  2+ days, and not-found counts.
- AI Assistant redesigned from scratch: a full-screen chat (the
  side column hides while you chat), conversation only, a Clear
  button, PDF and photo attachments that really send (paste a photo
  straight into the chat), and a multi-line message box —
  Enter sends, Shift+Enter starts a new line. Its BL answers are
  short and chat-like now, and it can still make shipment images
  and PDF reports when you ask.
- Theme Studio is slimmer and is now a builder: pick your own
  Primary + Secondary colours (or a single colour), with options
  for animations, button shape and heading style — applied
  instantly and remembered.
- New clock designs: Flip (HTC-style black cards), Digital and
  Pill, next to Classic / Boxed / Minimal.
- A full self-audit was also done: 24 extra issues found and fixed
  (including a history file that could be wiped by a crash during
  saving, a backup that leaked the AI key — now stripped — and
  several wrong-result and hang bugs).
