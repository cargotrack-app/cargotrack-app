# -*- coding: utf-8 -*-
"""v80 build: base = build_v79. 'Samajh wala version' — us ki
list (26 Oct raat, screenshots ke saboot ke sath):
1) LIVE WEB SEARCH: aam/live sawal par server DuckDuckGo se
asal results la kar AI ko deta hai; AI unhi se jawab dega,
source ke sath (KFC number wali ghalti ka ilaj).
2) AI ko AAJ KI TAREEKH har prompt mein (Ramzan Feb-2025
wali ghalti ka ilaj) + app ki asal salahiyaton ki pakki
list (PDF se inkaar wali ghalti ka ilaj).
3) SAWAL vs HUKM: 'Pdf bana sakte ho' par file nahi banegi —
pehle capability ka jawab; media block mosam wale sawal ko
hijack nahi karega (Quetta case); list-cue sakht.
4) KISI BHI MOZUA KI FILE: shipment se bahar ke mozua par
bhi asal file (PDF print-page / TXT download) — AI content
likhega, app asal button degi (naya 'textfile' action).
5) Weather DETAIL: guzra kal + aaj + ane wala kal (past_days
API se) jab sawal mein detail/guzra kal ho."""
import shutil, re, sys
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

SRC = Path.home() / "workspace" / "build_v79"
DST = Path.home() / "workspace" / "build_v80"
if DST.exists():
    shutil.rmtree(DST)
shutil.copytree(SRC, DST, ignore=shutil.ignore_patterns("__pycache__"))

STAMP = datetime.now(ZoneInfo("Asia/Karachi")).strftime("%d %b %Y, %-I:%M %p PKT")
print("build stamp:", STAMP)

SP = DST / "server.py"
HP = DST / "static" / "index.html"
fails = []

def patch(path, old, new, count=1):
    t = path.read_text(encoding="utf-8")
    n = t.count(old)
    if n != count:
        fails.append(f"{path.name}: {count}x chahiye, {n}x mila: {old[:60]!r}")
        return
    path.write_text(t.replace(old, new), encoding="utf-8")

def insert_before(path, marker, block):
    t = path.read_text(encoding="utf-8")
    if t.count(marker) != 1:
        fails.append(f"insert marker masla: {marker[:50]!r}")
        return
    path.write_text(t.replace(marker, block + marker), encoding="utf-8")

patch(SP, "APP_VERSION = 79", "APP_VERSION = 80")

# ============ helpers (gemini_body se pehle) ============
HELPERS = '''# ================= v80: tareekh, web search, file =================

def _today_line():
    from datetime import timedelta, timezone
    now = datetime.now(timezone(timedelta(hours=5)))
    return ("\\nTODAY'S DATE: " + now.strftime("%A %d %B %Y")
            + " (Pakistan time). Use THIS date for every "
            "date-relative question (next Ramzan, kal, "
            "deadlines) — never answer dates from old memory. "
            "APP FILES: this app creates REAL downloadable "
            "files — PDF, Excel (CSV) and Text — for a "
            "shipment, for lists, and on ANY other topic the "
            "user names; the app attaches the real file "
            "button itself. If he ASKS whether you can make "
            "a file or PDF, say YES and ask the topic — never "
            "claim you cannot make files. WEB ACCESS: when "
            "WEB RESULTS are given with the question, answer "
            "current facts FROM them and name the source; "
            "if they do not cover the question, say so "
            "plainly instead of guessing. If he asks a "
            "question, ANSWER it — only DO something when "
            "he asks you to do it.\\n")


def _wx_hit(q):
    ql = " " + (q or "").lower() + " "
    return bool(any(w in ql for w in
                    ("mosam", "mausam", "garmi", "barish",
                     "baarish", "sardi", "dhund"))
                or _kw_match(ql, words=("weather", "rain",
                                        "fog")))


def _is_capability_q(q):
    ql = " " + (q or "").lower() + " "
    return any(s in ql for s in
               ("sakte ho", "sakta hai", "sakti hai",
                "sakte hain", "can you", "kya tum", "kia tum",
                "kya aap", "ho sakta", "mumkin hai",
                "possible hai"))


def _generic_file_req(q, local_q=None):
    """Shipment se bahar ke mozua ki file ki saaf khwahish —
    (format, mozua) ya None. Sawaal ('bana sakte ho?') par
    None — poochne par file nahi banti."""
    if not _media_ask(q) or _is_capability_q(q):
        return None
    if _find_mentioned_entry(local_q or q):
        return None
    ql = " " + (q or "").lower() + " "
    if any(s in ql for s in ("shipment", "arriving", "arrivals",
                             " list ", "sab ki", "in sab")):
        return None
    fmt = ("txt" if (_kw_match(ql, words=("txt",))
                     or "text file" in ql) else "pdf")
    topic = ql
    for w in ("text file", "pdf", "file", "txt"):
        topic = topic.replace(" " + w + " ", " ")
    topic = " ".join(topic.split()).strip()
    tails = ("bana do", "de do", "banao", "banana", "bana",
             "chahiye", "download", "do", "de", "par", "mein",
             "report")
    changed = True
    while changed:
        changed = False
        for tword in tails:
            if topic.endswith(" " + tword):
                topic = topic[: -len(tword)].strip()
                changed = True
        if topic in tails:
            topic = ""
    for lead in ("ek", "mujhe", "mujhy", "please", "plz"):
        if topic.startswith(lead + " "):
            topic = topic[len(lead):].strip()
    topic = topic.strip(" ?.")
    if len(topic) < 3:
        return None
    return fmt, topic


def _web_search(q, hist=None):
    """Live internet talash (DuckDuckGo — muft, baghair key)
    taake AI asal results se jawab de, yaad se nahi.
    Na mile to khali string."""
    import urllib.request as _u, urllib.parse as _up
    import html as _html
    ql = " " + (q or "").lower() + " "
    skip = ("tum kon", "tumhara naam", "your name", "shukriya",
            "thank", "tum sunao", "apne bare", "kaise ho",
            "kese ho", "acha laga", "theek ho", "zinda ho")
    if any(s in ql for s in skip):
        return ""
    query = (q or "").strip()
    words = query.split()
    if len(words) <= 4 and hist:
        for t in reversed(hist):
            if (t or {}).get("role") == "user" \\
                    and (t.get("text") or "").strip():
                query = (t["text"].strip() + " " + query)[:200]
                break
    _hdr = {"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; "
                           "Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/126.0 "
                           "Safari/537.36"),
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9"}

    def _fetch(u):
        req = _u.Request(u, headers=_hdr)
        with _u.urlopen(req, timeout=7) as r:
            return r.read().decode("utf-8", "replace")

    def _ddg():
        page = _fetch("https://lite.duckduckgo.com/lite/?q="
                      + _up.quote_plus(query))
        got = []
        for m in re.finditer(
                r"<a[^>]*class='result-link'[^>]*>(.*?)</a>",
                page, re.S):
            tag = m.group(0)
            hm = re.search(r'href="([^"]+)"', tag)
            href = hm.group(1) if hm else ""
            title = _html.unescape(
                re.sub(r"<[^>]+>", "", m.group(1))).strip()
            rest = page[m.end():m.end() + 3000]
            sm = re.search(
                r"class='result-snippet'[^>]*>(.*?)</td>",
                rest, re.S)
            snip = (_html.unescape(re.sub(r"<[^>]+>", "",
                                          sm.group(1))).strip()
                    if sm else "")
            dom = ""
            um = re.search(r"uddg=([^&]+)", href)
            if um:
                dom = _up.urlparse(_up.unquote(um.group(1))).netloc
            elif href.startswith("http"):
                dom = _up.urlparse(href).netloc
            if title:
                got.append(f"- {title} ({dom})\\n  {snip}")
            if len(got) >= 8:
                break
        return got

    def _bing():
        page = _fetch("https://www.bing.com/search?q="
                      + _up.quote_plus(query))
        got = []
        for m in re.finditer(r'<li class="b_algo".*?</li>',
                             page, re.S):
            blk = m.group(0)
            am = re.search(
                r'<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                blk, re.S)
            if not am:
                continue
            title = _html.unescape(
                re.sub(r"<[^>]+>", "", am.group(2))).strip()
            pm = re.search(r"<p[^>]*>(.*?)</p>", blk, re.S)
            snip = (_html.unescape(re.sub(r"<[^>]+>", "",
                                          pm.group(1))).strip()
                    if pm else "")
            dom = _up.urlparse(am.group(1)).netloc
            if title:
                got.append(f"- {title} ({dom})\\n  {snip}")
            if len(got) >= 8:
                break
        return got

    import time as _time
    out = []
    for _att, _fn in enumerate((_ddg, _ddg, _bing)):
        if _att:
            _time.sleep(1.0)
        try:
            out = _fn()
        except Exception:
            out = []
        if out:
            break
    if not out:
        return ""
    return ("\\n\\nWEB RESULTS (live internet se aaj ki talash "
            "— jawab inhi ki bunyad par do, source ka naam "
            "lo):\\n" + "\\n".join(out))[:4500]


def _wx_detail_block(w):
    lines = [f"{w['name']} ka mosam — detail report:"]
    yest = w.get("yest") or (None, None, None)
    if yest[0] is not None and yest[1] is not None:
        desc = _WX_CODES.get(yest[2], "")
        lines.append(
            f"Guzra kal: zyada se zyada {yest[0]:.0f}°C, "
            f"kam se kam {yest[1]:.0f}°C"
            + (f" — {desc}" if desc else ""))
    lines.append(_wx_block(w, False))
    if w["max"][1] is not None and w["min"][1] is not None:
        s = (f"Ane wala kal: zyada se zyada {w['max'][1]:.0f}°C, "
             f"kam se kam {w['min'][1]:.0f}°C")
        if w["pop"][1] is not None:
            s += f"; barish ka chance {w['pop'][1]:.0f}%"
        lines.append(s)
    return "\\n".join(lines)


def _wx_detail_asked(ql):
    return any(k in ql for k in
               ("guzra", "guzre", "guzri", "yesterday", "pichla",
                "peechla", "beeta", "detail", "tafseel",
                "teen din", "3 din", "three days",
                "poori report"))


'''
insert_before(SP, "def _gemini_body(", HELPERS)

# ============ prompt: tareekh + salahiyatein (2 jagah) ============
patch(SP, "automatically.\\n\\nLIVE APP DATA:\\n\"",
      "automatically.\" + _today_line() + \"\\n\\nLIVE APP DATA:\\n\"",
      count=2)

# ============ weather: trigger helper + yesterday ============
patch(SP, '''    ql = " " + (q or "").lower() + " "
    if not (any(w in ql for w in
                ("mosam", "mausam", "garmi", "barish", "baarish",
                 "sardi", "dhund"))
            or _kw_match(ql, words=("weather", "rain", "fog"))):
        return None''',
'''    ql = " " + (q or "").lower() + " "
    if not _wx_hit(q):
        return None''')
patch(SP, '''                   "timezone": tz, "forecast_days": 3}))''',
'''                   "timezone": tz, "forecast_days": 3,
                   "past_days": 1}))''')
patch(SP, '''           + _up.urlencode({"name": city, "count": 1,
                            "language": "en", "format": "json"}))
    with _u.urlopen(url, timeout=6) as r:
        g = _j.loads(r.read().decode("utf-8", "replace"))
    res = (g.get("results") or [None])[0]''',
'''           + _up.urlencode({"name": city, "count": 6,
                            "language": "en", "format": "json"}))
    with _u.urlopen(url, timeout=6) as r:
        g = _j.loads(r.read().decode("utf-8", "replace"))
    _res = g.get("results") or []
    res = (next((x for x in _res
                 if x.get("country_code") == "PK"), None)
           or next((x for x in _res
                    if (x.get("name") or "").lower() == key),
                   None))''')
patch(SP, '''                   "daily": ("temperature_2m_max,"
                             "temperature_2m_min,"
                             "precipitation_probability_max"),''',
'''                   "daily": ("temperature_2m_max,"
                             "temperature_2m_min,weather_code,"
                             "precipitation_probability_max"),''')
patch(SP, '''            "max": [_at(day.get("temperature_2m_max"), 0),
                    _at(day.get("temperature_2m_max"), 1)],
            "min": [_at(day.get("temperature_2m_min"), 0),
                    _at(day.get("temperature_2m_min"), 1)],
            "pop": [_at(day.get("precipitation_probability_max"), 0),
                    _at(day.get("precipitation_probability_max"), 1)]}''',
'''            "max": [_at(day.get("temperature_2m_max"), 1),
                    _at(day.get("temperature_2m_max"), 2)],
            "min": [_at(day.get("temperature_2m_min"), 1),
                    _at(day.get("temperature_2m_min"), 2)],
            "pop": [_at(day.get("precipitation_probability_max"), 1),
                    _at(day.get("precipitation_probability_max"), 2)],
            "yest": (_at(day.get("temperature_2m_max"), 0),
                     _at(day.get("temperature_2m_min"), 0),
                     _at(day.get("weather_code"), 0))}''')
patch(SP, '''    blocks = []
    multi = len(cities) > 1
    for c in cities[:4]:
        w = _wx_fetch(c)
        if w:
            blocks.append(_wx_line(w, kal) if multi
                          else _wx_block(w, kal))''',
'''    blocks = []
    multi = len(cities) > 1
    for c in cities[:4]:
        w = _wx_fetch(c)
        if w:
            if multi:
                blocks.append(_wx_line(w, kal))
            elif _wx_detail_asked(ql):
                blocks.append(_wx_detail_block(w))
            else:
                blocks.append(_wx_block(w, kal))''')

patch(SP, '''"mardan", "abbottabad",''',
'''"mardan", "swat", "abbottabad",''')

# ---- weather probe guard: har lafz sheher nahi hota ----
patch(SP, '''        probed = 0
        for tok in re.findall(r"[a-z]{3,}", ql):
            if probed >= 2:
                break
            if tok in stop2:
                continue
            probed += 1''',
'''        probed = 0
        _words80 = ql.split()
        for tok in re.findall(r"[a-z]{3,}", ql):
            if probed >= 2:
                break
            if tok in stop2:
                continue
            _i80 = (_words80.index(tok) if tok in _words80
                    else -1)
            _nxt = (_words80[_i80 + 1]
                    if 0 <= _i80 < len(_words80) - 1 else "")
            _nx2 = (_words80[_i80 + 2]
                    if 0 <= _i80 < len(_words80) - 2 else "")
            _prv = _words80[_i80 - 1] if _i80 > 0 else ""
            _cityctx = ((_nxt in ("ka", "ki")
                         and _nx2 in ("mosam", "mausam",
                                      "weather", "haal", "hal"))
                        or (_prv == "aur"
                            and _nxt in ("ka", "ki", "ke",
                                         "mein", "me")))
            if not _cityctx:
                continue
            probed += 1''')

# ============ capability guard + media block sakhti ============
patch(SP, '''    acts = _media_intent_actions(q, local_q, hist)''',
'''    if not attach and _media_ask(q) and _is_capability_q(q):
        return {"answer": "Haan — mein asal file bana sakta "
                "hoon: PDF, Excel (CSV) aur Text file — kisi "
                "ek shipment ki, shipments ki list ki, ya kisi "
                "bhi doosre mozua ki. Banani ho to mozua bata "
                "kar 'bana do' kahein; mein content tayyar "
                "karke asal file ka button de dunga.",
                "actions": [], "mode": "local"}
    acts = _media_intent_actions(q, local_q, hist)''')
patch(SP, '''    if _media_ask(q) and not acts and not attach:
        ql59 = (q or "").lower()
        prev_list = False
        for t59 in reversed(hist or []):
            if (t59 or {}).get("role") == "model":
                _pt = (t59.get("text") or "")
                prev_list = ("shipment(s)" in _pt or "Arriving" in _pt)
                break
        list_cue = any(w in ql59 for w in
                       ("list", "tamaam", "aane wal", "vessel",
                        "shipment", "detail", "in sab", "sab ki"))''',
'''    if (_media_ask(q) and not acts and not attach
            and not _wx_hit(q)
            and not _generic_file_req(q, local_q)):
        ql59 = (q or "").lower()
        prev_list = False
        if len((q or "").split()) <= 5:
            for t59 in reversed(hist or []):
                if (t59 or {}).get("role") == "model":
                    _pt = (t59.get("text") or "")
                    prev_list = ("shipment(s)" in _pt
                                 or "Arriving" in _pt)
                    break
        list_cue = any(w in ql59 for w in
                       ("list", "tamaam", "aane wal", "shipment",
                        "arriving", "arrivals", "in sab", "sab ki"))''')

# ============ AI race: web results + generic file ============
patch(SP, '''    key = _ai_key_single()
    gk = _groq_key()
    if key or gk:''',
'''    key = _ai_key_single()
    gk = _groq_key()
    want_file = None if attach else _generic_file_req(q, local_q)
    if key or gk:''')
patch(SP, '''        _t0 = time.time()
        try:
            txt = _ai_answer_any(q, hist, gk, key, extra)
        except Exception:
            txt = None''',
'''        _t0 = time.time()
        extra2 = (extra or "") + _web_search(q, hist)
        if want_file:
            extra2 += ("\\n\\nFILE REQUEST: the user wants a "
                       "downloadable file on the topic '"
                       + want_file[1] + "'. Write the COMPLETE "
                       "file content as your reply: first line "
                       "the title, then the full, well-organized "
                       "content. The app attaches the real "
                       "download button under your reply.")
        try:
            txt = _ai_answer_any(q, hist, gk, key, extra2)
        except Exception:
            txt = None''')
patch(SP, '''        if txt:
            return {"answer": txt, "actions": acts, "mode": "ai",''',
'''        if txt:
            _acts80 = acts
            if want_file:
                _f80, _t80 = want_file
                _acts80 = acts + [{
                    "label": (("📄 PDF — " if _f80 == "pdf"
                               else "📝 Text file — ")
                              + _t80.title()[:44]),
                    "act": "textfile", "fmt": _f80,
                    "title": _t80.title(), "text": txt}]
            return {"answer": txt, "actions": _acts80,
                    "mode": "ai",''')

# ============ frontend: textfile action ============
patch(HP, '''      else if (a.act === "copyq") {''',
'''      else if (a.act === "textfile") {
        const e80 = v => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;");
        if (a.fmt === "txt") {
          dl59(new Blob([(a.title || "File") + "\\n\\n" + (a.text || "")], {type: "text/plain"}), (a.title || "file").replace(/[^\\w\\- ]+/g, "").trim().replace(/\\s+/g, "-") + ".txt");
        } else {
          const w = window.open("", "_blank");
          const paras = (a.text || "").split(/\\n+/).map(p => "<p>" + e80(p) + "</p>").join("");
          w.document.write("<!doctype html><html><head><meta charset='utf-8'><title>" + e80(a.title || "File") + "</title><style>body{font-family:Segoe UI,Arial;margin:32px;line-height:1.55}h2{margin-bottom:14px}p{margin:7px 0}</style></head><body><h2>" + e80(a.title || "File") + "</h2>" + paras + "</body></html>");
          w.document.close(); w.focus(); setTimeout(() => w.print(), 350);
        }
      }
      else if (a.act === "copyq") {''')

patch(HP, "<title>CargoTrack v79 — Shipment Tracking</title>",
          "<title>CargoTrack v80 — Shipment Tracking</title>")
t = HP.read_text(encoding="utf-8")
t2, n = re.subn(r'(<div id="verLine" class="verline">)CargoTrack v79 · [^<]*',
                r'\g<1>CargoTrack v80 · ' + STAMP, t)
if n != 1:
    fails.append(f"index.html verLine: 1x chahiye, {n}x mila")
else:
    HP.write_text(t2, encoding="utf-8")
patch(HP, "const APPV = 79;", "const APPV = 80;")

(DST / "VERSION").write_text("80\n", encoding="utf-8")
bat = DST / "CargoTrack-v79.bat"
bat.write_text(bat.read_text(encoding="utf-8").replace("v79", "v80"), encoding="utf-8")
bat.rename(DST / "CargoTrack-v80.bat")
rm = DST / "README.txt"
rm.write_text(rm.read_text(encoding="utf-8").replace("v79", "v80"), encoding="utf-8")

if fails:
    print("NAKAM:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("tamam patches lag gaye ✓  ->", DST)
