/* CargoTrack service worker — install ke liye zaroori.
   Usool: data hamesha LIVE network se; cache sirf tab kaam
   aata hai jab network na mile, aur /api ko kabhi cache nahi
   karta. Har version par cache ka naam badal jata hai taake
   purana shell khud saaf ho jaye. */
const CACHE = "ct-shell-v118";
const SHELL = ["/", "/manifest.webmanifest", "/icon-192.png",
               "/icon-512.png", "/logos/ct-logo.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL))
    .then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys()
    .then((ks) => Promise.all(ks.filter((k) => k !== CACHE)
      .map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener("fetch", (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET"
      || u.pathname.startsWith("/api/")
      || u.pathname.startsWith("/profile")) return;
  e.respondWith(fetch(e.request).then((r) => {
    const cp = r.clone();
    caches.open(CACHE).then((c) => c.put(e.request, cp));
    return r;
  }).catch(() => caches.match(e.request, { ignoreSearch: true })));
});
