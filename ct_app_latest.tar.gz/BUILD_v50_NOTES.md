# CargoTrack v50 — Build Notes (Items 4–14, on top of verified v49)

Built 24 Oct 2026 from `build_v49/` (copy; v48/v49 untouched). Version bumped
everywhere: server docstring + startup print, `APP_VERSION = 50`, `/api/ping`
returns `{"v": 50}`, page `<title>`, `const APPV = 50`, `VERSION` file = 50,
`CargoTrack-v50.bat`, README first line. Leftover `AUDIT_findings.md` removed.
`seed_history.json` intact (78 entries) — all test runs used a separate copy
with a temp HOME; build_v50 itself was never executed.

## Item 4 — Copy results (dead button) — FIXED
Root cause: the app is served over plain HTTP on a LAN IP, which is NOT a
secure context, so `navigator.clipboard` is undefined and every
`navigator.clipboard.writeText(...)` threw and died silently.
Fix: `_copyRaw()` helper (async Clipboard API when available, otherwise a
hidden-textarea `execCommand('copy')` fallback) + `copyText()` wrapper that
always shows a "Copied ✓" toast. Applied to ALL copy sites: result Copy
results, Assistant answer copy, Assistant copyq action, WhatsApp share,
MSC-open copy, morning-report copy.

## Item 5 — Terminal check — REDESIGNED
The old modal (3 generic home-page links) is replaced by `openTermMenu(ctx)`:
a compact list-style menu (max-width 430px) built per record:
- The record's ACTUAL terminal only (KICT / SAPT / QICT from `result.terminal`,
  never combined). Terminal portals are form/session based — no deep link
  exists — so the row opens the official enquiry page in a NORMAL tab
  (`window.open(url, "_blank")`, no feature strings), copies the number first,
  and toasts "Number copied — paste it on the … site".
- Carrier row with a true deep link where one verifies (COSCO record page,
  ShipsGo for Emkay), otherwise the carrier's official tracking page + copy.
- track-trace + Traqo rows (home page + copy; see verification below).
- Vessel live-map row when a vessel is known.
All links are plain `target=_blank` anchors/buttons — no oversized popups.

## Item 6 — Documents / Notes / Client / Amount / Received — KEPT, COLLAPSED
All functionality preserved (same ids, same `/api/history/update` endpoints,
saved values load/save as before) but wrapped in one `<details class="docsec">`
"📎 Documents & client details", closed by default, with a "● saved" marker
when the record already has entries.

## Item 7 — Tracking progress panel — REBUILT
(a) Every "source ↗" link now comes from `layerLink()` using the current job's
query and the found record: COSCO deep link, ShipsGo deep link (Emkay),
VesselFinder record URL (`vf_url`) or vessel search, terminal enquiry page for
the ACTUAL terminal named by the layer detail/result, official carrier page
for direct-API layers. Form-based sources carry `data-copyq` — the click
copies the number and toasts. Unknown-terminal rows open the Item 5 menu.
(b) New progress header: gradient progress bar with %, "x of y sources
checked" / final "All N sources checked — M found a record", elapsed seconds,
and per-row state pills: spinner + "Searching", "✓ Found" (green),
"✗ Not found" (grey), "⚠ Error" (amber, when the layer detail reports an
error/timeout). Layers re-render once at job end so links use the found record.

## Item 8 — Result detail card — ALL 9 AUDIT POINTS
1. Status contradiction fixed: the badge no longer gets an extra "✓ " prefix
   (the old double ✓), and when the source status text is short the badge
   shows that EXACT text (e.g. "Partially discharged") — one status everywhere.
2. Dates relabelled with meanings: "Vessel arrival (ETA)", "Vessel departure
   (ETD)", "Container discharged on", "Delivery order (DO) expiry",
   "Last activity".
3. Free time: `demurrageInfo()` already counted from today; it now also
   returns the exact end date, and the card ALWAYS shows it ("Free time ends
   on 26 Oct 2026 — N days left", amber ≤2 days, red "Free time ended on …"
   when over).
4. Holds removed from the detail grid — shown once, in the top summary line.
5. Stale-data banner no longer repeats the "last checked" time (kept once in
   the card header).
6. Weight formatted: "29580" → "29,580 KGS" (`fmtWeight`).
7. Container size/type friendly: "22 / G1" → "20 ft GP (General Purpose)
   (22 / G1)" (`fmtSizeType`, ISO size/type code maps).
8. Label cleanup (`cleanPlace`): "PORT KEELANG" → "PORT KELANG",
   "EXAMIN" → "Examination" in route/position/place fields.
9. Top of card decluttered: single status badge, holds in the summary,
   free-time end date always visible.

## Item 9 — Classic search refine — LAYOUT ONLY, NO FUNCTION REMOVED
Primary row (search input + TRACK + 🎤 + 🩺) unchanged and dominant; second
row: mode tabs (BL/Container/Vessel) + carrier Auto-detect dropdown; tools
row: 📷 Photo scan (prominent, blue, "reads the whole BL"), 📋 Paste photo,
👤 Client tag; bulk paste + Import file (TXT/CSV) moved into a collapsible
"Bulk search" area. Photo OCR panel still appears under the card message
(auto-fill + auto-search flow from v49 untouched).

## Item 10 — Theme Studio compaction
Modal max-width 520px, tighter padding/labels/segments; colour builder is now
small swatches (46×27px) + ONE slim 10px gradient preview bar; preset chips
and swatches shrunk. All functions still work and persist (presets, single
colour, Rounded/Square, Gradient/Plain, pattern, clock, font).

## Item 11 — Animations — REAL NOW, 15 OPTIONS, DROPDOWN
Root cause: the v47 system had only 4 keyframes, Fade and Glow were literally
the SAME keyframe, and the motion (≤16px / plain opacity) was too subtle to
see — it read as "nothing happens". New system: each name has its own
`@keyframes cta-<name>`, applied via `--ct-kf` to view cards/stats/result
cards/chat messages, PLUS a JS replay (`playAnim`, hooked into showView)
that restarts the animation on every view switch with a small stagger.
Dropdown `#animSel`: Off, Fade, Fade Up, Slide Up, Slide Left, Slide Right,
Zoom, Flip, Bounce, Blur, Drop In, Swing, Elastic, Rotate In, Glow (14 real +
Off). Old values migrate (slide→slideup, on→fade). Off keeps the existing
`no-anim` gating (kills all animation).

## Item 12 — Fonts — DROPDOWN, 19 STYLES
Pill row replaced by `#fontSel` dropdown: System, Inter, Poppins, Roboto,
Open Sans, Montserrat, Lato, Source Sans, Raleway, Nunito, Ubuntu, Work Sans,
DM Sans (web fonts via Google Fonts with system fallbacks — offline still
works), Serif (Georgia), Book (Palatino), Mono (Consolas), Verdana, Tahoma,
Rounded (Trebuchet). Live preview line under the dropdown renders in the
chosen font and updates on change (`applyFont` + `FONT_STACKS`). Persisted in
`ct_font` as before.

## Item 13 — Clock fix + new designs + weather widget
(a) Containment: the header clock slot is fixed-height (56px), overflow
hidden, flex-centred — no style can escape it; Flip/Digital sizes reduced to
fit. (b) Kept Classic, Flip (HTC), Digital; retired Boxed/Minimal/Pill (old
saved values map: boxed/minimal→classic, pill→glass). New: **Analog** (SVG,
smooth-sweep second hand via a 120ms ticker), **Neon LED**, **Glass**
(glassmorphism + date), **Ring** (seconds progress ring around HH:MM text) —
all in `#clockSel` dropdown, all size-contained. (c) Weather widget beside
the clock: Karachi (24.86, 67.00) from Open-Meteo (free, no key), animated
SVG icons (rotating sun rays, drifting clouds, falling rain drops, flashing
bolt, moon at night), temperature + condition, humidity/wind in the tooltip,
30-minute localStorage cache, fail-SILENT (stays hidden on any error/offline,
hidden on narrow screens).

## Item 14 — Version info on the main page
Server: GET `/api/version` → `{app: 50, latest: <int|null>}`; latest comes
from the GitHub `version.txt` (urllib, 4s timeout), cached 6h on success /
10 min on failure, fail-silent (`latest: null` on any error). UI: small
centred line at the foot of the Track view — "CargoTrack v50", green
"Latest ✓" when current, amber "Update available: vNN" when newer, plain
version only when latest is unknown.

## Verified deep-link patterns (fetched during the build, 24 Oct 2026)
| Pattern | Result |
|---|---|
| `https://elines.coscoshipping.com/ebtracking/public/bill/6461573730` | **200** — deep link wired (digits only) |
| `https://shipsgo.com/dashboard/register?transport=ocean&carrier=1305&trace_number=EMKAYMBAKHI59055` | **200** — wired (Emkay) |
| `https://www.vesselfinder.com/vessels?name=EVER+URBAN` | **200** — wired (vessel search; `vf_url` preferred) |
| `https://www.kictl.com/Enquiries/ContainerBLEnquiry` | **200** — enquiry page + copy fallback |
| `https://www.sapt.com.pk/Enquiries/ContainerBLEnquiry` | **200** — enquiry page + copy fallback |
| `https://lfs.qict.com.pk/` | **200** — portal + copy fallback |
| `https://ct.shipmentlink.com/servlet/TDB1_CargoTracking.do` | **200** — form page + copy fallback (POST-based) |
| `https://www.track-trace.com/container/<no>`, `/bol/<no>` | **404 (verified)** — no deep link; home + copy fallback |
| `https://traqocontainer.com/` | 200 home; JS app, no linkable record URL — home + copy fallback |
| `https://www.maersk.com/tracking/268607384` | 502 via sandbox proxy — unverifiable → official page + copy fallback |
| `https://www.cma-cgm.com/ebusiness/tracking/search?Reference=…` | 403 bot-block — unverifiable → official page + copy fallback |

## Tests run (on a COPY with temp HOME, port 8899)
- `py_compile` server.py + bl_track.py: OK. Both inline `<script>` blocks
  pass `node --check`.
- `POST /api/ping` → `{"v": 50}` ✓
- `GET /api/version` → `{"app": 50, "latest": 48}` ✓ (repo still publishes 48;
  live fetch + JSON shape both work)
- `GET /api/history` → 78 seed entries, 25 carriers ✓
- `GET /` → 200; page contains animSel/fontSel/clockSel (dropdowns), wxBox,
  clockSvg + ckRing, progWrap + progFill, termList, docsec, verLine; no stale
  animSeg/fontSeg/clockSeg references ✓
- `POST /api/ocr` (Monter photo, the true file
  `…/image/7c/7c8a8f8e….png`): BL **MCLSUB26104308**, containers
  **MGEU1916791** (seal MCL0200757, check ✓) + **MGEU1917360** (seal
  MCL0200758, check ✓), carrier Monter Container Line, vessel MYDZHANGZHOU /
  CS2090N, gross 54,108, net 54,000, on-board 18 Sep 2026, freight Prepaid,
  free days 14, engine rapidocr ✓ (v49 photo-scan unbroken; the documented
  cosmetic spacing limits remain, e.g. "MYDZHANGZHOU", "PORTKLANG FCL/FCL…")
- Grep: no user-facing "Tesseract" anywhere (only server.py code comments
  stating it is NOT used); `navigator.clipboard.writeText` remains only
  inside `_copyRaw`.
- build_v50 `seed_history.json` re-verified at the end: 78 entries, and the
  build copy itself was never run.

## OCR auto-setup (v50 addition, 24 Oct 2026) — one-time, no venv shipped

**Problem:** the 362 MB `ocr/venv` can never ship (GitHub update tarball
must stay code-only; laptop ZIP should stay small), so on a fresh machine
(fresh Oracle server / fresh Windows laptop) photo scan had no engine.

**Behaviour (server.py):**
- Engine resolution order in `_ocr_resolve()`: (0) `CT_OCR_PYTHON`
  override → (1) `ocr/venv` interpreter, probed exactly as in v49 (the
  fast path is unchanged) → (2) **`ocr/pylibs` via the app's own Python
  (`sys.executable`) + `PYTHONPATH=ocr/pylibs`** → (3) app Python if it
  already has rapidocr → (4) developer `~/workspace/ocrvenv`. Successful
  resolution is cached; a failed probe is cached only 20 s so a finished
  setup is picked up immediately.
- If no engine resolves, `_run_ocr_items()` starts the **one-time setup**
  in a background thread and returns the existing `{ok:false, error}`
  shape with: *"Photo-scan engine is being set up on this device
  (one-time setup, a few minutes). Please try again shortly."* After a
  failure in the same server run it returns a clean "could not be
  completed … check the internet connection" message — never a traceback,
  never a Tesseract reference. One attempt per server start max
  (thread + `ocr/setup_state.json` guard; progress in `ocr/setup.log`).
- **Setup is pure stdlib** (no `python -m venv`, no ensurepip, no apt):
  fetch the latest stable pip wheel URL from `https://pypi.org/pypi/pip/json`,
  download + unzip it under `ocr/_bootstrap/`, then run
  `sys.executable -m pip install --break-system-packages --target ocr/pylibs
  -r ocr/requirements.txt` with `PYTHONPATH=<bootstrap>`, timeout 1800 s.
  On success the bootstrap dir is deleted and state = `ready`.
- `requirements.txt` now pins **`opencv-python-headless==5.0.0.93`** (was
  `opencv-python` — headless servers have no libGL) + rapidocr-onnxruntime
  1.4.4, onnxruntime 1.31.0, numpy 2.5.4, pillow 13.0.0 (same versions as
  the tested venv).
- Two real bugs found by the fresh-setup test and fixed in the worker:
  1. **pip temp space:** pip unpacks wheels under the system temp dir;
     on a small tmpfs `/tmp` the install died with `No space left on
     device`. The worker now points the pip subprocess's
     `TMPDIR`/`TEMP`/`TMP` at `ocr/_bootstrap/tmp` (same disk as pylibs).
  2. **GUI OpenCV overwrite:** rapidocr's dependency pulls BOTH
     opencv-python and opencv-python-headless into pylibs, and the GUI
     build's files won the overwrite order; a plain `--force-reinstall`
     then refused to replace them ("Target directory already exists").
     The worker now force-reinstalls headless with
     `--force-reinstall --upgrade --no-deps` whenever the GUI dist is
     present. Verified by binary inspection: pylibs `cv2.abi3.so` has
     **no libQt5/libGL NEEDED entries** (the GUI build links libQt5*).
- Assistant "OCR ready?" texts updated to match (no more "ocr folder
  missing" — it now says the engine sets itself up on first scan).
  `ocr/setup_ocr.bat`/`.sh` untouched — still there as a manual
  alternative. Windows parity: same code path (sys.executable +
  subprocess + PYTHONPATH); the venv probe keeps the
  `Scripts/python.exe` platform logic.

**Tests (copies only, temp HOME, port 8899; build_v50 itself never run):**
- (i) **Regression, copy WITH venv:** Monter photo → full record in
  12.8 s — BL MCLSUB26104308, containers MGEU1916791 (seal MCL0200757,
  check ✓) + MGEU1917360 (seal MCL0200758, check ✓), gross 54,108,
  net 54,000, Prepaid, 14 free days. No setup artifacts created —
  venv fast path untouched.
- (ii) **Fresh setup, copy WITHOUT venv/pylibs:** first scan → the
  setting-up message in 0.1 s + setup started. Run 1 **FAILED at the
  pip-install step** after 82 s (`No space left on device` — sandbox
  /tmp is a 512 MB tmpfs; downloads had succeeded, unpacking did not)
  → TMPDIR fix above. Run 2 (with TMPDIR fix): **READY in 47 s**, scan
  returned the full Monter record (10.8 s) — but binary inspection
  showed the GUI cv2 had won → `--upgrade` fix above. Run 3 (final
  code, fresh copy + fresh server): **READY in 83 s** (cold pip
  cache), zero overwrite warnings, headless cv2 confirmed via
  readelf, Monter scan full record (13.5 s), second scan 12.8 s with
  setup run count still 1 (no re-setup; state stays `ready`).
- `py_compile` server.py + bl_track.py + ocr_runner.py OK;
  `build_v50/seed_history.json` re-verified: **78 entries**; build
  dir's `ocr/` contains no pylibs/setup artifacts; venv intact (362 MB).
- Note: sandbox `/tmp` is a 512 MB tmpfs — test copies had to live
  under `~/workspace/` (cleaned up afterwards). On the real server the
  TMPDIR fix also protects against small-`/tmp` VMs.

## Not verified here (needs the parent agent's real-browser QA)
- Visual behaviour of the new animations/clocks/weather in a real browser
  (sandbox has no working browser; JS syntax + server responses verified).
- Copy fallback on the user's actual HTTP/LAN setup (code path is the
  standard execCommand fallback; logic reviewed, toast always fires).

## Item 11 REVISION (24 Oct, after Yousuf's clarification)
Yousuf clarified: "animation se mera maqsad button, bar, heading aisi jitni
chize hain un ki animation se hy - pure page ko ya windows ko hilana julana
nahi." The view-entrance system (cta-* keyframes on cards, playAnim replay)
was therefore REMOVED entirely: .view.active has no animation, the
.view.active>* vin rules are deleted, playAnim is a no-op. New system =
element animations only, chosen via the same #animSel dropdown, applied as
body[data-anim] CSS: glow (buttons breathe a glow, headings halo), flow
(animated gradients on topstrip/buttons/active tab/progress fill/gradient
headings), shine (periodic ::after sweep on buttons), lift (hover raise),
press (press ring/squeeze), pulse (#btnTrack + active tab), bounce (hover
bounce on buttons/tabs/chips), slide (hover slide-fill), neon (neon halo).
Old saved values migrate (fade->shine, slideup->lift, elastic->bounce, ...);
default is now "flow". Rules use longhand animation properties; jsdom
cascade check confirms data-anim="glow" gives #btnTrack
animation-name:ea-glow while cards compute to none, with zero script errors.
