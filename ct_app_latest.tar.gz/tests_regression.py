# -*- coding: utf-8 -*-
"""CargoTrack regression tests (v79) — chalane ka tareeqa:
    HOME=<koi test home> python3 tests_regression.py
Har test ka asal output print hota hai; aakhir mein PASS/FAIL
gin-ti. Ye file is liye hai taake test sirf report mein na
rahen — koi bhi dobara chala kar wohi natija dekh sake."""
import sys, time
sys.path.insert(0, ".")
import server

ok = fail = 0
def chk(label, cond, extra=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"PASS {label} {extra}")
    else:
        fail += 1
        print(f"FAIL {label} {extra}")

print("== Context: aam sawal par data NAHI ==")
for q in ["call me", "small talk karo", "Photosynthesis kya hai?",
          "what is AI?", "everything theek hai?", "listen to me",
          "sabar karo", "hold on a second", "weather in Lahore"]:
    chk(f"context khali {q!r}", server._assistant_context_for(q) == "")

print("== Context: list sawal par POORA data ==")
for q in ["show all shipments", "sab shipments ki list do",
          "Which shipments are on hold?", "What is arriving this week?"]:
    n = len(server._assistant_context_for(q))
    chk(f"context poora {q!r}", n > 1000, f"(len {n})")

c = server._assistant_context_for("142G513366 ka status batao", "142G513366")
chk("BL-only context", "142G513366" in c and "274094021" not in c,
    f"(len {len(c)})")

print("== Data-sawal pehchan ==")
for q, want in [("give me the details", False),
                ("ye important baat hai", False),
                ("customer care number do", False),
                ("train ka time kya hai", False),
                ("142G513366 ka status batao", True),
                ("holds batao", True), ("vessel kab ayegi", True),
                ("mosam kesa hai", False)]:
    chk(f"looks_data {q!r}={want}", server._looks_data_q(q) == want)

print("== Local branches (had ke baad bhi zinda) ==")
def loc(q):
    return (server._assistant_local(q) or {}).get("answer") or ""
chk("photosynthesis par OCR jawab nahi",
    "Photo scanning" not in loc("Photosynthesis kya hai?"))
chk("system health", "System health" in loc("system ki halat kesi hai"))
chk("holds branch", len(loc("konsi shipments hold par hain")) > 60)
chk("thank branch", "welcome" in loc("thank you").lower())
chk("identity branch", "CargoTrack assistant" in loc("tum kon ho"))
chk("payment branch", "pending" in loc("payment pending kitna hai").lower())

print("== Weather ==")
a = server._weather_answer("Lahore ka mosam kesa hai")
chk("Lahore only", bool(a) and a.startswith("Lahore ka mosam"), )
a = server._weather_answer("Mardan ka batabo mosam")
chk("Mardan only", bool(a) and a.startswith("Mardan ka mosam"))
a = server._weather_answer("Lahore aur Mardan mein aaj barish ka imkaan hai?")
chk("Lahore+Mardan", bool(a) and "Lahore:" in a and "Mardan:" in a)
a = server._weather_answer("Lahore aur Xyzabc ka mosam batao")
chk("known+unknown", bool(a) and "Lahore" in a and "nahi mil saka" in a)
a = server._weather_answer("Xyzabc ka mosam batao")
chk("unknown only (koi number nahi)", bool(a) and "°C" not in a)
a = server._weather_answer("Barish kaha ho sakti hy kis city me")
chk("barish panel", bool(a) and a.count(":") >= 8)
chk("train par weather nahi",
    server._weather_answer("train ka time kya hai") is None)

import urllib.request, urllib.error, json as _j
class FakeResp:
    def __init__(self, payload): self._p = payload
    def __enter__(self): return self
    def __exit__(self, *x): return False
    def read(self): return _j.dumps(self._p).encode()
_orig = urllib.request.urlopen
def fake_missing(url, timeout=0):
    if "geocoding" in str(url):
        return FakeResp({"results": [{"latitude": 31.5,
                                       "longitude": 74.3,
                                       "timezone": "Asia/Karachi",
                                       "name": "Lahore"}]})
    return FakeResp({"current": {}, "daily": {}})
urllib.request.urlopen = fake_missing
try:
    a = server._weather_answer("Lahore ka mosam kesa hai")
finally:
    urllib.request.urlopen = _orig
chk("missing fields -> imaandar jawab", bool(a) and "nahi mil sakin" in a)

def fake_down(url, timeout=0):
    raise TimeoutError("simulated timeout")
urllib.request.urlopen = fake_down
try:
    a = server._weather_answer("Karachi ka mosam kesa hai")
finally:
    urllib.request.urlopen = _orig
chk("API timeout -> imaandar jawab", bool(a) and "nahi mil sakin" in a)

print("== Provider nakami ki simulation (429 Groq + 503 Gemini) ==")
server._groq_key = lambda: "gsk_dummy_sim"
server._ai_key_single = lambda: "AIzaDummySim"
def fake_providers(url, timeout=0):
    u = str(getattr(url, "full_url", url))
    if "groq.com" in u:
        raise urllib.error.HTTPError(u, 429, "rate limit", {}, None)
    if "googleapis.com" in u:
        raise urllib.error.HTTPError(u, 503, "overloaded", {}, None)
    return _orig(url, timeout=timeout)
urllib.request.urlopen = fake_providers
t0 = time.time()
try:
    out = server.assistant_answer("Duniya ka sab se bara samandar konsa hai?", [])
finally:
    urllib.request.urlopen = _orig
secs = time.time() - t0
chk("429+503 par jhoota jawab nahi",
    out.get("mode") != "ai" and bool(out.get("ai_error") or out.get("mode")),
    f"(mode {out.get('mode')}, {secs:.0f}s mein band)")
chk("nakami ki wajah note mein hai", bool(out.get("ai_note")))

print(f"\nMAJMUA: {ok} PASS, {fail} FAIL")
sys.exit(1 if fail else 0)
