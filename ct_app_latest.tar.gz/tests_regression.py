# -*- coding: utf-8 -*-
"""CargoTrack regression tests (v79) — chalane ka tareeqa:
    HOME=<koi test home> python3 tests_regression.py
Har test ka asal output print hota hai; aakhir mein PASS/FAIL
gin-ti. Ye file is liye hai taake test sirf report mein na
rahen — koi bhi dobara chala kar wohi natija dekh sake."""
import sys, time
sys.path.insert(0, ".")
import server

ok = fail = 0
def chk(label, cond, extra=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"PASS {label} {extra}")
    else:
        fail += 1
        print(f"FAIL {label} {extra}")

print("== Context: aam sawal par data NAHI ==")
for q in ["call me", "small talk karo", "Photosynthesis kya hai?",
          "what is AI?", "everything theek hai?", "listen to me",
          "sabar karo", "hold on a second", "weather in Lahore"]:
    chk(f"context khali {q!r}", server._assistant_context_for(q) == "")

print("== Context: list sawal par POORA data ==")
for q in ["show all shipments", "sab shipments ki list do",
          "Which shipments are on hold?", "What is arriving this week?"]:
    n = len(server._assistant_context_for(q))
    chk(f"context poora {q!r}", n > 1000, f"(len {n})")

c = server._assistant_context_for("142G513366 ka status batao", "142G513366")
chk("BL-only context", "142G513366" in c and "274094021" not in c,
    f"(len {len(c)})")

print("== Data-sawal pehchan ==")
for q, want in [("give me the details", False),
                ("ye important baat hai", False),
                ("customer care number do", False),
                ("train ka time kya hai", False),
                ("142G513366 ka status batao", True),
                ("holds batao", True), ("vessel kab ayegi", True),
                ("mosam kesa hai", False)]:
    chk(f"looks_data {q!r}={want}", server._looks_data_q(q) == want)

print("== Local branches (had ke baad bhi zinda) ==")
def loc(q):
    return (server._assistant_local(q) or {}).get("answer") or ""
chk("photosynthesis par OCR jawab nahi",
    "Photo scanning" not in loc("Photosynthesis kya hai?"))
chk("system health", "System health" in loc("system ki halat kesi hai"))
chk("holds branch", len(loc("konsi shipments hold par hain")) > 60)
chk("thank branch", "welcome" in loc("thank you").lower())
chk("identity branch", "CargoTrack assistant" in loc("tum kon ho"))
chk("payment branch", "pending" in loc("payment pending kitna hai").lower())

print("== Weather ==")
a = server._weather_answer("Lahore ka mosam kesa hai")
chk("Lahore only", bool(a) and a.startswith("Lahore ka mosam"), )
a = server._weather_answer("Mardan ka batabo mosam")
chk("Mardan only", bool(a) and a.startswith("Mardan ka mosam"))
a = server._weather_answer("Lahore aur Mardan mein aaj barish ka imkaan hai?")
chk("Lahore+Mardan", bool(a) and "Lahore:" in a and "Mardan:" in a)
a = server._weather_answer("Lahore aur Xyzabc ka mosam batao")
chk("known+unknown", bool(a) and "Lahore" in a and "nahi mil saka" in a)
a = server._weather_answer("Xyzabc ka mosam batao")
chk("unknown only (koi number nahi)", bool(a) and "°C" not in a)
a = server._weather_answer("Barish kaha ho sakti hy kis city me")
chk("barish panel", bool(a) and a.count(":") >= 8)
chk("train par weather nahi",
    server._weather_answer("train ka time kya hai") is None)

import urllib.request, urllib.error, json as _j
class FakeResp:
    def __init__(self, payload): self._p = payload
    def __enter__(self): return self
    def __exit__(self, *x): return False
    def read(self): return _j.dumps(self._p).encode()
_orig = urllib.request.urlopen
def fake_missing(url, timeout=0):
    if "geocoding" in str(url):
        return FakeResp({"results": [{"latitude": 31.5,
                                       "longitude": 74.3,
                                       "timezone": "Asia/Karachi",
                                       "name": "Lahore"}]})
    return FakeResp({"current": {}, "daily": {}})
urllib.request.urlopen = fake_missing
try:
    a = server._weather_answer("Lahore ka mosam kesa hai")
finally:
    urllib.request.urlopen = _orig
chk("missing fields -> imaandar jawab", bool(a) and "nahi mil sakin" in a)

def fake_down(url, timeout=0):
    raise TimeoutError("simulated timeout")
urllib.request.urlopen = fake_down
try:
    a = server._weather_answer("Karachi ka mosam kesa hai")
finally:
    urllib.request.urlopen = _orig
chk("API timeout -> imaandar jawab", bool(a) and "nahi mil sakin" in a)

print("== Provider nakami ki simulation (429 Groq + 503 Gemini) ==")
server._groq_key = lambda: "gsk_dummy_sim"
server._ai_key_single = lambda: "AIzaDummySim"
def fake_providers(url, timeout=0):
    u = str(getattr(url, "full_url", url))
    if "groq.com" in u:
        raise urllib.error.HTTPError(u, 429, "rate limit", {}, None)
    if "googleapis.com" in u:
        raise urllib.error.HTTPError(u, 503, "overloaded", {}, None)
    return _orig(url, timeout=timeout)
urllib.request.urlopen = fake_providers
t0 = time.time()
try:
    out = server.assistant_answer("Duniya ka sab se bara samandar konsa hai?", [])
finally:
    urllib.request.urlopen = _orig
secs = time.time() - t0
chk("429+503 par jhoota jawab nahi",
    out.get("mode") != "ai" and bool(out.get("ai_error") or out.get("mode")),
    f"(mode {out.get('mode')}, {secs:.0f}s mein band)")
chk("nakami ki wajah note mein hai", bool(out.get("ai_note")))

print("== Empty-return presumption (user's 2+ day rule, v96) ==")
from datetime import datetime as _dt96, timedelta as _td96, \
    timezone as _tz96
_today96 = _dt96.now(_tz96(_td96(hours=5))).date()
def _go96(days_ago):
    d = _today96 - _td96(days=days_ago)
    return d.strftime("%d-%b-%y").upper() + " 06.38.19 PM"
def _rec96(days_ago, returned=False, blob=""):
    return {"query": "TESTBL96", "found": True, "returned": returned,
            "result": {"gate_out": _go96(days_ago), "status": "Gate out"},
            "layers": ([{"name": "Terminal", "detail": blob}]
                       if blob else [])}
chk("presumed: 5d gate-out, no return record",
    server._lifecycle(_rec96(5))["empty"] == "presumed")
chk("presumed ki grade estimate hai",
    server._lifecycle(_rec96(5))["empty_certainty"] == "estimate")
chk("presumed: 3d gate-out",
    server._lifecycle(_rec96(3))["empty"] == "presumed")
chk("pending: theek 2d gate-out (rule se bahar)",
    server._lifecycle(_rec96(2))["empty"] == "pending")
chk("pending: 1d gate-out",
    server._lifecycle(_rec96(1))["empty"] == "pending")
chk("asal return presumption par jeet-ta hai (manual mark)",
    server._lifecycle(_rec96(9, returned=True))["empty"] == "returned")
chk("asal return presumption par jeet-ta hai (layer text)",
    server._lifecycle(_rec96(9, blob="Empty returned to terminal"))["empty"]
    == "returned")

print("== Merge guards (v96 data audit: downgrade + cross-cycle) ==")
ENG = server.ENG
chk("stage: Delivered text = 5",
    ENG.status_text_stage("Released — Delivered") == 5)
chk("stage: Gate out text = 4", ENG.status_text_stage("Gate out") == 4)
chk("stage: Discharged text = 3",
    ENG.status_text_stage("Discharged at QICT") == 3)
chk("stage: Expected text <= 1",
    ENG.status_stage({"status": "Expected at QICT — on X, still at sea"})
    <= 1)
chk("stage: saboot jeet-ta hai (OUT + truck delivered = 5)",
    ENG.status_stage({"status": "Discharged at QICT", "position": "OUT",
                      "truck": "delivered"}) == 5)
_r = ENG._reconcile_status({"status": "Discharged at QICT",
                            "position": "OUT", "truck": "delivered",
                            "terminal": "QICT"})
chk("reconcile: khud-takrari fresh result Delivered banta hai",
    _r["status"] == "Released — Delivered")
_r = ENG._reconcile_status({"status": "Partially discharged",
                            "gate_out": "22-OCT-26 04.50.06 PM"})
chk("reconcile: gate_out saboot -> 'Gate out'",
    _r["status"] == "Gate out")
_r = ENG._reconcile_status({"status": "On hold at QICT",
                            "position": "OUT", "truck": "delivered"})
chk("reconcile: hold status ko haath nahi lagta",
    _r["status"] == "On hold at QICT")

_old269 = {"status": "Released — Delivered", "position": "OUT",
           "truck": "delivered", "discharge_time": "30-JUL-2026 17:36",
           "vir": "PKBQMQICT_260726004914", "vessel": "GSL ROSSI",
           "voyage": "631W", "terminal": "QICT"}
_new269 = dict(_old269, status="Discharged at QICT", speed="0.2 knots")
_m = server._merge_result(dict(_old269), dict(_new269))
chk("merge: 269665315 Delivered mehfooz",
    _m["status"] == "Released — Delivered" and _m["position"] == "OUT")
chk("merge: voyage canonical (631W -> W631)", _m["voyage"] == "W631")

_oldSS = {"status": "Gate out", "position": "Gate Out",
          "gate_out": "05-SEP-26 05.30.16 PM",
          "discharge_time": "01-SEP-26 11.52.04 PM",
          "vir": "PKKHISAPT_240826012013", "vessel": "DELPHINUS C",
          "voyage": "0112", "terminal": "SAPT", "eta": "01 Sep 2026"}
_newSS = {"status": "Arrived at Karachi terminal",
          "position": "Loaded on Vessel", "vessel": "KMTC MOMBASA",
          "voyage": "E2605", "eta": "26 Sep 2026"}
_m = server._merge_result(dict(_oldSS), dict(_newSS))
chk("merge: agla cycle mukammal record ko nahi dabata (SSLSU)",
    _m["vessel"] == "DELPHINUS C" and _m["status"] == "Gate out"
    and _m["gate_out"] == "05-SEP-26 05.30.16 PM")

_oldPAL = {"status": "Gate out", "position": "Gate Out",
           "gate_out": "09-SEP-26 10.35.11 AM",
           "discharge_time": "27-AUG-26 05.19.05 PM",
           "vir": "PKKHIKICT_210826122038", "vessel": "OOCL LE HAVRE",
           "voyage": "209", "terminal": "KICT", "eta": "27 Aug 2026"}
_newPAL = {"status": "In transit", "position": "Loaded on Vessel",
           "vessel": "OOCL DALIAN", "voyage": "722",
           "eta": "14 Oct 2026"}
_m = server._merge_result(dict(_oldPAL), dict(_newPAL))
chk("merge: doosri BL ki sailing pehchan nahi badal sakti (PAL)",
    _m["vessel"] == "OOCL LE HAVRE" and _m["status"] == "Gate out")

_oldS49 = {"status": "Gate out", "position": "Gate Out",
           "gate_out": "12-SEP-26 11.47.19 AM",
           "discharge_time": "05-SEP-26 02.26.47 AM",
           "vir": "PKKHIKICT_310826104443", "vessel": "OOCL DALIAN",
           "voyage": "721", "terminal": "KICT"}
_newS49 = {"status": "Partially discharged", "position": "In Yard",
           "vessel": "OOCL DALIAN", "voyage": "721",
           "terminal": "KICT"}
_m = server._merge_result(dict(_oldS49), dict(_newS49))
chk("merge: proven Gate out -> 'Partially discharged' nahi (S490321128)",
    _m["status"] == "Gate out"
    and _m["gate_out"] == "12-SEP-26 11.47.19 AM")

_old16 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "discharge_time": "17-SEP-2026 11:47",
          "vir": "PKBQMQICT_140926131731", "vessel": "BSG BIMINI",
          "voyage": "638W", "terminal": "QICT"}
_new16 = {"status": "Discharged at QICT", "position": "In Yard",
          "discharge_time": "17-SEP-2026 11:47",
          "vir": "PKBQMQICT_140926131731", "vessel": "BSG BIMINI",
          "voyage": "638W", "terminal": "QICT"}
_m = server._merge_result(dict(_old16), dict(_new16))
chk("merge: apne cycle ka yard saboot jhooti Delivered sudharta hai (1016)",
    _m["status"] == "Discharged at QICT" and _m["position"] == "In Yard")
_new16b = dict(_new16, position="OUT")
_m = server._merge_result(dict(_old16), dict(_new16b))
chk("merge: yard saboot ke baghair correction nahi hoti",
    _m["status"] == "Released — Delivered")

print("== v98 S2: 59055 — QICT BL-mode khaali + Ctr-Inq sirf discharge ==")
# Asal waqia (29 Oct 2026, 17:40): stored record 'Released —
# Delivered' (position OUT, truck delivered) tha. Taza check
# mein QICT BL-mode gate-out ke baad khaali mili aur Ctr-Inq
# ne sirf discharge diya (position/gate_out us leg par kabhi
# hota hi nahi — wo discharge gate-out ke baad bhi rehta
# hai). Engine ke veto ne khaali position par 'In Yard'
# GHAR liya, merge ke _own_cycle_correction ne use yard
# saboot maan kar Delivered ko 'Discharged at QICT' par
# peeche kar diya aur _record ne status-change stamp laga
# diya. Ab: aisi fresh shakal final record ko NAHI chhu
# sakti; asal yard POSITION wala correction (1016, oper)
# ab bhi chalta hai.
_old55 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered",
          "discharge_time": "13-OCT-2026 16:59",
          "vir": "PKBQMQICT_051026131058", "vessel": "SLS TOPAZ",
          "voyage": "642S", "terminal": "QICT",
          "containers": ["FFAU2343188"]}
_new55 = {"status": "Discharged at QICT",
          "discharge_time": "13-OCT-2026 16:59",
          "vir": "PKBQMQICT_051026131058", "vessel": "SLS TOPAZ",
          "voyage": "642S", "terminal": "QICT",
          "containers": ["FFAU2343188"]}
_m = server._merge_result(dict(_old55), dict(_new55))
chk("merge v98: 59055 Delivered mehfooz (Ctr-Inq discharge-only)",
    _m["status"] == "Released — Delivered"
    and _m["position"] == "OUT" and _m["truck"] == "delivered",
    f"({_m['status']} / {_m['position']})")
_new55b = dict(_new55, status="Discharged at QICT — in yard")
_m = server._merge_result(dict(_old55), dict(_new55b))
chk("merge v98: status text ka 'yard' akela correction nahi kholta",
    _m["status"] == "Released — Delivered")
_res55 = {"status": "Released — Delivered", "position": "",
          "truck": "delivered", "terminal": "QICT",
          "vir": "PKBQMQICT_051026131058",
          "discharge_time": "13-OCT-2026 16:59",
          "containers": ["FFAU2343188"]}
_ev55 = {"FFAU2343188": {"out": False, "in_yard": True,
                         "virs": {"PKBQMQICT_051026131058"},
                         "status": "Discharged at QICT",
                         "position": ""}}
ENG._apply_container_veto(_res55, _ev55)
chk("veto v98: khaali position par 'In Yard' NAHI ghara jata",
    (_res55.get("position") or "") == "",
    f"(position={_res55.get('position')!r})")

print("== v98 S1: profile naam + tareekh AI context mein ==")
_pl = server._profile_line()
_nm = str(server.get_settings().get("profile_name") or "").strip()
chk("profile line: naam prompt mein hai ya saaf 'saved nahi'",
    (_nm and _nm in _pl) or (not _nm and "no name is saved" in _pl))
_body = server._gemini_body("mera naam kya hai?", [], "")
_sys = _body["systemInstruction"]["parts"][0]["text"]
chk("gemini prompt: TODAY'S DATE + profile + web-honesty rule",
    "TODAY'S DATE:" in _sys and "USER PROFILE:" in _sys
    and "never cite 'web results'" in _sys)
chk("wx hit: 'temperature' bhi mosam ka sawal hai",
    server._wx_hit("aaj temperature kya hai")
    and server._wx_hit("Lahore ka mosam kesa hai"))
a = server._weather_answer("Karachi mein barish kahan ho sakti hai")
chk("where-rain: sheher ke naam ke bawajood single-city card NAHI",
    bool(a) and "barish ka chance" in a
    and "ka mosam (abhi)" not in a)

print("== Live-layer saboot (v96 data audit FIX 2) ==")
chk("live: sirf identification done = live nahi",
    server._live_data_layers(
        [{"name": "Layer 0 — Carrier identification",
          "status": "done"}]) == [])
chk("live: QICT data layer done = live",
    len(server._live_data_layers(
        [{"name": "Layer 3b — QICT (DP World Karachi)",
          "status": "done"}])) == 1)
chk("live: manual-check done = live nahi",
    server._live_data_layers(
        [{"name": "Layer 3g — Hutchison Portal (manual check)",
          "status": "done"}]) == [])
chk("live: fail layers live nahi",
    server._live_data_layers(
        [{"name": "Layer 3b — QICT (DP World Karachi)",
          "status": "fail"}]) == [])

print("== Round 2: terminal pehchan VIR se (FIX A) ==")
chk("vir_terminal: QICT", ENG.vir_terminal("PKBQMQICT_030826132505") == "QICT")
chk("vir_terminal: KICT", ENG.vir_terminal("PKKHIKICT_310826105637") == "KICT")
chk("vir_terminal: SAPT", ENG.vir_terminal("PKKHISAPT_080926021505") == "SAPT")
chk("vir_terminal: KGTL", ENG.vir_terminal("PKKHIKGTL_210826165034") == "KGTL")
chk("vir_terminal: khaali -> None", ENG.vir_terminal("") is None)
_oldA = {"status": "Released — Delivered", "terminal": "QICT",
         "vir": "PKBQMQICT_030826132505", "source": "QICT (DP World)",
         "discharge_time": "11-AUG-2026 21:20", "position": "OUT",
         "truck": "delivered", "vessel": "SLS TOPAZ", "voyage": "642S"}
_newA = {"status": "Arrived at Karachi terminal", "terminal": "SAPT",
         "vir": "PKBQMQICT_030826132505",
         "source": "Karachi Terminal (Hutchison Ports)",
         "position": "Loaded on Vessel", "etd": "09 Sep 2026"}
_m = server._merge_result(dict(_oldA), dict(_newA))
chk("merge FIX A: wahi VIR -> terminal SAPT nahi banta (59009)",
    _m["terminal"] == "QICT")
_m = server._merge_result(
    {"status": "Discharged at SAPT", "terminal": "SAPT",
     "vir": "PKBQMQICT_030826132505",
     "discharge_time": "11-AUG-2026 21:20"}, {})
chk("merge FIX A: status ke andar ka 'at SAPT' bhi VIR se sudharta hai",
    _m["status"] == "Discharged at QICT" and _m["terminal"] == "QICT")
_r = ENG._reconcile_status({"status": "Discharged at SAPT",
                            "terminal": "SAPT",
                            "vir": "PKBQMQICT_030826132505",
                            "discharge_time": "11-AUG-2026 21:20"})
chk("reconcile FIX A: fresh synthesis ka terminal VIR se milta hai",
    _r["terminal"] == "QICT")
_r = ENG._reconcile_status({"status": "Arrived", "vir": "PKKHISAPT_1"})
chk("reconcile FIX A: terminal khaali ho to VIR se bhar jata hai",
    _r["terminal"] == "SAPT")

print("== Round 2: pakki maloomat kabhi nahi mit-ti (FIX B) ==")
_oldB = {"status": "In transit — departed Shekou 09 Oct 2026",
         "terminal": "SAPT", "source": "COSCO Shipping (API)",
         "eta": "26 Oct 2026", "vessel": "APL CHONGQING"}
_newB = {"status": "Arrived", "terminal": "SAPT", "source": "COSCO API",
         "eta": "26 Oct 2026", "vessel": "APL CHONGQING"}
_m = server._merge_result(dict(_oldB), dict(_newB))
chk("merge FIX B: departed tareekh 'Arrived' par bhi mehfooz",
    _m.get("departed") == "09 Oct 2026")
_ms = server._milestones({"result": _m, "layers": [
    {"name": "Layer 1 — COSCO API", "status": "done"}]})
_dep = [x for x in _ms if x["key"] == "departed"][0]
chk("milestone FIX B: departed wahi tareekh dikhata hai",
    _dep["state"] == "done" and _dep["when"] == "09 Oct 2026")
_r = ENG._reconcile_status(
    {"status": "In transit — departed Shekou 09 Oct 2026"})
chk("reconcile FIX B: departed field synthesis par hi banta hai",
    _r.get("departed") == "09 Oct 2026")
_m = server._merge_result({"departed": "09 Oct 2026",
                           "status": "Arrived"},
                          {"status": "Discharged"})
chk("merge FIX B: departed field naye text par bhi nahi mit-ta",
    _m.get("departed") == "09 Oct 2026")
_oldP = {"status": "On hold at KICT — loaded on vessel",
         "terminal": "KICT", "vir": "PKKHIKICT_191026105443",
         "source": "KICT Trade Portal (Hutchison) — verified by "
                   "Shezi, 27 Oct 2026 5:23 PM",
         "position": "Loaded On Vessel"}
_newP = {"status": "Discharged", "terminal": "KICT",
         "vir": "PKKHIKICT_191026105443",
         "source": "Karachi Terminal (Hutchison Ports)",
         "discharge_time": "27-OCT-26 05.23.27 PM",
         "position": "In Yard"}
_m = server._merge_result(dict(_oldP), dict(_newP))
chk("merge FIX B: 'verified by Shezi' provenance mehfooz",
    "verified by Shezi" in (_m.get("source") or ""))
_oldX = {"status": "Partially discharged", "terminal": "KICT",
         "vir": "PKKHIKICT_051026114110",
         "gate_out": "24-OCT-26 09.27.08 PM",
         "discharge_time": "2026-10-12 01:04", "position": "Gate Out"}
_m = server._merge_result(dict(_oldX), {"status": "Arrived at Karachi "
                                         "terminal",
                                         "position": "Loaded on Vessel"})
chk("merge FIX B: kamzor re-check par bhi 'Partially' nahi chipakta",
    _m["status"] == "Gate out")
_m = server._merge_result(dict(_oldX), {})
chk("merge FIX B: read par hi 'Partially discharged' sudhar jata hai",
    _m["status"] == "Gate out")
_m = server._merge_result(
    {"status": "Partially discharged",
     "discharge_time": "2026-10-12 01:04"}, {})
chk("merge FIX B: gate-out saboot na ho to 'Partially' barqarar",
    _m["status"] == "Partially discharged")

print("== Round 2: v96 enrich corrections (populated HOME par) ==")
_hist = {e.get("query"): e for e in server.get_history()}
_e = _hist.get("MBAQITS8502261016") or {}
_r = _e.get("result") or {}
chk("enrich: 1016 jhooti Delivered -> Discharged/In Yard",
    _r.get("status") == "Discharged at QICT"
    and _r.get("position") == "In Yard" and not _r.get("gate_out"),
    f"({_r.get('status')} / {_r.get('position')})")
_e = _hist.get("EMKAYMBAKHI59055") or {}
_r = _e.get("result") or {}
chk("enrich: 59055 container + hold khatam",
    _r.get("containers") == ["FFAU2343188"]
    and "hold" not in (_r.get("status") or "").lower()
    and not _r.get("gate_out"),
    f"({_r.get('status')} / {_r.get('containers')})")
_e = _hist.get("COAU6464740334") or {}
_r = _e.get("result") or {}
chk("enrich: 6464740334 gate-out stamped, Partially khatam",
    _r.get("gate_out") == "17-OCT-26 06.56.35 PM"
    and _r.get("status") == "Gate out" and _e.get("returned") is True)
_e = _hist.get("EMKAYMBAKHI59009") or {}
chk("enrich: 59009 empty return darj", _e.get("returned") is True)

print("== Data Doctor (v96): pehchaan, sahi karna, report ==")
import time as _tdd
# 1) terminal != VIR -> auto-correct + log; voyage bhi canonical
_bad = {"query": "TESTDD1", "found": True, "mode": "bl",
        "result": {"status": "Discharged at SAPT",
                   "terminal": "SAPT",
                   "vir": "PKBQMQICT_030826132505",
                   "voyage": "631W",
                   "discharge_time": "11-AUG-2026 21:20"}}
_c, _f = server._doctor_check_entry(_bad, {}, _tdd.time())
chk("doctor: terminal VIR se khud sudhra (SAPT->QICT)",
    _bad["result"]["terminal"] == "QICT")
chk("doctor: terminal correction LOG huwi",
    any(c["rule"] == "terminal-vir" and c["field"] == "terminal"
        for c in _c))
chk("doctor: status ke andar ka 'at SAPT' bhi sudhra",
    _bad["result"]["status"] == "Discharged at QICT")
chk("doctor: voyage canonical (631W -> W631)",
    _bad["result"]["voyage"] == "W631")
# 2) jhooti Delivered wali shakal -> FINDING, rewrite NAHI
_fd = {"query": "TESTDD2", "found": True, "mode": "bl",
       "result": {"status": "Released — Delivered",
                  "position": "In Yard",
                  "discharge_time": "17-SEP-2026 11:47",
                  "vir": "PKBQMQICT_140926131731",
                  "terminal": "QICT"}}
_c, _f = server._doctor_check_entry(_fd, {}, _tdd.time())
chk("doctor: jhooti Delivered -> finding banti hai",
    any(f["rule"] == "false-delivered-suspect" for f in _f))
chk("doctor: jhooti Delivered ko rewrite NAHI kiya",
    _fd["result"]["status"] == "Released — Delivered"
    and not any(c["field"] == "status" for c in _c))
# 3) 'Partially discharged' + mukammal gate-out saboot -> Gate out
_pg = {"query": "TESTDD3", "found": True, "mode": "bl",
       "result": {"status": "Partially discharged",
                  "gate_out": "24-OCT-26 09.27.08 PM",
                  "discharge_time": "2026-10-12 01:04",
                  "terminal": "KICT",
                  "vir": "PKKHIKICT_051026114110"}}
_c, _f = server._doctor_check_entry(_pg, {}, _tdd.time())
chk("doctor: Partially + gate-out saboot -> 'Gate out'",
    _pg["result"]["status"] == "Gate out"
    and any(c["rule"] == "status-evidence" for c in _c))
# 4) shared container -> finding (auto-fix kabhi nahi)
_sh = {"TESTDD4A": ["MSKU1234567"], "TESTDD4B": ["MSKU1234567"]}
_e4 = {"query": "TESTDD4A", "found": True, "mode": "bl",
       "result": {"status": "In transit",
                  "containers": ["MSKU1234567"]}}
_c, _f = server._doctor_check_entry(
    _e4, {"MSKU1234567": ["TESTDD4A", "TESTDD4B"]}, _tdd.time())
chk("doctor: shared container finding, koi correction nahi",
    any(f["rule"] == "shared-container" for f in _f) and _c == [])
# 5) dedupe: wahi finding dobara alert nahi; values badlein to naya
_f1 = [{"id": "dd_testdedupe", "query": "TESTDD5",
        "rule": "stuck-nonfinal", "severity": "medium",
        "detail": "d", "time": "t"}]
_r1 = server._doctor_update_report({}, _f1, [], 1, 1000.0)
chk("doctor: pehli sweep — finding queue mein gayi",
    len(_r1["shezi_queue"]) == 1)
_r2 = server._doctor_update_report(_r1, _f1, [], 1, 2000.0)
chk("doctor: wahi finding dobara alert NAHI (dedupe)",
    len(_r2["shezi_queue"]) == 1)
_f2 = [dict(_f1[0], id="dd_testdedupe2")]
_r3 = server._doctor_update_report(_r2, _f2, [], 1, 3000.0)
chk("doctor: values badlein to naya alert banta hai",
    len(_r3["shezi_queue"]) == 2)
# 6) populated HOME par mukammal sweep + report file
_rep = server._doctor_run("test")
chk("doctor: report file DATA_DIR mein bana",
    server.DOCTOR_FILE.exists())
chk("doctor: tamam stored records sweep huwe",
    _rep["records"] == len(server.get_history()),
    f"(records {_rep['records']}, findings "
    f"{len(_rep['findings'])}, corrections "
    f"{len(_rep['corrections'])})")
_pub = server._doctor_public(_rep)
chk("doctor: public payload — findings/corrected alag + alerts",
    _pub["needs_shezi"] == _pub["findings"]
    and isinstance(_pub["corrected"], list)
    and len(_pub["alerts"]) == min(60, len(_pub["findings"])))
chk("doctor: email set na ho to jhoota 'sent' nahi — queue sach",
    _pub["queued"] == bool(_rep.get("shezi_queue")))

print("== Proof-run fix: container saboot ka veto (case 3) ==")
# Asal nakami (live sabit): QICT BL-inquiry (3b) jhoota
# 'Released — Delivered' + truck delivered kehti hai, jabke
# by-container leg (3c, Ctr-Inq) usi cycle ka discharge dikhati
# hai aur gate-out ka koi saboot nahi — dabba yard mein hai.
# Merge guard sirf downgrade rokta tha; ye ghalat upgrade
# synthesis ke andar hi rukna chahiye.
_orig96 = {n: getattr(ENG, n) for n in (
    "track_bol_tracktrace", "track_karachi_terminals",
    "track_qict_bl", "track_kgtl_bl",
    "track_qict_container_layer",
    "track_karachi_terminals_container",
    "track_kgtl_container", "vessel_live_position")}
_nf96 = lambda *a, **k: {"found": False}
_claim96 = {"found": True, "terminal": "QICT",
            "source": "QICT (DP World)",
            "containers": ["MRKU8740840"],
            "status": "Released — Delivered",
            "position": "OUT", "truck": "delivered",
            "vir": "PKBQMQICT_140926131731",
            "vessel": "BSG BIMINI", "voyage": "638W",
            "discharge_time": "17-SEP-2026 11:47"}
_ctr96 = {"found": True, "terminal": "QICT",
          "source": "QICT (DP World)",
          "containers": ["MRKU8740840"],
          "discharge_time": "17-SEP-2026 11:47",
          "vir": "PKBQMQICT_140926131731",
          "vessel": "BSG BIMINI", "voyage": "638W"}
try:
    for _n, _f in (("track_bol_tracktrace", _nf96),
                   ("track_karachi_terminals", _nf96),
                   ("track_kgtl_bl", _nf96),
                   ("track_karachi_terminals_container", _nf96),
                   ("track_kgtl_container", _nf96),
                   ("vessel_live_position", _nf96),
                   ("track_qict_bl",
                    lambda bl: dict(_claim96))):
        setattr(ENG, _n, _f)
    ENG.track_qict_container_layer = lambda c: dict(
        _ctr96, status="Discharged at QICT")
    _o = ENG.track_all(bl="MBAQITS8502261016")
    _r = _o["result"]
    chk("veto: 3b Delivered vs 3c In Yard -> Discharged rehta hai",
        _r.get("status") == "Discharged at QICT"
        and _r.get("position") == "In Yard"
        and _r.get("truck") != "delivered"
        and not _r.get("gate_out"),
        f"({_r.get('status')} / {_r.get('position')})")
    # genuine: by-container leg gate-out ki tasdeeq kar de to
    # Delivered ka dawa bilkul barqarar
    ENG.track_qict_container_layer = lambda c: dict(
        _ctr96, status="Gate out",
        gate_out="20-SEP-26 09.15.00 AM", position="Gate Out")
    _o = ENG.track_all(bl="MBAQITS8502261016")
    _r = _o["result"]
    chk("veto: 3c gate-out tasdeeq -> Delivered barqarar",
        _r.get("status") == "Released — Delivered"
        and _r.get("truck") == "delivered"
        and _r.get("position") == "OUT",
        f"({_r.get('status')} / {_r.get('position')})")
    # doosre cycle ka container record veto nahi kar sakta
    ENG.track_qict_container_layer = lambda c: dict(
        _ctr96, status="Discharged at QICT",
        vir="PKBQMQICT_010126000000")
    _o = ENG.track_all(bl="MBAQITS8502261016")
    _r = _o["result"]
    chk("veto: doosre cycle (alag VIR) ka saboot veto nahi karta",
        _r.get("status") == "Released — Delivered",
        f"({_r.get('status')})")
finally:
    for _n, _f in _orig96.items():
        setattr(ENG, _n, _f)
# partial: ek dabba out, ek yard mein -> na Delivered na
# Discharged — 'Partially discharged', aur reconcile use
# dobara upar nahi utha sakta
_ev96 = {}
ENG._ctn_evidence_add(_ev96, "BOXA1111111", {
    "found": True, "status": "Gate out",
    "gate_out": "20-SEP-26 09.15.00 AM", "position": "Gate Out",
    "vir": "PKKHIKICT_111026105443",
    "discharge_time": "17-SEP-2026 11:47"})
ENG._ctn_evidence_add(_ev96, "BOXB2222222", {
    "found": True, "status": "Discharged at KICT",
    "discharge_time": "18-SEP-2026 08:00",
    "vir": "PKKHIKICT_111026105443"})
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered",
          "gate_out": "20-SEP-26 09.15.00 AM",
          "discharge_time": "17-SEP-2026 11:47",
          "terminal": "KICT", "vir": "PKKHIKICT_111026105443",
          "containers": ["BOXA1111111", "BOXB2222222"]}
ENG._apply_container_veto(_res96, _ev96)
ENG._reconcile_status(_res96)
chk("veto partial: ek out + ek yard -> 'Partially discharged'",
    _res96.get("status") == "Partially discharged"
    and _res96.get("truck") != "delivered"
    and not _res96.get("gate_out")
    and ENG.status_stage(_res96) == 3,
    f"({_res96.get('status')} / {_res96.get('position')})")
# koi by-container saboot hi na ho to asal Delivered mehfooz
# (269665315 ki asal surat: Ctr-Inq par record hi nahi)
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "terminal": "QICT",
          "containers": ["TCNU1213916"]}
ENG._apply_container_veto(_res96, {})
chk("veto: saboot na ho to asal Delivered barqarar (269665315)",
    _res96.get("status") == "Released — Delivered"
    and _res96.get("truck") == "delivered")
# lekin 269665315 par asal khatra dohra hai: Ctr-Inq kabhi
# purana discharge record de deti hai — wahan veto is liye
# nahi lagta ke dabba us ke baad AGLE safar par load ho
# chuka hota hai (SAPT record: 'Loaded on Vessel'); purana
# discharge ab yard ki halat nahi raha.
_ev96 = {}
ENG._ctn_evidence_add(_ev96, "TCNU1213916", {
    "found": True, "status": "Discharged at QICT",
    "discharge_time": "30-JUL-2026 17:36",
    "vir": "PKBQMQICT_260726004914"})
ENG._ctn_evidence_add(_ev96, "TCNU1213916", {
    "found": True, "position": "Loaded on Vessel",
    "vir": "PKKHISAPT_020926135001"})
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "terminal": "QICT",
          "vir": "PKBQMQICT_260726004914",
          "discharge_time": "30-JUL-2026 17:36",
          "containers": ["TCNU1213916"]}
ENG._apply_container_veto(_res96, _ev96)
chk("veto: agle safar par load dabba purane discharge par veto nahi",
    _res96.get("status") == "Released — Delivered"
    and _res96.get("truck") == "delivered")
# terminal rows mein 'N/A' gate-out asal gate-out NAHI —
# tareekh parse karna lazmi hai (warna yard wala dabba
# 'out' ban jata hai aur veto ruk jata hai)
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "terminal": "KICT",
          "vir": "PKKHIKICT_111026105443",
          "containers": ["BOXC3333333"],
          "terminal_rows": [{
              "CONTAINER NO": "BOXC3333333",
              "DISCHARGING TIME": "17-SEP-26 11.47.00 AM",
              "GATE OUT TIME": "N/A"}]}
ENG._apply_container_veto(_res96, {})
chk("veto rows: 'N/A' gate-out par yard saboot jeet-ta hai",
    _res96.get("status") == "Discharged at KICT"
    and _res96.get("position") == "In Yard"
    and _res96.get("truck") != "delivered",
    f"({_res96.get('status')} / {_res96.get('position')})")

print("== Proof-run SF-1: voyage ka harf na gire ==")
_m = server._merge_result(
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "W151"},
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "151"})
chk("merge SF-1: bare-digit fresh purane W151 ko nahi dabata",
    _m["voyage"] == "W151")
_m = server._merge_result(
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "W151"},
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "152"})
chk("merge SF-1: digits badlein to naya voyage hi chalta hai",
    _m["voyage"] == "152")
_m = server._merge_result(
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "631W"},
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "631"})
chk("merge SF-1: digit-first purana + bare fresh -> W631",
    _m["voyage"] == "W631")

print("== Profile: naam + photo (v96) ==")
# In-process HTTP round-trip: test HOME par asal handler chala kar
# endpoint ka poora chakkar — naam settings mein, photo DATA_DIR ki
# file mein, bahar sirf flag (data-URI kabhi nahi).
import base64 as _b64, json as _json, threading as _th
import urllib.request as _u, urllib.error as _ue
from http.server import ThreadingHTTPServer as _THS
_srv = _THS(("127.0.0.1", 0), server.H)
_th.Thread(target=_srv.serve_forever, daemon=True).start()
_B = f"http://127.0.0.1:{_srv.server_address[1]}"
def _call(method, path, body=None):
    req = _u.Request(_B + path, method=method,
                     data=_json.dumps(body).encode() if body is not None
                     else None,
                     headers={"Content-Type": "application/json"})
    try:
        with _u.urlopen(req, timeout=10) as r:
            return r.status, r.read(), r.headers.get("Content-Type") or ""
    except _ue.HTTPError as e:
        return e.code, e.read(), e.headers.get("Content-Type") or ""
_PNG1 = ("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8"
         "Xw8AAwMCAO+ip1sAAAAASUVORK5CYII=")
_png_bytes = _b64.b64decode(_PNG1)
st, _, _ = _call("GET", "/profile/photo")
chk("profile: photo na ho to 404", st == 404)
st, _, _ = _call("POST", "/api/settings", {"profile_name": "Test Name"})
_pub = server._public_settings()
chk("profile: naam settings mein + public mein",
    st == 200 and _pub.get("profile_name") == "Test Name")
chk("profile: photo flag pehle False", _pub.get("profile_photo_set") is False)
st, r, _ = _call("POST", "/api/profile/photo", {"data": _PNG1})
chk("profile: photo POST ok + flag",
    st == 200 and _json.loads(r).get("profile_photo_set") is True)
st, r, ct = _call("GET", "/profile/photo")
chk("profile: photo GET — wahi bytes, image/png",
    st == 200 and r == _png_bytes and "image/png" in ct)
st, r, _ = _call("GET", "/api/history")
_set = _json.loads(r)["settings"]
chk("profile: settings jawab mein flag hai, data-URI NAHI",
    _set.get("profile_photo_set") is True
    and "data:image" not in _json.dumps(_set))
st, _, _ = _call("POST", "/api/profile/photo",
                 {"data": _b64.b64encode(b"ye image nahi hai").decode()})
chk("profile: ghair-image reject (400)", st == 400)
st, r, _ = _call("POST", "/api/profile/photo", {"remove": True})
st2, _, _ = _call("GET", "/profile/photo")
chk("profile: remove ke baad 404 + flag False",
    st == 200 and st2 == 404
    and server._public_settings().get("profile_photo_set") is False)
_call("POST", "/api/settings", {"profile_name": "X" * 120})
chk("profile: naam 80 harf par kata (sanitize)",
    len(server._public_settings().get("profile_name") or "") == 80)
_srv.shutdown()

print(f"\nMAJMUA: {ok} PASS, {fail} FAIL")
sys.exit(1 if fail else 0)
