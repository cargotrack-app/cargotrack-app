# -*- coding: utf-8 -*-
"""CargoTrack regression tests (v79) — chalane ka tareeqa:
    HOME=<koi test home> python3 tests_regression.py
Har test ka asal output print hota hai; aakhir mein PASS/FAIL
gin-ti. Ye file is liye hai taake test sirf report mein na
rahen — koi bhi dobara chala kar wohi natija dekh sake."""
import sys, time
sys.path.insert(0, ".")
import server

ok = fail = 0
def chk(label, cond, extra=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"PASS {label} {extra}")
    else:
        fail += 1
        print(f"FAIL {label} {extra}")

print("== Context: aam sawal par data NAHI ==")
for q in ["call me", "small talk karo", "Photosynthesis kya hai?",
          "what is AI?", "everything theek hai?", "listen to me",
          "sabar karo", "hold on a second", "weather in Lahore"]:
    chk(f"context khali {q!r}", server._assistant_context_for(q) == "")

print("== Context: list sawal par POORA data ==")
for q in ["show all shipments", "sab shipments ki list do",
          "Which shipments are on hold?", "What is arriving this week?"]:
    n = len(server._assistant_context_for(q))
    chk(f"context poora {q!r}", n > 1000, f"(len {n})")

c = server._assistant_context_for("142G513366 ka status batao", "142G513366")
chk("BL-only context", "142G513366" in c and "274094021" not in c,
    f"(len {len(c)})")

print("== Data-sawal pehchan ==")
for q, want in [("give me the details", False),
                ("ye important baat hai", False),
                ("customer care number do", False),
                ("train ka time kya hai", False),
                ("142G513366 ka status batao", True),
                ("holds batao", True), ("vessel kab ayegi", True),
                ("mosam kesa hai", False)]:
    chk(f"looks_data {q!r}={want}", server._looks_data_q(q) == want)

print("== Local branches (had ke baad bhi zinda) ==")
def loc(q):
    return (server._assistant_local(q) or {}).get("answer") or ""
chk("photosynthesis par OCR jawab nahi",
    "Photo scanning" not in loc("Photosynthesis kya hai?"))
chk("system health", "System health" in loc("system ki halat kesi hai"))
chk("holds branch", len(loc("konsi shipments hold par hain")) > 60)
chk("thank branch", "welcome" in loc("thank you").lower())
chk("identity branch", "CargoTrack assistant" in loc("tum kon ho"))
chk("payment branch", "pending" in loc("payment pending kitna hai").lower())

print("== Weather ==")
a = server._weather_answer("Lahore ka mosam kesa hai")
chk("Lahore only", bool(a) and a.startswith("Lahore ka mosam"), )
a = server._weather_answer("Mardan ka batabo mosam")
chk("Mardan only", bool(a) and a.startswith("Mardan ka mosam"))
a = server._weather_answer("Lahore aur Mardan mein aaj barish ka imkaan hai?")
chk("Lahore+Mardan", bool(a) and "Lahore:" in a and "Mardan:" in a)
a = server._weather_answer("Lahore aur Xyzabc ka mosam batao")
chk("known+unknown", bool(a) and "Lahore" in a and "nahi mil saka" in a)
a = server._weather_answer("Xyzabc ka mosam batao")
chk("unknown only (koi number nahi)", bool(a) and "°C" not in a)
a = server._weather_answer("Barish kaha ho sakti hy kis city me")
chk("barish panel", bool(a) and a.count(":") >= 8)
chk("train par weather nahi",
    server._weather_answer("train ka time kya hai") is None)

import urllib.request, urllib.error, json as _j
class FakeResp:
    def __init__(self, payload): self._p = payload
    def __enter__(self): return self
    def __exit__(self, *x): return False
    def read(self): return _j.dumps(self._p).encode()
_orig = urllib.request.urlopen
def fake_missing(url, timeout=0):
    if "geocoding" in str(url):
        return FakeResp({"results": [{"latitude": 31.5,
                                       "longitude": 74.3,
                                       "timezone": "Asia/Karachi",
                                       "name": "Lahore"}]})
    return FakeResp({"current": {}, "daily": {}})
urllib.request.urlopen = fake_missing
try:
    a = server._weather_answer("Lahore ka mosam kesa hai")
finally:
    urllib.request.urlopen = _orig
chk("missing fields -> imaandar jawab", bool(a) and "nahi mil sakin" in a)

def fake_down(url, timeout=0):
    raise TimeoutError("simulated timeout")
urllib.request.urlopen = fake_down
try:
    a = server._weather_answer("Karachi ka mosam kesa hai")
finally:
    urllib.request.urlopen = _orig
chk("API timeout -> imaandar jawab", bool(a) and "nahi mil sakin" in a)

print("== Provider nakami ki simulation (429 Groq + 503 Gemini) ==")
server._groq_key = lambda: "gsk_dummy_sim"
server._ai_key_single = lambda: "AIzaDummySim"
def fake_providers(url, timeout=0):
    u = str(getattr(url, "full_url", url))
    if "groq.com" in u:
        raise urllib.error.HTTPError(u, 429, "rate limit", {}, None)
    if "googleapis.com" in u:
        raise urllib.error.HTTPError(u, 503, "overloaded", {}, None)
    return _orig(url, timeout=timeout)
urllib.request.urlopen = fake_providers
t0 = time.time()
try:
    out = server.assistant_answer("Duniya ka sab se bara samandar konsa hai?", [])
finally:
    urllib.request.urlopen = _orig
secs = time.time() - t0
chk("429+503 par jhoota jawab nahi",
    out.get("mode") != "ai" and bool(out.get("ai_error") or out.get("mode")),
    f"(mode {out.get('mode')}, {secs:.0f}s mein band)")
chk("nakami ki wajah note mein hai", bool(out.get("ai_note")))

print("== Empty-return presumption (user's 2+ day rule, v96) ==")
from datetime import datetime as _dt96, timedelta as _td96, \
    timezone as _tz96
_today96 = _dt96.now(_tz96(_td96(hours=5))).date()
def _go96(days_ago):
    d = _today96 - _td96(days=days_ago)
    return d.strftime("%d-%b-%y").upper() + " 06.38.19 PM"
def _rec96(days_ago, returned=False, blob=""):
    return {"query": "TESTBL96", "found": True, "returned": returned,
            "result": {"gate_out": _go96(days_ago), "status": "Gate out"},
            "layers": ([{"name": "Terminal", "detail": blob}]
                       if blob else [])}
chk("presumed: 5d gate-out, no return record",
    server._lifecycle(_rec96(5))["empty"] == "presumed")
chk("presumed ki grade estimate hai",
    server._lifecycle(_rec96(5))["empty_certainty"] == "estimate")
chk("presumed: 3d gate-out",
    server._lifecycle(_rec96(3))["empty"] == "presumed")
chk("pending: theek 2d gate-out (rule se bahar)",
    server._lifecycle(_rec96(2))["empty"] == "pending")
chk("pending: 1d gate-out",
    server._lifecycle(_rec96(1))["empty"] == "pending")
chk("asal return presumption par jeet-ta hai (manual mark)",
    server._lifecycle(_rec96(9, returned=True))["empty"] == "returned")
chk("asal return presumption par jeet-ta hai (layer text)",
    server._lifecycle(_rec96(9, blob="Empty returned to terminal"))["empty"]
    == "returned")

print("== Merge guards (v96 data audit: downgrade + cross-cycle) ==")
ENG = server.ENG
chk("stage: Delivered text = 5",
    ENG.status_text_stage("Released — Delivered") == 5)
chk("stage: Gate out text = 4", ENG.status_text_stage("Gate out") == 4)
chk("stage: Discharged text = 3",
    ENG.status_text_stage("Discharged at QICT") == 3)
chk("stage: Expected text <= 1",
    ENG.status_stage({"status": "Expected at QICT — on X, still at sea"})
    <= 1)
chk("stage: saboot jeet-ta hai (OUT + truck delivered = 5)",
    ENG.status_stage({"status": "Discharged at QICT", "position": "OUT",
                      "truck": "delivered"}) == 5)
_r = ENG._reconcile_status({"status": "Discharged at QICT",
                            "position": "OUT", "truck": "delivered",
                            "terminal": "QICT"})
chk("reconcile: khud-takrari fresh result Delivered banta hai",
    _r["status"] == "Released — Delivered")
_r = ENG._reconcile_status({"status": "Partially discharged",
                            "gate_out": "22-OCT-26 04.50.06 PM"})
chk("reconcile: gate_out saboot -> 'Gate out'",
    _r["status"] == "Gate out")
_r = ENG._reconcile_status({"status": "On hold at QICT",
                            "position": "OUT", "truck": "delivered"})
chk("reconcile: hold status ko haath nahi lagta",
    _r["status"] == "On hold at QICT")

_old269 = {"status": "Released — Delivered", "position": "OUT",
           "truck": "delivered", "discharge_time": "30-JUL-2026 17:36",
           "vir": "PKBQMQICT_260726004914", "vessel": "GSL ROSSI",
           "voyage": "631W", "terminal": "QICT"}
_new269 = dict(_old269, status="Discharged at QICT", speed="0.2 knots")
_m = server._merge_result(dict(_old269), dict(_new269))
chk("merge: 269665315 Delivered mehfooz",
    _m["status"] == "Released — Delivered" and _m["position"] == "OUT")
chk("merge: voyage canonical (631W -> W631)", _m["voyage"] == "W631")

_oldSS = {"status": "Gate out", "position": "Gate Out",
          "gate_out": "05-SEP-26 05.30.16 PM",
          "discharge_time": "01-SEP-26 11.52.04 PM",
          "vir": "PKKHISAPT_240826012013", "vessel": "DELPHINUS C",
          "voyage": "0112", "terminal": "SAPT", "eta": "01 Sep 2026"}
_newSS = {"status": "Arrived at Karachi terminal",
          "position": "Loaded on Vessel", "vessel": "KMTC MOMBASA",
          "voyage": "E2605", "eta": "26 Sep 2026"}
_m = server._merge_result(dict(_oldSS), dict(_newSS))
chk("merge: agla cycle mukammal record ko nahi dabata (SSLSU)",
    _m["vessel"] == "DELPHINUS C" and _m["status"] == "Gate out"
    and _m["gate_out"] == "05-SEP-26 05.30.16 PM")

_oldPAL = {"status": "Gate out", "position": "Gate Out",
           "gate_out": "09-SEP-26 10.35.11 AM",
           "discharge_time": "27-AUG-26 05.19.05 PM",
           "vir": "PKKHIKICT_210826122038", "vessel": "OOCL LE HAVRE",
           "voyage": "209", "terminal": "KICT", "eta": "27 Aug 2026"}
_newPAL = {"status": "In transit", "position": "Loaded on Vessel",
           "vessel": "OOCL DALIAN", "voyage": "722",
           "eta": "14 Oct 2026"}
_m = server._merge_result(dict(_oldPAL), dict(_newPAL))
chk("merge: doosri BL ki sailing pehchan nahi badal sakti (PAL)",
    _m["vessel"] == "OOCL LE HAVRE" and _m["status"] == "Gate out")

_oldS49 = {"status": "Gate out", "position": "Gate Out",
           "gate_out": "12-SEP-26 11.47.19 AM",
           "discharge_time": "05-SEP-26 02.26.47 AM",
           "vir": "PKKHIKICT_310826104443", "vessel": "OOCL DALIAN",
           "voyage": "721", "terminal": "KICT"}
_newS49 = {"status": "Partially discharged", "position": "In Yard",
           "vessel": "OOCL DALIAN", "voyage": "721",
           "terminal": "KICT"}
_m = server._merge_result(dict(_oldS49), dict(_newS49))
chk("merge: proven Gate out -> 'Partially discharged' nahi (S490321128)",
    _m["status"] == "Gate out"
    and _m["gate_out"] == "12-SEP-26 11.47.19 AM")

_old16 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "discharge_time": "17-SEP-2026 11:47",
          "vir": "PKBQMQICT_140926131731", "vessel": "BSG BIMINI",
          "voyage": "638W", "terminal": "QICT"}
_new16 = {"status": "Discharged at QICT", "position": "In Yard",
          "discharge_time": "17-SEP-2026 11:47",
          "vir": "PKBQMQICT_140926131731", "vessel": "BSG BIMINI",
          "voyage": "638W", "terminal": "QICT"}
_m = server._merge_result(dict(_old16), dict(_new16))
chk("merge: apne cycle ka yard saboot jhooti Delivered sudharta hai (1016)",
    _m["status"] == "Discharged at QICT" and _m["position"] == "In Yard")
_new16b = dict(_new16, position="OUT")
_m = server._merge_result(dict(_old16), dict(_new16b))
chk("merge: yard saboot ke baghair correction nahi hoti",
    _m["status"] == "Released — Delivered")

print("== v98 S2: 59055 — QICT BL-mode khaali + Ctr-Inq sirf discharge ==")
# Asal waqia (29 Oct 2026, 17:40): stored record 'Released —
# Delivered' (position OUT, truck delivered) tha. Taza check
# mein QICT BL-mode gate-out ke baad khaali mili aur Ctr-Inq
# ne sirf discharge diya (position/gate_out us leg par kabhi
# hota hi nahi — wo discharge gate-out ke baad bhi rehta
# hai). Engine ke veto ne khaali position par 'In Yard'
# GHAR liya, merge ke _own_cycle_correction ne use yard
# saboot maan kar Delivered ko 'Discharged at QICT' par
# peeche kar diya aur _record ne status-change stamp laga
# diya. Ab: aisi fresh shakal final record ko NAHI chhu
# sakti; asal yard POSITION wala correction (1016, oper)
# ab bhi chalta hai.
_old55 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered",
          "discharge_time": "13-OCT-2026 16:59",
          "vir": "PKBQMQICT_051026131058", "vessel": "SLS TOPAZ",
          "voyage": "642S", "terminal": "QICT",
          "containers": ["FFAU2343188"]}
_new55 = {"status": "Discharged at QICT",
          "discharge_time": "13-OCT-2026 16:59",
          "vir": "PKBQMQICT_051026131058", "vessel": "SLS TOPAZ",
          "voyage": "642S", "terminal": "QICT",
          "containers": ["FFAU2343188"]}
_m = server._merge_result(dict(_old55), dict(_new55))
chk("merge v98: 59055 Delivered mehfooz (Ctr-Inq discharge-only)",
    _m["status"] == "Released — Delivered"
    and _m["position"] == "OUT" and _m["truck"] == "delivered",
    f"({_m['status']} / {_m['position']})")
_new55b = dict(_new55, status="Discharged at QICT — in yard")
_m = server._merge_result(dict(_old55), dict(_new55b))
chk("merge v98: status text ka 'yard' akela correction nahi kholta",
    _m["status"] == "Released — Delivered")
_res55 = {"status": "Released — Delivered", "position": "",
          "truck": "delivered", "terminal": "QICT",
          "vir": "PKBQMQICT_051026131058",
          "discharge_time": "13-OCT-2026 16:59",
          "containers": ["FFAU2343188"]}
_ev55 = {"FFAU2343188": {"out": False, "in_yard": True,
                         "virs": {"PKBQMQICT_051026131058"},
                         "status": "Discharged at QICT",
                         "position": ""}}
ENG._apply_container_veto(_res55, _ev55)
chk("veto v98: khaali position par 'In Yard' NAHI ghara jata",
    (_res55.get("position") or "") == "",
    f"(position={_res55.get('position')!r})")

print("== v98 S1: profile naam + tareekh AI context mein ==")
_pl = server._profile_line()
_nm = str(server.get_settings().get("profile_name") or "").strip()
chk("profile line: naam prompt mein hai ya saaf 'saved nahi'",
    (_nm and _nm in _pl) or (not _nm and "no name is saved" in _pl))
_body = server._gemini_body("mera naam kya hai?", [], "")
_sys = _body["systemInstruction"]["parts"][0]["text"]
chk("gemini prompt: TODAY'S DATE + profile + web-honesty rule",
    "TODAY'S DATE:" in _sys and "USER PROFILE:" in _sys
    and "never cite 'web results'" in _sys)
chk("wx hit: 'temperature' bhi mosam ka sawal hai",
    server._wx_hit("aaj temperature kya hai")
    and server._wx_hit("Lahore ka mosam kesa hai"))
a = server._weather_answer("Karachi mein barish kahan ho sakti hai")
chk("where-rain: sheher ke naam ke bawajood single-city card NAHI",
    bool(a) and "barish ka chance" in a
    and "ka mosam (abhi)" not in a)

print("== Live-layer saboot (v96 data audit FIX 2) ==")
chk("live: sirf identification done = live nahi",
    server._live_data_layers(
        [{"name": "Layer 0 — Carrier identification",
          "status": "done"}]) == [])
chk("live: QICT data layer done = live",
    len(server._live_data_layers(
        [{"name": "Layer 3b — QICT (DP World Karachi)",
          "status": "done"}])) == 1)
chk("live: manual-check done = live nahi",
    server._live_data_layers(
        [{"name": "Layer 3g — Hutchison Portal (manual check)",
          "status": "done"}]) == [])
chk("live: fail layers live nahi",
    server._live_data_layers(
        [{"name": "Layer 3b — QICT (DP World Karachi)",
          "status": "fail"}]) == [])

print("== Round 2: terminal pehchan VIR se (FIX A) ==")
chk("vir_terminal: QICT", ENG.vir_terminal("PKBQMQICT_030826132505") == "QICT")
chk("vir_terminal: KICT", ENG.vir_terminal("PKKHIKICT_310826105637") == "KICT")
chk("vir_terminal: SAPT", ENG.vir_terminal("PKKHISAPT_080926021505") == "SAPT")
chk("vir_terminal: KGTL", ENG.vir_terminal("PKKHIKGTL_210826165034") == "KGTL")
chk("vir_terminal: khaali -> None", ENG.vir_terminal("") is None)
_oldA = {"status": "Released — Delivered", "terminal": "QICT",
         "vir": "PKBQMQICT_030826132505", "source": "QICT (DP World)",
         "discharge_time": "11-AUG-2026 21:20", "position": "OUT",
         "truck": "delivered", "vessel": "SLS TOPAZ", "voyage": "642S"}
_newA = {"status": "Arrived at Karachi terminal", "terminal": "SAPT",
         "vir": "PKBQMQICT_030826132505",
         "source": "Karachi Terminal (Hutchison Ports)",
         "position": "Loaded on Vessel", "etd": "09 Sep 2026"}
_m = server._merge_result(dict(_oldA), dict(_newA))
chk("merge FIX A: wahi VIR -> terminal SAPT nahi banta (59009)",
    _m["terminal"] == "QICT")
_m = server._merge_result(
    {"status": "Discharged at SAPT", "terminal": "SAPT",
     "vir": "PKBQMQICT_030826132505",
     "discharge_time": "11-AUG-2026 21:20"}, {})
chk("merge FIX A: status ke andar ka 'at SAPT' bhi VIR se sudharta hai",
    _m["status"] == "Discharged at QICT" and _m["terminal"] == "QICT")
_r = ENG._reconcile_status({"status": "Discharged at SAPT",
                            "terminal": "SAPT",
                            "vir": "PKBQMQICT_030826132505",
                            "discharge_time": "11-AUG-2026 21:20"})
chk("reconcile FIX A: fresh synthesis ka terminal VIR se milta hai",
    _r["terminal"] == "QICT")
_r = ENG._reconcile_status({"status": "Arrived", "vir": "PKKHISAPT_1"})
chk("reconcile FIX A: terminal khaali ho to VIR se bhar jata hai",
    _r["terminal"] == "SAPT")

print("== Round 2: pakki maloomat kabhi nahi mit-ti (FIX B) ==")
_oldB = {"status": "In transit — departed Shekou 09 Oct 2026",
         "terminal": "SAPT", "source": "COSCO Shipping (API)",
         "eta": "26 Oct 2026", "vessel": "APL CHONGQING"}
_newB = {"status": "Arrived", "terminal": "SAPT", "source": "COSCO API",
         "eta": "26 Oct 2026", "vessel": "APL CHONGQING"}
_m = server._merge_result(dict(_oldB), dict(_newB))
chk("merge FIX B: departed tareekh 'Arrived' par bhi mehfooz",
    _m.get("departed") == "09 Oct 2026")
_ms = server._milestones({"result": _m, "layers": [
    {"name": "Layer 1 — COSCO API", "status": "done"}]})
_dep = [x for x in _ms if x["key"] == "departed"][0]
chk("milestone FIX B: departed wahi tareekh dikhata hai",
    _dep["state"] == "done" and _dep["when"] == "09 Oct 2026")
_r = ENG._reconcile_status(
    {"status": "In transit — departed Shekou 09 Oct 2026"})
chk("reconcile FIX B: departed field synthesis par hi banta hai",
    _r.get("departed") == "09 Oct 2026")
_m = server._merge_result({"departed": "09 Oct 2026",
                           "status": "Arrived"},
                          {"status": "Discharged"})
chk("merge FIX B: departed field naye text par bhi nahi mit-ta",
    _m.get("departed") == "09 Oct 2026")
_oldP = {"status": "On hold at KICT — loaded on vessel",
         "terminal": "KICT", "vir": "PKKHIKICT_191026105443",
         "source": "KICT Trade Portal (Hutchison) — verified by "
                   "Shezi, 27 Oct 2026 5:23 PM",
         "position": "Loaded On Vessel"}
_newP = {"status": "Discharged", "terminal": "KICT",
         "vir": "PKKHIKICT_191026105443",
         "source": "Karachi Terminal (Hutchison Ports)",
         "discharge_time": "27-OCT-26 05.23.27 PM",
         "position": "In Yard"}
_m = server._merge_result(dict(_oldP), dict(_newP))
chk("merge FIX B: 'verified by Shezi' provenance mehfooz",
    "verified by Shezi" in (_m.get("source") or ""))
_oldX = {"status": "Partially discharged", "terminal": "KICT",
         "vir": "PKKHIKICT_051026114110",
         "gate_out": "24-OCT-26 09.27.08 PM",
         "discharge_time": "2026-10-12 01:04", "position": "Gate Out"}
_m = server._merge_result(dict(_oldX), {"status": "Arrived at Karachi "
                                         "terminal",
                                         "position": "Loaded on Vessel"})
chk("merge FIX B: kamzor re-check par bhi 'Partially' nahi chipakta",
    _m["status"] == "Gate out")
_m = server._merge_result(dict(_oldX), {})
chk("merge FIX B: read par hi 'Partially discharged' sudhar jata hai",
    _m["status"] == "Gate out")
_m = server._merge_result(
    {"status": "Partially discharged",
     "discharge_time": "2026-10-12 01:04"}, {})
chk("merge FIX B: gate-out saboot na ho to 'Partially' barqarar",
    _m["status"] == "Partially discharged")

print("== Round 2: v96 enrich corrections (populated HOME par) ==")
_hist = {e.get("query"): e for e in server.get_history()}
_e = _hist.get("MBAQITS8502261016") or {}
_r = _e.get("result") or {}
chk("enrich: 1016 jhooti Delivered -> Discharged/In Yard",
    _r.get("status") == "Discharged at QICT"
    and _r.get("position") == "In Yard" and not _r.get("gate_out"),
    f"({_r.get('status')} / {_r.get('position')})")
_e = _hist.get("EMKAYMBAKHI59055") or {}
_r = _e.get("result") or {}
chk("enrich: 59055 container + hold khatam",
    _r.get("containers") == ["FFAU2343188"]
    and "hold" not in (_r.get("status") or "").lower()
    and not _r.get("gate_out"),
    f"({_r.get('status')} / {_r.get('containers')})")
_e = _hist.get("COAU6464740334") or {}
_r = _e.get("result") or {}
chk("enrich: 6464740334 gate-out stamped, Partially khatam",
    _r.get("gate_out") == "17-OCT-26 06.56.35 PM"
    and _r.get("status") == "Gate out" and _e.get("returned") is True)
_e = _hist.get("EMKAYMBAKHI59009") or {}
chk("enrich: 59009 empty return darj", _e.get("returned") is True)

print("== Data Doctor (v96): pehchaan, sahi karna, report ==")
import time as _tdd
# 1) terminal != VIR -> auto-correct + log; voyage bhi canonical
_bad = {"query": "TESTDD1", "found": True, "mode": "bl",
        "result": {"status": "Discharged at SAPT",
                   "terminal": "SAPT",
                   "vir": "PKBQMQICT_030826132505",
                   "voyage": "631W",
                   "discharge_time": "11-AUG-2026 21:20"}}
_c, _f = server._doctor_check_entry(_bad, {}, _tdd.time())
chk("doctor: terminal VIR se khud sudhra (SAPT->QICT)",
    _bad["result"]["terminal"] == "QICT")
chk("doctor: terminal correction LOG huwi",
    any(c["rule"] == "terminal-vir" and c["field"] == "terminal"
        for c in _c))
chk("doctor: status ke andar ka 'at SAPT' bhi sudhra",
    _bad["result"]["status"] == "Discharged at QICT")
chk("doctor: voyage canonical (631W -> W631)",
    _bad["result"]["voyage"] == "W631")
# 2) jhooti Delivered wali shakal -> FINDING, rewrite NAHI
_fd = {"query": "TESTDD2", "found": True, "mode": "bl",
       "result": {"status": "Released — Delivered",
                  "position": "In Yard",
                  "discharge_time": "17-SEP-2026 11:47",
                  "vir": "PKBQMQICT_140926131731",
                  "terminal": "QICT"}}
_c, _f = server._doctor_check_entry(_fd, {}, _tdd.time())
chk("doctor: jhooti Delivered -> finding banti hai",
    any(f["rule"] == "false-delivered-suspect" for f in _f))
chk("doctor: jhooti Delivered ko rewrite NAHI kiya",
    _fd["result"]["status"] == "Released — Delivered"
    and not any(c["field"] == "status" for c in _c))
# 3) 'Partially discharged' + mukammal gate-out saboot -> Gate out
_pg = {"query": "TESTDD3", "found": True, "mode": "bl",
       "result": {"status": "Partially discharged",
                  "gate_out": "24-OCT-26 09.27.08 PM",
                  "discharge_time": "2026-10-12 01:04",
                  "terminal": "KICT",
                  "vir": "PKKHIKICT_051026114110"}}
_c, _f = server._doctor_check_entry(_pg, {}, _tdd.time())
chk("doctor: Partially + gate-out saboot -> 'Gate out'",
    _pg["result"]["status"] == "Gate out"
    and any(c["rule"] == "status-evidence" for c in _c))
# 4) shared container -> finding (auto-fix kabhi nahi)
_sh = {"TESTDD4A": ["MSKU1234567"], "TESTDD4B": ["MSKU1234567"]}
_e4 = {"query": "TESTDD4A", "found": True, "mode": "bl",
       "result": {"status": "In transit",
                  "containers": ["MSKU1234567"]}}
_c, _f = server._doctor_check_entry(
    _e4, {"MSKU1234567": ["TESTDD4A", "TESTDD4B"]}, _tdd.time())
chk("doctor: shared container finding, koi correction nahi",
    any(f["rule"] == "shared-container" for f in _f) and _c == [])
# 5) dedupe: wahi finding dobara alert nahi; values badlein to naya
_f1 = [{"id": "dd_testdedupe", "query": "TESTDD5",
        "rule": "stuck-nonfinal", "severity": "medium",
        "detail": "d", "time": "t"}]
_r1 = server._doctor_update_report({}, _f1, [], 1, 1000.0)
chk("doctor: pehli sweep — finding queue mein gayi",
    len(_r1["shezi_queue"]) == 1)
_r2 = server._doctor_update_report(_r1, _f1, [], 1, 2000.0)
chk("doctor: wahi finding dobara alert NAHI (dedupe)",
    len(_r2["shezi_queue"]) == 1)
_f2 = [dict(_f1[0], id="dd_testdedupe2")]
_r3 = server._doctor_update_report(_r2, _f2, [], 1, 3000.0)
chk("doctor: values badlein to naya alert banta hai",
    len(_r3["shezi_queue"]) == 2)
# 6) populated HOME par mukammal sweep + report file
_rep = server._doctor_run("test")
chk("doctor: report file DATA_DIR mein bana",
    server.DOCTOR_FILE.exists())
chk("doctor: tamam stored records sweep huwe",
    _rep["records"] == len(server.get_history()),
    f"(records {_rep['records']}, findings "
    f"{len(_rep['findings'])}, corrections "
    f"{len(_rep['corrections'])})")
_pub = server._doctor_public(_rep)
chk("doctor: public payload — findings/corrected alag + alerts",
    _pub["needs_shezi"] == _pub["findings"]
    and isinstance(_pub["corrected"], list)
    and len(_pub["alerts"]) == min(60, len(_pub["findings"])))
chk("doctor: email set na ho to jhoota 'sent' nahi — queue sach",
    _pub["queued"] == bool(_rep.get("shezi_queue")))

print("== Proof-run fix: container saboot ka veto (case 3) ==")
# Asal nakami (live sabit): QICT BL-inquiry (3b) jhoota
# 'Released — Delivered' + truck delivered kehti hai, jabke
# by-container leg (3c, Ctr-Inq) usi cycle ka discharge dikhati
# hai aur gate-out ka koi saboot nahi — dabba yard mein hai.
# Merge guard sirf downgrade rokta tha; ye ghalat upgrade
# synthesis ke andar hi rukna chahiye.
_orig96 = {n: getattr(ENG, n) for n in (
    "track_bol_tracktrace", "track_karachi_terminals",
    "track_qict_bl", "track_kgtl_bl",
    "track_qict_container_layer",
    "track_karachi_terminals_container",
    "track_kgtl_container", "vessel_live_position")}
_nf96 = lambda *a, **k: {"found": False}
_claim96 = {"found": True, "terminal": "QICT",
            "source": "QICT (DP World)",
            "containers": ["MRKU8740840"],
            "status": "Released — Delivered",
            "position": "OUT", "truck": "delivered",
            "vir": "PKBQMQICT_140926131731",
            "vessel": "BSG BIMINI", "voyage": "638W",
            "discharge_time": "17-SEP-2026 11:47"}
_ctr96 = {"found": True, "terminal": "QICT",
          "source": "QICT (DP World)",
          "containers": ["MRKU8740840"],
          "discharge_time": "17-SEP-2026 11:47",
          "vir": "PKBQMQICT_140926131731",
          "vessel": "BSG BIMINI", "voyage": "638W"}
try:
    for _n, _f in (("track_bol_tracktrace", _nf96),
                   ("track_karachi_terminals", _nf96),
                   ("track_kgtl_bl", _nf96),
                   ("track_karachi_terminals_container", _nf96),
                   ("track_kgtl_container", _nf96),
                   ("vessel_live_position", _nf96),
                   ("track_qict_bl",
                    lambda bl: dict(_claim96))):
        setattr(ENG, _n, _f)
    ENG.track_qict_container_layer = lambda c: dict(
        _ctr96, status="Discharged at QICT")
    _o = ENG.track_all(bl="MBAQITS8502261016")
    _r = _o["result"]
    chk("veto: 3b Delivered vs 3c In Yard -> Discharged rehta hai",
        _r.get("status") == "Discharged at QICT"
        and _r.get("position") == "In Yard"
        and _r.get("truck") != "delivered"
        and not _r.get("gate_out"),
        f"({_r.get('status')} / {_r.get('position')})")
    # genuine: by-container leg gate-out ki tasdeeq kar de to
    # Delivered ka dawa bilkul barqarar
    ENG.track_qict_container_layer = lambda c: dict(
        _ctr96, status="Gate out",
        gate_out="20-SEP-26 09.15.00 AM", position="Gate Out")
    _o = ENG.track_all(bl="MBAQITS8502261016")
    _r = _o["result"]
    chk("veto: 3c gate-out tasdeeq -> Delivered barqarar",
        _r.get("status") == "Released — Delivered"
        and _r.get("truck") == "delivered"
        and _r.get("position") == "OUT",
        f"({_r.get('status')} / {_r.get('position')})")
    # doosre cycle ka container record veto nahi kar sakta
    ENG.track_qict_container_layer = lambda c: dict(
        _ctr96, status="Discharged at QICT",
        vir="PKBQMQICT_010126000000")
    _o = ENG.track_all(bl="MBAQITS8502261016")
    _r = _o["result"]
    chk("veto: doosre cycle (alag VIR) ka saboot veto nahi karta",
        _r.get("status") == "Released — Delivered",
        f"({_r.get('status')})")
finally:
    for _n, _f in _orig96.items():
        setattr(ENG, _n, _f)
# partial: ek dabba out, ek yard mein -> na Delivered na
# Discharged — 'Partially discharged', aur reconcile use
# dobara upar nahi utha sakta
_ev96 = {}
ENG._ctn_evidence_add(_ev96, "BOXA1111111", {
    "found": True, "status": "Gate out",
    "gate_out": "20-SEP-26 09.15.00 AM", "position": "Gate Out",
    "vir": "PKKHIKICT_111026105443",
    "discharge_time": "17-SEP-2026 11:47"})
ENG._ctn_evidence_add(_ev96, "BOXB2222222", {
    "found": True, "status": "Discharged at KICT",
    "discharge_time": "18-SEP-2026 08:00",
    "vir": "PKKHIKICT_111026105443"})
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered",
          "gate_out": "20-SEP-26 09.15.00 AM",
          "discharge_time": "17-SEP-2026 11:47",
          "terminal": "KICT", "vir": "PKKHIKICT_111026105443",
          "containers": ["BOXA1111111", "BOXB2222222"]}
ENG._apply_container_veto(_res96, _ev96)
ENG._reconcile_status(_res96)
chk("veto partial: ek out + ek yard -> 'Partially discharged'",
    _res96.get("status") == "Partially discharged"
    and _res96.get("truck") != "delivered"
    and not _res96.get("gate_out")
    and ENG.status_stage(_res96) == 3,
    f"({_res96.get('status')} / {_res96.get('position')})")
# koi by-container saboot hi na ho to asal Delivered mehfooz
# (269665315 ki asal surat: Ctr-Inq par record hi nahi)
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "terminal": "QICT",
          "containers": ["TCNU1213916"]}
ENG._apply_container_veto(_res96, {})
chk("veto: saboot na ho to asal Delivered barqarar (269665315)",
    _res96.get("status") == "Released — Delivered"
    and _res96.get("truck") == "delivered")
# lekin 269665315 par asal khatra dohra hai: Ctr-Inq kabhi
# purana discharge record de deti hai — wahan veto is liye
# nahi lagta ke dabba us ke baad AGLE safar par load ho
# chuka hota hai (SAPT record: 'Loaded on Vessel'); purana
# discharge ab yard ki halat nahi raha.
_ev96 = {}
ENG._ctn_evidence_add(_ev96, "TCNU1213916", {
    "found": True, "status": "Discharged at QICT",
    "discharge_time": "30-JUL-2026 17:36",
    "vir": "PKBQMQICT_260726004914"})
ENG._ctn_evidence_add(_ev96, "TCNU1213916", {
    "found": True, "position": "Loaded on Vessel",
    "vir": "PKKHISAPT_020926135001"})
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "terminal": "QICT",
          "vir": "PKBQMQICT_260726004914",
          "discharge_time": "30-JUL-2026 17:36",
          "containers": ["TCNU1213916"]}
ENG._apply_container_veto(_res96, _ev96)
chk("veto: agle safar par load dabba purane discharge par veto nahi",
    _res96.get("status") == "Released — Delivered"
    and _res96.get("truck") == "delivered")
# terminal rows mein 'N/A' gate-out asal gate-out NAHI —
# tareekh parse karna lazmi hai (warna yard wala dabba
# 'out' ban jata hai aur veto ruk jata hai)
_res96 = {"status": "Released — Delivered", "position": "OUT",
          "truck": "delivered", "terminal": "KICT",
          "vir": "PKKHIKICT_111026105443",
          "containers": ["BOXC3333333"],
          "terminal_rows": [{
              "CONTAINER NO": "BOXC3333333",
              "DISCHARGING TIME": "17-SEP-26 11.47.00 AM",
              "GATE OUT TIME": "N/A"}]}
ENG._apply_container_veto(_res96, {})
chk("veto rows: 'N/A' gate-out par yard saboot jeet-ta hai",
    _res96.get("status") == "Discharged at KICT"
    and _res96.get("position") == "In Yard"
    and _res96.get("truck") != "delivered",
    f"({_res96.get('status')} / {_res96.get('position')})")

print("== Proof-run SF-1: voyage ka harf na gire ==")
_m = server._merge_result(
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "W151"},
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "151"})
chk("merge SF-1: bare-digit fresh purane W151 ko nahi dabata",
    _m["voyage"] == "W151")
_m = server._merge_result(
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "W151"},
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "152"})
chk("merge SF-1: digits badlein to naya voyage hi chalta hai",
    _m["voyage"] == "152")
_m = server._merge_result(
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "631W"},
    {"status": "Discharged at KICT", "position": "In Yard",
     "voyage": "631"})
chk("merge SF-1: digit-first purana + bare fresh -> W631",
    _m["voyage"] == "W631")

print("== Profile: naam + photo (v96) ==")
# In-process HTTP round-trip: test HOME par asal handler chala kar
# endpoint ka poora chakkar — naam settings mein, photo DATA_DIR ki
# file mein, bahar sirf flag (data-URI kabhi nahi).
import base64 as _b64, json as _json, threading as _th
import urllib.request as _u, urllib.error as _ue
from http.server import ThreadingHTTPServer as _THS
_srv = _THS(("127.0.0.1", 0), server.H)
_th.Thread(target=_srv.serve_forever, daemon=True).start()
_B = f"http://127.0.0.1:{_srv.server_address[1]}"
def _call(method, path, body=None):
    req = _u.Request(_B + path, method=method,
                     data=_json.dumps(body).encode() if body is not None
                     else None,
                     headers={"Content-Type": "application/json"})
    try:
        with _u.urlopen(req, timeout=10) as r:
            return r.status, r.read(), r.headers.get("Content-Type") or ""
    except _ue.HTTPError as e:
        return e.code, e.read(), e.headers.get("Content-Type") or ""
_PNG1 = ("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8"
         "Xw8AAwMCAO+ip1sAAAAASUVORK5CYII=")
_png_bytes = _b64.b64decode(_PNG1)
st, _, _ = _call("GET", "/profile/photo")
chk("profile: photo na ho to 404", st == 404)
st, _, _ = _call("POST", "/api/settings", {"profile_name": "Test Name"})
_pub = server._public_settings()
chk("profile: naam settings mein + public mein",
    st == 200 and _pub.get("profile_name") == "Test Name")
chk("profile: photo flag pehle False", _pub.get("profile_photo_set") is False)
st, r, _ = _call("POST", "/api/profile/photo", {"data": _PNG1})
chk("profile: photo POST ok + flag",
    st == 200 and _json.loads(r).get("profile_photo_set") is True)
st, r, ct = _call("GET", "/profile/photo")
chk("profile: photo GET — wahi bytes, image/png",
    st == 200 and r == _png_bytes and "image/png" in ct)
st, r, _ = _call("GET", "/api/history")
_set = _json.loads(r)["settings"]
chk("profile: settings jawab mein flag hai, data-URI NAHI",
    _set.get("profile_photo_set") is True
    and "data:image" not in _json.dumps(_set))
st, _, _ = _call("POST", "/api/profile/photo",
                 {"data": _b64.b64encode(b"ye image nahi hai").decode()})
chk("profile: ghair-image reject (400)", st == 400)
st, r, _ = _call("POST", "/api/profile/photo", {"remove": True})
st2, _, _ = _call("GET", "/profile/photo")
chk("profile: remove ke baad 404 + flag False",
    st == 200 and st2 == 404
    and server._public_settings().get("profile_photo_set") is False)
_call("POST", "/api/settings", {"profile_name": "X" * 120})
chk("profile: naam 80 harf par kata (sanitize)",
    len(server._public_settings().get("profile_name") or "") == 80)
_srv.shutdown()

print("== v99 LIFECYCLE BATTERY (30 Oct 2026) — mapping discipline ==")
# Usool: vessel departure -> berthing -> discharge ->
# gate out -> delivery -> empty return. Har case asal
# ghalti / truth table (agent_recheck_2weeks.md) par
# mabni hai. Inference kabhi terminal saboot par nahi
# jeet-ti; record re-track par KHUD sudharna chahiye.
_NF99 = lambda *a, **k: {"found": False}
_LAYERS99 = ("identify_carrier", "track_bol_tracktrace",
             "track_karachi_terminals", "track_qict_bl",
             "track_kgtl_bl",
             "track_karachi_terminals_container",
             "track_kgtl_container", "vessel_live_position",
             "track_qict_vesselwatch",
             "track_shippingline_official",
             "track_sailingschedule", "quick_eta",
             "track_container_tracktrace",
             "track_hutchison_guidance", "track_traqo_bl")


def _patch99(**kw):
    saved = {}
    for _n in _LAYERS99:
        if hasattr(ENG, _n):
            saved[_n] = getattr(ENG, _n)
            if _n in kw:
                setattr(ENG, _n, kw[_n])
            elif _n == "identify_carrier":
                setattr(ENG, _n, lambda q: (None, None))
            else:
                setattr(ENG, _n, _NF99)
    return saved


def _restore99(saved):
    for _n, _f in saved.items():
        setattr(ENG, _n, _f)


# (a) EMKAYMBAKHI59055 — QICT 'Out Time' wala asal rasta
_old55v = {"status": "Released — Delivered",
           "position": "OUT", "truck": "delivered",
           "discharge_time": "13-OCT-2026 16:59",
           "vir": "PKBQMQICT_051026131058",
           "vessel": "SLS TOPAZ", "voyage": "S642",
           "containers": ["FFAU2343188"], "terminal": "QICT",
           "source": "QICT (DP World)"}
_det55 = {"vir": "PKBQMQICT_051026131058",
          "discharge_time": "13-OCT-2026 16:59",
          "gate_out": "28-OCT-2026 00:12", "position": "OUT",
          "truck": "delivered", "category": "IMPORT",
          "vessel": "SLS TOPAZ", "voyage": "642S",
          "line": "Maersk Pakistan (Pvt) Ltd. - Maersk A/s"}
_orig_qc99 = ENG.track_qict_container
ENG.track_qict_container = lambda c: dict(_det55)
_leg55 = ENG.track_qict_container_layer("FFAU2343188")
ENG.track_qict_container = _orig_qc99
chk("v99a: Ctr-Inq leg 'Out Time' se gate_out rakhti hai",
    _leg55.get("gate_out") == "28-OCT-2026 00:12"
    and not _leg55.get("discharge_only"), str(_leg55))
_sv = _patch99(
    identify_carrier=lambda q: ("EMKAY", "Emkay Line"),
    track_qict_bl=lambda bl: {
        "found": True, "terminal": "QICT",
        "source": "QICT (DP World)",
        "containers": ["FFAU2343188"],
        "status": "Released — Delivered", "position": "OUT",
        "truck": "delivered",
        "vir": "PKBQMQICT_051026131058",
        "discharge_time": "13-OCT-2026 16:59",
        "vessel": "SLS TOPAZ", "voyage": "642S"})
_api55 = ENG.CARRIER_APIS.get("Emkay Line")
ENG.CARRIER_APIS["Emkay Line"] = _NF99
ENG.track_qict_container = lambda c: dict(_det55)
try:
    _o55 = ENG.track_all(bl="EMKAYMBAKHI59055")
finally:
    _restore99(_sv)
    ENG.track_qict_container = _orig_qc99
    if _api55 is not None:
        ENG.CARRIER_APIS["Emkay Line"] = _api55
_r55 = _o55["result"]
chk("v99a: track_all gate_out ki tareekh stamp karta hai",
    _r55.get("gate_out") == "28-OCT-2026 00:12"
    and _r55.get("status") == "Released — Delivered"
    and _r55.get("position") == "OUT", str(_r55))
_ms55 = server._milestones({"query": "EMKAYMBAKHI59055",
                            "result": _r55,
                            "layers": _o55["layers"]})
_g55 = [m for m in _ms55 if m["key"] == "gateout"][0]
chk("v99a: gate-out milestone done + asal tareekh",
    _g55["state"] == "done"
    and _g55["when"] == "28-OCT-2026 00:12", str(_g55))
_m55 = server._merge_result(dict(_old55v), dict(_r55))
chk("v99a: merge — Delivered + gate_out tareekh barqarar",
    _m55.get("status") == "Released — Delivered"
    and _m55.get("gate_out") == "28-OCT-2026 00:12",
    str(_m55))
# (a2) discharge-only leg (Out Time/Position na ho to)
ENG.track_qict_container = lambda c: {
    "vir": "PKBQMQICT_051026131058",
    "discharge_time": "13-OCT-2026 16:59",
    "vessel": "SLS TOPAZ", "voyage": "642S"}
_leg55d = ENG.track_qict_container_layer("FFAU2343188")
ENG.track_qict_container = _orig_qc99
_ev55d = {}
ENG._ctn_evidence_add(_ev55d, "FFAU2343188", _leg55d)
chk("v99a2: discharge-only leg se in_yard saboot NAHI banta",
    _leg55d.get("discharge_only") is True
    and not _ev55d.get("FFAU2343188", {}).get("in_yard"),
    str(_ev55d))
# (a3) repro-exact: v98 wali assembly (status overwrite +
# haath ki leg) — Delivered phir bhi mehfooz
_fresh55b = dict(_old55v, status="Discharged at QICT")
_ev55b = {}
ENG._ctn_evidence_add(_ev55b, "FFAU2343188", {
    "found": True, "terminal": "QICT",
    "containers": ["FFAU2343188"], "status": "Discharged at QICT",
    "vir": "PKBQMQICT_051026131058",
    "discharge_time": "13-OCT-2026 16:59",
    "vessel": "SLS TOPAZ", "voyage": "S642"})
ENG._apply_container_veto(_fresh55b, _ev55b)
ENG._reconcile_status(_fresh55b)
chk("v99a3: merge guard veto-provenance saboot se inkaar",
    server._own_cycle_correction(_old55v, _fresh55b) is False)
_m55b = server._merge_result(dict(_old55v), _fresh55b)
chk("v99a3: repro-exact rasta bhi Delivered mehfooz rakhta hai",
    _m55b.get("status") == "Released — Delivered"
    and _m55b.get("position") == "OUT"
    and "position_via" not in _m55b
    and "_rejected_fields" not in _m55b, str(_m55b))

# (b) MBAQITS8502261016 — asal correction: BL leg ka apna
# POSITION field 'IN YARD' Delivered text ke khilaf
_claim16 = {"found": True, "terminal": "QICT",
            "source": "QICT (DP World)",
            "containers": ["MRKU8740840"],
            "status": "Released — Delivered",
            "position": "IN YARD", "truck": "delivered",
            "vir": "PKBQMQICT_140926131731",
            "vessel": "BSG BIMINI", "voyage": "638W",
            "discharge_time": "17-SEP-2026 11:47"}
_sv = _patch99(track_qict_bl=lambda bl: dict(_claim16))
ENG.track_qict_container = lambda c: {
    "vir": "PKBQMQICT_140926131731",
    "discharge_time": "17-SEP-2026 11:47",
    "vessel": "BSG BIMINI", "voyage": "638W"}
try:
    _o16 = ENG.track_all(bl="MBAQITS8502261016")
finally:
    _restore99(_sv)
    ENG.track_qict_container = _orig_qc99
_r16 = _o16["result"]
chk("v99b: 1016 synthesis — Discharged/In Yard (field jeet-ta hai)",
    _r16.get("status") == "Discharged at QICT"
    and "yard" in (_r16.get("position") or "").lower()
    and (_r16.get("truck") or "") != "delivered"
    and not _r16.get("position_via"), str(_r16))
_m16 = server._merge_result(dict(_old16), dict(_r16))
chk("v99b: merge correction lagti hai — record khud sudhra",
    _m16.get("status") == "Discharged at QICT"
    and "yard" in (_m16.get("position") or "").lower()
    and (_m16.get("truck") or "") != "delivered", str(_m16))

# (c) EMASUBKHI37726 — container mode se gate-out (BL mode
# gate-out ke baad khaali ho jati hai); stored 'Partially
# discharged / Examin Area' khud sudharna chahiye
_detE = {"found": True, "terminal": "KICT",
         "source": "Karachi Terminal (Hutchison Ports)",
         "status": "Gate out", "position": "Gate Out",
         "gate_out": "24-OCT-26 07.50.45 PM",
         "discharge_time": "19-OCT-26 10.07.28 PM",
         "vir": "PKKHIKICT_121026100008",
         "vessel": "EVER URBAN", "voyage": "228",
         "containers": [{
             "CONTAINER NO": "CBHU3535203", "STATUS": "IF",
             "DISCHARGING TIME": "19-OCT-26 10.07.28 PM",
             "GATE OUT TIME": "24-OCT-26 07.50.45 PM"}]}
_sv = _patch99(track_karachi_terminals_container=lambda c: dict(_detE))
ENG.track_qict_container = lambda c: {}
try:
    _oE = ENG.track_all(ctn="CBHU3535203")
finally:
    _restore99(_sv)
    ENG.track_qict_container = _orig_qc99
_rE = _oE["result"]
chk("v99c: EMASU container-mode — Gate out + tareekh",
    _rE.get("gate_out") == "24-OCT-26 07.50.45 PM"
    and _rE.get("status") == "Gate out", str(_rE))
_msE = server._milestones({"query": "EMASUBKHI37726",
                           "result": _rE, "layers": _oE["layers"]})
_gE = [m for m in _msE if m["key"] == "gateout"][0]
chk("v99c: gate-out milestone done (final)",
    _gE["state"] == "done" and _gE["certainty"] == "final",
    str(_gE))
_oldE = {"status": "Partially discharged",
         "position": "Examin Area",
         "discharge_time": "19-OCT-26 10.07.28 PM",
         "vir": "PKKHIKICT_121026100008",
         "vessel": "EVER URBAN", "terminal": "KICT",
         "containers": ["CBHU3535203"]}
_mE = server._merge_result(dict(_oldE), dict(_rE))
chk("v99c: stored 'Partially/Examin Area' khud sudhra",
    _mE.get("status") == "Gate out"
    and _mE.get("gate_out") == "24-OCT-26 07.50.45 PM"
    and _mE.get("position") == "Gate Out", str(_mE))

# (d) QICT OUT + truck delivered — gate-out milestone
# done, tareekh ghari NAHI jati, demurrage band
_hD = {"query": "EMKAYMBAKHI59055",
       "result": {"status": "Released at QICT",
                  "position": "OUT", "truck": "delivered",
                  "discharge_time": "13-OCT-2026 16:59",
                  "terminal": "QICT",
                  "vir": "PKBQMQICT_051026131058"},
       "layers": [{"name": "Layer 3b — QICT (DP World Karachi)",
                   "status": "done"}]}
_gD = [m for m in server._milestones(_hD)
       if m["key"] == "gateout"][0]
chk("v99d: QICT OUT+delivered par gate-out done (bina tareekh)",
    _gD["state"] == "done" and _gD["when"] == ""
    and _gD["certainty"] in ("confirmed", "single"), str(_gD))
chk("v99d: completed shipment — demurrage ka input nahi",
    server._ast_completed(_hD) is True
    and server._lifecycle(_hD)["stage"] == "out")

# (e) empty return — EM row (asal MEDUT1383412 shapes)
_resE = {"containers": ["MSDU2176977"],
         "gate_out": "22-OCT-26 04.50.06 PM",
         "discharge_time": "12-OCT-26 08.57.48 PM",
         "terminal_rows": [
             {"CONTAINER NO": "MSDU2176977",
              "DISCHARGING TIME": "12-OCT-26 08.57.48 PM",
              "GATE OUT TIME": "22-OCT-26 04.50.06 PM",
              "STATUS": "IF"},
             {"CONTAINER NO": "MSDU2176977",
              "DISCHARGING TIME": "23-OCT-26 11.59.32 AM",
              "STATUS": "EM"}]}
ENG._apply_empty_return(_resE)
chk("v99e: EM row se returned + asal tareekh likhi jati hai",
    _resE.get("returned") is True
    and "23-OCT-26" in (_resE.get("returned_date") or ""),
    str(_resE))
_resE2 = {"containers": ["MSDU2176977"],
          "gate_out": "22-OCT-26 04.50.06 PM",
          "terminal_rows": [
              {"CONTAINER NO": "MSDU2176977",
               "DISCHARGING TIME": "20-OCT-26 09.00.00 AM",
               "STATUS": "EM"}]}
ENG._apply_empty_return(_resE2)
chk("v99e: gate-out se PEHLE ki EM row wapsi nahi banti",
    not _resE2.get("returned"))
# (e2) parser: EM details pehle aa jayein to bhi status
# 'Partially discharged' NAHI banta (asal corruption)
_outT = {"found": True, "terminal": "", "containers": []}
ENG._term_apply_details(_outT, [
    {"_ctn": "MSDU2176977", "_row_status": "EM",
     "_row_gate_out": "", "_row_discharge": "23-OCT-26 11.59.32 AM",
     "Vessel Voyage": "MSC TEST / 1", "ETA": "", "ETD": "",
     "Origin": "", "Destination": "", "VIR No": "PKKHISAPT_1",
     "Current Position": "In Yard", "Present Holds": "",
     "DO Expiry Date": "", "Owner": "", "Weight": "",
     "Commodity": "", "Container Size/Type": "",
     "Custom Status": "", "Category": "EM",
     "Gate In Time": "", "Discharge Time": "",
     "Gate Out Time": ""},
    {"_ctn": "MSDU2176977", "_row_status": "IF",
     "_row_gate_out": "22-OCT-26 04.50.06 PM",
     "_row_discharge": "12-OCT-26 08.57.48 PM",
     "Vessel Voyage": "MSC TEST / 1", "ETA": "", "ETD": "",
     "Origin": "", "Destination": "", "VIR No": "PKKHISAPT_1",
     "Current Position": "Gate Out", "Present Holds": "",
     "DO Expiry Date": "", "Owner": "", "Weight": "",
     "Commodity": "", "Container Size/Type": "",
     "Custom Status": "", "Category": "IF",
     "Gate In Time": "", "Discharge Time": "12-OCT-26 08.57.48 PM",
     "Gate Out Time": "22-OCT-26 04.50.06 PM"}])
chk("v99e2: EM details gin-ti se bahar — Gate out durust",
    _outT.get("status") == "Gate out"
    and _outT.get("gate_out") == "22-OCT-26 04.50.06 PM"
    and _outT.get("discharge_time") == "12-OCT-26 08.57.48 PM",
    str(_outT))
# (e3) duplicate rows: ek dabba, do discharge rows — ek
# gate-out wali, ek baghair (MCLSUB26104308); shipment
# gate_out = aakhri dabbe ka
_outT3 = {"found": True, "terminal": "", "containers": []}
_dT3 = {"Vessel Voyage": "MSC TEST / 1", "ETA": "", "ETD": "",
        "Origin": "", "Destination": "",
        "VIR No": "PKKHIKICT_121026100008",
        "Current Position": "Gate Out", "Present Holds": "",
        "DO Expiry Date": "", "Owner": "", "Weight": "",
        "Commodity": "", "Container Size/Type": "",
        "Custom Status": "", "Category": "IF",
        "Gate In Time": ""}
ENG._term_apply_details(_outT3, [
    dict(_dT3, _ctn="MGEU1916791", _row_status="IF",
         _row_gate_out="29-OCT-26 07.25.34 PM",
         _row_discharge="18-OCT-26 07.44.21 PM",
         **{"Discharge Time": "18-OCT-26 07.44.21 PM",
            "Gate Out Time": "29-OCT-26 07.25.34 PM"}),
    dict(_dT3, _ctn="MGEU1916791", _row_status="IF",
         _row_gate_out="",
         _row_discharge="18-OCT-26 08.54.09 PM",
         **{"Discharge Time": "18-OCT-26 08.54.09 PM",
            "Gate Out Time": ""}),
    dict(_dT3, _ctn="MGEU1917360", _row_status="IF",
         _row_gate_out="29-OCT-26 07.54.44 PM",
         _row_discharge="18-OCT-26 06.00.00 PM",
         **{"Discharge Time": "18-OCT-26 06.00.00 PM",
            "Gate Out Time": "29-OCT-26 07.54.44 PM"})])
chk("v99e3: duplicate row gate_out nahi kaat-ti; aakhri stamp",
    _outT3.get("status") == "Gate out"
    and _outT3.get("gate_out") == "29-OCT-26 07.54.44 PM",
    str(_outT3))
# (e4) _record entry par returned ka nishan
server._record({"query": "TESTV99RET", "mode": "bl",
                "client": "", "carrier": "MSC", "prefix": "",
                "found": True,
                "result": {"status": "Gate out",
                           "returned": True,
                           "returned_date": "23-OCT-26 11.59.32 AM",
                           "containers": ["MSDU2176977"]},
                "layers": [], "contacts": None})
_entE = next((e for e in server.get_history()
              if e.get("query") == "TESTV99RET"), {})
chk("v99e4: _record entry.returned set karta hai",
    _entE.get("returned") is True, str(_entE.get("returned")))

# (f) terminal flip — Expected-layer VIR-confirmed
# record ko nahi palat sakti (CCLU3833738/XINU1190143)
_oldF = {"status": "Discharged at QICT", "terminal": "QICT",
         "position": "In Yard",
         "vir": "PKBQMQICT_051026131058",
         "discharge_time": "13-OCT-2026 16:59",
         "containers": ["CCLU3833738"]}
_newF = {"status": "Expected at SAPT — on CSTAR VOYAGER "
                   "(W3), still at sea",
         "terminal": "SAPT", "vessel": "CSTAR VOYAGER",
         "eta": "05 Nov 2026", "containers": ["CCLU3833738"]}
_mF = server._merge_result(dict(_oldF), dict(_newF))
chk("v99f: Expected-layer terminal/Status nahi palat-ti",
    _mF.get("status") == "Discharged at QICT"
    and _mF.get("terminal") == "QICT", str(_mF))
_oldF2 = {"status": "At QICT terminal (Port Qasim)",
          "terminal": "QICT", "position": "",
          "vir": "PKBQMQICT_051026131058",
          "containers": ["XINU1190143"]}
_mF2 = server._merge_result(
    dict(_oldF2), dict(_newF, containers=["XINU1190143"]))
chk("v99f: sirf berthed bhi flip se mehfooz; ETA update ok",
    _mF2.get("status") == "At QICT terminal (Port Qasim)"
    and _mF2.get("terminal") == "QICT"
    and _mF2.get("eta") == "05 Nov 2026", str(_mF2))

# (g) QICT label — Port Qasim (Karachi nahi)
import json as _j99


class _FR99:
    def __init__(self, body):
        self._b = body

    def read(self):
        return self._b

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


_body99 = _j99.dumps(_j99.dumps(
    [{"STANDING": "", "TRUCK_IN_YARD": "", "POSITION": "",
      "EQ_NBR": "BOX1234567", "CATEGORY": "IMPORT"}])).encode()
_uo99 = ENG.urllib.request.urlopen
ENG.urllib.request.urlopen = lambda req, timeout=0: _FR99(_body99)
try:
    _bl99 = ENG.track_qict_bl("TESTLABEL99")
finally:
    ENG.urllib.request.urlopen = _uo99
chk("v99g: QICT BL status mein Port Qasim",
    _bl99.get("status") == "At QICT terminal (Port Qasim)",
    str(_bl99.get("status")))
ENG.track_qict_container = lambda c: {
    "vir": "PKBQMQICT_051026131058"}
_lay99 = ENG.track_qict_container_layer("BOX1234567")
ENG.track_qict_container = _orig_qc99
chk("v99g: Ctr-Inq layer ka status bhi Port Qasim",
    "Port Qasim" in (_lay99.get("status") or "")
    and "Karachi" not in (_lay99.get("status") or ""),
    str(_lay99.get("status")))

# (h) COSCO trio — terminal discharge carrier stamp par
# jeet-ta hai (COAU6468005230: berthing stamp 29-Oct
# 15:00 discharge bana huwa tha; asal 30-Oct 06:43)
_apiC = ENG.CARRIER_APIS.get("COSCO Shipping")
_sv = _patch99(
    identify_carrier=lambda q: ("COAU", "COSCO Shipping"),
    track_karachi_terminals=lambda bl: {
        "found": True, "terminal": "SAPT",
        "source": "Karachi Terminal (Hutchison Ports)",
        "status": "Discharged",
        "discharge_time": "30-OCT-26 06.43.24 AM",
        "position": "In Yard",
        "vir": "PKKHISAPT_221026134915",
        "vessel": "APL CHONGQING", "voyage": "0K123",
        "containers": [{"CONTAINER NO": "CSNU6961392"}]})
ENG.CARRIER_APIS["COSCO Shipping"] = lambda bl: {
    "found": True, "status": "Discharged",
    "discharge_time": "2026-10-29 15:00",
    "vessel": "APL CHONGQING", "voyage": "0K123",
    "containers": ["CSNU6961392"],
    "source": "COSCO e-Booking"}
ENG.track_qict_container = lambda c: {}
try:
    _oH = ENG.track_all(bl="COAU6468005230")
finally:
    _restore99(_sv)
    ENG.track_qict_container = _orig_qc99
    if _apiC is not None:
        ENG.CARRIER_APIS["COSCO Shipping"] = _apiC
_rH = _oH["result"]
chk("v99h: terminal discharge carrier stamp ko dabata hai",
    _rH.get("discharge_time") == "30-OCT-26 06.43.24 AM"
    and _rH.get("position") == "In Yard", str(_rH))
_oldH = {"status": "Discharged", "position": "Loaded on Vessel",
         "discharge_time": "2026-10-29 15:00",
         "vir": "PKKHISAPT_221026134915",
         "vessel": "APL CHONGQING", "terminal": "SAPT",
         "containers": ["CSNU6961392"]}
_mH = server._merge_result(dict(_oldH), dict(_rH))
chk("v99h: stored ghalat discharge/position khud sudhra",
    _mH.get("discharge_time") == "30-OCT-26 06.43.24 AM"
    and _mH.get("position") == "In Yard", str(_mH))
# (h2) container mode: carrier position bhi terminal se
# dabta hai
_sv = _patch99(
    track_container_tracktrace=lambda c: {
        "found": True, "position": "Loaded on Vessel",
        "status": "In transit", "vessel": "APL CHONGQING"},
    track_karachi_terminals_container=lambda c: {
        "found": True, "terminal": "SAPT",
        "source": "Karachi Terminal (Hutchison Ports)",
        "status": "Discharged",
        "discharge_time": "30-OCT-26 06.43.24 AM",
        "position": "In Yard",
        "vir": "PKKHISAPT_221026134915",
        "vessel": "APL CHONGQING",
        "containers": [{"CONTAINER NO": "CSNU6961392",
                        "STATUS": "IF",
                        "DISCHARGING TIME": "30-OCT-26 06.43.24 AM"}]})
ENG.track_qict_container = lambda c: {}
try:
    _oH2 = ENG.track_all(ctn="CSNU6961392")
finally:
    _restore99(_sv)
    ENG.track_qict_container = _orig_qc99
chk("v99h2: container mode mein terminal position jeet-ta hai",
    _oH2["result"].get("position") == "In Yard"
    and _oH2["result"].get("discharge_time")
    == "30-OCT-26 06.43.24 AM", str(_oH2["result"]))

# (i) EMKAYMBAKHI57984 — band cycle: BL-Inq khaali,
# dabba export cycle mein (export In 21-Oct, load 28-Oct —
# v99fix3 usool: gate-in wapsi NAHI hai; v99fix4 usool:
# gate-in + LOAD = dateless confirmed wapsi, basis
# export_reload — tareekh kabhi nahi banti)
_sv = _patch99(
    identify_carrier=lambda q: ("EMKAY", "Emkay Line"))
_api84 = ENG.CARRIER_APIS.get("Emkay Line")
ENG.CARRIER_APIS["Emkay Line"] = _NF99
ENG.track_qict_container = lambda c: {
    "category": "EXPORT", "in_time": "21-OCT-2026 02:52",
    "load_time": "28-OCT-2026 06:45",
    "vir": "PKBQMQICT_201026130531",
    "vessel": "BSG BARBADOS", "voyage": "644S",
    "position": "Vessel", "truck": "received",
    "line": "Maersk Pakistan (Pvt) Ltd. - Maersk A/s"}
try:
    _o84 = ENG.track_all(bl="EMKAYMBAKHI57984",
                         known_containers=["MRSU8030271"])
finally:
    _restore99(_sv)
    ENG.track_qict_container = _orig_qc99
    if _api84 is not None:
        ENG.CARRIER_APIS["Emkay Line"] = _api84
_r84 = _o84["result"]
chk("v99i+fix4: band-cycle — LOAD se dateless confirmed wapsi, pehchan leak nahi",
    _r84.get("cycle_closed") is True
    and _r84.get("returned") is True and not _r84.get("returned_date")
    and _r84.get("returned_basis") == "export_reload"
    and _r84.get("qict_export_in") == "21-OCT-2026 02:52"
    and _r84.get("status") == "Gate out"
    and not _r84.get("vir") and not _r84.get("vessel"),
    str(_r84))
_old84 = {"status": "On hold at QICT",
          "holds": "LOAD LIST HOLD",
          "vir": "PKBQMQICT_201026130531",
          "vessel": "BSG BARBADOS", "voyage": "644S",
          "terminal": "QICT",
          "containers": ["MRSU8030271"]}
_m84 = server._merge_result(dict(_old84), dict(_r84))
chk("v99i+fix4: 'On hold' record mukammal halat par khud sudhra",
    _m84.get("status") == "Gate out"
    and _m84.get("returned") is True and not _m84.get("returned_date")
    and not _m84.get("holds")
    and "cycle_closed" not in _m84, str(_m84))
_old84b = {"status": "In transit — on BSG BARBADOS",
           "eta": "01 Nov 2026", "terminal": "",
           "containers": ["MRSU8030271"]}
_m84b = server._merge_result(dict(_old84b), dict(_r84))
chk("v99i: anchor ke baghair band-cycle saboot NAHI lagta",
    _m84b.get("status") == "In transit — on BSG BARBADOS"
    and not _m84b.get("returned"), str(_m84b))

# (j) ONEYALYG09255800 — container mode se holds wapis
# (BL mode khaali; stored mein holds ghayb thay)
_sv = _patch99(track_karachi_terminals_container=lambda c: {
    "found": True, "terminal": "SAPT",
    "source": "Karachi Terminal (Hutchison Ports)",
    "status": "Discharged",
    "discharge_time": "18-OCT-26 02.05.05 PM",
    "holds": "DT(Detention), HP(Payment Hold), LH(Line Hold)",
    "position": "In Yard",
    "vir": "PKKHISAPT_111026100001",
    "vessel": "YM WITNESS",
    "containers": [{"CONTAINER NO": "ONEU5963083",
                    "STATUS": "IF",
                    "DISCHARGING TIME": "18-OCT-26 02.05.05 PM"}]})
ENG.track_qict_container = lambda c: {}
try:
    _oJ = ENG.track_all(ctn="ONEU5963083")
finally:
    _restore99(_sv)
    ENG.track_qict_container = _orig_qc99
chk("v99j: container mode holds + Discharged deta hai",
    "DT" in (_oJ["result"].get("holds") or "")
    and _oJ["result"].get("status") == "Discharged",
    str(_oJ["result"]))

# ============================================================
# v99fix battery (30 Oct 2026, Phase-1 fail ke 4 nuqson ki
# battery): (a) EM derivation har choke point par —
# stored EM row / gate_in se bhi; (b) har dabbe ki
# history (completion loop); (c) ghost row se position/
# status kabhi nahi; (d) 'Gate out' tareekh ke baghair
# kabhi nahi + carrier discharge terminal tasdeeq ke
# baghair unclaimed. Asal fail records ki shakal par.
# ============================================================
print("== v99fix: (a) EM derivation — stored row se ==")
_FX_EM = {"CONTAINER NO": "MSNU1300240", "STATUS": "EM",
          "DISCHARGING TIME": "29-OCT-26 04.59.35 PM",
          "GATE OUT TIME": None, "pid": "fxh1"}
_FX_IF = {"CONTAINER NO": "MSNU1300240", "STATUS": "IF",
          "DISCHARGING TIME": "21-OCT-26 06.09.26 PM",
          "GATE OUT TIME": "28-OCT-26 09.34.03 PM", "pid": "fxh2"}
# MEDUT1385110 ki asal mushkil: EM usi din hai jis din
# shipment ka completion gate-out (doosre dabbe ka) —
# din-wala hisaab rad kar deta tha; dabbe ke APNE
# gate-out se poora timestamp muqabla lazmi hai.
_r = {"containers": ["MSNU1300240", "CXDU1175597"],
      "gate_out": "29-OCT-26 03.51.15 AM",
      "discharge_time": "21-OCT-26 06.09.26 PM",
      "terminal_rows": [dict(_FX_EM), dict(_FX_IF)]}
ENG._apply_empty_return(_r)
chk("v99fix a: stored EM row -> returned (usi-din wapsi)",
    _r.get("returned")
    and _r.get("returned_date") == "29-OCT-26 04.59.35 PM", str(_r))
_OLD5110 = {"status": "Gate out",
            "gate_out": "29-OCT-26 03.51.15 AM",
            "discharge_time": "21-OCT-26 06.09.26 PM",
            "holds": "DT(Detention), HP(Payment Hold), "
                     "LH(Line Hold)",
            "terminal": "SAPT",
            "containers": ["MSNU1300240", "CXDU1175597"],
            "terminal_rows": [dict(_FX_EM), dict(_FX_IF)],
            "found": True}
_m = server._merge_result(_OLD5110, {"found": True,
                                     "source": "battery"})
chk("v99fix a: merge par stored EM se returned banta hai",
    _m.get("returned")
    and "29-OCT-26" in str(_m.get("returned_date")), str(_m))
chk("v99fix holds: mukammal cycle par holds clear",
    not _m.get("holds"), str(_m.get("holds")))
_m = server._merge_result(
    _OLD5110, {"found": True, "returned": True,
               "returned_date": "29-OCT-26",
               "holds": "DT(Detention), HP(Payment Hold), "
                        "LH(Line Hold)",
               "status": "Gate out"})
chk("v99fix holds: fresh basi holds bhi clear (cycle band)",
    not _m.get("holds"), str(_m.get("holds")))
_m = server._merge_result(
    {"holds": "LOAD LIST HOLD", "status": "On hold at QICT",
     "terminal": "QICT", "found": True},
    {"found": True, "returned": True,
     "status": "On hold at QICT", "holds": "LOAD LIST HOLD"})
chk("v99fix holds: khule hold-cycle par holds mehfooz",
    _m.get("holds") == "LOAD LIST HOLD", str(_m.get("holds")))

print("== v99fix: (a) gate_in -> returned (OOLU shakl) ==")
_OLD_OOLU = {"status": "Gate out",
             "gate_out": "20-OCT-26 09.36.53 AM",
             "discharge_time": "04-OCT-26 07.39.48 AM",
             "gate_in": "20-OCT-26 06.23.29 PM",
             "terminal": "SAPT", "containers": ["OOCU6305986"],
             "terminal_rows": [{"CONTAINER NO": "OOCU6305986",
                                "Category": "IF",
                                "pid": "20780105"}],
             "found": True}
_m = server._merge_result(_OLD_OOLU, {"found": True,
                                      "source": "battery"})
chk("v99fix a: OOLU gate_in merge par returned banta hai",
    _m.get("returned")
    and _m.get("returned_date") == "20-OCT-26 06.23.29 PM",
    str(_m))
# manfi joray: gate_in jo export row ki gate-in se wazeh
# ho (agle safar ki ibtida) wapsi NAHI hai.
_r = {"containers": ["WHSU8432537"],
      "discharge_time": "01-OCT-26 04.05.47 PM",
      "gate_out": "22-OCT-26 07.36.05 PM",
      "gate_in": "25-OCT-26 12.15.44 PM",
      "terminal_rows": [
          {"CONTAINER NO": "WHSU8432537", "STATUS": "XM",
           "GATE In TIME": "25-OCT-26 12.15.44 PM",
           "GATE OUT TIME": "N/A"},
          {"CONTAINER NO": "WHSU8432537", "STATUS": "IF",
           "DISCHARGING TIME": "01-OCT-26 04.05.47 PM",
           "GATE OUT TIME": "22-OCT-26 07.36.05 PM"}]}
chk("v99fix a: XM-wazeh gate_in wapsi NAHI (025G shakl)",
    not ENG.derive_empty_return(_r), str(_r))
_r = {"containers": ["TRLU7363854"],
      "discharge_time": "12-OCT-26 06.06.01 AM",
      "gate_out": "25-OCT-26 05.30.44 AM",
      "gate_in": "29-OCT-26 05.47.42 PM",
      "terminal_rows": [
          {"CONTAINER NO": "TRLU7363854", "STATUS": "XF",
           "GATE In TIME": "29-OCT-26 05.47.42 PM",
           "GATE OUT TIME": "N/A"},
          {"CONTAINER NO": "TRLU7363854", "STATUS": "IF",
           "DISCHARGING TIME": "12-OCT-26 06.06.01 AM",
           "GATE OUT TIME": "25-OCT-26 05.30.44 AM"}]}
chk("v99fix a: XF-wazeh gate_in wapsi NAHI (BALC shakl)",
    not ENG.derive_empty_return(_r), str(_r))
_r = {"containers": ["MRKU8740840"],
      "discharge_time": "17-SEP-2026 11:47",
      "gate_in": "28-OCT-26 08.23.38 AM", "terminal_rows": []}
chk("v99fix a: gate_out ke baghair gate_in wapsi NAHI (1016)",
    not ENG.derive_empty_return(_r), str(_r))

print("== v99fix2: Phase-2 defect 1016 — XF gate-in ==")
# Phase 2 ki asal shakl: gate_out mojood (QICT, 02-OCT),
# gate_in XF export row ki gate-in hai, aur XF row
# terminal_rows mein mojood hai. Guard is surat mein
# pehle bhi rokta tha — lekin merge tak row pahunchti
# hi nahi thi (3d absorb ne gira di thi). Ye test dono
# satah pakarta hai: fresh derivation + merge retraction.
_FX1016 = {"CONTAINER NO": "MRKU8740840", "STATUS": "XF",
           "GATE In TIME": "28-OCT-26 08.23.38 AM",
           "GATE OUT TIME": "N/A", "pid": "fx1016"}
_r = {"containers": ["MRKU8740840"],
      "discharge_time": "17-SEP-2026 11:47",
      "gate_out": "02-OCT-2026 21:31",
      "gate_in": "28-OCT-26 08.23.38 AM",
      "terminal_rows": [dict(_FX1016)]}
ENG._apply_empty_return(_r)
chk("v99fix2: XF gate-in + gate_out bhi ho to bhi wapsi NAHI (1016 fresh)",
    not _r.get("returned") and not _r.get("returned_date"), str(_r))
# Poisoned record: Phase 2 ne returned=True likh diya tha.
# Dobara merge par XF saboot dekh kar retract hona chahiye.
_OLD1016 = {"status": "Released — Delivered", "position": "OUT",
            "terminal": "QICT", "containers": ["MRKU8740840"],
            "discharge_time": "17-SEP-2026 11:47",
            "gate_out": "02-OCT-2026 21:31",
            "gate_in": "28-OCT-26 08.23.38 AM",
            "returned": True,
            "returned_date": "28-OCT-26 08.23.38 AM",
            "found": True}
_m = server._merge_result(
    _OLD1016,
    {"found": True, "terminal": "QICT",
     "gate_out": "02-OCT-2026 21:31",
     "discharge_time": "17-SEP-2026 11:47",
     "terminal_rows": [dict(_FX1016)]})
chk("v99fix2: poisoned returned merge par retract (1016)",
    not _m.get("returned") and not _m.get("returned_date"), str(_m))
# Manfi control: EM wali wapsi retract NAHI hoti.
_m = server._merge_result(
    _OLD5110, {"found": True, "source": "battery"})
chk("v99fix2: EM wali wapsi retract NAHI (5110 control)",
    _m.get("returned")
    and "29-OCT-26" in str(_m.get("returned_date")), str(_m))

print("== v99fix: (c)+(d) ghost row / dateless Gate out ==")
_FXDET = {"Vessel Voyage": "XIN CHANG SHU / 102", "ETA": "",
          "ETD": "", "Origin": "", "Destination": "",
          "VIR No": "PKKHISAPT_230526123730",
          "Current Position": "Loaded on Vessel",
          "Present Holds": "", "DO Expiry Date": "",
          "Owner": "", "Weight": "", "Commodity": "",
          "Container Size/Type": "", "Custom Status": "",
          "Category": "EXPORT",
          "Gate In Time": "08-JUN-26 11.16.53 PM",
          "Discharge Time": "", "Gate Out Time": ""}
_o = {"found": True, "terminal": "", "containers": []}
ENG._term_apply_details(_o, [dict(_FXDET, _ctn="UETU6442146",
                                  _row_status="XM",
                                  _row_gate_out="N/A",
                                  _row_discharge="")])
chk("v99fix c: XM (ghost) detail se kuch derive nahi hota",
    not _o.get("status") and not _o.get("position")
    and not _o.get("vir"), str(_o))
_o = {"found": True, "terminal": "", "containers": []}
ENG._term_apply_details(_o, [dict(_FXDET, _ctn="UETU6442146",
                                  _row_status="IF",
                                  _row_gate_out="N/A",
                                  _row_discharge="",
                                  Category="IMPORT")])
chk("v99fix d: 'N/A' gate-out se Gate out status/field nahi",
    not _o.get("status") and not _o.get("gate_out"), str(_o))
chk("v99fix c: event ke baghair position nahi li jati",
    not _o.get("position"), str(_o))
_o = {"found": True, "terminal": "", "containers": []}
ENG._term_apply_details(_o, [dict(
    _FXDET, _ctn="UETU6442146", _row_status="IF",
    _row_gate_out="", _row_discharge="29-OCT-26 03.00.00 PM",
    Category="IMPORT",
    **{"Discharge Time": "29-OCT-26 03.00.00 PM",
       "Current Position": "In Yard"})])
chk("v99fix c: event-anchored position + Discharged banta hai",
    _o.get("position") == "In Yard"
    and _o.get("status") == "Discharged", str(_o))
_r = ENG._reconcile_status({"status": "Gate out",
                            "discharge_time": "12-OCT-26 08.57.48 PM",
                            "terminal": "SAPT",
                            "position": "In Yard"})
chk("v99fix d: reconcile dateless 'Gate out' ko peeche lata hai",
    _r["status"] == "Discharged at SAPT", str(_r))

print("== v99fix: (b)+(d) full synthesis — do fail shaklein ==")
def _fx_patch(**kw):
    old = _patch99(**kw)
    extra = {}
    for n in ("track_bol_tracktrace", "track_container_tracktrace",
              "vessel_live_position"):
        extra[n] = getattr(ENG, n, None)
        setattr(ENG, n, _NF99)
    apis = dict(ENG.CARRIER_CONTAINER_APIS)
    for k in list(ENG.CARRIER_CONTAINER_APIS):
        ENG.CARRIER_CONTAINER_APIS[k] = _NF99
    # Layer 1 attribute se nahi, CARRIER_APIS dict se
    # dispatch hoti hai — mock wahan bhi lagana lazmi hai
    # (warna asal API live chalti hai aur battery jhooti
    # sabz ho sakti hai).
    bl_apis = dict(ENG.CARRIER_APIS)
    for k in list(ENG.CARRIER_APIS):
        ENG.CARRIER_APIS[k] = _NF99
    if kw.get("track_cosco"):
        ENG.CARRIER_APIS["COSCO Shipping"] = kw["track_cosco"]
    return old, extra, apis, bl_apis


def _fx_unpatch(old, extra, apis, bl_apis):
    for n, fn in old.items():
        setattr(ENG, n, fn)
    for n, fn in extra.items():
        setattr(ENG, n, fn)
    ENG.CARRIER_CONTAINER_APIS.clear()
    ENG.CARRIER_CONTAINER_APIS.update(apis)
    ENG.CARRIER_APIS.clear()
    ENG.CARRIER_APIS.update(bl_apis)


# (b) MEDUT1385110: BL listing rows + pehle dabbe ki
# history; doosra dabba completion loop se aayega.
_CX_EM = {"CONTAINER NO": "CXDU1175597", "STATUS": "EM",
          "DISCHARGING TIME": "29-OCT-26 07.56.01 PM",
          "GATE OUT TIME": None, "pid": "fxh3"}
_CX_IF = {"CONTAINER NO": "CXDU1175597", "STATUS": "IF",
          "DISCHARGING TIME": "21-OCT-26 07.42.25 PM",
          "GATE OUT TIME": "29-OCT-26 03.51.15 AM", "pid": "fxh4"}


def _fx_cmock(c):
    if c == "MSNU1300240":
        return {"found": True, "terminal": "SAPT",
                "containers": [dict(_FX_EM), dict(_FX_IF)],
                "discharge_time": "21-OCT-26 06.09.26 PM",
                "gate_out": "28-OCT-26 09.34.03 PM",
                "status": "Gate out",
                "source": "Karachi Terminal (Hutchison Ports)"}
    if c == "CXDU1175597":
        return {"found": True, "terminal": "SAPT",
                "containers": [dict(_CX_EM), dict(_CX_IF)],
                "discharge_time": "21-OCT-26 07.42.25 PM",
                "gate_out": "29-OCT-26 03.51.15 AM",
                "status": "Gate out",
                "source": "Karachi Terminal (Hutchison Ports)"}
    return {"found": False}


_p = _fx_patch(
    track_cosco=lambda bl: {
        "found": True,
        "containers": ["MSNU1300240", "CXDU1175597"],
        "status": "Gate out", "source": "battery"},
    track_karachi_terminals=lambda bl: {
        "found": True, "terminal": "SAPT",
        "vir": "PKKHISAPT_141026141909",
        "containers": [
            {"CONTAINER NO": "MSNU1300240", "Category": "IF",
             "pid": "20906685"},
            {"CONTAINER NO": "CXDU1175597", "Category": "IF",
             "pid": "20906782"}],
        "discharge_time": "21-OCT-26 06.09.26 PM",
        "gate_out": "29-OCT-26 03.51.15 AM",
        "status": "Gate out",
        "source": "Karachi Terminal (Hutchison Ports)"},
    track_karachi_terminals_container=_fx_cmock)
_o = ENG.track_all(bl="MEDUT1385110", ctn="MSNU1300240",
                   known_containers=["MSNU1300240",
                                     "CXDU1175597"])
_r = _o["result"]
chk("v99fix b: doosre dabbe ki history store hoti hai",
    any(row.get("CONTAINER NO") == "CXDU1175597"
        and row.get("STATUS") == "EM"
        for row in _r.get("terminal_rows") or []), str(_r))
chk("v99fix b: completion loop layer chala",
    any("3d+" in l["name"] for l in _o["layers"]),
    str([l["name"] for l in _o["layers"]]))
chk("v99fix a: synthesis mein returned derive hota hai",
    _r.get("returned")
    and "29-OCT-26" in str(_r.get("returned_date")), str(_r))
chk("v99fix b: gate_out completion (sab dabbe) rehta hai",
    _r.get("gate_out") == "29-OCT-26 03.51.15 AM",
    str(_r.get("gate_out")))
_fx_unpatch(*_p)

# v99fix2: 1016 synthesis — XF-only leg ka terminal
# khaali hai (koi detail nahi), lekin us ki row
# terminal_rows mein zinda rehni chahiye (Phase 2 mein
# yehi row 3d absorb mein gir gayi thi, aur merge par
# legacy gate_in ke samne wazahat na rehne se XF
# gate-in 'returned' ban gayi thi).
_p = _fx_patch(
    identify_carrier=lambda q: ("MBAQ", "RTW Shipping Lines"),
    track_karachi_terminals=lambda bl: {"found": False},
    track_qict_bl=lambda bl: {
        "found": True, "terminal": "QICT",
        "containers": ["MRKU8740840"],
        "discharge_time": "17-SEP-2026 11:47",
        "status": "Released — Delivered",
        "source": "QICT (DP World)"},
    track_qict_container_layer=lambda c: {
        "found": True, "terminal": "QICT",
        "containers": [c], "status": "Gate out",
        "gate_out": "02-OCT-2026 21:31",
        "source": "QICT (DP World)"},
    track_karachi_terminals_container=lambda c: {
        "found": True, "terminal": "",
        "containers": [dict(_FX1016)],
        "source": "Karachi Terminal (Hutchison Ports)"},
    track_kgtl_bl=lambda bl: {"found": False},
    track_kgtl_container=lambda c: {"found": False})
_o = ENG.track_all(bl="MBAQITS8502261016",
                   ctn="MRKU8740840",
                   known_containers=["MRKU8740840"])
_r = _o["result"]
chk("v99fix2: XF-only leg ki row terminal_rows mein zinda hai",
    any(row.get("CONTAINER NO") == "MRKU8740840"
        and row.get("STATUS") == "XF"
        for row in _r.get("terminal_rows") or []), str(_r))
chk("v99fix2: synthesis mein XF gate-in returned NAHI",
    not _r.get("returned") and not _r.get("returned_date"),
    str(_r))
_fx_unpatch(*_p)

# (c)+(d) COAU6468022200: carrier stamp + terminal par
# sirf listing/ghost saboot — discharge unclaimed.
_XM_ROW = {"CONTAINER NO": "UETU6442146", "STATUS": "XM",
           "GATE In TIME": "08-JUN-26 11.16.53 PM",
           "GATE OUT TIME": "N/A", "pid": "20026921"}
_p = _fx_patch(
    identify_carrier=lambda q: ("COAU", "COSCO Shipping"),
    track_cosco=lambda bl: {
        "found": True, "containers": ["UETU6442146"],
        "status": "Discharged",
        "discharge_time": "2026-10-29 15:00",
        "pod": "Karachi-South Asia Pakistan Terminals(SAPT)",
        "vessel": "APL CHONGQING", "source": "battery"},
    track_karachi_terminals=lambda bl: {
        "found": True, "terminal": "SAPT",
        "vir": "PKKHISAPT_221026134915",
        "containers": [{"CONTAINER NO": "UETU6442146",
                        "Category": "IF", "pid": "20948220"}],
        "holds": "DT(Detention), HP(Payment Hold), "
                 "LH(Line Hold)",
        "source": "Karachi Terminal (Hutchison Ports)"},
    track_karachi_terminals_container=lambda c: {
        "found": True, "terminal": "SAPT",
        "containers": [dict(_XM_ROW)],
        "source": "Karachi Terminal (Hutchison Ports)"})
_o = ENG.track_all(bl="COAU6468022200", ctn="UETU6442146")
_r = _o["result"]
chk("v99fix d: terminal tasdeeq baghair discharge unclaimed",
    not _r.get("discharge_time")
    and _r.get("discharge_unconfirmed"), str(_r))
chk("v99fix d: status Arrived-stage, Gate out nahi",
    _r.get("status") == "Arrived at SAPT terminal (Karachi)",
    str(_r.get("status")))
chk("v99fix c: ghost position synthesis mein nahi aati",
    not _r.get("position"), str(_r.get("position")))
_OLD8022 = {"status": "Gate out",
            "discharge_time": "2026-10-29 15:00",
            "position": "Loaded on Vessel", "terminal": "SAPT",
            "vir": "PKKHISAPT_221026134915",
            "containers": ["UETU6442146"],
            "terminal_rows": [dict(_XM_ROW)],
            "holds": "DT(Detention), HP(Payment Hold), "
                     "LH(Line Hold)",
            "found": True}
_m = server._merge_result(_OLD8022, _r)
chk("v99fix d: merge purana carrier discharge zinda nahi karta",
    not _m.get("discharge_time"), str(_m))
chk("v99fix c: merge ghost position zinda nahi karta",
    not _m.get("position"), str(_m.get("position")))
chk("v99fix d: merge status Arrived-stage par aata hai",
    _m.get("status") == "Arrived at SAPT terminal (Karachi)",
    str(_m.get("status")))
chk("v99fix holds: khule cycle par holds mehfooz rehte hain",
    bool(_m.get("holds")), str(_m.get("holds")))
chk("v99fix d: discharge_unconfirmed stored nahi hota",
    "discharge_unconfirmed" not in _m)
_fx_unpatch(*_p)

print("== v99fix3: QICT cycle_closed writer — export gate-in wapsi NAHI ==")
# EK usool, dono routes par: export gate-in (SAPT XF row ho ya
# QICT EXPORT-category Ctr-Inq row) agle safar ki ibtida hai,
# is shipment ki khaali-dabba wapsi nahi. Wapsi sirf EM row
# se sabit hoti hai. Phase-2 retest ke teen proven-false
# cases + 57984 convention + 268607384 ki do-tareekh
# tazad — sab isi usool se.
_QICT1159 = {"category": "EXPORT", "status": "FULL",
             "in_time": "27-OCT-2026 17:49",
             "load_time": "30-OCT-2026 13:31",
             "position": "Vessel", "vessel": "BSG BIMINI",
             "voyage": "644W", "vir": "PKBQMQICT_231026134144",
             "gate_out": "", "discharge_time": ""}
_orig_qct = ENG.track_qict_container
try:
    ENG.track_qict_container = lambda c: dict(_QICT1159)
    _w = ENG.track_qict_container_layer("MRSU0695223")
finally:
    ENG.track_qict_container = _orig_qct
chk("v99fix3: QICT EXPORT writer returned NAHI likhta",
    _w.get("found") and _w.get("cycle_closed")
    and not _w.get("returned") and not _w.get("returned_date")
    and _w.get("qict_export_in") == "27-OCT-2026 17:49", str(_w))
# Synthesis: cycle_closed leg se result mein returned NAHI aaye.
# NOTE (v99fix4): track_qict_container_layer _LAYERS99 mein
# NAHI hai — _fx_patch use patch nahi karta tha, is liye ye
# mock pehle kabhi laga hi nahi (asal QICT jawab mock ki
# copied values se milta tha, test phir bhi sabz rehta tha).
# Ab layer attribute seedha patch hota hai.
_p = _fx_patch(
    identify_carrier=lambda q: ("MBAQ", "RTW Shipping Lines"),
    track_karachi_terminals=lambda bl: {"found": False},
    track_qict_bl=lambda bl: {"found": False},
    track_karachi_terminals_container=lambda c: {"found": False},
    track_kgtl_bl=lambda bl: {"found": False},
    track_kgtl_container=lambda c: {"found": False})
_orig_qcl = ENG.track_qict_container_layer
ENG.track_qict_container_layer = lambda c: {
    "found": True, "terminal": "QICT",
    "containers": [c], "status": "Gate out",
    "cycle_closed": True,
    "qict_export_in": "27-OCT-2026 17:49",
    "qict_export_load": "30-OCT-2026 13:31",
    "source": "QICT (DP World)"}
try:
    _o = ENG.track_all(bl="MBAQITS8502261159",
                       ctn="MRSU0695223",
                       known_containers=["MRSU0695223"])
finally:
    ENG.track_qict_container_layer = _orig_qcl
_r = _o["result"]
chk("v99fix3+4: synthesis — gate-in tareekh NAHI banti, LOAD se dateless wapsi",
    _r.get("returned") is True and not _r.get("returned_date")
    and _r.get("returned_basis") == "export_reload"
    and _r.get("qict_export_in") == "27-OCT-2026 17:49", str(_r))
_fx_unpatch(*_p)
# Poisoned QICT record: returned date == export In Time, rows null.
_PQ = {"containers": ["MRSU0695223"], "terminal": "QICT",
       "status": "Released — Delivered",
       "returned": True, "returned_date": "27-OCT-2026 17:49",
       "qict_export_in": "27-OCT-2026 17:49",
       "qict_export_load": "30-OCT-2026 13:31",
       "terminal_rows": None}
ENG._settle_empty_return(_PQ)
chk("v99fix3+4: QICT ghalat tareekh retract, LOAD se dateless wapsi derive",
    _PQ.get("returned") is True and not _PQ.get("returned_date")
    and _PQ.get("returned_basis") == "export_reload", str(_PQ))
# EM row ho to retraction NAHI (EM jeet-ta hai).
_PQE = {"containers": ["MRSU0695223"], "terminal": "QICT",
        "status": "Released — Delivered",
        "returned": True, "returned_date": "27-OCT-2026 17:49",
        "qict_export_in": "27-OCT-2026 17:49",
        "terminal_rows": [{"CONTAINER NO": "MRSU0695223", "STATUS": "EM",
                          "DISCHARGING TIME": "29-OCT-2026 10:00"}]}
ENG._settle_empty_return(_PQE)
chk("v99fix3: EM mojood ho to QICT retraction NAHI",
    _PQE.get("returned") and _PQE.get("returned_date"), str(_PQE))
# 57984: wahi usool — returned gaya.
_P584 = {"containers": ["MRSU8030271"], "terminal": "QICT",
         "status": "Released — Delivered",
         "returned": True, "returned_date": "21-OCT-2026 02:52",
         "qict_export_in": "21-OCT-2026 02:52",
         "qict_export_load": "28-OCT-2026 06:45",
         "terminal_rows": None}
ENG._settle_empty_return(_P584)
chk("v99fix3+4: 57984 — ghalat tareekh gayi, LOAD se dateless wapsi",
    _P584.get("returned") is True and not _P584.get("returned_date")
    and _P584.get("returned_basis") == "export_reload",
    str(_P584))
# Fallback: gate_in jo QICT export In Time ho, derivation NAHI.
_PFG = {"containers": ["MRSU0695223"],
        "discharge_time": "08-OCT-2026 13:31",
        "gate_out": "20-OCT-2026 10:00",
        "gate_in": "27-OCT-2026 17:49",
        "qict_export_in": "27-OCT-2026 17:49",
        "terminal_rows": None}
chk("v99fix3: QICT export gate_in se derivation NAHI",
    not ENG.derive_empty_return(_PFG) and not _PFG.get("returned"),
    str(_PFG))
# 268607384: merge par ghalat tareekh + 31-Aug dawa dono gaye.
_OLD268 = {"status": "Delivered — container returned empty to depot 31 Aug 2026",
           "terminal": "QICT", "containers": ["SEKU6723227"],
           "discharge_time": "13 Aug 2026",
           "returned": True, "returned_date": "29-SEP-2026 01:45",
           "found": True}
_m = server._merge_result(
    _OLD268,
    {"found": True, "terminal": "QICT", "status": "Gate out",
     "cycle_closed": True, "qict_export_in": "29-SEP-2026 01:45",
     "qict_export_load": "14-OCT-2026 03:05"})
chk("v99fix3+4: 268607384 ghalat tareekh + 31-Aug dawa gaye, LOAD se dateless wapsi",
    _m.get("returned") is True and not _m.get("returned_date")
    and _m.get("returned_basis") == "export_reload"
    and "31 Aug" not in str(_m.get("status"))
    and "returned empty" not in str(_m.get("status")).lower(),
    str(_m))
# 57984 merge: returned gaya, Delivered (import cycle mukammal) raha.
_OLD584 = {"status": "Released — Delivered", "terminal": "QICT",
           "containers": ["MRSU8030271"],
           "vir": "PKBQMQICT_201026130531",
           "returned": True, "returned_date": "21-OCT-2026 02:52",
           "found": True}
_m = server._merge_result(
    _OLD584,
    {"found": True, "terminal": "QICT", "status": "Gate out",
     "cycle_closed": True, "qict_export_in": "21-OCT-2026 02:52",
     "qict_export_load": "28-OCT-2026 06:45"})
chk("v99fix3+4: 57984 merge — dateless wapsi, Delivered barkarar",
    _m.get("returned") is True and not _m.get("returned_date")
    and _m.get("returned_basis") == "export_reload"
    and _m.get("status") == "Released — Delivered", str(_m))
# Doctor: purana status text entry flag ko dobara zeher NAHI de.
_h268 = {"query": "268607384", "found": True,
         "result": {"status": "Delivered — container returned empty to depot 31 Aug 2026",
                    "terminal": "QICT", "containers": ["SEKU6723227"],
                    "discharge_time": "13 Aug 2026",
                    "returned": False},
         "returned": False}
_c, _f = server._doctor_check_entry(_h268, {}, int(time.time()))
chk("v99fix3: Doctor purane status text se entry flag zeher NAHI karta",
    not _h268.get("returned"), str(_c))

print("== v99fix4: Fix Round 4 replay ==")
# (i) QICT record: export_in + export_load -> returned
# True, returned_date None, basis export_reload.
_F1 = {"containers": ["SEKU6723227"], "terminal": "QICT",
       "status": "Gate out", "discharge_time": "13 Aug 2026",
       "qict_export_in": "29-SEP-2026 01:45",
       "qict_export_load": "14-OCT-2026 03:05",
       "terminal_rows": None}
ENG._settle_empty_return(_F1)
chk("v99fix4 (i): export LOAD -> dateless confirmed wapsi + basis",
    _F1.get("returned") is True and not _F1.get("returned_date")
    and _F1.get("returned_basis") == "export_reload", str(_F1))
# (ii) export gate-in ONLY (1016 shakl: XF row, koi load
# nahi) -> returned False hi rehta hai.
_F2 = {"containers": ["MRKU8740840"], "terminal": "SAPT",
       "status": "Released — Delivered",
       "discharge_time": "17-SEP-2026 11:47",
       "gate_out": "02-OCT-2026 21:31",
       "gate_in": "28-OCT-26 08.23.38 AM",
       "terminal_rows": [{"CONTAINER NO": "MRKU8740840",
                          "STATUS": "XF",
                          "GATE In TIME": "28-OCT-26 08.23.38 AM",
                          "GATE OUT TIME": "N/A"}]}
ENG._settle_empty_return(_F2)
chk("v99fix4 (ii): export gate-in akeli (1016) -> wapsi NAHI",
    not _F2.get("returned") and not _F2.get("returned_basis"),
    str(_F2))
# (iii) basis-derived True: saboot (EM ya load) ghayb ho
# to retract — stickiness nahi.
_F3 = {"containers": ["SEKU6723227"], "terminal": "QICT",
       "status": "Gate out",
       "returned": True, "returned_basis": "export_reload",
       "terminal_rows": None}
ENG._settle_empty_return(_F3)
chk("v99fix4 (iii): basis wapsi saboot ghayb hone par retract",
    not _F3.get("returned") and not _F3.get("returned_basis"),
    str(_F3))
# (iii-b) basis True + load barqarar -> wapsi rehti hai.
_F3b = {"containers": ["SEKU6723227"], "terminal": "QICT",
        "status": "Gate out",
        "returned": True, "returned_basis": "export_reload",
        "qict_export_in": "29-SEP-2026 01:45",
        "qict_export_load": "14-OCT-2026 03:05",
        "terminal_rows": None}
ENG._settle_empty_return(_F3b)
chk("v99fix4 (iii-b): basis wapsi load ke sath barkarar",
    _F3b.get("returned") is True
    and _F3b.get("returned_basis") == "export_reload"
    and not _F3b.get("returned_date"), str(_F3b))
# (iii-c) basis True + EM row aa jaye -> tareekh wali
# asal wapsi basis ki jagah leti hai.
_F3c = {"containers": ["SEKU6723227"], "terminal": "QICT",
        "status": "Gate out", "gate_out": "19-OCT-2026 10:00",
        "returned": True, "returned_basis": "export_reload",
        "qict_export_load": "14-OCT-2026 03:05",
        "terminal_rows": [{"CONTAINER NO": "SEKU6723227",
                           "STATUS": "EM",
                           "DISCHARGING TIME": "20-OCT-26 06.23.29 PM",
                           "GATE OUT TIME": "19-OCT-26 10.00.00 AM"}]}
ENG._settle_empty_return(_F3c)
chk("v99fix4 (iii-c): EM aa jaye to tareekh wali wapsi jeet-ti hai",
    _F3c.get("returned") is True
    and "20-OCT-26" in str(_F3c.get("returned_date"))
    and not _F3c.get("returned_basis"), str(_F3c))
# Multi-container: record-level load saboot kis dabbe
# ka hai tay nahi — flip NAHI (partial).
_F5 = {"containers": ["AAAA1111111", "BBBB2222222"],
       "terminal": "QICT", "status": "Gate out",
       "qict_export_in": "29-SEP-2026 01:45",
       "qict_export_load": "14-OCT-2026 03:05",
       "terminal_rows": None}
ENG._settle_empty_return(_F5)
chk("v99fix4: multi-container par record-level LOAD flip NAHI (partial)",
    not _F5.get("returned") and not _F5.get("returned_basis"),
    str(_F5))
# (iv) gate_in anchor: gate_out ke BAAD wali gate_in
# drop, pehle wali barkarar (merge choke point par).
_F4old = {"status": "Released — Delivered", "terminal": "QICT",
          "containers": ["MRKU8740840"], "found": True,
          "discharge_time": "17-SEP-2026 11:47",
          "gate_out": "02-OCT-2026 21:31",
          "gate_in": "28-OCT-26 08.23.38 AM", "returned": False}
_m4 = server._merge_result(dict(_F4old), {"found": True})
chk("v99fix4 (iv): gate_out ke BAAD wali gate_in drop (1016)",
    not _m4.get("gate_in"), str(_m4.get("gate_in")))
_F4old2 = dict(_F4old, gate_in="01-OCT-2026 09:00")
_m4b = server._merge_result(dict(_F4old2), {"found": True})
chk("v99fix4 (iv-b): gate_out se PEHLE wali gate_in barkarar",
    _m4b.get("gate_in") == "01-OCT-2026 09:00",
    str(_m4b.get("gate_in")))
# Synthesis: QICT cycle_closed sirf gate-in ke sath
# (load NAHI) -> synthesis mein bhi wapsi NAHI banti.
# (Layer attribute seedha patch — oper wali NOTE dekho.)
_p = _fx_patch(
    identify_carrier=lambda q: ("MBAQ", "RTW Shipping Lines"),
    track_karachi_terminals=lambda bl: {"found": False},
    track_qict_bl=lambda bl: {"found": False},
    track_karachi_terminals_container=lambda c: {"found": False},
    track_kgtl_bl=lambda bl: {"found": False},
    track_kgtl_container=lambda c: {"found": False})
_orig_qcl2 = ENG.track_qict_container_layer
ENG.track_qict_container_layer = lambda c: {
    "found": True, "terminal": "QICT",
    "containers": [c], "status": "Gate out",
    "cycle_closed": True,
    "qict_export_in": "27-OCT-2026 17:49",
    "source": "QICT (DP World)"}
try:
    _o = ENG.track_all(bl="MBAQITS8502261159",
                       ctn="MRSU0695223",
                       known_containers=["MRSU0695223"])
finally:
    ENG.track_qict_container_layer = _orig_qcl2
_r = _o["result"]
chk("v99fix4: synthesis — gate-in akeli (load NAHI) wapsi NAHI",
    not _r.get("returned") and not _r.get("returned_date")
    and not _r.get("returned_basis")
    and _r.get("qict_export_in") == "27-OCT-2026 17:49", str(_r))
_fx_unpatch(*_p)

print(f"\nMAJMUA: {ok} PASS, {fail} FAIL")
sys.exit(1 if fail else 0)
