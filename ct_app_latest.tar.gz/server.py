#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CargoTrack v51 — Web UI server (stdlib only).
Tracking engine: bl_track.py. Data lives outside the app folder:
  ~/CargoTrack_Data/history.json + settings.json
Run:  python server.py   (your browser opens automatically)
"""
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shutil
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as _FutTimeout
import zipfile
from datetime import datetime, date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import urllib.request
import urllib.error

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bl_track as ENG

DATA_DIR = Path.home() / "CargoTrack_Data"
DATA_DIR.mkdir(exist_ok=True)
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
STAFF_ACTIVITY_FILE = DATA_DIR / "staff_activity.json"
STAFF_HISTORY_FILE = DATA_DIR / "staff_history.json"
PHOTOS_DIR = DATA_DIR / "photos"
PHOTOS_DIR.mkdir(exist_ok=True)
PORT = 8765
APP_VERSION = 136
APP_BUILT = "11 Nov 2026, 06:31 PM PKT"

_lock = threading.Lock()


def load_json(p, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(p, obj):
    # F-05 fix (v46 audit): write to a temp file, then atomically
    # replace — a crash/power-cut mid-write used to corrupt the file,
    # and load_json then silently returned empty (whole history lost).
    try:
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        os.replace(tmp, p)
        return True
    except Exception:
        return False


APP_DIR = Path(__file__).resolve().parent


def _apply_seed_once():
    """v44 FINAL one-time seed: replace history with the verified 78-BL
    record shipped beside server.py. The old history is first copied to a
    dated backup in the data dir; a marker stops any re-application."""
    seed = APP_DIR / "seed_history.json"
    marker = DATA_DIR / "seed_v44final.done"
    try:
        if seed.exists() and not marker.exists():
            data = load_json(seed, None)
            if isinstance(data, list) and data:
                if HISTORY_FILE.exists():
                    bak = DATA_DIR / "history_backup_2026-10-22.json"
                    if not bak.exists():
                        bak.write_bytes(HISTORY_FILE.read_bytes())
                if save_json(HISTORY_FILE, data):
                    marker.write_text("done", encoding="utf-8")
                    seed.unlink()
    except Exception:
        pass


_apply_seed_once()


def _remove_lock_once():
    """v51 one-time lock removal (Yousuf's order): the update package
    includes ct_remove_lock.flag present beside server.py
    and if no marker exists in the data dir, then remove ONLY the app_pass
    key from settings — the Groq key and all other settings stay safe.
    The marker prevents re-running and the flag file is also deleted
    afterwards. It never raises an exception."""
    flag = APP_DIR / "ct_remove_lock.flag"
    marker = DATA_DIR / "ct_lock_removed_v51.done"
    try:
        if flag.exists() and not marker.exists():
            s = load_json(SETTINGS_FILE, {})
            if isinstance(s, dict) and "app_pass" in s:
                s.pop("app_pass", None)
                save_json(SETTINGS_FILE, s)
            marker.write_text("done", encoding="utf-8")
            flag.unlink()
    except Exception:
        pass


_remove_lock_once()


def _enrich_history_once():
    """v54/v55 one-time record ENRICH (24 Oct 2026): enrich data
    fields given in the files are filled into existing entries
    only where they are empty — no filled
    field is ever overwritten, except those in the item's
    'force' list (for example an old placeholder status).
    If an entry does not exist, a new one is created. Each file's
    own marker prevents re-running; the data file is deleted after
    it is applied. It never raises an exception.
    v96 (29 Oct 2026): ct_enrich_history_v96.json — evidence-based
    corrections from the data audit; an item-level 'returned': true
    can also set the entry's empty-return flag."""
    for _fname, _mname in (
            ("ct_enrich_history.json", "ct_enrich_v54.done"),
            ("ct_enrich_history_v55.json", "ct_enrich_v55.done"),
            ("ct_enrich_history_v66.json", "ct_enrich_v66.done"),
            ("ct_enrich_history_v87.json", "ct_enrich_v87.done"),
            ("ct_enrich_history_v96.json", "ct_enrich_v96.done")):
        data_file = APP_DIR / _fname
        marker = DATA_DIR / _mname
        try:
            if data_file.exists() and not marker.exists():
                raw = load_json(data_file, {})
                items = raw.get("enrich") if isinstance(raw, dict) else raw
                if isinstance(items, list) and items:
                    hist = load_json(HISTORY_FILE, [])
                    if not isinstance(hist, list):
                        hist = []
                    by_q = {(e.get("query") or ""): e for e in hist
                            if isinstance(e, dict)}
                    changed = False
                    for it in items:
                        q = (it.get("query") or "").strip()
                        if not q:
                            continue
                        fill = it.get("result") or {}
                        force = set(it.get("force") or [])
                        e = by_q.get(q)
                        if e is None:
                            now = time.time()
                            stamp = _DT(datetime.fromtimestamp(now))
                            e = {"query": q, "mode": "bl", "client": "",
                                 "carrier": it.get("carrier", ""),
                                 "prefix": "", "contacts": None,
                                 "amount": "", "received": "",
                                 "returned": "", "notes": "",
                                 "photo": "", "starred": False,
                                 "checklist": {}, "changes": [],
                                 "change_kind": "", "changed": False,
                                 "found": bool(it.get("found")),
                                 "result": dict(fill),
                                 "layers": [{
                                     "name": "Shezi — record update "
                                             "(24 Oct 2026)",
                                     "status": "done",
                                     "detail": "Verified details added "
                                               "by Shezi; recheck in "
                                               "the app for live "
                                               "status."}],
                                 "checked_ts": int(now), "time": stamp,
                                 "first_seen": stamp}
                            if it.get("returned"):
                                e["returned"] = True
                            hist.append(e)
                            by_q[q] = e
                            changed = True
                            continue
                        r = e.get("result")
                        if not isinstance(r, dict):
                            r = {}
                            e["result"] = r
                        for k, v in fill.items():
                            if k in force or r.get(k) in (None, "", []):
                                if r.get(k) != v:
                                    r[k] = v
                                    changed = True
                        if it.get("found") and not e.get("found"):
                            e["found"] = True
                            changed = True
                        # v96: item-level 'returned' — lifecycle
                        # reads the entry's h['returned'] flag;
                        # on terminal evidence, the empty-return is recorded
                        # through this (data audit round 2).
                        if it.get("returned") and not e.get("returned"):
                            e["returned"] = True
                            changed = True
                        if it.get("carrier") and not e.get("carrier"):
                            e["carrier"] = it["carrier"]
                            changed = True
                    if changed:
                        save_json(HISTORY_FILE, hist)
                marker.write_text("done", encoding="utf-8")
                data_file.unlink()
        except Exception:
            pass


def _merge_extra_history_once():
    """v51 one-time record merge (Yousuf's order, 24 Oct 2026):
    the BL records in ct_extra_history.json that came with the update package —
    add only those that are NOT already in history
    — no existing entry is ever overwritten.
    The marker prevents re-running, and the data file
    is deleted after it is applied. It never raises
    an exception."""
    data_file = APP_DIR / "ct_extra_history.json"
    marker = DATA_DIR / "ct_extra_history_v51.done"
    try:
        if data_file.exists() and not marker.exists():
            raw = load_json(data_file, [])
            entries = raw.get("history") if isinstance(raw, dict) else raw
            if isinstance(entries, list) and entries:
                hist = load_json(HISTORY_FILE, [])
                if not isinstance(hist, list):
                    hist = []
                have = {(e.get("query") or "") for e in hist
                        if isinstance(e, dict)}
                added = [e for e in entries
                         if isinstance(e, dict)
                         and (e.get("query") or "")
                         and (e.get("query") or "") not in have]
                if added:
                    save_json(HISTORY_FILE, hist + added)
            marker.write_text("done", encoding="utf-8")
            data_file.unlink()
    except Exception:
        pass


_merge_extra_history_once()
_enrich_history_once()


def _is_insertion_variant(longer, shorter):
    """True if 'longer' is just 'shorter' with ONE character
    inserted into it (length +1, order unchanged)."""
    if len(longer) != len(shorter) + 1:
        return False
    return any(longer[:i] + longer[i + 1:] == shorter
               for i in range(len(longer)))


def _first_seen_key(e):
    v = str((e or {}).get("first_seen") or "")
    for f in ("%d %b %Y, %I:%M %p", "%Y-%m-%d", "%d %b %Y", "%d-%b-%Y"):
        try:
            return datetime.strptime(v, f).timestamp()
        except Exception:
            continue
    return 9e18


def _dup_bl_fold(hist):
    """ONE BL = ONE ENTRY (v112): cleans up two types of duplicate
    BL entries and returns the cleaned list.
    (A) Two entries for the same shipment: containers overlap
        + (VIRs are equal, or VIR is empty and vessel+discharge
        are equal) -> merge data into the original (first-created) entry
        and remove the other one.
    (B) A completely empty not-found entry whose number is an
        insertion-variant of a data-bearing entry (one digit
        inserted) -> it is a misread, remove it.
        A substitution variant (same length) is NOT touched —
        it could be a genuine BL.
    An entry with bl_copy is never touched."""
    def _q(e):
        return str((e or {}).get("query") or "").strip().upper()

    def _res(e):
        return (e or {}).get("result") or {}

    def _ctns(e):
        return {str(c).strip().upper()
                for c in (_res(e).get("containers") or []) if c}

    def _has_data(e):
        return bool(e.get("found") or _ctns(e)
                    or _res(e).get("vessel")
                    or _res(e).get("discharge_time"))

    import re as _re2
    cntr_re = _re2.compile(r"^[A-Z]{4}[0-9]{7}$")
    out = [e for e in hist if isinstance(e, dict)]
    removed = set()
    # (A) same-shipment pairs
    for i in range(len(out)):
        if i in removed or out[i].get("bl_copy"):
            continue
        for j in range(len(out)):
            if j <= i or j in removed or out[j].get("bl_copy"):
                continue
            a, b = out[i], out[j]
            qa, qb = _q(a), _q(b)
            if not qa or qa == qb:
                continue
            if cntr_re.match(qa) or cntr_re.match(qb):
                continue  # container entries are the work of the v111 sweep
            ca, cb = _ctns(a), _ctns(b)
            # the container SET must be exactly equal — the preceding/following
            # real BLs in the series keep their own separate boxes,
            # only in a duplicate is the set the same
            if not (ca and ca == cb):
                continue
            va = str(_res(a).get("vir") or "")
            vb = str(_res(b).get("vir") or "")
            same_voyage = bool(va and vb and va == vb) or (
                not va and not vb
                and _res(a).get("vessel")
                and _res(a).get("vessel") == _res(b).get("vessel")
                and _res(a).get("discharge_time")
                and _res(a).get("discharge_time")
                == _res(b).get("discharge_time"))
            if not same_voyage:
                continue
            # the number's form must also be variant-like: one
            # digit inserted, or on one side only a bare
            # digits fragment. Two format-valid BL
            # numbers are NEVER auto-merged — in groupage
            # two real BLs can share one container
            # (MBAQITS8502261012/1015 evidence).
            _variant = _is_insertion_variant(qa, qb) or \
                _is_insertion_variant(qb, qa) or \
                qa.isdigit() != qb.isdigit()
            if not _variant:
                continue
            # canonical: a format-valid BL number (never a bare
            # digits fragment), then the one created
            # first, then the smaller number
            def _frag(q):
                return 1 if q.isdigit() else 0
            ka = (_frag(qa), _first_seen_key(a), len(qa))
            kb = (_frag(qb), _first_seen_key(b), len(qb))
            keep, drop = (a, b) if ka <= kb else (b, a)
            di = i if drop is a else j
            try:
                if va and vb and va == vb:
                    merged = _merge_result(_res(keep), _res(drop))
                    if merged:
                        keep["result"] = merged
                kr = keep.setdefault("result", {})
                dr = _res(drop)
                cu = list(kr.get("containers") or [])
                for c in (dr.get("containers") or []):
                    if c and c not in cu:
                        cu.append(c)
                if cu:
                    kr["containers"] = cu
                if drop.get("found"):
                    keep["found"] = True
                ch = keep.setdefault("changes", [])
                if isinstance(ch, list):
                    ch.append({"kind": "dup_merge",
                               "from": _q(drop),
                               "note": "Duplicate entry merged "
                                       "(same shipment)"})
            except Exception:
                pass
            removed.add(di)
    out = [e for k, e in enumerate(out) if k not in removed]
    # (B) empty insertion-variant entries
    kept = []
    for e in out:
        q = _q(e)
        drop = False
        if q and not cntr_re.match(q) \
                and not e.get("bl_copy") and not _has_data(e):
            for o in out:
                oq = _q(o)
                if oq and oq != q and not cntr_re.match(oq) \
                        and _has_data(o) \
                        and _is_insertion_variant(q, oq):
                    drop = True
                    ch = o.setdefault("changes", [])
                    if isinstance(ch, list):
                        ch.append({"kind": "dup_merge",
                                   "from": q,
                                   "note": "Empty mis-read entry "
                                           "removed"})
                    break
        if not drop:
            kept.append(e)
    return kept


def _merge_duplicate_bls_v112():
    """v112 (Yousuf, 4 Nov 2026): cleanup of duplicate BL entries
    — on both the main file and the staff file, on every import
    (so duplicates returned via sync are also cleaned).
    It never raises an exception."""
    try:
        for _f in (HISTORY_FILE, STAFF_HISTORY_FILE):
            try:
                if not _f.exists():
                    continue
                _h = load_json(_f, [])
                if isinstance(_h, list) and _h:
                    _n = _dup_bl_fold(_h)
                    if len(_n) != len(_h):
                        save_json(_f, _n)
            except Exception:
                continue
    except Exception:
        pass


def _fix_emkay_typo_v114():
    """v114 (Yousuf, 5 Nov 2026): EMKAYMBAKH1##### entries
    — incorrect entries created by reading 'I' as '1' —
    merge them into the genuine EMKAYMBAKHI#####. If the genuine entry
    exists, move the typo entry's BL copy (and copy-fields) there
    and remove the typo; if not, correct the entry's number
    itself. On both files, on every import
    (entries returned via sync are also cleaned). It never raises."""
    try:
        import re as _re4
        pat = _re4.compile(r"^EMKAYMBAKH1(\d{5})$")
        for _f in (HISTORY_FILE, STAFF_HISTORY_FILE):
            try:
                if not _f.exists():
                    continue
                _h = load_json(_f, [])
                if not (isinstance(_h, list) and _h):
                    continue
                _byq = {}
                for _e in _h:
                    if isinstance(_e, dict):
                        _byq[str(_e.get("query") or "")
                             .strip().upper()] = _e
                _out, _changed = [], False
                for _e in _h:
                    if not isinstance(_e, dict):
                        _out.append(_e)
                        continue
                    _q = str(_e.get("query") or "").strip().upper()
                    _m = pat.match(_q)
                    if not _m:
                        _out.append(_e)
                        continue
                    _good = "EMKAYMBAKHI" + _m.group(1)
                    _tgt = _byq.get(_good)
                    if _tgt is not None and _tgt is not _e:
                        if _e.get("bl_copy") and \
                                not _tgt.get("bl_copy"):
                            _tgt["bl_copy"] = _e["bl_copy"]
                        if _e.get("bl_copy_fields") and \
                                not _tgt.get("bl_copy_fields"):
                            _tgt["bl_copy_fields"] = \
                                _e["bl_copy_fields"]
                        _changed = True
                    else:
                        _e["query"] = _good
                        _out.append(_e)
                        _changed = True
                if _changed:
                    save_json(_f, _out)
            except Exception:
                continue
    except Exception:
        pass


def _merge_linked_containers_v111():
    """v111 (Yousuf's order, 4 Nov 2026): a container number that is
    listed in a BL entry's containers, its SEPARATE entry —
    whether found or not-found, whatever the mode — is a duplicate entry;
    ONE BL = ONE ENTRY (there is no logic for a separate entry).
    If the container entry's VIR matches an owner BL entry's VIR
    (the same terminal cycle), first preserve its data
    into the BL entry via _merge_result, then remove the entry.
    If the VIR does not match, that data is not from this BL's voyage
    at all (previous cycle / ghost) — remove it without merging,
    so that old data does not corrupt the BL record.
    NOTE: this function is called AFTER _merge_result
    (see below), because it needs it. It runs on every import
    so that an entry returned via sync is also cleaned
    up. It never raises an exception."""
    try:
        hist = load_json(HISTORY_FILE, [])
        if not (isinstance(hist, list) and hist):
            return
        import re as _re
        cntr_re = _re.compile(r"^[A-Z]{4}[0-9]{7}$")

        def _q(e):
            return str((e or {}).get("query") or "").strip().upper()

        owners = {}
        for e in hist:
            if not isinstance(e, dict):
                continue
            if cntr_re.match(_q(e)):
                continue
            for c in ((e.get("result") or {}).get("containers") or []):
                if c:
                    owners.setdefault(str(c).strip().upper(), []).append(e)
        if not owners:
            return
        kept, changed = [], False
        for e in hist:
            if not isinstance(e, dict):
                kept.append(e)
                continue
            q = _q(e)
            if e.get("bl_copy"):
                kept.append(e)
                continue
            if cntr_re.match(q) and q in owners:
                r = e.get("result") or {}
                cvir = str(r.get("vir") or "")
                if e.get("found") and cvir:
                    for owner in owners[q]:
                        ovir = str(((owner.get("result") or {})
                                    .get("vir")) or "")
                        if ovir and ovir == cvir:
                            try:
                                merged = _merge_result(
                                    owner.get("result") or {}, r)
                                if merged:
                                    owner["result"] = merged
                            except Exception:
                                pass
                            break
                changed = True
                continue
            kept.append(e)
        if changed:
            save_json(HISTORY_FILE, kept)
    except Exception:
        pass


def _bl_links_v107_once():
    """v107 (Yousuf's order, 2 Nov 2026): BL copies given by Yousuf
    provide proven link data — empty containers/vessel fields of 4 BL records
    are filled so that their container entries do not stay
    separate (ONE BL = ONE ENTRY). It fills only an empty field; if the entry
    does not exist it does nothing; a filled field is never
    overwritten. The marker prevents re-running.
    It never raises an exception."""
    marker = DATA_DIR / "ct_bl_links_v107.done"
    try:
        if marker.exists():
            return
        links = {
            "051GA16585": (["WHSU2098504", "WHSU2294908",
                            "WHSU2350283", "WHSU2760117"],
                           "WAN HAI 351"),
            "EMKAYMBAKHI59203": (["MRSU9683521"], "ARGOLIKOS"),
            "PELMSASUBKHI030926": (["CBHU5680350", "BMOU2755409"], ""),
            "PELMSASUBKHI010926": (["GLDU9608137", "FCIU4245866",
                                    "HGMU1110890", "MOAU0774432",
                                    "XINU1190143", "CCLU3833738"], ""),
        }
        hist = load_json(HISTORY_FILE, [])
        if isinstance(hist, list) and hist:
            by_q = {(e.get("query") or ""): e for e in hist
                    if isinstance(e, dict)}
            changed = False
            for q, (conts, vess) in links.items():
                e = by_q.get(q)
                if e is None:
                    continue
                r = e.get("result")
                if not isinstance(r, dict):
                    r = {}
                    e["result"] = r
                if not r.get("containers"):
                    r["containers"] = list(conts)
                    changed = True
                if vess and not r.get("vessel"):
                    r["vessel"] = vess
                    changed = True
            if changed:
                save_json(HISTORY_FILE, hist)
        marker.write_text("done", encoding="utf-8")
    except Exception:
        pass


_bl_links_v107_once()


def _refresh_history_once():
    """v63 one-time record REFRESH (25 Oct 2026): Yousuf's
    order — fresh records sent after re-tracking all records.
    If the shipped entry's checked_ts is newer than the stored one,
    ONLY the tracking part (found/result/layers/time/
    checked_ts) is replaced; the user's own fields (starred,
    checklist, notes, client, amount, received, returned,
    photo, first_seen) are never touched. If the status changed,
    it is recorded in changes. The marker prevents re-running;
    the data file is deleted after applying. It never raises."""
    data_file = APP_DIR / "ct_refresh_history_v63.json"
    marker = DATA_DIR / "ct_refresh_v63.done"
    try:
        if data_file.exists() and not marker.exists():
            raw = load_json(data_file, {})
            items = raw.get("refresh") if isinstance(raw, dict) else raw
            if isinstance(items, list) and items:
                hist = load_json(HISTORY_FILE, [])
                if not isinstance(hist, list):
                    hist = []
                by_q = {(e.get("query") or ""): e for e in hist
                        if isinstance(e, dict)}
                changed = False
                for it in items:
                    q = (it.get("query") or "").strip()
                    if not q:
                        continue
                    e = by_q.get(q)
                    if e is None:
                        continue  # refresh only for existing records
                    if int(it.get("checked_ts") or 0) <= int(
                            e.get("checked_ts") or 0):
                        continue
                    old_status = (e.get("result") or {}).get(
                        "status") or ""
                    e["found"] = bool(it.get("found"))
                    e["result"] = it.get("result") or {}
                    e["layers"] = it.get("layers") or []
                    e["time"] = it.get("time") or e.get("time")
                    e["checked_ts"] = int(it.get("checked_ts") or 0)
                    new_status = (e["result"] or {}).get("status") or ""
                    if new_status != old_status:
                        ch = e.get("changes")
                        if not isinstance(ch, list):
                            ch = []
                            e["changes"] = ch
                        ch.append({"from": old_status,
                                   "to": new_status,
                                   "time": e["time"]})
                        e["changed"] = True
                        e["change_kind"] = "status"
                    changed = True
                if changed:
                    save_json(HISTORY_FILE, hist)
            marker.write_text("done", encoding="utf-8")
            data_file.unlink()
    except Exception:
        pass


_refresh_history_once()


def get_history():
    h = load_json(HISTORY_FILE, [])
    if not isinstance(h, list):
        return []
    return [_migrate_entry(x) for x in h]


def _get_staff_history():
    """v111 (Option 1): a separate file for records tracked by staff themselves
    — always separate from Admin's main history."""
    h = load_json(STAFF_HISTORY_FILE, [])
    if not isinstance(h, list):
        return []
    return [_migrate_entry(x) for x in h]


def _save_staff_history(entries):
    save_json(STAFF_HISTORY_FILE, entries[:1000])


# ---------------- v49: bundled OCR engine + BL record extractor ------------
# Photo scan now runs via the engine bundled INSIDE the app (RapidOCR/onnxruntime)
# — there is no need for Tesseract. Every scan takes place in a
# small subprocess so that the model's memory after the scan
# is freed.
# v50: the engine can be found in two places — (a) shipped with the app,
# ocr/venv, or (b) ocr/pylibs, which on the first scan a ONE-TIME
# AUTO-SETUP creates itself (see ocr/setup_state.json +
# ocr/setup.log). Therefore, even on a completely new machine (fresh
# server / fresh laptop) the user does not have to install anything:
# on the first photo the setup completes itself in a few minutes,
# and subsequent scans run directly.
# The extractor's rules were learned from Yousuf's 43 BL photos
# (~/workspace/bl-formats-learned.md): the BL number is always from near the LABEL;
# booking/S-O/serial is never a BL; the container from the ISO check
# digit; a seal is never a BL; a PROFORMA has no BL at all.
OCR_DIR = BASE / "ocr"
OCR_PYLIBS = OCR_DIR / "pylibs"
OCR_BOOTSTRAP_DIR = OCR_DIR / "_bootstrap"
OCR_SETUP_STATE = OCR_DIR / "setup_state.json"
OCR_SETUP_LOG = OCR_DIR / "setup.log"
# v86 (system fix): the scan engine is now in a PERMANENT shared location —
# "ocr_engine" alongside DATA_DIR. Previously the engine was built inside each version's
# folder; every new version = engine gone =
# 450MB setup again, and if the setup remained incomplete the scan silently
# fell back to AI-vision only (the root of the I/1 error). Now
# an engine built once will be used by every version.
OCR_SHARED = DATA_DIR / "ocr_engine"
OCR_SHARED_PYLIBS = OCR_SHARED / "pylibs"
OCR_SHARED_STATE = OCR_SHARED / "setup_state.json"
OCR_SHARED_LOG = OCR_SHARED / "setup.log"
OCR_SETUP_MSG = ("Photo-scan engine is being set up on this device "
                 "(one-time setup, a few minutes). Please try again "
                 "shortly.")
OCR_FAILED_MSG = ("Photo-scan engine setup could not be completed "
                  "on this device. Please check the internet "
                  "connection and try again later.")
_ocr_cache = {"py": None, "env": None, "ts": 0.0}
_ocr_setup = {"proc": None}
_ocr_setup_lock = threading.Lock()


def _ocr_probe(py, env_extra=None):
    """Quick check of the rapidocr import on a single interpreter.
    env_extra (e.g. PYTHONPATH=ocr/pylibs) is passed
    to the subprocess. Returns False if file missing / import fails."""
    import subprocess
    if not py or not os.path.isfile(py):
        return False
    env = None
    if env_extra:
        env = dict(os.environ)
        for k, v in env_extra.items():
            if k == "PYTHONPATH" and env.get("PYTHONPATH"):
                env[k] = v + os.pathsep + env["PYTHONPATH"]
            else:
                env[k] = v
    try:
        r = subprocess.run([py, "-c", "import rapidocr_onnxruntime"],
                           capture_output=True, timeout=60, env=env)
        return r.returncode == 0
    except Exception:
        return False


def _ocr_resolve(force=False):
    """Engine resolution: (python_path, env_extra) or (None, None).
    Order: (0) CT_OCR_PYTHON override, (1) the app's ocr/venv —
    exactly as it was in v49, (2) ocr/pylibs with the app's
    own Python (sys.executable) + PYTHONPATH,
    (3) this same Python if rapidocr is already present in it,
    (4) the developer machine's ocrvenv.
    Successful resolution is always cached; failure is cached only 20 seconds
    so an expensive probe does not run on every request and
    the engine is found immediately after auto-setup."""
    now = time.time()
    if _ocr_cache["py"]:
        return _ocr_cache["py"], _ocr_cache["env"]
    if not force and now - _ocr_cache["ts"] < 20:
        return None, None
    cands = []
    env_py = os.environ.get("CT_OCR_PYTHON")
    if env_py:
        cands.append((env_py, None))
    cands.append((str(OCR_DIR / "venv" / (
        "Scripts/python.exe" if os.name == "nt" else "bin/python")),
        None))
    if OCR_SHARED_PYLIBS.is_dir():
        cands.append((sys.executable,
                      {"PYTHONPATH": str(OCR_SHARED_PYLIBS)}))
    if OCR_PYLIBS.is_dir():
        cands.append((sys.executable,
                      {"PYTHONPATH": str(OCR_PYLIBS)}))
    cands.append((sys.executable, None))
    cands.append((str(Path.home() / "workspace" / "ocrvenv"
                      / "bin" / "python"), None))
    py = envx = None
    seen = set()
    for c, e in cands:
        key = (c, (e or {}).get("PYTHONPATH", ""))
        if key in seen:
            continue
        seen.add(key)
        if _ocr_probe(c, e):
            py, envx = c, e
            break
    _ocr_cache.update(py=py, env=envx, ts=now)
    return py, envx


def _ocr_python():
    """The Python (path) of the OCR engine, or None. Other callers use it
    only for a ready / not-ready check;
    the actual scan is done via _run_ocr_items, which also handles the env
    (the pylibs path requires PYTHONPATH)."""
    return _ocr_resolve()[0]


# ------------- v51: one-time OCR auto-setup (detached worker) -------------
# On a new machine there is neither ocr/venv nor often python3-venv /
# ensurepip (Debian/Ubuntu neuter them) — for this
# reason the setup does NOT run on a venv, only on the stdlib:
#   1. Download pip's latest stable wheel from the PyPI JSON API
#      and unzip it into ocr/_bootstrap/ (a wheel is itself a
#      zip; the unzipped pip runs via `python -m pip`).
#   2. With that same pip, install ocr/requirements.txt into ocr/pylibs
#      with --target (the system Python is not touched,
#      --break-system-packages is for PEP 668 servers
#      where --target is also sometimes blocked).
#   3. cv2 import probe: if the GUI opencv-python has come in and
#      the import fails on a headless server (there is no libGL)
#      then clear cv2's package dirs and reinstall ONLY headless
#      again, then probe again.
#   4. The real probe: try importing pylibs from the app's Python.
# v51 change: the real work is now done by ocr/setup_worker.py —
# the server runs it in a DETACHED process (start_new_session=True)
# so that an app/service restart cannot kill the setup in the
# middle. The state is in ocr/setup_state.json, the details
# in ocr/setup.log (the last lines are also saved in the state's 'log_tail'
# so that the reason for a failure appears in the app's error
# message). If it fails, after 120 seconds on the next scan
# a NEW attempt can be made — the old "in one server-run
# only one attempt" restriction is gone; there is still no retry loop,
# every attempt starts only from the user's scan.


def _ocr_state_path():
    return OCR_SHARED_STATE if OCR_SHARED_STATE.exists() \
        else OCR_SETUP_STATE


def _ocr_log_path():
    return OCR_SHARED_LOG if OCR_SHARED_LOG.exists() \
        else OCR_SETUP_LOG


def _ocr_setup_state():
    st = load_json(_ocr_state_path(), None)
    return st if isinstance(st, dict) else {"state": "idle"}


def _ocr_setup_log(msg):
    try:
        OCR_SHARED.mkdir(parents=True, exist_ok=True)
        with open(OCR_SHARED_LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %I:%M:%S %p  ")
                    + str(msg) + "\n")
    except Exception:
        pass


def _ocr_set_setup_state(**kw):
    st = _ocr_setup_state()
    st.update(kw)
    try:
        OCR_SHARED.mkdir(parents=True, exist_ok=True)
        OCR_SHARED_STATE.write_text(json.dumps(st, indent=1),
                                    encoding="utf-8")
    except Exception:
        pass


def _ocr_setup_pid_alive(st):
    """Whether the worker pid recorded in the state file is alive or not.
    This same check works even after a server restart —
    the Popen handle is lost on restart, the pid remains."""
    try:
        pid = int(st.get("pid") or 0)
    except Exception:
        pid = 0
    if pid <= 0:
        return False
    if os.name == "nt":
        # On Windows os.kill(pid, 0) can send a signal to another process
        # — there, rely only on your own spawned
        # handle.
        p = _ocr_setup.get("proc")
        return p is not None and p.poll() is None
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _ocr_log_tail(n=15):
    """The last n clean lines of ocr/setup.log (timestamps
    removed) — to find the cause of the failure."""
    try:
        lines = _ocr_log_path().read_text(
            encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    out = []
    for ln in lines[-max(n * 3, n):]:
        ln = ln.strip()
        m = re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\s+",
                     ln)
        if m:
            ln = ln[m.end():].strip()
        if ln:
            out.append(ln)
    return out[-n:]


def _ocr_failed_msg():
    """On setup failure, a clean error + one line of the real cause
    (from state's log_tail, else from setup.log, else from state's
    error) — so the user's screenshot alone is enough for diagnosis.
    The cause is trimmed to ~200 chars."""
    reason = ""
    st = _ocr_setup_state()
    tail = st.get("log_tail")
    if isinstance(tail, list) and tail:
        reason = str(tail[-1]).strip()
    if not reason:
        t2 = _ocr_log_tail(15)
        if t2:
            reason = t2[-1]
    if not reason:
        reason = str(st.get("error") or "").strip()
    reason = re.sub(r"\s+", " ", reason).strip()
    if len(reason) > 200:
        reason = reason[:197].rstrip() + "..."
    if reason:
        return OCR_FAILED_MSG + f" (Reason: {reason})"
    return OCR_FAILED_MSG


_ocr_pylibs_size = {"mb": 0.0, "ts": 0.0}


def _ocr_pylibs_mb():
    """Size of ocr/pylibs in MB (5s cache — walking thousands of files
    on every poll is expensive)."""
    now = time.time()
    if _ocr_pylibs_size["mb"] and \
            now - _ocr_pylibs_size["ts"] < 5:
        return _ocr_pylibs_size["mb"]
    total = 0
    try:
        for _base in (OCR_SHARED_PYLIBS, OCR_PYLIBS):
            for root, _dirs, files in os.walk(_base):
                for fn in files:
                    try:
                        total += os.path.getsize(
                            os.path.join(root, fn))
                    except OSError:
                        pass
    except Exception:
        pass
    _ocr_pylibs_size.update(mb=round(total / 1048576.0, 1),
                            ts=now)
    return _ocr_pylibs_size["mb"]


def _ocr_setup_activity(tail):
    """A human-readable sentence from the last lines of setup.log: what is
    happening right now (which package is being downloaded/installed)
    — so the user does not have to wait in the dark."""
    for ln in reversed(tail or []):
        s = str(ln).strip()
        m = re.search(r"Downloading\s+(\S+?)-(\d[\d.]*)-", s)
        if m:
            sz = re.search(r"\(([\d.]+\s*[MG]B)\)", s)
            return ("Downloading " +
                    m.group(1).replace("_", "-") +
                    (" (" + sz.group(1) + ")" if sz else ""))
        m = re.search(r"Collecting\s+(\S+)", s)
        if m:
            return "Collecting " + m.group(1)
        if "Installing collected packages" in s:
            return "Installing the downloaded packages"
        if "Successfully installed" in s:
            return "Install complete — final check running"
        if "setup READY" in s:
            return "Setup complete"
    if tail:
        return str(tail[-1]).strip()[:120]
    return "Starting"


def _ocr_setup_status():
    """LIVE status of the photo-scan setup (v52): state, how much
    time has elapsed, what is happening now, how many MB have arrived,
    how many attempts were made, and the cause if it failed. On Yousuf's
    instruction — proof of setup should be visible inside the app,
    the user should not have to open files in the ocr folder."""
    st = _ocr_setup_state()
    ready = False
    try:
        ready = bool(_ocr_python())
    except Exception:
        ready = False
    state = str(st.get("state") or "idle")
    if ready:
        state = "ready"
    tail = _ocr_log_tail(15)
    elapsed = None
    if state == "running":
        try:
            t0 = datetime.fromisoformat(
                str(st.get("started") or "")).timestamp()
            elapsed = max(0, int(time.time() - t0))
        except Exception:
            elapsed = None
    reason = ""
    if state == "failed":
        t = st.get("log_tail")
        if isinstance(t, list) and t:
            reason = str(t[-1]).strip()
        if not reason and tail:
            reason = str(tail[-1]).strip()
        if not reason:
            reason = str(st.get("error") or "").strip()
        reason = re.sub(r"\s+", " ", reason)[:200]
    return {
        "state": state,
        "engine_ready": ready,
        "started": st.get("started") or "",
        "finished": st.get("finished") or "",
        "elapsed_s": elapsed,
        "attempts": int(st.get("attempts") or 0),
        "activity": (_ocr_setup_activity(tail)
                     if state in ("running", "failed")
                     else ("Setup complete"
                           if state == "ready" else "")),
        "pylibs_mb": _ocr_pylibs_mb(),
        "log_tail": [str(x)[:160] for x in tail[-3:]],
        "reason": reason,
    }


def _ocr_trigger_setup():
    """Run the detached setup worker if needed.
    Returns 'running' (running / just started) or
    'failed' (failed recently — no new attempt within 120 seconds;
    after that, on the next scan a new
    attempt will happen automatically)."""
    import subprocess
    with _ocr_setup_lock:
        st = _ocr_setup_state()
        state = st.get("state")
        if state == "running":
            if _ocr_setup_pid_alive(st):
                return "running"
            state = "failed"   # the worker died in the middle
        if state == "failed":
            fin = 0.0
            try:
                fin = datetime.fromisoformat(
                    str(st.get("finished") or "")).timestamp()
            except Exception:
                fin = 0.0
            if fin and time.time() - fin <= 120:
                return "failed"
        try:
            OCR_DIR.mkdir(parents=True, exist_ok=True)
            OCR_SHARED.mkdir(parents=True, exist_ok=True)
            lf = open(OCR_SHARED_LOG, "a", encoding="utf-8")
            _env = dict(os.environ)
            _env["CT_OCR_DIR"] = str(OCR_SHARED)
            proc = subprocess.Popen(
                [sys.executable,
                 str(OCR_DIR / "setup_worker.py")],
                cwd=str(BASE), stdout=lf, env=_env,
                stderr=subprocess.STDOUT,
                start_new_session=True)
            _ocr_setup["proc"] = proc
            _ocr_set_setup_state(
                state="running",
                started=datetime.now().isoformat(
                    timespec="seconds"),
                pid=proc.pid, error="",
                attempts=int(st.get("attempts") or 0) + 1)
            return "running"
        except Exception:
            return "failed"


def _run_ocr_items(img_path):
    """OCR subprocess: (result_dict, None) or (None, reason).
    result = {"items":[{box,text,score}], "w":W, "h":H}
    If the engine is found nowhere (neither ocr/venv nor ocr/pylibs), a one-time
    auto-setup starts in the background and the client gets
    a clean 'setting up' response — no traceback or
    installation instructions are shown to the user."""
    import subprocess
    py, envx = _ocr_resolve()
    if not py:
        if _ocr_trigger_setup() == "running":
            return None, OCR_SETUP_MSG
        return None, _ocr_failed_msg()
    env = None
    if envx:
        env = dict(os.environ)
        for k, v in envx.items():
            if k == "PYTHONPATH" and env.get("PYTHONPATH"):
                env[k] = v + os.pathsep + env["PYTHONPATH"]
            else:
                env[k] = v
    try:
        out = subprocess.run(
            [py, str(OCR_DIR / "ocr_runner.py"), str(img_path)],
            capture_output=True, timeout=120, env=env)
    except subprocess.TimeoutExpired:
        return None, ("Photo scanning took too long — please try a "
                      "clearer, closer photo.")
    except Exception as e:
        return None, str(e)
    txt = out.stdout.decode("utf-8", "replace").strip()
    d = None
    for line in reversed(txt.splitlines()):
        try:
            d = json.loads(line)
            break
        except Exception:
            continue
    if not d or d.get("error") or "items" not in d:
        return None, ("OCR could not read that photo — please try a "
                      "clearer, closer photo.")
    return d, None


def _sq(s):
    """Squash: only A-Z0-9 — free from OCR space/punctuation hassles."""
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def _it_cx(it):
    b = it["box"]
    return (b[0][0] + b[2][0]) / 2.0


def _it_cy(it):
    b = it["box"]
    return (b[0][1] + b[2][1]) / 2.0


def _ocr_lines(items, page_h):
    """Join OCR items into reading lines (close y values = one line)."""
    its = sorted(items, key=lambda i: (_it_cy(i), _it_cx(i)))
    heights = sorted((i["box"][2][1] - i["box"][0][1]) for i in its)
    med = heights[len(heights) // 2] if heights else 20
    tol = max(9.0, med * 0.72)
    lines = []
    for it in its:
        cy = _it_cy(it)
        if lines and abs(cy - lines[-1]["cy"]) <= tol:
            lines[-1]["items"].append(it)
            n = len(lines[-1]["items"])
            lines[-1]["cy"] = (lines[-1]["cy"] * (n - 1) + cy) / n
        else:
            lines.append({"cy": cy, "items": [it]})
    for ln in lines:
        ln["items"].sort(key=_it_cx)
        ln["text"] = " ".join(i["text"] for i in ln["items"])
        ln["squash"] = _sq(ln["text"])
    return lines


# Carrier BL formats — from bl-formats-learned.md. In some places the digit
# count is kept matching the document's actual number (Monter's 8-10,
# KMTC's 7-8, RCL's 8-9) otherwise the real BL itself would be missed.
_BL_PATTERNS = [
    (r"EMKAYMBAKHI\d{5}", "Emkay Line"),
    (r"\d{3}G[A-Z0-9]\d{5,6}", "Wan Hai Lines"),  # 051GA16585 also (2 Nov 2026)
    (r"C[O0]AU\d{10}", "COSCO Shipping"),
    (r"[O0]{2}LU\d{10}", "OOCL"),
    (r"(?:MEDU[TS]|MEDT)\d{7}", "MSC"),
    (r"YMJAS\d{9}", "Yang Ming"),
    (r"KMTC[A-Z]{3}\d{7,8}", "KMTC Line"),
    (r"PELMSA[A-Z]{6}\d{6}", "Prolog Express Line (PEL)"),
    (r"MBAQITS\d{10}", "RTW Shipping & Logistics"),
    (r"STS[A-Z]{3,}\d{4,5}", "Star Lines"),
    (r"BAL[A-Z]{3,}\d{7}", "Baltic Lines"),
    (r"FRL[A-Z]{3,}\d{6}", "Feeder Logistics DMCC"),
    (r"EMA[A-Z]{3,}\d{5,6}", "EM-A Shipping"),
    (r"SGS\d{4}SINKHI\d?", "SeaGem Shipping"),
    (r"SSL[A-Z]{3,}\d{4,}", "Samudera Shipping Line"),
    (r"MCL[A-Z]{3}\d{8,10}", "Monter Container Line"),
    (r"HAICB\d{8,9}", "RCL (Regional Container Lines)"),
    # ASYAD LINE (11 Nov 2026, ACLCMB2600026): BL = ACLCMB + 7
    # digits; the export reference is ACLCMB + 9 digits, so the
    # digit lookahead keeps a finditer sweep from harvesting the
    # reference's first 7 digits as a BL number.
    (r"ACLCMB\d{7}(?!\d)", "ASYAD LINE"),
]

_LETTERHEAD_CARRIERS = [
    ("ASYAD", "ASYAD LINE"),
    ("MAXTOP", "MAXTOP Logistics"),
    ("MONTER", "Monter Container Line"),
    ("MEDITERRANEANSHIPPING", "MSC"),
    ("NEWGOLDENSEA", "COSCO Shipping"),
    ("ORIENTOVERSEAS", "OOCL"),
    ("KOREAMARINE", "KMTC Line"),
    ("PROLOGEXPRESS", "Prolog Express Line (PEL)"),
    ("SEAGEM", "SeaGem Shipping"),
    ("SAMUDERA", "Samudera Shipping Line"),
    ("FEEDERLOGISTICS", "Feeder Logistics DMCC"),
    ("REGIONALCONTAINER", "RCL (Regional Container Lines)"),
    ("YANGMING", "Yang Ming"),
    ("WANHAI", "Wan Hai Lines"),
    ("BALTICLINES", "Baltic Lines"),
    ("STARLINES", "Star Lines"),
    ("EMKAY", "Emkay Line"),
    ("MAERSK", "Maersk"),
]


def _bl_pattern_fix(m, pat):
    """Fix OCR's 0/O mistake in the prefix (0OLU -> OOLU)."""
    if pat in (r"C[O0]AU\d{10}", r"[O0]{2}LU\d{10}"):
        head = m[:4].replace("0", "O")
        return head + m[4:]
    return m


_MONTHS = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
           "JUL": 7, "AUG": 8, "SEP": 9, "SEPT": 9, "OCT": 10,
           "NOV": 11, "DEC": 12,
           "JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4,
           "JUNE": 6, "JULY": 7, "AUGUST": 8, "SEPTEMBER": 9,
           "OCTOBER": 10, "NOVEMBER": 11, "DECEMBER": 12}
_MONTH_ABBR = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
               "Aug", "Sep", "Oct", "Nov", "Dec"]


def _norm_date(s):
    """Make a date string into '18 Sep 2026'; if not possible, return raw."""
    t = (s or "").strip().upper().replace(",", " ")
    m = re.search(r"(\d{1,2})[-/. ](\d{1,2})[-/. ](\d{2,4})", t)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{d:02d} {_MONTH_ABBR[mo]} {y}"
    m = re.search(r"(\d{1,2})[-/. ]([A-Z]{3,9})[-/. ](\d{2,4})", t)
    if m:
        mon = _MONTHS.get(m.group(2)) or _MONTHS.get(m.group(2)[:3])
        if mon:
            d, y = int(m.group(1)), int(m.group(3))
            if y < 100:
                y += 2000
            return f"{d:02d} {_MONTH_ABBR[mon]} {y}"
    m = re.search(r"([A-Z]{3,9})\.?\s+(\d{1,2})\s+(\d{4})", t)
    if m and m.group(1) in _MONTHS:
        return (f"{int(m.group(2)):02d} "
                f"{_MONTH_ABBR[_MONTHS[m.group(1)]]} {m.group(3)}")
    m = re.search(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", t)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12:
            return f"{d:02d} {_MONTH_ABBR[mo]} {y}"
    return (s or "").strip()


_DATE_RE = (r"\d{1,2}[-/. ](?:\d{1,2}|[A-Z]{3,9})[-/. ]\d{2,4}"
            r"|[A-Z]{3,9}\.?\s+\d{1,2},?\s+\d{4}"
            r"|\d{4}[-/.]\d{1,2}[-/.]\d{1,2}")


def _date_str_ok(s):
    """True if the string is a REAL calendar-shaped date. _DATE_RE
    alone also matches HS codes ('0908.21.00' -> '08.21.00') and
    weights; a candidate whose month is 21 is not a date
    (YMJAS430202944 clean scan read its on-board date as an HS
    code, 11 Nov 2026)."""
    t = (s or "").strip().upper()
    m = re.fullmatch(r"(\d{1,2})[-/. ](\d{1,2})[-/. ](\d{2,4})", t)
    if m:
        return 1 <= int(m.group(2)) <= 12 and 1 <= int(m.group(1)) <= 31
    m = re.fullmatch(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", t)
    if m:
        return 1 <= int(m.group(2)) <= 12 and 1 <= int(m.group(3)) <= 31
    m = re.fullmatch(r"(\d{1,2})[-/. ]([A-Z]{3,9})[-/. ](\d{2,4})", t)
    if m:
        # NOTE: the module-level _MONTHS name is REBOUND later in
        # this file to a lowercase-keyed dict (line ~3601) — check
        # both cases or every month-name date fails (ASYAD BL
        # ACLCMB2600026's '02-NOV-2026' did, 11 Nov 2026).
        g = m.group(2)
        return g in _MONTHS or g.lower() in _MONTHS \
            or g[:3] in _MONTHS or g[:3].lower() in _MONTHS
    m = re.fullmatch(r"([A-Z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})", t)
    if m:
        g = m.group(1)
        return g in _MONTHS or g.lower() in _MONTHS
    return False


def _num_or_blank(s):
    """'54,108.000' -> 54108 (int); if it cannot be converted, return ''."""
    if s is None:
        return ""
    t = str(s).replace(",", "").replace(" ", "").strip()
    try:
        f = float(t)
    except Exception:
        return ""
    return int(f) if f == int(f) else f


_LABEL_KEYS = [
    ("bl", ("BILLOFLADINGNO", "BLNO")),
    ("booking", ("BOOKINGNO", "BOOKINGREF")),
    ("sono", ("SONO",)),
    ("serial", ("SERIALNO",)),
    ("reference", ("SHIPMENTREFERENCE", "CARRIERSREFERENCE",
                   "CARRIERREFERENCE", "EXPORTREFERENCE",
                   "SHIPPERSREF", "SHIPPERREFERENCE")),
    ("shipper", ("SHIPPER",)),
    ("consignee", ("CONSIGNEE", "CONSIGNED")),
    ("notify", ("NOTIFY",)),
    ("precarriage", ("PRECARRIED",)),
    ("vessel", ("VESSEL",)),
    ("voyage", ("VOYAGE", "VOYNO")),
    ("pol", ("PORTOFLOADING",)),
    ("pod", ("PORTOFDISCHARGE", "PORTOFLANDING")),
    ("receipt", ("PLACEOFRECEIPT", "PLACEOFACCEPTANCE")),
    ("delivery", ("PLACEOFDELIVERY", "PLACEOFFINALDELIVERY")),
    ("tranship", ("TRANSHIPMENT", "TRANSSHIPMENT")),
    ("issue", ("DATEOFISSUE", "PLACEANDDATEOFISSUE")),
    ("containers", ("CONTAINER",)),
    ("goods", ("DESCRIPTION", "PARTICULARS")),
    ("gross", ("GROSSWEIGHT", "GROSSWT")),
    ("net", ("NETWEIGHT", "NETTWEIGHT", "NETWT")),
    ("measure", ("MEASUREMENT",)),
    ("freight", ("FREIGHT",)),
    ("marks", ("MARKSAND", "MARKS")),
    ("seal", ("SEAL",)),
]


def _item_label_kind(it):
    """Which label an OCR item belongs to (or None)."""
    sq = _sq(it["text"])
    if not sq:
        return None
    if "CONSIGNEE" in sq:
        return "consignee"  # this is also the long negotiable label
    for kind, keys in _LABEL_KEYS:
        for k in keys:
            if k in sq:
                if kind == "shipper" and (
                        "LOAD" in sq or "STOW" in sq
                        or len(sq) > 26):
                    continue  # SHIPPER'S LOAD... is not a party
                if kind == "bl" and "FOROCEAN" in sq:
                    continue  # the document's title, not the number box
                return kind
    return None


def _line_label_kinds(ln):
    return {k for k in (_item_label_kind(i) for i in ln["items"]) if k}


def extract_bl_record(items, page_w, page_h):
    """A complete BL record from OCR items.
    (record, meta) — meta contains the extractor's internal information
    (excluded values etc.) which does not go into the API response."""
    W = float(page_w or 1000)
    H = float(page_h or 1400)
    lines = _ocr_lines(items, H)
    full_sq = "".join(_sq(i["text"]) for i in
                      sorted(items, key=lambda i: (_it_cy(i), _it_cx(i))))
    warnings = []
    rec = {"bl_no": "", "containers": [], "carrier": "", "vessel": "",
           "voyage": "", "precarriage": "", "precarriage_voyage": "",
           "shipper": "", "consignee": "", "pol": "",
           "pod": "", "ts_port": "", "on_board": "", "issue_date": "",
           "goods": "", "packages": "", "gross_kg": "", "net_kg": "",
           "cbm": "", "freight": "", "free_days": "", "proforma": False}

    # ---- 1) labels and the values near them (claiming) ----
    labels = []       # (kind, cx, cy)
    for ln in lines:
        for it in ln["items"]:
            k = _item_label_kind(it)
            if k in ("bl", "booking", "sono", "serial", "reference"):
                labels.append((k, _it_cx(it), _it_cy(it), it))
    # a glued label+value in a single item (for example "B/LNoYMJAS430202944",
    # "S/O No: KCT60910727") — catch it from here first
    inline_bl, inline_excl = "", set()
    for it in items:
        t = it["text"]
        m = re.search(r"(?i)B\s*/\s*L\s*\.?\s*(?:NO|NUMBER)\.?\s*:?\s*"
                      r"([A-Z0-9][A-Z0-9\-]{5,19})$", t.strip())
        if m and not inline_bl:
            inline_bl = _sq(m.group(1))
        m = re.search(r"(?i)S\s*/\s*O\s*\.?\s*NO\.?\s*:?\s*"
                      r"([A-Z0-9][A-Z0-9\-]{3,19})", t)
        if m:
            inline_excl.add(_sq(m.group(1)))
    cands = []        # (squash, cx, cy)
    for it in items:
        sq = _sq(it["text"])
        if 6 <= len(sq) <= 20 and re.search(r"\d", sq) \
                and not _item_label_kind(it):
            cands.append((sq, _it_cx(it), _it_cy(it)))
    # A label whose value is merged into the same item (for example
    # "S/O No: KCT60910727") does not take part in geometric claiming
    # — otherwise it would also swallow the nearby real BL
    # and put it into exclusion (this happened on Wan Hai).
    def _label_has_inline(k, it):
        sq = _sq(it["text"])
        for kk in ("BILLOFLADINGNO", "BLNO", "BOOKINGNO",
                   "BOOKINGREF", "SONO", "SERIALNO",
                   "SHIPMENTREFERENCE", "CARRIERSREFERENCE",
                   "CARRIERREFERENCE", "EXPORTREFERENCE",
                   "SHIPPERSREF", "SHIPPERREFERENCE"):
            sq = sq.replace(kk, "", 1) if sq.startswith(kk) else sq
        return len(sq) >= 4 and bool(re.search(r"\d", sq))

    # Claiming: each candidate goes to its NEAREST label;
    # the BL label only wins when it is approximately just as
    # close (otherwise on PROFORMA the booking number swallows the BL label,
    # and on Wan Hai the S/O puts the actual BL into the exclusion
    # list).
    raw_pairs = []
    for li, (k, lx, ly, _it) in enumerate(labels):
        if k != "bl" and _label_has_inline(k, _it):
            continue
        for ci, (sq, cx, cy) in enumerate(cands):
            dx = abs(cx - lx) / W
            dy = abs(cy - ly) / H
            if dx < 0.36 and dy < 0.065:
                raw_pairs.append((dx + dy, li, ci))
    best_for_c = {}
    for d, li, ci in raw_pairs:
        if ci not in best_for_c or d < best_for_c[ci]:
            best_for_c[ci] = d
    pairs = []
    for d, li, ci in raw_pairs:
        k = labels[li][0]
        prio = 0 if (k == "bl" and d <= best_for_c[ci] + 0.02) else 1
        pairs.append((prio, d, li, ci))
    pairs.sort()
    claimed_c, claimed_l = {}, {}
    for _p, _d, li, ci in pairs:
        if li in claimed_l or ci in claimed_c:
            continue
        claimed_l[li] = ci
        claimed_c[ci] = li
    excluded_soft, excluded_hard = set(inline_excl), set(inline_excl)
    label_bl_value = ""
    bl_label_seen = booking_seen = False
    for li, (k, _x, _y, _it) in enumerate(labels):
        if k == "bl":
            bl_label_seen = True
            if li in claimed_l:
                label_bl_value = cands[claimed_l[li]][0]
        elif k == "booking":
            booking_seen = True
            if li in claimed_l:
                excluded_soft.add(cands[claimed_l[li]][0])
        elif li in claimed_l:
            excluded_hard.add(cands[claimed_l[li]][0])
    if inline_bl:
        label_bl_value = inline_bl

    # ---- 2) containers (ISO + check digit) and seals ----
    stream = []       # (token_raw, line_idx)
    for li, ln in enumerate(lines):
        for it in ln["items"]:
            for tok in re.split(r"[\s/,;()]+", it["text"]):
                tok = tok.strip(".:")
                if tok:
                    stream.append((tok, li, it))
    cont_hits = []    # (stream_idx, number, check_ok, item)
    seen_cont = set()
    for si, (tok, li, it) in enumerate(stream):
        if re.search(r"\d{1,2}-\d{1,2}-\d{2,4}", tok) \
                or "DATED" in _sq(it["text"]):
            continue  # a token with a date cannot be a container
        if "-" in tok:
            continue  # a hyphenated number is a seal (ML-KE…),
            # a container is never printed with a hyphen
        sq = _sq(tok)
        for m in re.finditer(r"[A-Z]{4}\d{7}", sq):
            num = m.group(0)
            if num[:4] == "CODE":
                continue  # false container formed by merging "HS CODE 0909..."
                # — the real prefix is never CODE
            ok = _iso_ok(num)
            if not ok:
                rep = _iso_repair(num)
                if rep:
                    num, ok = rep, True
            if num in seen_cont:
                continue
            if not ok:
                ctx = (it["text"] + " " + lines[li]["text"]).upper()
                if not ("CONTAINER" in ctx or "SEAL" in ctx
                        or re.search(r"(20|40|45)\s?'?\s?"
                                     r"(GP|HC|HQ|SD|DC|DV|RF|G1)", ctx)):
                    continue  # check digit failed + no context either — useless
            seen_cont.add(num)
            cont_hits.append((si, num, ok, it))
    cont_pos = {si for si, _n, _o, _i in cont_hits}

    def _size_of(it, li):
        ctx = it["text"] + " " + lines[li]["text"]
        m = re.search(r"(20|40|45)\s?'?\s?(GP|HC|HQ|SD|DC|DV|RF|G1|G2)",
                      ctx.upper())
        return (m.group(1) + m.group(2)) if m else ""

    cont_numbers = {n for _s, n, _o, _i in cont_hits}
    # Seals: on each container's own line or in the next 2 lines, the first
    # seal-like token. If the raw token contains '.' or ',', it is a fragment of weight,
    # not a seal. A token with a date is also not a seal.
    line_tokens = []
    for ln in lines:
        toks = []
        for it in ln["items"]:
            for tok in re.split(r"[\s/,;()]+", it["text"]):
                tok = tok.strip(".:")
                if tok:
                    toks.append(tok)
        line_tokens.append(toks)

    def _seal_shape(tok):
        if "." in tok or "," in tok:
            return ""
        raw = tok.upper()
        sq = _sq(tok)
        if sq.startswith("DATED"):
            return ""
        if re.fullmatch(r"ML-[A-Z]{2}\d{5,}", raw):
            return raw  # ML-KE0272798 — the actual form with a hyphen
        if re.fullmatch(r"[A-Z]{2,6}\d{4,8}", sq):
            return sq
        m = re.search(r"(?:20|40|45)(?:GP|HC|HQ|SD|DC|DV|RF|G1|G2)"
                      r"\d{0,2}([A-Z]{4}\d{5,8})$", sq)
        if m:
            return m.group(1)  # seal merged with the size:
            # "40SD96WHAD001536" -> WHAD001536
        return ""

    def _seal_ok(sq, raw=""):
        if not sq or sq == label_bl_value \
                or sq in excluded_hard or sq in excluded_soft \
                or sq in cont_numbers:
            return False
        if "-" in raw:
            return True  # a hyphenated number is always a seal,
            # a container is never printed with a hyphen
        return not re.fullmatch(r"[A-Z]{4}\d{7}", sq) \
            and not any(re.fullmatch(p, sq)
                        for p, _c in _BL_PATTERNS)

    containers = []
    used_seals = set()
    for si, num, ok, it in cont_hits:
        li = next(l for l, ln in enumerate(lines)
                  if it in ln["items"])
        seal = ""
        for j in range(li, min(li + 3, len(lines))):
            for tok in line_tokens[j]:
                s = _seal_shape(tok)
                if s and _seal_ok(s, tok) and s not in used_seals:
                    seal = s
                    break
            if seal:
                break
        if seal:
            used_seals.add(seal)
        containers.append({"no": num, "seal": seal,
                           "type": _size_of(it, li), "check_ok": ok})
        if not ok:
            warnings.append(f"Container {num}: check digit could not "
                            "be verified — please confirm the number.")
    seal_hits = []
    for j, toks in enumerate(line_tokens):
        if "SEAL" in lines[j]["squash"]:
            for tok in toks:
                s = _seal_shape(tok) or (
                    _sq(tok) if re.fullmatch(r"\d{5,8}", _sq(tok))
                    and "." not in tok and "," not in tok else "")
                if s and _seal_ok(s, tok) and s not in used_seals:
                    seal_hits.append((j, s))
    for _j, s in seal_hits:
        warnings.append(f"Seal {s} was read but could not be "
                        "paired with a container.")
    rec["containers"] = containers
    seal_numbers = {s for _j, s in seal_hits} \
        | {c["seal"] for c in containers if c["seal"]}

    # ---- 3) BL number: the labelled one first, then carrier formats ----
    def _bl_sane(v):
        return bool(v) and v not in cont_numbers \
            and v not in seal_numbers and v not in excluded_hard \
            and 8 <= len(v) <= 20

    bl, bl_from_label = "", False
    if label_bl_value:
        v = label_bl_value
        for pat, _c in _BL_PATTERNS:
            m = re.fullmatch(pat, v)
            if m:
                v = _bl_pattern_fix(m.group(0), pat)
                break
        if _bl_sane(v):
            bl, bl_from_label = v, True
    # A confirmed carrier-format hit always wins over a labelled
    # non-format value (for example a barcode)
    pattern_bl = ""
    for pat, _c in _BL_PATTERNS:
        hits = []
        for it in items:
            for m in re.finditer(pat, _sq(it["text"])):
                hits.append(_bl_pattern_fix(m.group(0), pat))
        if not hits:
            hits = [_bl_pattern_fix(m.group(0), pat)
                    for m in re.finditer(pat, full_sq)]
        for v in hits:
            if _bl_sane(v) and v not in excluded_soft:
                pattern_bl = v
                break
        if pattern_bl:
            break
    if pattern_bl and pattern_bl != bl:
        if not bl or not any(re.fullmatch(p, bl)
                             for p, _c in _BL_PATTERNS):
            bl, bl_from_label = pattern_bl, False
    if not bl and booking_seen and bl_label_seen:
        # Maersk rule: the booking and B/L number are ONE and the same.
        for v in excluded_soft:
            if "MAERSK" in full_sq and re.fullmatch(r"\d{9}", v):
                bl = v
                warnings.append("BL and booking number are the same "
                                "on this document (Maersk style).")
                break
    rec["bl_no"] = bl

    # ---- 4) PROFORMA ----
    if not bl and ("PROFORMA" in full_sq
                   or (bl_label_seen and booking_seen)):
        rec["proforma"] = True
    if not bl and not rec["proforma"]:
        warnings.append("BL number could not be read from this photo.")

    # ---- 5) carrier ----
    carrier = ""
    for pat, cname in _BL_PATTERNS:
        if bl and re.fullmatch(pat, bl):
            carrier = cname
            break
    if not carrier:
        for key, cname in _LETTERHEAD_CARRIERS:
            if key in full_sq:
                carrier = cname
                break
    if not carrier and bl:
        try:
            _pfx, cname = ENG.identify_carrier(bl)
            carrier = cname or ""
        except Exception:
            carrier = ""
    rec["carrier"] = carrier

    # ---- 6) labeled fields ----
    def label_item_of(ln, kinds):
        for it in ln["items"]:
            if _item_label_kind(it) in kinds:
                return it
        return None

    def after_label(kinds, max_lines=1, joiner=" "):
        for li, ln in enumerate(lines):
            lab = label_item_of(ln, kinds)
            if lab is None:
                continue
            if kinds == {"voyage"}:
                # The value often sits INSIDE the label item itself
                # ("Voy No.158W") — take it from there first; looking
                # below with the wide band swallowed the next line's
                # values ("YM EXCELLENCE SURABAYA" as the voyage,
                # YMJAS430202944 clean scan, 11 Nov 2026).
                _own = re.sub(r"VOYAGE|VOY|NO\.?|[:#-]", " ",
                              lab["text"].upper())
                _vm = re.search(r"\b(\d{3,4}[A-Z]{1,2}|[A-Z]\d{3,4})\b",
                                _own)
                if _vm:
                    return _vm.group(1)
            band = (_it_cx(lab) - 0.30 * W, _it_cx(lab) + 0.30 * W)
            multi = len(_line_label_kinds(ln)) >= 2
            vals = []
            # first the values BELOW the label (in a merged line
            # including the item stuck below the label) — on the label's
            # line, on the RIGHT side there is often a reference number,
            # not the actual value
            below0 = [i for i in ln["items"]
                      if _it_cy(i) > _it_cy(lab) + 4
                      and band[0] <= _it_cx(i) <= band[1]
                      and _item_label_kind(i) is None]
            if below0:
                vals.append(" ".join(i["text"] for i in below0))
            for j in range(li + 1, min(li + 1 + max_lines + 2,
                                       len(lines))):
                if len(vals) >= max_lines:
                    break
                lk = _line_label_kinds(lines[j])
                if lk and not lk.issubset(kinds):
                    break  # another label has appeared; its own label
                    # (for example "SAME AS CONSIGNEE") is the value
                cand = [i for i in lines[j]["items"]
                        if band[0] <= _it_cx(i) <= band[1]]
                if not cand and not multi:
                    cand = lines[j]["items"]
                if not cand:
                    break
                vals.append(" ".join(i["text"] for i in cand))
            if vals:
                return joiner.join(vals).strip()
            right = [i for i in ln["items"]
                     if _it_cx(i) > _it_cx(lab) + 4
                     and abs(_it_cy(i) - _it_cy(lab)) <= 6
                     and _item_label_kind(i) is None]
            if right:
                return " ".join(i["text"] for i in right).strip()
            return ""
        return ""

    def column_value(kind):
        """Header row (many labels on one line) — the items on the line
        below are assigned to the nearest label."""
        for li, ln in enumerate(lines):
            kinds_here = _line_label_kinds(ln)
            if kind not in kinds_here or len(kinds_here) < 2:
                continue
            labs = [( _item_label_kind(i), _it_cx(i))
                    for i in ln["items"] if _item_label_kind(i)]
            for j in range(li + 1, len(lines)):
                if not lines[j]["items"]:
                    continue
                got = []
                for i in lines[j]["items"]:
                    near = min(labs, key=lambda t: abs(t[1] - _it_cx(i)))
                    if near[0] == kind:
                        got.append(i["text"])
                if got:
                    return " ".join(got).strip()
                break
        return ""

    # precarriage — the feeder that carried the box to the ocean
    # vessel ("Precarried by YM CENTENNIAL V.071N"). It is NOT the
    # vessel, and its name must never pair with the ocean vessel's
    # voyage (YMJAS430202944, 11 Nov 2026: the panel showed
    # "YM CENTENNIAL / 158W" — the precarriage name with the ocean
    # vessel's voyage).
    def _split_vv(raw):
        v = (raw or "").strip(" .,-")
        voy = ""
        if v:
            m = re.split(r"\s*/\s*", v, maxsplit=1)
            if len(m) == 2 and m[1]:
                v, voy = m[0].strip(), m[1].strip()
            else:
                m2 = re.match(r"^(.*?)[\s]+(\d{3,4}[A-Z]|[A-Z]\d{3,4}|"
                              r"\d{3}[A-Z]{2}|[A-Z]{2}\d{4}[A-Z])$", v)
                if m2:
                    v, voy = m2.group(1).strip(), m2.group(2)
                else:
                    m3 = re.match(r"^(.*?)[\s]+V\.?\s*(\d{3,4}[A-Z])$",
                                  v)
                    if m3:
                        v, voy = m3.group(1).strip(), m3.group(2)
        return v.upper(), voy.upper()

    _pre_raw = column_value("precarriage") or after_label(
        {"precarriage"})
    if _pre_raw:
        _pv, _pvy = _split_vv(_pre_raw)
        rec["precarriage"] = _pv
        rec["precarriage_voyage"] = _pvy

    # vessel / voyage
    vessel_raw = column_value("vessel") or after_label({"vessel"})
    voy = after_label({"voyage"})
    if vessel_raw:
        v = vessel_raw.strip(" .,-")
        m = re.split(r"\s*/\s*", v, maxsplit=1)
        if len(m) == 2 and m[1]:
            v, voy = m[0].strip(), (voy or m[1].strip())
        else:
            m2 = re.match(r"^(.*?)[\s]+(\d{3,4}[A-Z]|[A-Z]\d{3,4}|"
                          r"\d{3}[A-Z]{2}|[A-Z]{2}\d{4}[A-Z])$", v)
            if m2:
                v, voy = m2.group(1).strip(), (voy or m2.group(2))
        rec["vessel"] = v.upper()
    if voy:
        rec["voyage"] = voy.strip().upper()
    if rec["precarriage"] and rec["vessel"] == rec["precarriage"]:
        # Pairing guard: the "vessel" came out as the precarriage
        # name — photo geometry can merge the precarriage row into
        # the vessel row. Take the value that belongs to the Vessel
        # box itself: the first non-label items under the Vessel
        # label, skipping the precarriage value.
        for li, ln in enumerate(lines):
            if "vessel" not in _line_label_kinds(ln):
                continue
            _lab = label_item_of(ln, {"vessel"})
            _band = (_it_cx(_lab) - 0.30 * W, _it_cx(_lab) + 0.30 * W)
            for j in range(li + 1, min(li + 3, len(lines))):
                _cand = [i for i in lines[j]["items"]
                         if _band[0] <= _it_cx(i) <= _band[1]
                         and _item_label_kind(i) is None
                         and _sq(i["text"]) != _sq(rec["precarriage"])]
                if _cand:
                    _fv, _fvoy = _split_vv(
                        " ".join(i["text"] for i in _cand))
                    if _fv and _fv != rec["precarriage"]:
                        rec["vessel"] = _fv
                        if _fvoy and not rec["voyage"]:
                            rec["voyage"] = _fvoy
                    break
            break
    if not rec["vessel"]:
        m = re.search(r"SHIPPEDONBOARDBY([A-Z]{4,30}?)"
                      r"(CS\d{4}[A-Z]|\d{3,4}[A-Z]\b|\d{3,4}[A-Z])",
                      full_sq)
        if m:
            rec["vessel"] = m.group(1)
            rec["voyage"] = rec["voyage"] or m.group(2)

    # parties (first 2-3 lines, up to the next label)
    for kinds, key in (({"shipper"}, "shipper"),
                       ({"consignee"}, "consignee")):
        val = after_label(kinds, max_lines=3, joiner=", ")
        val = re.sub(r"\s+", " ", val).strip(" ,")
        if val and "SAME AS" not in val.upper()[:9]:
            rec[key] = val

    rec["pol"] = (column_value("pol") or after_label({"pol"})
                  or after_label({"receipt"}))
    rec["pod"] = column_value("pod") or after_label({"pod"})
    rec["ts_port"] = (column_value("tranship")
                      or after_label({"tranship"}))
    for k in ("pol", "pod", "ts_port"):
        rec[k] = re.sub(r"\s+", " ", rec[k]).strip(" ,").upper()

    # dates
    def _date_near(pred, span=3):
        for li, ln in enumerate(lines):
            if pred(ln):
                for j in range(li, min(li + span, len(lines))):
                    for m in re.finditer(_DATE_RE, lines[j]["text"],
                                          re.I):
                        if _date_str_ok(m.group(0)):
                            return _norm_date(m.group(0))
                # no valid date in this span — keep scanning: a
                # two-column form interleaves other text between
                # the label and its date.
        return ""

    rec["on_board"] = _date_near(
        lambda ln: "ONBOARD" in ln["squash"]
        or "LADENONBOARD" in ln["squash"]
        or "SHIPPEDONBOARD" in ln["squash"], span=5)
    if not rec["on_board"]:
        rec["on_board"] = _date_near(
            lambda ln: "ONBOARDDATE" in ln["squash"], span=2)
    rec["issue_date"] = _date_near(
        lambda ln: "DATEOFISSUE" in ln["squash"]
        or "PLACEANDDATEOFISSUE" in ln["squash"])

    # ---- 7) goods / packages / weights / freight / free time ----
    spaced = " ".join(ln["text"] for ln in lines)
    best_pkg = None
    for m in re.finditer(r"(\d[\d,]*)\s*(BAGS?|PACKAGES?|CARTONS?|"
                          r"BOXES|PKGS|PCS)\b", spaced, re.I):
        n = int(m.group(1).replace(",", ""))
        if best_pkg is None or n > best_pkg[0]:
            best_pkg = (n, m.group(1) + " " + m.group(2).upper())
    if best_pkg:
        rec["packages"] = best_pkg[1]
    m = re.search(r"(\d[\d,]*)\s*(?:BAGS?|PACKAGES?|CARTONS?|BOXES)"
                  r"\s+OF\s+([A-Z][A-Z .&/'-]{2,40})", spaced)
    if not m:
        m2 = re.search(r"(\d+)(BAGS|PACKAGES|CARTONS|BOXES)OF"
                       r"([A-Z]{3,30})", full_sq)
        if m2:
            m = None
            rec["goods"] = m2.group(3)
            if not rec["packages"]:
                rec["packages"] = m2.group(1) + " " + m2.group(2)
    if m:
        rec["goods"] = re.sub(r"\s+", " ",
                              m.group(2)).strip(" .,-").upper()
    if not rec["goods"]:
        m = re.search(r"(?:SAID TO CONTAIN|STC)\s*[:\-]?\s*"
                      r"([A-Z][A-Z ]{3,30})", spaced)
        if m and "CONTAINER" not in m.group(1):
            rec["goods"] = m.group(1).strip().upper()

    def _weight(kinds_keys, pats):
        # First the clear TOTAL/label patterns; then, among the candidates near the label,
        # the LARGEST number (the total is always
        # larger than the per-container weight). Only a number
        # that is with KGS or has a decimal — the digits of a container/seal
        # cannot become weight.
        for p in pats:
            m = re.search(p, spaced, re.I)
            if m:
                return _num_or_blank(m.group(1))
        best = None
        for li, ln in enumerate(lines):
            if _line_label_kinds(ln) & kinds_keys:
                for j in range(li, min(li + 9, len(lines))):
                    for m in re.finditer(
                            r"([\d,]+\.\d+|\d[\d,]*)\s*\(?(KGS?)?\)?",
                            lines[j]["text"]):
                        has_unit = bool(m.group(2)) or "KGS" in \
                            lines[j]["text"][m.end():m.end() + 5].upper()
                        if "." in m.group(1) or has_unit:
                            v = _num_or_blank(m.group(1))
                            if isinstance(v, (int, float)) and (
                                    best is None or v > best):
                                best = v
                if best is not None:
                    return best
        return ""

    rec["gross_kg"] = _weight({"gross"}, [
        r"TOTAL\s*GROSS\s*(?:WT|WEIGHT)?[:\s.]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"GROSS\s*WEIGHT[:\s]*([\d,]+\.?\d*)"])
    rec["net_kg"] = _weight({"net"}, [
        r"TOTAL\s*NET\s*(?:WT|WEIGHT)?[:\s.]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"NET\s*WEIGHT[:\s]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"NETT\s*WEIGHT[:\s]*([\d,]+\.?\d*)"])
    # v54 CBM fix: first from GEOMETRY — on the form the CBM value
    # is often directly ABOVE the 'CBM' label and OCR gives them
    # as separate items; on text-join the adjacency is broken
    # and line-merge creates a line like 'EXPIRYDATE:07/2029 CBM',
    # so the year (2029) was picked up as CBM (on the Wan Hai BL
    # 2029 came instead of the actual 65.0000). In the label's column
    # the closest number above it is the actual value.
    _cbm_done = False
    for it in items:
        if str(it.get("text", "")).strip().upper() not in ("CBM", "M3"):
            continue
        lx0, ly0 = it["box"][0][0], it["box"][0][1]
        lx1 = it["box"][2][0]
        best_v, best_gap = None, None
        for jt in items:
            if jt is it:
                continue
            t = str(jt.get("text", "")).strip().replace(",", "")
            if not re.fullmatch(r"\d+\.\d+|\d+", t):
                continue
            jx0, jy1 = jt["box"][0][0], jt["box"][2][1]
            jx1 = jt["box"][2][0]
            if jx1 < lx0 - 0.06 * W or jx0 > lx1 + 0.06 * W:
                continue  # second column
            gap = ly0 - jy1
            if gap < -0.02 * H or gap > 0.08 * H:
                continue  # must be directly above the label
            v = _num_or_blank(t)
            if isinstance(v, (int, float)) and 0 < v < 10000:
                if best_gap is None or abs(gap) < best_gap:
                    best_v, best_gap = v, abs(gap)
        if best_v is not None:
            rec["cbm"] = best_v
            _cbm_done = True
            break
    if not _cbm_done:
        m = re.search(r"(?<![\d/,.\-])([\d,]+\.\d+)\s*(CBM|M3)\b",
                      spaced) \
            or re.search(r"(?<![\d/,.\-])([\d,]+\.?\d*)\s*(CBM|M3)\b",
                         spaced)
        if m:
            v = _num_or_blank(m.group(1))
            # If the HS code gets merged, a false CBM in crores appears;
            # a pure year (2029 etc.) is also not CBM —
            # the actual CBM is always small
            if isinstance(v, (int, float)) and v < 10000 \
                    and not (float(v).is_integer()
                             and 1900 <= v <= 2099):
                rec["cbm"] = v
    if "FREIGHTPREPAID" in full_sq or re.search(
            r"FREIGHT\s+PREPAID", spaced, re.I):
        rec["freight"] = "Prepaid"
    elif "FREIGHTCOLLECT" in full_sq:
        rec["freight"] = "Collect"
    m = (re.search(r"(\d+)\s*DAYS?\s*(?:FREE\s*)?(?:FREETIME|FREE\s*TIME|"
                   r"DETENTION|DEMURRAGE)", spaced, re.I)
         or re.search(r"FREETIMEATDESTINATION:?(\d+)", full_sq)
         or re.search(r"(\d+)DAYSFREETIME", full_sq)
         or re.search(r"FREETIME:?(\d+)DAYS", full_sq)
         or re.search(r"(\d+)DAYSFREE", full_sq)
         or re.search(r"FREE\s*TIME:?\s*(\d+)\s*DAYS", spaced, re.I))
    if m:
        rec["free_days"] = int(m.group(1))

    if items:
        low = [i for i in items if i.get("score", 1) < 0.6]
        if len(low) > len(items) * 0.35:
            warnings.append("Parts of this photo were hard to read — "
                            "please check the record against the BL.")
    rec["warnings"] = warnings
    meta = {"excluded": sorted(excluded_hard | excluded_soft),
            "seals": sorted(seal_numbers), "bl_from_label": bl_from_label}
    return rec, meta


def _vision_bl_extract(data_url, offline, meta):
    """OPTIONAL booster (v49): if settings have an AI key, send the photo to a
    vision model and cross-check the record. It is used only
    when the response is clean JSON, bl_no is not empty, and it
    is NOT a container/seal/booking pattern. If any error occurs,
    silently use the offline result — this path never blocks a scan."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    try:
        key = _ai_key_single()
        if not key and not _groq_key():
            return None
        prompt = (
            "Read this Bill of Lading photo and return ONLY a JSON "
            "object with keys: bl_no, carrier, vessel, voyage, precarriage, precarriage_voyage, "
            "shipper, consignee, pol, pod, ts_port, on_board, "
            "issue_date, goods, packages, gross_kg, net_kg, cbm, "
            "freight, free_days, containers (array of {no, seal, "
            "type}). RULES: bl_no is the value printed next to the "
            "'Bill Of Lading No' / 'B/L No.' label. NEVER use the "
            "booking number, S/O number, serial number, shipment "
            "reference, a container number (4 letters + 7 digits) or "
            "a seal number as bl_no. If the document is a PROFORMA "
            "or the BL number box is empty, set bl_no to \"\". Use "
            "\"\" for anything not printed. No commentary, JSON only.")
        _vmime = "image/png"
        _vb64 = data_url or ""
        if _vb64.startswith("data:"):
            _vmime = _vb64[5:].split(";", 1)[0].strip().lower() or _vmime
        if "," in _vb64:
            _vb64 = _vb64.split(",", 1)[1]
        txt = _vision_text_any(prompt, _vmime, _vb64)
        v = None
        if txt:
            txt = re.sub(r"^```(?:json)?|```$", "", txt,
                         flags=re.M).strip()
            try:
                v = _j.loads(txt)
            except Exception:
                v = None
        if not isinstance(v, dict):
            return None
        blv = _sq(str(v.get("bl_no") or ""))
        if not blv:
            return None
        if re.fullmatch(r"[A-Z]{4}\d{7}", blv) and _iso_ok(blv):
            return None  # turned a container into a BL — not acceptable
        if blv in set(meta.get("excluded") or []) \
                or blv in set(meta.get("seals") or []):
            return None
        if not (8 <= len(blv) <= 20):
            return None
        return v
    except Exception:
        return None


# ------------- v86: THE FINAL GATE OF THE SCAN -------------
def _matches_any_pat(s):
    try:
        return any(re.fullmatch(p, s) for p, _c in _BL_PATTERNS)
    except Exception:
        return False


def _confusable_alt(no):
    """A confusable variant of the read BL number (1->I, 0->O,
    5->S, 8->B) — only when the variant fully matches a known BL pattern
    and the original number does not. On correct numbers,
    a false variant is never created."""
    try:
        _bn = str(no or "")
        _flip = {"1": "I", "0": "O", "5": "S", "8": "B"}
        for _i, _ch in enumerate(_bn):
            if _ch in _flip and _i > 2:
                _cand = (_bn[:_i] + _flip[_ch]
                         + _bn[_i + 1:])
                if (_matches_any_pat(_cand)
                        and not _matches_any_pat(_bn)):
                    return _cand
        return ""
    except Exception:
        return ""


def _scan_rescue(no, alt=""):
    """History-rescue: if the read number itself is NOT FOUND in history
    and does not match any known pattern either, but its
    close form (a confusable substitution, or a one-letter difference)
    IS FOUND in history and matches a pattern — then that is
    the real number. The pattern condition protects sequential numbers
    (Maersk/Emkay) from a wrong rescue: a correctly
    read number either matches a pattern or its
    neighbour does not match either."""
    try:
        if not no or _matches_any_pat(no):
            return ""
        hist = load_json(HISTORY_FILE, [])
        found = set()
        for h in hist if isinstance(hist, list) else []:
            if isinstance(h, dict) and h.get("found"):
                q = _sq(str(h.get("query") or ""))
                if q:
                    found.add(q)
        if not found or no in found:
            return ""
        cands = []
        if alt:
            cands.append(alt)
        _fl = {"1": "I", "I": "1", "0": "O", "O": "0",
               "5": "S", "S": "5", "8": "B", "B": "8"}
        for _i, _ch in enumerate(str(no)):
            if _ch in _fl and _i > 2:
                cands.append(str(no)[:_i] + _fl[_ch]
                             + str(no)[_i + 1:])
        for c in cands:
            if c in found and _matches_any_pat(c):
                return c
        for f in found:
            if _matches_any_pat(f) and _lev(str(no), f) == 1:
                return f
        return ""
    except Exception:
        return ""


def _finalize_scan(rec, vision_no=""):
    """THE FINAL GATE FOR SCANS (v86 system fix): EVERY response from /api/ocr
    — whether from the local engine or the AI-vision-only fallback —
    passes through here before going out. (Previously the variant
    protection was only on the local path; the vision fallback would
    bypass it — the same flaw that caused FRLS's I/1
    mistake twice.) For every number: first the variant (bl_alt),
    then history-rescue — if a close FOUND record exists, that becomes
    the real number (bl_no), the read number goes into bl_alt
    so it is also checked, and the matter is written clearly
    in the warning."""
    try:
        if not isinstance(rec, dict):
            return rec
        no = str(rec.get("bl_no") or "")
        if not no:
            return rec
        _corr = ENG.norm(no)
        if _corr != no:
            rec["bl_no"] = _corr
            rec.setdefault("warnings", []).append(
                "The number was read as " + no + " — Emkay "
                "BLs are always EMKAYMBAKHI plus 5 digits, "
                "so it was corrected to " + _corr + ".")
            no = _corr
        warns = list(rec.get("warnings") or [])
        alt = ""
        if vision_no and str(vision_no) != no:
            alt = str(vision_no)
        if not alt:
            alt = _confusable_alt(no)
        rescue = _scan_rescue(no, alt)
        if rescue and rescue != no:
            rec["bl_rescue_from"] = no
            rec["bl_no"] = rescue
            rec["bl_alt"] = no
            warns.append(
                "The photo read " + no + " — but a shipment "
                "with the very similar number " + rescue +
                " is already in your history as FOUND, so "
                "that number is being tracked as the BL "
                "(the read number is also checked).")
        elif alt:
            rec["bl_alt"] = alt
        # A container can never be a fragment of a BL number:
        # the OCR regex cuts an 11-character "container" out of
        # inside the BL token and the check digit can coincidentally
        # also be correct (inside COAU6470268490,
        # COAU6470268 — passed the ISO check, on 2 Nov 2026
        # Yousuf caught it: "the container number was not even in this page,
        # on what basis is this claim?"). Any candidate
        # that falls inside any form of the BL (parsed / final / alt /
        # rescue-source) is NOT a container.
        try:
            conts = rec.get("containers")
            if isinstance(conts, list) and conts:
                blforms = set()
                for b in (no, rec.get("bl_no"), rec.get("bl_alt"),
                          rec.get("bl_rescue_from")):
                    bb = _sq(str(b or ""))
                    if bb:
                        blforms.add(bb)
                kept = []
                for c in conts:
                    cn = _sq(str(c.get("no") or "")) \
                        if isinstance(c, dict) else ""
                    if cn and any(cn in bf for bf in blforms):
                        warns.append(
                            cn + " is part of the BL number "
                            "itself, so it was not treated as "
                            "a container number.")
                        continue
                    kept.append(c)
                rec["containers"] = kept
        except Exception:
            pass
        rec["warnings"] = warns
        return rec
    except Exception:
        return rec


# ------------- v51: AI vision fallback (if there is no local engine) -------------
_VISION_BL_PROMPT = (
    "Read this Bill of Lading photo and return ONLY a JSON "
    "object with keys: bl_no, carrier, vessel, voyage, precarriage, precarriage_voyage, "
    "shipper, consignee, pol, pod, ts_port, on_board, "
    "issue_date, goods, packages, gross_kg, net_kg, cbm, "
    "freight, free_days, proforma, containers (array of {no, "
    "seal, type}). RULES: bl_no is the value printed next to "
    "the 'Bill Of Lading No' / 'B/L No.' label. NEVER use the "
    "booking number, S/O number, serial number, shipment "
    "reference, a container number (4 letters + 7 digits) or "
    "a seal number as bl_no. If the document is a PROFORMA "
    "or the BL number box is empty, set proforma to true and "
    "bl_no to \"\". Use \"\" for anything not printed. No "
    "commentary, JSON only.")


def _vision_extract_record(image_bytes, mime, ai_key):
    """v51: the second path for photo-scan — if the local OCR engine
    is not ready (missing / setup running / setup failed), then
    extract the record directly with Gemini's vision model. Record
    shape is exactly what extract_bl_record returns, with engine
    'vision'. Strict validation: bl_no pattern
    (^[A-Z0-9]{8,20}$), container ISO 6346 check digit (a failed
    container is dropped, check_ok honestly), on a PROFORMA
    bl_no is always empty (a booking never becomes a BL). Any
    error at all returns None — this function never raises;
    the handler then falls back to the old clean error."""
    import base64 as _b64
    import urllib.request as _u
    import json as _j
    try:
        key = _ai_key_single() or str(ai_key or "").strip()
        if key.startswith("gsk_"):
            key = ""
        if (not key and not _groq_key()) or not image_bytes:
            return None
        txt = _vision_text_any(_VISION_BL_PROMPT,
                               mime or "image/png",
                               _b64.b64encode(image_bytes).decode())
        v = None
        if txt:
            txt = re.sub(r"^```(?:json)?|```$", "", txt,
                         flags=re.M).strip()
            try:
                v = _j.loads(txt)
            except Exception:
                v = None

        if not isinstance(v, dict):
            return None
        # ---- validation + record shape ----
        rec = {"bl_no": "", "containers": [], "carrier": "",
               "vessel": "", "voyage": "", "precarriage": "",
               "precarriage_voyage": "", "shipper": "",
               "consignee": "", "pol": "", "pod": "",
               "ts_port": "", "on_board": "", "issue_date": "",
               "goods": "", "packages": "", "gross_kg": "",
               "net_kg": "", "cbm": "", "freight": "",
               "free_days": "", "proforma": False}
        blv = _sq(str(v.get("bl_no") or ""))
        proforma = bool(v.get("proforma"))
        if blv:
            if not re.fullmatch(r"[A-Z0-9]{8,20}", blv):
                return None
            # if a container number has been made into a BL, it is not acceptable
            if re.fullmatch(r"[A-Z]{4}\d{7}", blv) \
                    and _iso_ok(blv):
                return None
            rec["bl_no"] = blv
            proforma = False
        elif not proforma:
            return None   # neither BL found nor proforma — no-result
        rec["proforma"] = proforma
        for k in ("carrier", "vessel", "voyage", "precarriage",
                  "precarriage_voyage", "shipper",
                  "consignee", "pol", "pod", "ts_port",
                  "on_board", "issue_date", "goods", "packages",
                  "freight"):
            val = v.get(k)
            if val not in (None, ""):
                rec[k] = str(val).strip()
        for k in ("gross_kg", "net_kg", "cbm"):
            rec[k] = _num_or_blank(v.get(k))
        fd = _num_or_blank(v.get("free_days"))
        rec["free_days"] = int(fd) if fd != "" else ""
        for c in v.get("containers") or []:
            if not isinstance(c, dict) or not c.get("no"):
                continue
            no = _sq(str(c["no"]))
            if not re.fullmatch(r"[A-Z]{4}\d{7}", no):
                continue
            if not _iso_ok(no):
                continue   # check digit fail — container drop
            rec["containers"].append({
                "no": no,
                "seal": str(c.get("seal") or "").strip().upper(),
                "type": str(c.get("type") or ""),
                "check_ok": True})
        rec["ok"] = True
        rec["engine"] = "vision"
        rec["warnings"] = [
            "Read with the AI vision fallback (the built-in "
            "scan engine is not ready on this device yet) — "
            "please double-check the details against the "
            "document."]
        return rec
    except Exception:
        return None


def _public_settings():
    s = dict(get_settings())
    s["ai_key_set"] = bool(str(s.get("ai_key") or "").strip())
    s.pop("ai_key", None)
    # v67: the Gemini key also goes out only as a flag.
    s["gemini_key_set"] = bool(str(s.get("gemini_key") or "").strip())
    s.pop("gemini_key", None)
    s["groq_key_set"] = bool(str(s.get("groq_key") or "").strip())
    s.pop("groq_key", None)
    # v56: the Traqo key is also like ai_key — only the flag goes out, not the key.
    s["traqo_key_set"] = bool(str(s.get("traqo_key") or "").strip())
    s.pop("traqo_key", None)
    # v59: mail setup (sending chat to Shezi) - app password only as a flag.
    s["mail_pass_set"] = bool(str(s.get("mail_pass") or "").strip())
    s.pop("mail_pass", None)
    if not s.get("mail_user"):
        s["mail_user"] = "officeuseonlydell@gmail.com"
    # v110: staff logins — only the count goes out, name/hash never.
    s["staff_users_count"] = len(
        [x for x in (s.get("staff_users") or []) if isinstance(x, dict)])
    s.pop("staff_users", None)
    # v48: the password hash itself never leaves the server — only a flag.
    s["app_pass_set"] = bool(str(s.get("app_pass") or "").strip())
    s.pop("app_pass", None)
    # v96 Profile: the name stays in the settings store; the photo is a file
    # in DATA_DIR — in the settings response only a flag goes out, the photo data
    # never (the photo is served via the /profile/photo route).
    s["profile_name"] = str(s.get("profile_name") or "").strip()
    s["profile_photo_set"] = _profile_photo_path() is not None
    # v98 Stage B (Sync): token/hash never goes out — only
    # the state (role, address, last sync, joined copies).
    s.pop("sync_token_hash", None)
    s.pop("sync_client_token", None)
    s.pop("sync_instance_id", None)
    s.pop("profile_sync_ts", None)
    try:
        s.update(_sync_public())
    except Exception:
        pass
    return s


PROFILE_PHOTO_EXTS = (".jpg", ".png", ".webp")


def _profile_photo_path():
    for ext in PROFILE_PHOTO_EXTS:
        f = DATA_DIR / ("profile_photo" + ext)
        if f.exists():
            return f
    return None


def get_settings():
    s = load_json(SETTINGS_FILE, {})
    return s if isinstance(s, dict) else {}


# ---------------- data sync (v98, Stage B) ----------------
# Principle (Yousuf's order, 29 Oct 2026): whichever copy is used — laptop
# ZIP, permanent server link, or temporary link — the data must always be UPDATED
# and SAME, with no difference anywhere. Design: one copy is the central HUB
# (an always-awake server); the other copies connect to it
# themselves. On first joining, a protective union merge — nothing is lost,
# a deleted record does not come back to life. API keys /
# secrets NEVER go in the sync payload; shipment data and
# profile (name + photo) do go.
#
# The heart of merge: record-level, key = query (BL). On each record
# sync_ts (Lamport-style: always ahead of the largest ts
# ever seen in the system) + stage rank (by milestone order). The higher
# stage wins; on equal stage, the newer sync_ts; the winner
# is taken WHOLE, but any field that is empty in the winner
# and filled in the loser is filled in
# (the same enrich-fill principle). A tombstone (delete marker)
# always defeats an old record; a new record defeats the tombstone.
#
# All helpers of the state file are without _lock — every caller
# must hold _lock (HTTP calls happen OUTSIDE the lock).

SYNC_STATE_FILE = DATA_DIR / "sync_state.json"
_SYNC_TOMB_CAP = 500
_SYNC_TOMB_KEEP = 180 * 24 * 3600
_SYNC_HASH_SKIP = ("sync_ts", "milestones")


def _sync_state():
    st = load_json(SYNC_STATE_FILE, {})
    if not isinstance(st, dict):
        st = {}
    if not isinstance(st.get("tombstones"), list):
        st["tombstones"] = []
    if not isinstance(st.get("last_sent"), dict):
        st["last_sent"] = {}
    if not isinstance(st.get("peers"), dict):
        st["peers"] = {}
    st.setdefault("max_ts", 0)
    st.setdefault("last_pull_ts", 0)
    return st


def _sync_state_save(st):
    return save_json(SYNC_STATE_FILE, st)


def _sync_role():
    return str(get_settings().get("sync_role") or "").strip()


def _sync_token_ok(token):
    want = str(get_settings().get("sync_token_hash") or "").strip()
    if not want or not token:
        return False
    got = hashlib.sha256(str(token).encode("utf-8")).hexdigest()
    return hmac.compare_digest(got, want)


def _sync_next_ts(st=None):
    """Lamport clock: a new stamp on this copy will always be ahead
    of the largest ts it has ever seen — even if the clock goes
    backwards, no change can become 'old'."""
    try:
        mx = float((st or _sync_state()).get("max_ts") or 0)
    except Exception:
        mx = 0
    return max(time.time(), mx + 0.01)


def _sync_clone(x):
    return json.loads(json.dumps(x, ensure_ascii=False, default=str))


def _sync_rec_hash(rec):
    core = {k: v for k, v in (rec or {}).items()
            if k not in _SYNC_HASH_SKIP}
    blob = json.dumps(core, sort_keys=True, ensure_ascii=False,
                      default=str)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _sync_empty(v):
    return v is None or v == "" or v == [] or v == {}


_SYNC_FILL_BOOL = ("found", "returned", "starred", "bl_confirmed_ever")


def _sync_stage_rank(rec):
    """Stage number by milestone order (larger = further ahead):
    0 nothing · 1 received · 2 departed · 3 berthed (berth) ·
    4 half unloaded · 5 unloaded · 6 gate out · 7 delivered ·
    8 empty returned (returned)."""
    r = (rec or {}).get("result") or {}
    rank = 1 if (rec or {}).get("found") else 0
    try:
        states = {m.get("key"): m.get("state")
                  for m in _milestones(rec or {})}
    except Exception:
        states = {}
    if states.get("departed") == "done":
        rank = max(rank, 2)
    if states.get("berthed") == "done":
        rank = max(rank, 3)
    if states.get("discharged") == "partial":
        rank = max(rank, 4)
    if states.get("discharged") == "done":
        rank = max(rank, 5)
    if states.get("gateout") == "done":
        rank = max(rank, 6)
    if _status_final(r):
        rank = max(rank, 7)
    if (rec or {}).get("returned"):
        rank = max(rank, 8)
    return rank


def _sync_fill(winner, loser):
    """The winner in full; only its EMPTY fields are filled from
    the loser's filled ones (the same rule applies one level
    down for 'result' as well)."""
    w = _sync_clone(winner)
    for k, lv in (loser or {}).items():
        if k in _SYNC_HASH_SKIP:
            continue
        wv = w.get(k)
        if k in _SYNC_FILL_BOOL:
            if not wv and lv:
                w[k] = lv
            continue
        if _sync_empty(wv) and not _sync_empty(lv):
            w[k] = lv
        elif k == "result" and isinstance(wv, dict) \
                and isinstance(lv, dict):
            for rk, rlv in lv.items():
                if _sync_empty(wv.get(rk)) and not _sync_empty(rlv):
                    wv[rk] = rlv
    return w


def _sync_pick(local, remote):
    """Merged record from two copies. Stage first,
    then sync_ts; on a full tie, the fuller record."""
    if local is None:
        return _sync_clone(remote)
    if remote is None:
        return _sync_clone(local)
    lr, rr = _sync_stage_rank(local), _sync_stage_rank(remote)
    lt = float(local.get("sync_ts") or 0)
    rt = float(remote.get("sync_ts") or 0)
    if rr > lr or (rr == lr and rt > lt):
        win, lose = remote, local
    elif lr > rr or (lr == rr and lt > rt):
        win, lose = local, remote
    elif _sync_rec_hash(remote) == _sync_rec_hash(local):
        win, lose = local, remote
    elif len(str(remote)) > len(str(local)):
        win, lose = remote, local
    else:
        win, lose = local, remote
    merged = _sync_fill(win, lose)
    merged["sync_ts"] = max(lt, rt)
    return merged


def _sync_prune_tombs(tombs, now=None):
    now = now or time.time()
    keep = [t for t in tombs
            if now - float(t.get("ts") or 0) <= _SYNC_TOMB_KEEP]
    keep.sort(key=lambda t: float(t.get("ts") or 0), reverse=True)
    return keep[:_SYNC_TOMB_CAP]


def _sync_add_tombstone(st, query, ts=None):
    """Caller holds _lock. The delete mark is in the state."""
    if not query:
        return
    ts = ts if ts is not None else _sync_next_ts(st)
    tombs = {t.get("query"): t for t in st["tombstones"]}
    old = tombs.get(query)
    if old is None or float(old.get("ts") or 0) < ts:
        tombs[query] = {"query": query, "ts": ts}
    st["tombstones"] = _sync_prune_tombs(list(tombs.values()))
    st["max_ts"] = max(float(st.get("max_ts") or 0), ts)


def _sync_apply(hist, records_in, tombs_in):
    """Apply incoming records + tombstones to this copy's hist (list,
    in-place) using the merge rule. Caller holds _lock and
    saves history afterwards. Return: (count of changed records,
    {query: hash} that were written, [deleted queries])."""
    st = _sync_state()
    tombs = {t.get("query"): dict(t) for t in st["tombstones"]}
    for t in (tombs_in or []):
        q = t.get("query")
        if not q:
            continue
        ts = float(t.get("ts") or 0)
        if q not in tombs or float(tombs[q].get("ts") or 0) < ts:
            tombs[q] = {"query": q, "ts": ts}
        st["max_ts"] = max(float(st.get("max_ts") or 0), ts)
    by_q = {}
    for h in hist:
        if h.get("query"):
            by_q[h["query"]] = h
    written, gone = {}, []
    changed = 0
    for rec in (records_in or []):
        q = (rec or {}).get("query")
        if not q:
            continue
        rts = float(rec.get("sync_ts") or 0)
        st["max_ts"] = max(float(st.get("max_ts") or 0), rts)
        tb = tombs.get(q)
        if tb is not None and float(tb.get("ts") or 0) >= rts \
                and rts > 0:
            continue  # the tombstone is newer than this record — the record stays dead
        merged = _sync_pick(by_q.get(q), rec)
        if tb is not None \
                and float(merged.get("sync_ts") or 0) > float(tb.get("ts") or 0):
            del tombs[q]  # the new record has defeated the tombstone
        old = by_q.get(q)
        if old is not None and _sync_rec_hash(old) == _sync_rec_hash(merged):
            hist[hist.index(old)] = merged  # only sync_ts refresh
            by_q[q] = merged
            continue
        old_status = ((old or {}).get("result") or {}).get("status") or ""
        new_status = (merged.get("result") or {}).get("status") or ""
        if old is not None and old_status != new_status and new_status:
            chg = {"time": _DT(datetime.now()),
                   "from": old_status or "In progress",
                   "to": new_status, "via": "sync"}
            merged["changes"] = ([chg] + list(
                merged.get("changes") or []))[:6]
            merged["changed"] = True
        if old is None:
            hist.insert(0, merged)
        else:
            hist[hist.index(old)] = merged
        by_q[q] = merged
        written[q] = _sync_rec_hash(merged)
        changed += 1
    for q, tb in list(tombs.items()):
        cur = by_q.get(q)
        if cur is not None \
                and float(tb.get("ts") or 0) >= float(cur.get("sync_ts") or 0):
            hist.remove(cur)
            del by_q[q]
            gone.append(q)
            changed += 1
    st["tombstones"] = _sync_prune_tombs(list(tombs.values()))
    _sync_state_save(st)
    return changed, written, gone


def _sync_snapshot(since=0.0):
    """Hub response: records + tombstones (newer than since) + profile.
    Caller holds _lock. Stamp core first — the hub's own fresh
    changes (even those from before the background cycle) must
    also be included in this response."""
    _sync_stamp_core(mark_clean=True)
    hist = get_history()
    recs = [h for h in hist
            if float(h.get("sync_ts") or 0) > since]
    st = _sync_state()
    tombs = [t for t in st["tombstones"]
             if float(t.get("ts") or 0) > since]
    mx = float(st.get("max_ts") or 0)
    for h in hist:
        mx = max(mx, float(h.get("sync_ts") or 0))
    return {"records": recs, "tombstones": tombs,
            "profile": _sync_profile_payload(),
            "staff": _sync_staff_payload(), "max_ts": mx}


def _sync_staff_payload():
    """Staff users + delete-tombstones + activity register —
    part of sync (v117): whichever copy staff works on, Admin
    should see their sign-in/activity on every copy.
    Like API keys, this does not leave via settings — only
    the sync channel (with token) is used."""
    s = get_settings()
    acts = load_json(STAFF_ACTIVITY_FILE, [])
    if not isinstance(acts, list):
        acts = []
    # v132: never send out a delete mark that is expired, or that
    # a live account (upd at/after the mark) has superseded — a
    # stale mark in circulation is what wiped re-created staff
    # accounts again and again.
    _users132 = _staff_users()
    _upd132 = {str(x.get("name") or "").strip().lower():
               float(x.get("upd") or x.get("created") or 0)
               for x in _users132}
    _now132 = time.time()
    _del132 = []
    for x in (s.get("staff_deleted") or []):
        if not isinstance(x, dict):
            continue
        _nm132 = str(x.get("name") or "").strip().lower()
        _ts132 = float(x.get("ts") or 0)
        if _now132 - _ts132 > _SYNC_TOMB_KEEP:
            continue
        if _upd132.get(_nm132, 0.0) >= _ts132 and _nm132 in _upd132:
            continue
        _del132.append(x)
    return {"users": _users132,
            "deleted": _del132,
            "activity": acts[-500:]}


def _sync_apply_staff(p):
    """Caller holds _lock. Merges staff users by the 'upd' clock and
    activity by append-only union; if a delete
    tombstone is newer, the user is removed."""
    if not isinstance(p, dict):
        return
    s = get_settings()
    rem_users = [x for x in (p.get("users") or [])
                 if isinstance(x, dict)
                 and str(x.get("name") or "").strip()]
    rem_del = [x for x in (p.get("deleted") or [])
               if isinstance(x, dict)]
    if rem_users or rem_del:
        users = _staff_users()
        byname = {str(x.get("name") or "").strip().lower(): x
                  for x in users}
        dels = {}
        for x in (s.get("staff_deleted") or []):
            if isinstance(x, dict):
                nm = str(x.get("name") or "").strip().lower()
                if nm:
                    dels[nm] = max(dels.get(nm, 0.0),
                                   float(x.get("ts") or 0))
        changed = False
        for d in rem_del:
            nm = str(d.get("name") or "").strip().lower()
            if nm and float(d.get("ts") or 0) > dels.get(nm, 0.0):
                dels[nm] = float(d.get("ts") or 0)
                changed = True
        for ru in rem_users:
            nm = str(ru.get("name") or "").strip().lower()
            if not nm:
                continue
            rupd = float(ru.get("upd") or ru.get("created") or 0)
            if dels.get(nm, 0.0) > rupd:
                if nm in byname:
                    byname.pop(nm)
                    changed = True
                continue
            cur = byname.get(nm)
            if cur is None:
                byname[nm] = ru
                changed = True
            elif rupd > float(cur.get("upd")
                              or cur.get("created") or 0):
                byname[nm] = ru
                changed = True
        for nm in list(byname):
            e = byname[nm]
            if dels.get(nm, 0.0) > float(e.get("upd")
                                         or e.get("created") or 0):
                byname.pop(nm)
                changed = True
        # v132 (Yousuf, 10 Nov 2026 — "staff har naye version par
        # khatam ho jate hain"): a delete mark must not outlive the
        # account it killed. If the account is alive with an 'upd'
        # at or after the mark, the mark is stale — drop it for
        # good, or the same old delete keeps circulating and can
        # wipe a re-created account again on a later sync. Marks
        # also expire on the record-tombstone keep window.
        _now132 = time.time()
        for nm in list(dels):
            e = byname.get(nm)
            if e is not None and float(
                    e.get("upd") or e.get("created")
                    or 0) >= dels[nm]:
                dels.pop(nm)
                changed = True
            elif _now132 - dels[nm] > _SYNC_TOMB_KEEP:
                dels.pop(nm)
                changed = True
        if changed:
            s["staff_users"] = list(byname.values())
            s["staff_deleted"] = [
                {"name": k, "ts": v} for k, v in dels.items()][-50:]
            save_json(SETTINGS_FILE, s)
    rem_act = p.get("activity")
    if isinstance(rem_act, list) and rem_act:
        cur = load_json(STAFF_ACTIVITY_FILE, [])
        if not isinstance(cur, list):
            cur = []
        seen = {(float(x.get("ts") or 0), str(x.get("name") or ""),
                 str(x.get("action") or ""))
                for x in cur if isinstance(x, dict)}
        merged = list(cur)
        added = False
        for x in rem_act:
            if not isinstance(x, dict):
                continue
            k = (float(x.get("ts") or 0), str(x.get("name") or ""),
                 str(x.get("action") or ""))
            if k not in seen:
                seen.add(k)
                merged.append(x)
                added = True
        if added:
            merged.sort(key=lambda x: float(x.get("ts") or 0))
            save_json(STAFF_ACTIVITY_FILE, merged[-500:])


def _sync_profile_payload():
    import base64
    s = get_settings()
    photo = None
    f = _profile_photo_path()
    if f is not None:
        try:
            raw = f.read_bytes()
            if len(raw) <= 2 * 1024 * 1024:
                photo = {"ext": f.suffix,
                         "b64": base64.b64encode(raw).decode("ascii")}
        except Exception:
            photo = None
    return {"name": str(s.get("profile_name") or "").strip(),
            "photo": photo,
            "photo_removed_ts": float(s.get("profile_photo_removed_ts") or 0),
            "ts": float(s.get("profile_sync_ts") or 0)}


def _sync_apply_profile(p):
    """Caller holds _lock. Only a NEWER profile is applied
    (the profile_sync_ts clock is that same Lamport)."""
    import base64
    if not isinstance(p, dict):
        return False
    ts = float(p.get("ts") or 0)
    s = get_settings()
    if ts <= float(s.get("profile_sync_ts") or 0):
        return False
    s["profile_name"] = str(p.get("name") or "").strip()[:80]
    s["profile_sync_ts"] = ts
    if not save_json(SETTINGS_FILE, s):
        return False
    ph = p.get("photo")
    if isinstance(ph, dict) and ph.get("ext") in PROFILE_PHOTO_EXTS:
        try:
            raw = base64.b64decode(ph.get("b64") or "", validate=True)
            if 0 < len(raw) <= 2 * 1024 * 1024:
                for ext in PROFILE_PHOTO_EXTS:
                    if ext != ph["ext"]:
                        (DATA_DIR / ("profile_photo" + ext)).unlink(
                            missing_ok=True)
                (DATA_DIR / ("profile_photo" + ph["ext"])).write_bytes(raw)
                s2 = get_settings()
                if float(s2.get("profile_photo_removed_ts") or 0):
                    s2["profile_photo_removed_ts"] = 0
                    save_json(SETTINGS_FILE, s2)
        except Exception:
            pass
    elif float(p.get("photo_removed_ts") or 0) >= ts and \
            float(p.get("photo_removed_ts") or 0) > \
            float(s.get("profile_photo_removed_ts") or 0):
        # Only a REAL Remove can delete the photo. Merely "no photo
        # sent" (ph=None) never deletes — this was the old root cause:
        # the sync of a copy that does not have the photo file would delete
        # the other copy's DP.
        for ext in PROFILE_PHOTO_EXTS:
            try:
                (DATA_DIR / ("profile_photo" + ext)).unlink(missing_ok=True)
            except Exception:
                pass
        s2 = get_settings()
        s2["profile_photo_removed_ts"] = float(p.get("photo_removed_ts") or 0)
        save_json(SETTINGS_FILE, s2)
    return True


def _sync_stamp_core(mark_clean=False):
    """The inner part of _sync_stamp_pass — the caller holds _lock
    already. Return is the same."""
    hist = get_history()
    st = _sync_state()
    last_sent = dict(st.get("last_sent") or {})
    now = time.time()
    dirty, present, hist_dirty = [], set(), False
    for rec in hist:
        q = rec.get("query")
        if not q:
            continue
        present.add(q)
        if not rec.get("sync_ts"):
            base = rec.get("checked_ts") or rec.get("attempt_ts") or now
            rec["sync_ts"] = float(base)
            st["max_ts"] = max(float(st.get("max_ts") or 0),
                               float(base))
            hist_dirty = True
        h = _sync_rec_hash(rec)
        if last_sent.get(q) != h:
            if q in last_sent:
                rec["sync_ts"] = _sync_next_ts(st)
                st["max_ts"] = max(float(st.get("max_ts") or 0),
                                   float(rec["sync_ts"]))
                hist_dirty = True
            dirty.append(_sync_clone(rec))
            if mark_clean:
                last_sent[q] = _sync_rec_hash(rec)
        elif mark_clean:
            last_sent[q] = h
    for q in list(last_sent):
        if q not in present:
            _sync_add_tombstone(st, q)
            del last_sent[q]
    st["last_sent"] = last_sent
    _sync_state_save(st)
    if hist_dirty:
        save_json(HISTORY_FILE, hist[:1000])
    return dirty, list(st["tombstones"])


def _sync_stamp_pass(mark_clean=False):
    """Capture this copy's own changes: a record that changed since
    the last baseline gets a new sync_ts; one that disappeared gets
    a tombstone. With mark_clean=True (hub) the baseline refreshes
    to the current state at once — the hub has nowhere to send,
    pull goes straight from history. On a joined copy the baseline
    refreshes via _sync_mark_sent after a successful push.
    Caller must NOT hold _lock — this takes the lock itself.
    Return: (dirty records [clone], all tombstones)."""
    with _lock:
        return _sync_stamp_core(mark_clean)


def _sync_mark_sent(queries):
    """Joined: after a successful push, set these records' baseline hash
    to the current state (so they are not pushed again)."""
    with _lock:
        hist = get_history()
        st = _sync_state()
        by_q = {h.get("query"): h for h in hist}
        for q in queries:
            rec = by_q.get(q)
            if rec is not None:
                st["last_sent"][q] = _sync_rec_hash(rec)
        _sync_state_save(st)


def _sync_http(url, token, payload=None, timeout=25):
    """Talk to the hub. (status, json) or (None, None) when there is no
    connection (offline) — caller tells apart: 401 means token
    wrong, None means no network."""
    headers = {"X-Sync-Token": str(token or ""),
               "Content-Type": "application/json",
               "X-Sync-Client": _sync_instance_id(),
               "X-Sync-Label": _sync_instance_label()}
    data = None
    if payload is not None:
        payload = dict(payload)
        payload.setdefault("client_id", _sync_instance_id())
        payload.setdefault("label", _sync_instance_label())
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, headers=headers,
        method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {}
    except Exception:
        return None, None


def _sync_instance_id():
    s = get_settings()
    iid = str(s.get("sync_instance_id") or "").strip()
    if not iid:
        iid = secrets.token_hex(6)
        s["sync_instance_id"] = iid
        save_json(SETTINGS_FILE, s)
    return iid


def _sync_instance_label():
    try:
        import socket
        return socket.gethostname() or "CargoTrack copy"
    except Exception:
        return "CargoTrack copy"


def _sync_note_peer(client_id, label):
    """Hub: which copy connected when. Caller holds _lock."""
    if not client_id:
        return
    st = _sync_state()
    st["peers"][str(client_id)[:40]] = {
        "label": str(label or "CargoTrack copy")[:60],
        "last_seen": time.time()}
    _sync_state_save(st)


_SYNC_KICK = threading.Event()


def _sync_set_status(msg, ok=False):
    st = _sync_state()
    st["last_sync_msg"] = str(msg or "")[:200]
    if ok:
        st["last_sync_ok_ts"] = time.time()
    _sync_state_save(st)


def _sync_cycle():
    """One cycle for a joined copy: send dirty records + tombstones,
    apply the hub's winning ones back, then pull new changes.
    Never raises — when offline it quietly
    waits for the next attempt."""
    s = get_settings()
    if _sync_role() != "joined":
        return
    hub = str(s.get("sync_hub_url") or "").strip().rstrip("/")
    token = str(s.get("sync_client_token") or "").strip()
    if not hub or not token:
        return
    dirty, tombs = _sync_stamp_pass()
    code, resp = _sync_http(hub + "/api/sync/push", token, {
        "records": dirty, "tombstones": tombs,
        "profile": _sync_profile_payload(),
        "staff": _sync_staff_payload()})
    if code is None:
        with _lock:
            _sync_set_status("offline — will sync when the hub "
                             "is reachable")
        return
    if code == 401:
        with _lock:
            _sync_set_status("sync token rejected by the hub — "
                             "check the token in Settings")
        return
    if code != 200 or not isinstance(resp, dict):
        with _lock:
            _sync_set_status(f"hub answered {code} — will retry")
        return
    _sync_mark_sent([r.get("query") for r in dirty if r.get("query")])
    with _lock:
        hist = get_history()
        _sync_apply_profile(resp.get("profile"))
        _sync_apply_staff(resp.get("staff"))
        ch, written, gone = _sync_apply(
            hist, resp.get("records") or [],
            resp.get("tombstones") or [])
        if ch:
            save_json(HISTORY_FILE, hist[:1000])
        st = _sync_state()
        for q, h in written.items():
            st["last_sent"][q] = h
        for q in gone:
            st["last_sent"].pop(q, None)
        st["profile_sent_hash"] = hashlib.sha256(json.dumps(
            _sync_profile_payload(), sort_keys=True,
            default=str).encode("utf-8")).hexdigest()
        _sync_state_save(st)
    # now pull the hub's new changes
    with _lock:
        since = float(_sync_state().get("last_pull_ts") or 0)
    code, resp = _sync_http(f"{hub}/api/sync/pull?since={since}",
                            token)
    if code == 200 and isinstance(resp, dict):
        with _lock:
            hist = get_history()
            _sync_apply_profile(resp.get("profile"))
            _sync_apply_staff(resp.get("staff"))
            ch, written, gone = _sync_apply(
                hist, resp.get("records") or [],
                resp.get("tombstones") or [])
            if ch:
                save_json(HISTORY_FILE, hist[:1000])
            st = _sync_state()
            for qq, h in written.items():
                st["last_sent"][qq] = h
            for qq in gone:
                st["last_sent"].pop(qq, None)
            st["last_pull_ts"] = max(
                float(st.get("last_pull_ts") or 0),
                float(resp.get("max_ts") or 0))
            st["last_sync_msg"] = "synced"
            st["last_sync_ok_ts"] = time.time()
            _sync_state_save(st)
    else:
        with _lock:
            _sync_set_status("synced (push); pull will retry", ok=True)
    # v131: scan-copy photos travel with the same cycle, so a copy
    # scanned anywhere shows up on every copy.
    try:
        _sync_photos_cycle(hub, token)
    except Exception:
        pass


def _sync_join_now():
    """First joining: union-merge the hub's FULL snapshot,
    then push everything of your own. Returns (ok, message)."""
    s = get_settings()
    hub = str(s.get("sync_hub_url") or "").strip().rstrip("/")
    token = str(s.get("sync_client_token") or "").strip()
    if not hub or not token:
        return False, "hub address or token missing"
    code, resp = _sync_http(hub + "/api/sync/join", token, {})
    if code is None:
        return False, "hub unreachable — check the address and network"
    if code == 401:
        return False, "sync token rejected by the hub"
    if code != 200 or not isinstance(resp, dict):
        return False, f"hub answered {code}"
    with _lock:
        hist = get_history()
        _sync_apply_profile(resp.get("profile"))
        _sync_apply_staff(resp.get("staff"))
        ch, written, gone = _sync_apply(
            hist, resp.get("records") or [],
            resp.get("tombstones") or [])
        if ch:
            save_json(HISTORY_FILE, hist[:1000])
        st = _sync_state()
        for q, h in written.items():
            st["last_sent"][q] = h
        for q in gone:
            st["last_sent"].pop(q, None)
        st["last_pull_ts"] = max(float(st.get("last_pull_ts") or 0),
                                 float(resp.get("max_ts") or 0))
        _sync_state_save(st)
    _sync_cycle()
    return True, "joined — data merged both ways, nothing lost"


def _sync_loop():
    """Background cycle: immediately at start, then pull every 2 minutes;
    push local changes after ~10s debounce. On the hub copy
    only the stamp pass (so its own changes go into the pull)."""
    time.sleep(5)
    last_full = 0.0
    dirty_since = 0.0
    while True:
        try:
            role = _sync_role()
            if role == "hub":
                _sync_stamp_pass(mark_clean=True)
            elif role == "joined":
                now = time.time()
                dirty, _ = _sync_stamp_pass()
                if dirty and not dirty_since:
                    dirty_since = now
                if (dirty and now - dirty_since >= 10) \
                        or now - last_full >= 120 \
                        or _SYNC_KICK.is_set():
                    _SYNC_KICK.clear()
                    _sync_cycle()
                    last_full = time.time()
                    dirty_since = 0.0
        except Exception:
            pass
        time.sleep(15)


def _sync_public():
    s = get_settings()
    st = _sync_state()
    peers = [{"label": v.get("label") or "CargoTrack copy",
              "last_seen": v.get("last_seen")}
             for v in (st.get("peers") or {}).values()]
    peers.sort(key=lambda x: x.get("last_seen") or 0, reverse=True)
    return {
        "sync_role": _sync_role(),
        "sync_hub_url": str(s.get("sync_hub_url") or ""),
        "sync_hub_token_set": bool(s.get("sync_token_hash")),
        "sync_client_token_set": bool(s.get("sync_client_token")),
        "sync_last_ok": st.get("last_sync_ok_ts"),
        "sync_last_msg": st.get("last_sync_msg") or "",
        "sync_peers": peers,
        "sync_records": len(get_history()),
        "sync_tombstones": len(st.get("tombstones") or [])}


# ---------------- app lock + sessions (v48) ----------------
# The password is stored ONLY as a salted hash in settings.json
# ("app_pass" = salt_hex$sha256_hex, sha256 of salt+password).
# No app_pass -> the app is UNLOCKED (first-run mode, old behaviour).
# Browser sessions live in sessions.json, keyed by sha256(token);
# the raw token only ever exists in the browser's HttpOnly cookie.

def _app_pass_hash():
    return str(get_settings().get("app_pass") or "").strip()


def _make_pass_hash(pw):
    salt = secrets.token_bytes(16)
    digest = hashlib.sha256(salt + pw.encode("utf-8")).hexdigest()
    return salt.hex() + "$" + digest


def _verify_pass(pw, stored):
    try:
        salt_hex, digest = stored.split("$", 1)
        cand = hashlib.sha256(
            bytes.fromhex(salt_hex) + pw.encode("utf-8")).hexdigest()
        return hmac.compare_digest(cand, digest)
    except Exception:
        return False


def _load_sessions():
    d = load_json(SESSIONS_FILE, {})
    if not isinstance(d, dict):
        d = {}
    if not isinstance(d.get("sessions"), dict):
        d["sessions"] = {}
    if not isinstance(d.get("attempts"), list):
        d["attempts"] = []
    # v123 (Yousuf, 7 Nov 2026 — pakka usool): a session with no
    # activity for 15 days is kicked automatically. Runs on every
    # load, so the dead entry stops authenticating and leaves the
    # list on its own; the file is saved only when something was
    # actually pruned.
    try:
        _cut = time.time() - 15 * 86400
        _dead = [_th for _th, _s in d["sessions"].items()
                 if max(float(_s.get("last_seen") or 0),
                        _SESS_SEEN.get(_th, 0),
                        float(_s.get("created") or 0)) < _cut]
        if _dead:
            for _th in _dead:
                d["sessions"].pop(_th, None)
            _save_sessions(d)
    except Exception:
        pass
    return d


def _sess_tag(s, current):
    """Plain-words label for the sessions list — whose browser this
    is, written out (Yousuf, 7 Nov 2026: he must see it in words,
    not guess it from IP numbers)."""
    if current:
        return "You — This Browser"
    if s.get("role") == "staff":
        return "Staff Member"
    if str(s.get("ip") or "") in ("127.0.0.1", "::1"):
        return "This Machine — Local Copy"
    if device_label(s.get("ua", "")) == "Browser":
        return "Test Browser — Shezi's Check"
    return "Admin — Another Device"


def _save_sessions(d):
    return save_json(SESSIONS_FILE, d)


def device_label(ua):
    """Friendly device label from a User-Agent string."""
    ua = ua or ""
    if "Edg/" in ua:
        browser = "Edge"
    elif "OPR/" in ua or "Opera" in ua:
        browser = "Opera"
    elif "Firefox/" in ua:
        browser = "Firefox"
    elif "CriOS" in ua or "Chrome/" in ua:
        browser = "Chrome"
    elif "Safari/" in ua:
        browser = "Safari"
    else:
        browser = "Browser"
    if "iPhone" in ua:
        osname = "iPhone"
    elif "iPad" in ua:
        osname = "iPad"
    elif "Android" in ua:
        osname = "Android"
    elif "Windows" in ua:
        osname = "Windows"
    elif "Mac OS" in ua or "Macintosh" in ua:
        osname = "Mac"
    elif "Linux" in ua:
        osname = "Linux"
    else:
        osname = ""
    return f"{browser} on {osname}" if osname else browser


def _create_session(ua, ip, role="admin", name=""):
    """Create a session; returns the raw token (for the cookie).
    v110: the session record also carries who signed in — the
    admin (the app password) or a named staff login — so the
    server can hold staff back from admin-only actions."""
    token = secrets.token_urlsafe(32)
    th = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = time.time()
    with _lock:
        d = _load_sessions()
        d["sessions"][th] = {"created": now, "last_seen": now,
                             "ua": ua, "ip": ip,
                             "role": role, "name": name}
        if len(d["sessions"]) > 20:  # cap: drop the oldest
            by_age = sorted(d["sessions"].items(),
                            key=lambda kv: kv[1].get("created", 0))
            for k, _v in by_age[:len(by_age) - 20]:
                d["sessions"].pop(k, None)
        _save_sessions(d)
    return token


def _record_attempt(ip, ua, ok):
    with _lock:
        d = _load_sessions()
        d["attempts"].append({"ts": time.time(), "ip": ip,
                              "ua": ua, "ok": bool(ok)})
        d["attempts"] = d["attempts"][-50:]  # keep only the last 50
        _save_sessions(d)


# ---- v110: staff logins + staff activity register ----
# Staff accounts live in settings.json under "staff_users"
# ({"name", "pass" (salted hash), "disabled", "created"}); the
# admin manages them from Settings. The activity register is a
# SEPARATE file on purpose: it never touches BL records — no
# "tracked by" marks on shipments, ever (user's hard rule).

def _staff_users():
    out = []
    for x in (get_settings().get("staff_users") or []):
        if isinstance(x, dict) and str(x.get("name") or "").strip():
            out.append(x)
    return out


def _staff_access(name):
    """'own' or 'full' — what a staff login may see (Yousuf, 8 Nov
    2026). Accounts created before this option existed carry no
    field and keep 'full', so nothing changes for them until the
    admin picks Own for them in Settings."""
    u = _staff_find(name)
    if u and str(u.get("access") or "") == "own":
        return "own"
    return "full"


def _staff_own_entries(name):
    """The staff member's own tracked entries (their separate
    file), same entry shape as the main history."""
    return [h for h in _get_staff_history()
            if h.get("staff_owner") == name]


_ASSISTANT_SCOPE = threading.local()


def _scoped_history():
    """History the Assistant may use on this request thread. The
    /api/assistant handler narrows it for own-records staff so the
    owner's record never reaches an answer."""
    ov = getattr(_ASSISTANT_SCOPE, "hist", None)
    return ov if ov is not None else get_history()


def _staff_find(name):
    nm = str(name or "").strip().lower()
    for x in _staff_users():
        if str(x.get("name") or "").strip().lower() == nm:
            return x
    return None


def _staff_log(name, ip, action):
    """One line in the staff activity register. Never raises —
    a logging failure must not break the staff member's work."""
    try:
        with _lock:
            d = load_json(STAFF_ACTIVITY_FILE, [])
            if not isinstance(d, list):
                d = []
            d.append({"ts": time.time(), "name": str(name or ""),
                      "ip": str(ip or ""),
                      "action": str(action or "")[:160]})
            save_json(STAFF_ACTIVITY_FILE, d[-500:])
    except Exception:
        pass


_SESS_SEEN = {}     # token_hash -> last_seen ts (in memory, freshest)
_SESS_WRITTEN = {}  # token_hash -> ts of last sessions.json write


def _touch_session(th, ua, ip):
    """Update a session's last_seen; the disk write is throttled to
    at most once per 60 seconds per session to avoid churn."""
    now = time.time()
    _SESS_SEEN[th] = now
    if now - _SESS_WRITTEN.get(th, 0) <= 60:
        return
    with _lock:
        d = _load_sessions()
        s = d["sessions"].get(th)
        if not s:
            return
        s["last_seen"] = now
        s["ua"] = ua
        s["ip"] = ip
        if _save_sessions(d):
            _SESS_WRITTEN[th] = now


def _sess_cookie(token):
    return (f"ct_sess={token}; HttpOnly; Path=/; "
            f"Max-Age=7776000; SameSite=Lax")


_SESS_COOKIE_CLEAR = "ct_sess=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax"

LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head><link rel="icon" type="image/x-icon" href="/favicon.ico"><link rel="icon" type="image/png" sizes="32x32" href="/favicon.png"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CargoTrack — Locked</title>
<style>
body{text-transform:capitalize}input{text-transform:none}

  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;display:flex;align-items:center;
    justify-content:center;background:#12121E;color:#ECECF4;
    font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
    padding:20px}
  .card{background:#1E1E30;border:1px solid #2F2F47;border-radius:20px;
    padding:34px 30px;width:100%;max-width:380px;text-align:center;
    box-shadow:0 24px 60px rgba(0,0,0,.5)}
  .ring{position:relative;width:126px;height:126px;margin:0 auto}
  .ring::before{content:'';position:absolute;inset:0;border-radius:50%;
    background:conic-gradient(from 0deg,#7C3AED,#DB2777,transparent 32%,transparent 55%,#A78BFA,transparent 82%);
    animation:spin 6s linear infinite;
    -webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 5px),#000 calc(100% - 4px));
            mask:radial-gradient(farthest-side,transparent calc(100% - 5px),#000 calc(100% - 4px))}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes pulse{0%,100%{transform:translate(-50%,-50%) scale(1)}50%{transform:translate(-50%,-50%) scale(1.05)}}
  .ring img{position:absolute;left:50%;top:50%;width:96px;height:96px;
    object-fit:contain;border-radius:18px;background:rgba(255,255,255,.94);
    transform:translate(-50%,-50%);animation:pulse 3.4s ease-in-out infinite}
  h1{margin:18px 0 2px;font-size:26px;letter-spacing:.3px;
    background:linear-gradient(90deg,#A78BFA,#F472B6);
    -webkit-background-clip:text;background-clip:text;color:transparent}
  .sub{color:#A8A8BE;font-size:14px;margin:0 0 22px}
  .seg{display:flex;background:#12121E;border:2px solid #2F2F47;
    border-radius:12px;padding:3px;gap:3px;margin:0 0 14px}
  .seg button{flex:1;width:auto;margin:0;padding:9px;border:0;
    border-radius:9px;cursor:pointer;background:transparent;
    color:#A8A8BE;font-size:14.5px;font-weight:600;
    font-family:inherit;transform:none}
  .seg button.on{background:linear-gradient(90deg,#7C3AED,#DB2777);
    color:#fff}
  input{width:100%;padding:13px 14px;border-radius:12px;font-size:16px;
    border:2px solid #2F2F47;background:#12121E;color:#ECECF4;outline:none}
  input:focus{border-color:#7C3AED}
  #nm{display:none;margin-bottom:10px}
  button{width:100%;margin-top:14px;padding:13px;border:0;border-radius:12px;
    font-size:16px;font-weight:700;color:#fff;cursor:pointer;
    background:linear-gradient(90deg,#7C3AED,#DB2777)}
  button:active{transform:scale(.99)}
  #err{display:none;color:#F87171;font-size:14px;margin-top:14px}
  .lock{font-size:15px;color:#A8A8BE;margin-top:18px}
</style></head><body>
  <div class="card">
    <div class="ring"><img src="/logos/ct-logo.png" alt="CargoTrack"
      onerror="this.style.display='none'"></div>
    <h1>CargoTrack</h1>
    <p class="sub" id="subTxt">This app is locked. Enter your password to open it.</p>
    <div class="seg"><button type="button" id="segAdmin" class="on">Admin</button><button type="button" id="segStaff">Staff</button></div>
    <form id="lf" autocomplete="off">
      <input id="nm" type="text" placeholder="Your name"
        autocomplete="username">
      <input id="pw" type="password" placeholder="Password"
        autocomplete="current-password" autofocus>
      <button type="submit">Open app</button>
    </form>
    <div id="err"></div>
    <div class="lock">🔐 Only browsers you sign in on can use this app.</div>
  </div>
<script>
  var staffMode = false;
  var segA = document.getElementById("segAdmin"),
      segS = document.getElementById("segStaff"),
      nmEl = document.getElementById("nm"),
      pwEl = document.getElementById("pw"),
      subEl = document.getElementById("subTxt");
  function setStaff(on) {
    staffMode = on;
    segA.classList.toggle("on", !on);
    segS.classList.toggle("on", on);
    nmEl.style.display = on ? "block" : "none";
    subEl.textContent = on
      ? "Staff sign-in — enter your name and your password."
      : "This app is locked. Enter your password to open it.";
    (on ? nmEl : pwEl).focus();
  }
  segA.addEventListener("click", function () { setStaff(false); });
  segS.addEventListener("click", function () { setStaff(true); });
  document.getElementById("lf").addEventListener("submit", async e => {
    e.preventDefault();
    const err = document.getElementById("err");
    err.style.display = "none";
    const payload = staffMode
      ? {staff: true, name: nmEl.value, password: pwEl.value}
      : {password: pwEl.value};
    try {
      const r = await fetch("/api/login", {method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(payload)});
      if (r.ok) { location.href = "/"; return; }
      const j = await r.json().catch(() => ({}));
      if (j.error === "disabled") {
        err.textContent = "This staff account is disabled — please ask the admin.";
      } else if (j.error === "wrong password") {
        err.textContent = staffMode
          ? "Wrong name or password — please try again."
          : "Wrong password — please try again.";
      } else {
        err.textContent = "Could not sign in: " + (j.error || r.status);
      }
      err.style.display = "block";
    } catch (ex) {
      err.textContent = "Could not reach the server.";
      err.style.display = "block";
    }
  });
</script>
</body></html>"""


# ---------------- tracking jobs (live layer progress) ----------------
JOBS = {}


def _run_job(job_id, items, mode, carrier_manual, client):
    job = JOBS[job_id]
    results = []
    for item in items:
        events = []

        def cb(name, status, detail=""):
            events.append({"name": name, "status": status, "detail": detail})
            job["events"] = list(events)
            job["current"] = item

        # v99: also give the containers of the existing record to the engine
        # — every re-check is always done from both BL + containers
        # (the 26 Oct principle); even if BL-Inquiry is closed
        # (cycle closed), the container's terminal
        # record can correct the record.
        _known = []
        try:
            _pool = get_history()
            if job.get("staff"):
                _pool = _pool + _get_staff_history()
            _hit = next((h for h in _pool
                         if h.get("query") == item), None)
            if _hit:
                _known = ((_hit.get("result") or {})
                          .get("containers") or [])
        except Exception:
            _known = []
        try:
            res = _track_all_timed(
                240,
                bl=item if mode == "bl" else None,
                ctn=item if mode == "container" else None,
                vessel_name=item if mode == "vessel" else None,
                progress_cb=cb,
                carrier_hint=carrier_manual,
                known_containers=_known or None,
                known_vessel=(((_hit.get("result") or {})
                               .get("vessel")) if _hit else None),
                traqo_key=str(get_settings().get("traqo_key")
                              or "").strip() or None)
        except _FutTimeout:
            res = {"carrier": None, "prefix": "", "result": {}, "layers": [],
                   "contacts": None}
            events.append({"name": "Timed out", "status": "fail",
                           "detail": "Sources took too long — the "
                                     "previous record is kept."})
        except Exception as e:
            res = {"carrier": None, "prefix": "", "result": {}, "layers": [],
                   "contacts": None}
            events.append({"name": "Error", "status": "fail", "detail": str(e)})
        if carrier_manual:
            res["carrier"] = carrier_manual
        ctx = {"query": item, "mode": mode, "client": client,
               "staff_owner": job.get("staff") or None,
               "carrier": res.get("carrier"), "prefix": res.get("prefix"),
               "result": res.get("result", {}), "layers": res.get("layers", []),
               "contacts": res.get("contacts"),
               "found": bool(res.get("result")),
               "time": _DT(datetime.now())}
        try:
            # v110 (Yousuf, 3 Nov): the container part inside a BL search
            # does NOT create its own separate entry —
            # the entry is always created from the BL itself, because the container
            # numbers are already present in the BL's record.
            if not job.get("no_save"):
                _record(ctx)
            else:
                _apply_stale_guard(ctx)
        except Exception:
            # F-04 fix (v46 audit): a bad history entry must never kill
            # the job thread — the UI polls until job["done"] is set and
            # would otherwise spin forever with the Track button dead.
            pass
        results.append(ctx)
        job["results"] = list(results)
    job["done"] = True


_PLACEHOLDERS = {"", "/", "—", "-", "N/A", "NA", "None", "null"}
_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun",
     "jul", "aug", "sep", "oct", "nov", "dec"])}


def _real(v):
    """True when a value is real data, not an empty placeholder."""
    if v is None:
        return False
    if isinstance(v, str):
        return v.strip() not in _PLACEHOLDERS
    if isinstance(v, (list, dict)):
        return len(v) > 0
    return True


def _pdate(s):
    """Best-effort date parse for the formats our sources produce."""
    if not s:
        return None
    t = str(s).strip().lower()
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            return None
    m = re.search(r"(\d{1,2})[\s\-]([a-z]{3,9})[\s\-,]+(\d{2,4})", t)
    if m and m.group(2)[:3] in _MONTHS:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        try:
            return date(y, _MONTHS[m.group(2)[:3]], int(m.group(1)))
        except Exception:
            return None
    m = re.search(r"([a-z]{3,9})\s+(\d{1,2})", t)
    if m and m.group(1)[:3] in _MONTHS:
        try:
            return date(date.today().year, _MONTHS[m.group(1)[:3]],
                        int(m.group(2)))
        except Exception:
            return None
    return None


def _canon_voyage(r):
    """Canonical form of a voyage — letters first, number after
    (W631, not 631W). The v91 rule was earlier on only one path
    of _record; now it is on EVERY merge path, so the stored record
    always stays in a single format (data audit: 49 records had
    a digit-first voyage)."""
    try:
        v = str(r.get("voyage") or "").strip()
        m = re.fullmatch(r"(\d{1,4})([A-Za-z])", v)
        if m:
            canon = m.group(2).upper() + m.group(1)
            if canon != v:
                r["voyage"] = canon
                for f in ("position", "status"):
                    fv = str(r.get(f) or "")
                    if ("(" + v + ")") in fv:
                        r[f] = fv.replace("(" + v + ")",
                                          "(" + canon + ")")
    except Exception:
        pass


def _own_cycle_correction(old_r, new_r):
    """A final status can go backwards in only ONE case:
    the new data is terminal proof from the record's OWN cycle — VIR
    is the same, the discharge day is the same — and the box actually
    shows standing inside the yard, while the old final claim has
    no trace of a gate_out date at all (MBAQITS8502261016:
    it said 'Delivered', the box was still in QICT's yard).
    Without this, the stage guard blocks a false final forever.
    269665315 is safe from this: there the new data's
    position was OUT, not yard."""
    _ov = str(old_r.get("vir") or "").strip().upper()
    _nv = str(new_r.get("vir") or "").strip().upper()
    if not (_ov and _nv and _ov == _nv):
        return False
    if _real(old_r.get("gate_out")):
        return False
    _od = _pdate(old_r.get("discharge_time"))
    _nd = _pdate(new_r.get("discharge_time"))
    if not (_od and _nd and _od == _nd):
        return False
    if ENG.status_text_stage(new_r.get("status")) < 3:
        return False
    # v98 (S2, EMKAYMBAKHI59055): proof of the yard must be in the POSITION
    # field — 'yard' in the status TEXT alone is not
    # enough. QICT's Ctr-Inq leg only shows discharge
    # (that state always remains even after gate-out);
    # a 'Discharged…' text built from it, or a fabricated
    # position, cannot move the final record backwards.
    # A real yard sighting always comes in the position
    # (terminal grid / Ctr-Inq's real position) — the real 1016
    # case ('In Yard' position) is protected by this.
    # v99 (investigation fix 2): a position written by the veto ITSELF
    # is NOT proof for this guard — if the veto has
    # turned 'OUT' into 'In Yard' by its own inference, that
    # position is a product of the same claim that is being
    # examined (on 30 Oct 2026, 59055's downgrade passed on this
    # self-made proof: the guard saw 'yard' in the position,
    # but did not see that the veto had written it
    # there). Correction only when the yard position has come
    # from a real data field — a clear refusal on
    # 'veto' provenance.
    if (new_r.get("position_via") or "") == "veto":
        return False
    _npos = (new_r.get("position") or "").lower()
    return "yard" in _npos


def _vir_cycle_date(vir):
    """Extract the cycle date embedded in a VIR number (the DDMMYY +
    HHMMSS suffix, e.g. PKKHISAPT_221026134915 -> 22 Oct 2026).
    Returns a date, or None when the VIR carries no parseable date.
    Used only for the gate_in cycle-anchor — it never builds a
    display string."""
    v = str(vir or "")
    m = re.search(r"_(\d{2})(\d{2})(\d{2})\d{6}\s*$", v)
    if m:
        try:
            yy = int(m.group(3))
            yy = 2000 + yy if yy <= 69 else 1900 + yy
            d = date(yy, int(m.group(2)), int(m.group(1)))
            if 2015 <= d.year <= date.today().year + 1:
                return d
        except Exception:
            pass
    m = re.search(r"(\d{2})(\d{2})(\d{4})\s*$", v)
    if m:
        try:
            d = date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            if 2015 <= d.year <= date.today().year + 1:
                return d
        except Exception:
            pass
    return None


def _bl_confirmed(layers):
    """Was this check confirmed via the BL or carrier's own path?
    Data found only via the container path is not confirmed."""
    for l in layers or []:
        if (l or {}).get("status") != "done":
            continue
        if (l or {}).get("mode") == "bl":
            return True
        n = (l or {}).get("name") or ""
        if "direct API" in n or "track-trace" in n:
            return True
    return False


def _result_containers(r):
    ctrs = []
    for c in ((r or {}).get("containers") or []):
        if c and c not in ctrs:
            ctrs.append(c)
    if (r or {}).get("container") and r["container"] not in ctrs:
        ctrs.append(r["container"])
    for row in ((r or {}).get("terminal_rows") or []):
        c = (row or {}).get("CONTAINER NO")
        if c and c not in ctrs:
            ctrs.append(c)
    return ctrs


def _stale_trip_alert(new_r, layers, today=None,
                      fallback_containers=None):
    """Yousuf's firm rule (31 Oct 2026): a record that is 1 month or
    more old (its last event — gate out/discharge —
    from 30+ days ago) is not the answer to this search.
    - kind=prev_trip: a complete cycle (gate out done) found ONLY
      via the container path — this is the container's Previous trip,
      not this BL's. Adoption is FORBIDDEN; notify the user in the alert window
      + request the complete BL copy.
    - kind=old_record: confirmed via BL/carrier, or only
      the discharge is old — it will be adopted, but with an alert."""
    today = today or date.today()
    if not new_r:
        new_r = {}
    go = _pdate(new_r.get("gate_out"))
    dis = _pdate(new_r.get("discharge_time"))
    last = go or dis
    if not last:
        # Current-cycle terminal evidence inside the result itself
        # (an accepted terminal layer's VIR, or KGTL departure /
        # empty-return evidence) means this result is NOT only a
        # previous-trip ghost: a recycled container's OLD row at
        # ANOTHER terminal survives only as a layer note and must
        # not wipe live evidence (142G512846, 6 Nov 2026 — the
        # Hutchison Jul-2025 ghost note erased KGTL's Departed +
        # storage-return evidence on every re-check, so the record
        # stayed 'On hold — discharged, in yard' for ever).
        if new_r.get("vir") or new_r.get("kgtl_departed") \
                or new_r.get("kgtl_empty_in"):
            return None
        # v112 (4 Nov): the engine now does not return old/export terminal rows
        # in the result at all — the information only remains in the layer's note
        # ("holds only an OLD record").
        # The alert should also be raised from there, otherwise the request for the BL copy
        # silently disappears (the PEL
        # case). If the containers were found only via the container route,
        # the kind is always prev_trip.
        for _l in layers or []:
            _det = str((_l or {}).get("detail") or "")
            if "OLD record" not in _det:
                continue
            _m = re.search(r"\(([^)]+)\)", _det)
            _when = None
            if _m:
                _w = _m.group(1).strip()
                _when = None
                for _f in ("%d %b %Y", "%b %Y", "%d-%b-%Y",
                           "%d-%b-%y", "%d %B %Y", "%B %Y"):
                    try:
                        _when = datetime.strptime(_w, _f).date()
                        break
                    except Exception:
                        pass
                if not _when:
                    _when = _pdate(_w)
            if not _when or (today - _when).days < 30:
                continue
            _ctrs = (_result_containers(new_r)
                     or list(fallback_containers or []))
            if not _ctrs:
                continue
            return {"kind": "prev_trip",
                    "event": "previous trip",
                    "event_date": _when.isoformat(),
                    "age_days": (today - _when).days,
                    "terminal": new_r.get("terminal") or "",
                    "vessel": new_r.get("vessel") or "",
                    "containers": _ctrs}
        return None
    age = (today - last).days
    if age < 30:
        return None
    kind = "old_record" if (_bl_confirmed(layers) or not go) \
        else "prev_trip"
    return {"kind": kind,
            "event": "gate out" if go else "discharge",
            "event_date": last.isoformat(), "age_days": age,
            "terminal": new_r.get("terminal") or "",
            "vessel": new_r.get("vessel") or "",
            "containers": _result_containers(new_r)}


def _stored_stale_check(h):
    """Read-path check (v103): if a stored record is from the container's
    previous complete trip — the BL arrived in this system 30+ days
    AFTER that cycle's gate out, and there is no BL/carrier
    confirmation in the layers — it cannot belong to this BL.
    In such a case, an empty shell + alert instead of the result."""
    r = h.get("result") or {}
    go = _pdate(r.get("gate_out"))
    if not go:
        return None
    fs = _pdate(h.get("first_seen"))
    if not fs or (fs - go).days < 30:
        return None
    if _bl_confirmed(h.get("layers")) or h.get("bl_confirmed_ever"):
        return None
    # The strongest proof: the entry was previously, inside this system,
    # at In-transit (or some lower stage), then changed to "Gate out"
    # — while according to the terminal, that gate out had happened
    # 30+ days before this BL entered the system.
    # These two things cannot both belong to this BL at the same time.
    jumped = False
    for ch in (h.get("changes") or []):
        if str((ch or {}).get("via") or "") == "sync":
            continue  # the sync merge's own bookkeeping is not proof
        to = str((ch or {}).get("to") or "").lower()
        frm = str((ch or {}).get("from") or "").lower()
        if "gate out" in to and "gate out" not in frm:
            jumped = True
        # Second form: while inside the system, the record received
        # a discharge/gate-out DATE that was 30+ days older than
        # the BL's entry into the system (the actual changes of PEL entries
        # have exactly this form).
        if "discharg" in to or "gate out" in to:
            _cd = _pdate((ch or {}).get("to"))
            if _cd and (fs - _cd).days >= 30:
                jumped = True
    if not jumped:
        return None
    return {"kind": "prev_trip", "event": "gate out",
            "event_date": go.isoformat(),
            "age_days": (date.today() - go).days,
            "terminal": r.get("terminal") or "",
            "vessel": r.get("vessel") or "",
            "containers": _result_containers(r)}


def _gateout_retract_evidence(old_r, new_r):
    """v104: the EVIDENCE test to reject an old gate_out — True only
    when a fresh TERMINAL record (of the same VIR) shows in its rows
    all of this record's containers still inside the port
    (gate-out empty), and there is no return (EM) proof. If even one
    condition is missing, False — without proof the old record stays
    safe (absence of evidence is not evidence)."""
    if not isinstance(new_r, dict) or not new_r:
        return False
    _ov = str(old_r.get("vir") or "").strip().upper()
    _nv = str(new_r.get("vir") or "").strip().upper()
    if not _ov or not _nv or _ov != _nv:
        return False
    _src = str(new_r.get("source") or "")
    if "Terminal" not in _src and "QICT" not in _src:
        return False
    if new_r.get("returned"):
        return False
    _od = _pdate(old_r.get("discharge_time"))
    _nd = _pdate(new_r.get("discharge_time"))
    if _od and _nd and _od != _nd:
        return False
    _oc = {str(c).strip().upper()
           for c in (old_r.get("containers") or [])
           if _real(c)}
    _one = str(old_r.get("container") or "").strip().upper()
    if _one:
        _oc.add(_one)
    if not _oc:
        return False
    _rows = new_r.get("terminal_rows") or []
    _seen = set()
    for _row in _rows:
        if not isinstance(_row, dict):
            continue
        _cn = str(_row.get("CONTAINER NO") or "").strip().upper()
        if _cn not in _oc:
            continue
        if str(_row.get("STATUS") or "").strip().upper() == "EM":
            return False
        if _real(_row.get("GATE OUT TIME")):
            return False
        _seen.add(_cn)
    if _rows and _seen >= _oc:
        return True
    # QICT form: there are no rows — the position itself is the proof
    if not _rows and "QICT" in _src \
            and str(new_r.get("position") or "").strip().lower() \
            == "in yard" and _nd:
        return True
    return False


# v132 khubi 1 — har field ka MALIK source: discharge / berthing /
# gate-out / VIR / terminal ka malik TERMINAL hai. Ye field purane
# record mein maujood hon aur taaza result kisi ghair-terminal
# source (carrier / aggregator) se mukhtalif value laye, to
# terminal wali value jeetegi — taaza lekin ghalat data achhe
# terminal saboot ko nahi kuchal sakta. Terminal se terminal
# ki tabdeeli (asal correction) hamesha jaiz hai.
_TERMINAL_OWNED = ("discharge_time", "berthing", "gate_out",
                   "vir", "terminal")


def _is_terminal_src(src):
    s = str(src or "")
    return any(t in s for t in ("QICT", "Hutchison", "KGTL",
                                "Terminal", "DP World", "SAPT",
                                "KICT", "Port Qasim"))


def _merge_result(old_r, new_r):
    """Merge a fresh tracking result into the stored one.

    A weaker new result must never erase data we already know:
    every field keeps the new value when it is real, otherwise the
    old value survives. Containers are unioned.

    v96 data-audit guards (merge = the choke point through which manual
    track, re-track and auto re-check ALL pass):
    (i) If VIR is on both sides and differs, the new data is not of
        this record's cycle at all — the old record stays fully safe
        (SSLSUKHICAD0733: the box's NEXT export cycle had overwritten
        the complete import cycle).
    (ii) If the old record is complete (stage >= 4), the new data's
        vessel differs and the new data itself is not delivered, this is
        data of another trip / another BL — identity stays safe
        (on PAL/PKKHI/003995, S430202793's sailing values had
        come in).
    (iii) No stage downgrade ever: if the new status's stage is lower
        than the old, status/position/gate_out keep the old ones
        — except for the one evidence case of _own_cycle_correction
        (269665315, S490321128 etc. stop right here
        )."""
    old_r = old_r or {}
    new_r = new_r or {}
    old_stage = ENG.status_stage(old_r)
    new_stage = ENG.status_stage(new_r)
    _ov = str(old_r.get("vir") or "").strip().upper()
    _nv = str(new_r.get("vir") or "").strip().upper()
    foreign = bool(_ov and _nv and _ov != _nv)
    if not foreign and old_stage >= 4:
        _ovv = re.sub(r"[^A-Z0-9]", "",
                      str(old_r.get("vessel") or "").upper())
        _nvv = re.sub(r"[^A-Z0-9]", "",
                      str(new_r.get("vessel") or "").upper())
        if _ovv and _nvv and _ovv != _nvv and new_stage < 5:
            foreign = True
    if foreign:
        merged = dict(old_r)
        _canon_voyage(merged)
        return merged
    # v99: the decision on an evidence-based correction is made ONCE — guard
    # (iii), the tombstone of the fields rejected by the veto, and
    # the final stage guard all look at this one decision
    # (previously, a separate calculation was done everywhere).
    _corr = _own_cycle_correction(old_r, new_r)
    _rejected = set(new_r.get("_rejected_fields") or [])
    # v99 closed-cycle gate: the container is now in the export cycle
    # (cycle_closed) — this proof will apply only to the record
    # that has a QICT import anchor present (QICT VIR or
    # discharge). Without an anchor (for example, a new BL whose
    # container has not yet returned from the previous voyage),
    # the closed-cycle status/returned cannot be this
    # record's.
    _cc_ok = not new_r.get("cycle_closed") \
        or _real(old_r.get("discharge_time")) \
        or ENG.vir_terminal(old_r.get("vir")) == "QICT"
    # v99fix (d): if the fresh synthesis has called the discharge
    # 'unconfirmed' (the terminal holds the record
    # but does not show a discharge — the carrier's stamp
    # was the berthing time, COAU6468022200) and the VIR is the same
    # old one, then this is an evidence-based correction:
    # the old carrier stamp will not survive the merge and
    # guard (iii) will not restore the status on it either.
    _unconf = bool(new_r.get("discharge_unconfirmed")) \
        and bool(_nv) and _ov == _nv
    merged = {}
    for k in set(old_r) | set(new_r):
        if k in ("_rejected_fields", "position_via",
                 "cycle_closed", "discharge_unconfirmed"):
            continue  # the process's internal markers —
            # are not preserved in the stored record
        nv, ov = new_r.get(k), old_r.get(k)
        if not _cc_ok and k in ("status", "returned",
                                "returned_date", "returned_basis"):
            nv = None  # closed-cycle proof without an anchor
            # does not apply to this record (v99fix4:
            # the basis marker too; the export-cycle evidence
            # fields — qict_export_in/load — are allowed in
            # so that the retraction of a wrong date
            # can also happen on an anchor-less record,
            # but the derivation of a NEW return from them remains
            # bound by the _cc_ok flag given to settle
            # )
        if k == "containers":
            seen, out_c = set(), []
            for c in list(nv or []) + list(ov or []):
                if _real(c) and c not in seen:
                    seen.add(c)
                    out_c.append(c)
            if out_c:
                merged[k] = out_c
            continue
        if k == "holds" and not _real(nv) and _real(ov):
            # WIP (2 Nov, Nigran live-run difference): if the terminal's
            # COMPLETE record (same VIR, discharge present) brings the holds
            # empty, then the hold has actually ended —
            # keeping the old hold alive is wrong information
            # (COAU6468022890: HP clear at SAPT, the Application
            # kept showing the old one). On an incomplete/carrier check,
            # the old rule will remain — there, empty means
            # "no information", not "no hold".
            _hsrc = str(new_r.get("source") or "")
            if (_ov and _ov == _nv
                    and _real(new_r.get("discharge_time"))
                    and any(t in _hsrc for t in
                            ("Terminal", "QICT", "KGTL"))):
                continue
        if k in _TERMINAL_OWNED and _real(nv) and _real(ov) \
                and nv != ov \
                and not _is_terminal_src(new_r.get("source")):
            merged[k] = ov  # malik source hi badal sakta hai
            continue
        if _real(nv):
            merged[k] = nv
        elif _real(ov):
            if k in _rejected and _corr:
                # v99 (investigation fix 3): the veto had REJECTED this
                # field and the correction stands
                # — reviving the old value made the card
                # self-contradictory ('Discharged'
                # alongside 'Gate pass: delivered').
                # If the correction is rejected, the normal rule (keep the old
                # one) will apply and guard (iii) will also restore the remaining
                # stage fields.
                continue
            merged[k] = ov
    # (iii) Stage downgrade protection: if the new status is behind the old stage,
    # the stage fields remain the old ones —
    # a weak/partial new synthesis can never move a complete record
    # backwards.
    if ENG.status_text_stage(new_r.get("status")) \
            < ENG.status_text_stage(old_r.get("status")) \
            and not _corr and not _unconf:
        for _f in ("status", "position", "gate_out"):
            if _real(old_r.get(_f)):
                merged[_f] = old_r[_f]
        if old_stage >= 4 and _real(old_r.get("discharge_time")):
            merged["discharge_time"] = old_r["discharge_time"]
    # v99 TERMINAL FLIP GUARD (user's order, 30 Oct 2026):
    # a state confirmed by the terminal (terminal derived from the VIR
    # + the terminal's own record: discharge/gate_out, or
    # an 'at terminal' stage) never changes from a weak 'Expected at …'
    # estimate (vessel/AIS layer) —
    # expected data can only touch the ETA fields
    # (those fields have already been updated in the field loop).
    # (CCLU3833738 / XINU1190143: from 'At QICT terminal' it had
    # flipped to 'Expected at SAPT' — 30 Oct 06:38.)
    _new_stl = (new_r.get("status") or "").strip().lower()
    if not _corr and _new_stl.startswith("expected") \
            and ENG.vir_terminal(old_r.get("vir")) \
            and (_real(old_r.get("discharge_time"))
                 or _real(old_r.get("gate_out"))
                 or ENG.status_text_stage(old_r.get("status")) >= 2):
        for _f in ("status", "position", "terminal"):
            if _real(old_r.get(_f)):
                merged[_f] = old_r[_f]
    # v99 FINAL STAGE GUARD — the final protection at this choke point
    # (manual track, auto re-check — every route
    # passes through _record -> _merge_result): the merged
    # record's real stage (status_stage — text + hard
    # fields) cannot be less than the old COMPLETE record (stage >= 4),
    # except for the evidence-based correction via _own_cycle_correction
    # — and _unconf, where
    # the fresh synthesis, on terminal evidence, has deliberately
    # rejected the carrier stamp (v99fix).
    # Guard (iii) looks at the text's stage;
    # this one also looks at the fields' stage — no
    # synthesis, by dropping its own evidence, can move a complete record
    # backwards, and no inference can ever
    # win over terminal evidence.
    if not _corr and not _unconf and old_stage >= 4 \
            and ENG.status_stage(merged) < old_stage:
        for _f in ("status", "position", "gate_out", "truck",
                   "returned"):
            if _real(old_r.get(_f)):
                merged[_f] = old_r[_f]
    # v104: GATE-OUT RETRACTION — fresh terminal evidence
    # (rows of the same VIR: container still inside, gate-out empty,
    # no EM return) cancels the old gate_out.
    # Stage guards would have saved it in the field loop
    # — the evidence is above them, exactly like the returned
    # retraction. Without this, once stuck, a
    # false gate-out would stay alive forever and a fresh
    # In Yard check could not cut it (ONEYALYG09255800).
    if _real(old_r.get("gate_out")) \
            and not _real(new_r.get("gate_out")) \
            and _gateout_retract_evidence(old_r, new_r):
        merged.pop("gate_out", None)
        if _real(new_r.get("status")):
            merged["status"] = new_r["status"]
        if _real(new_r.get("position")):
            merged["position"] = new_r["position"]
    # v99fix (d): an 'unconfirmed' discharge's old
    # carrier stamp will not survive the merge (see oper
    # _unconf) — otherwise the record would forever
    # remain stuck on a false discharge. Without fresh evidence,
    # the old position is also not kept
    # (that too was from the same ghost cycle).
    if _unconf and not _real(new_r.get("discharge_time")):
        merged.pop("discharge_time", None)
        if not _real(new_r.get("position")):
            merged.pop("position", None)
    # v99fix (a): empty-return derivation at record-finalize —
    # in the merged record's own terminal_rows, if an EM row
    # (or the import cycle's gate_in) is present,
    # returned is created RIGHT HERE, even if this run's
    # fresh rows remained incomplete (MEDUT1385110: EM row
    # was stored, the derivation did not run on any path;
    # OOLU2337916330: the return time was only in gate_in
    # ). v99fix2: derivation + retraction BOTH
    # happen through a single choke point (_settle_empty_return)
    # — no other path writes/clears returned
    # . Retraction (a previously recorded wrong returned that
    # turned out to be an XF export gate-in, MBAQITS8502261016) is
    # recognised here: old returned was True, after settle
    # it is False — only in this case will the entry flag also
    # be cleared (below, in _record).
    _was_ret = bool(merged.get("returned"))
    _was_date = merged.get("returned_date")
    _settled = False
    try:
        _settled = bool(ENG._settle_empty_return(merged, _cc_ok))
    except Exception:
        _settled = False
    _retracted = _was_ret and not merged.get("returned")
    # v99fix4: if a wrong returned_date has been retracted —
    # even if a dateless (export_reload) return was derived
    # in its place — then the old status text that claimed
    # that same false date also falls under the same
    # retraction order (repair below).
    _date_retracted = bool(_was_date) \
        and not merged.get("returned_date")
    _derived_ret = _settled and not _retracted
    # v99fix3: if the retracted return's claim is also in the status
    # text (268607384: 'Delivered —
    # container returned empty to depot 31 Aug 2026'
    # while returned_date was 29-Sep) then that text is
    # the remaining trace of the same false claim — the stage guard
    # had saved it because the old stage was higher,
    # but the retraction has proven the very basis of that stage
    # to be wrong. Therefore the status should come from the fresh
    # result's status (on cycle_closed,
    # 'Gate out'), otherwise 'Gate out' — an unverified claim like 31-Aug
    # must NOT remain in the record. This
    # is NOT a manual edit, it is a mapping: the retraction itself is
    # proof that the old status was false.
    if _retracted or _date_retracted:
        _mst = str(merged.get("status") or "").lower()
        if "returned empty" in _mst or "empty returned" in _mst:
            _fst = new_r.get("status") \
                if isinstance(new_r, dict) else None
            merged["status"] = _fst if _real(_fst) else "Gate out"
    # v99ship (Audit condition 5): gate_in cycle-anchor — mirror the
    # position ghost filter. A gate_in that predates the record's own
    # VIR cycle by 45+ days is a previous voyage's stamp
    # (COAU6468022200: gate_in 08-JUN-26 vs VIR PKKHISAPT_221026134915)
    # and must not survive as this voyage's gate-in. Runs after the
    # settle step so real return derivations (gate_in after gate-out,
    # same cycle) are untouched. Only applies when both the VIR date
    # and the gate_in parse; unparseable values are left alone — a
    # stamp that cannot be proven ghost is kept.
    _gi = merged.get("gate_in")
    if _real(_gi):
        _vd = _vir_cycle_date(merged.get("vir"))
        _gt = ENG._term_ts_full(_gi)
        if _vd is not None and _gt is not None:
            try:
                if (_vd - _gt[0].date()).days > 45:
                    merged.pop("gate_in", None)
            except Exception:
                pass
    # v99fix4 (Fix Round 4): a gate_in that is after the record's OWN
    # gate_out cannot possibly belong to this cycle
    # — it is the gate-in of the container's next (export) voyage
    # (MBAQITS8502261016: gate_in 28-OCT-26
    # 08.23.38 AM, gate_out 02-OCT-2026 21:31). Settle
    # has already run before this anchor — all of its
    # comparisons (XF row, qict_export_in, gate_in fallback)
    # are not affected by this drop, and terminal_rows
    # remain exactly as they are, as raw evidence.
    _gi2 = merged.get("gate_in")
    _go2 = merged.get("gate_out")
    if _real(_gi2) and _real(_go2):
        _gt2 = ENG._term_ts_full(_gi2)
        _go2t = ENG._term_ts_full(_go2)
        if _gt2 is not None and _go2t is not None \
                and _gt2[0] > _go2t[0]:
            merged.pop("gate_in", None)
    # v99: if terminal evidence shows the container has RETURNED,
    # old holds (that survived through the field loop)
    # end — a returned empty container cannot be on hold
    # (EMKAYMBAKHI57984: the cycle had already closed,
    # yet 'LOAD LIST HOLD' still remained stuck).
    # v99fix: this rule applies to every complete cycle — the return
    # may be proven by a closed cycle or derived from an EM row/gate_in
    # (_derived_ret), and even if the fresh result
    # has its own (stale) holds list: a complete
    # cycle's holds are stale (MEDUT1385110). But
    # if the fresh status ITSELF is a hold state, the holds are real
    # information — they are not touched there.
    if (new_r.get("returned") or _derived_ret
            or new_r.get("cycle_closed")) and _cc_ok \
            and "hold" not in _new_stl:
        merged.pop("holds", None)
    # A stored ETA later than the discharge date is a vessel-schedule
    # artifact, not the shipment's ETA — drop it for completed cargo.
    # The combined label "KICT/SAPT" is never a valid terminal name:
    # drop it, and repair any stored status that contains it.
    if merged.get("terminal") == "KICT/SAPT":
        merged.pop("terminal", None)
    _st = merged.get("status") or ""
    if "KICT/SAPT" in _st:
        if merged.get("terminal"):
            merged["status"] = _st.replace("KICT/SAPT",
                                             merged["terminal"])
        else:
            merged["status"] = "Arrived at Karachi terminal"
    # v96 data-audit round 2 — firm protection on merge:
    # (A) Terminal identity is from the VIR: merged VIR names whichever terminal,
    #     that terminal will remain — on any layer's guess
    #     a QICT record cannot become SAPT (Pattern B:
    #     EMKAYMBAKHI59009/58063/58118/58181/58182 — stored and
    #     fresh VIR was exactly the same QICT one, yet the terminal still
    #     flipped). A wrong 'at X' inside the status text also
    #     is corrected from the VIR name.
    _vt = ENG.vir_terminal(merged.get("vir"))
    if _vt:
        if merged.get("terminal") in ("KICT", "SAPT", "QICT",
                                      "KGTL") \
                and merged["terminal"] != _vt:
            merged["terminal"] = _vt
        elif not _real(merged.get("terminal")):
            merged["terminal"] = _vt
        _stm = merged.get("status") or ""
        _bad = re.search(r"\bat (KICT|SAPT|QICT|KGTL)\b", _stm)
        if _bad and _bad.group(1) != _vt:
            merged["status"] = _stm[:_bad.start(1)] + _vt \
                + _stm[_bad.end(1):]
    # (B1) A verified departed date is never erased: it
    #     exists only inside the status text (COSCO: 'departed
    #     Shekou 09 Oct 2026'); if new text suppresses it, the date
    #     is extracted from the old text into its own 'departed' field and
    #     remains preserved (COAU6468022200/6468022890/6468005230).
    if not _real(merged.get("departed")):
        for _src in (old_r, new_r):
            _dd = ENG.departed_date(_src.get("status"))
            if _dd:
                merged["departed"] = _dd
                break
    # (B2) Provenance label protection: a manually verified
    #     source (the 'verified by Shezi' one) is never
    #     replaced by an ordinary fresh label (FRLSUBKHI276826: re-track had
    #     erased Shezi's verification mark).
    _osrc = str(old_r.get("source") or "")
    if "verified by" in _osrc.lower() \
            and merged.get("source") != _osrc:
        merged["source"] = _osrc
    # (B3) 'Partially discharged' cannot survive proof of complete gate-out:
    #     on a weak fresh check, guard (iii)
    #     would bring back the old text, so the label had stuck for
    #     ever (COAU6469602070/COAU6464740334 —
    #     both had a complete gate_out field). The engine's
    #     _reconcile_status rule now applies on merge as well.
    _stm = (merged.get("status") or "").lower()
    if "partially" in _stm and "discharg" in _stm \
            and "hold" not in _stm \
            and ENG.status_stage(merged) >= 4:
        merged["status"] = "Released — Delivered" \
            if ENG.status_stage(merged) >= 5 else "Gate out"
    dis = _pdate(merged.get("discharge_time"))
    eta = _pdate(merged.get("eta"))
    st = (merged.get("status") or "").lower()
    if dis and eta and eta > dis and any(
            w in st for w in ("discharg", "released", "delivered",
                              "gate out", "hold")):
        merged.pop("eta", None)
    # v96 proof-run SF-1: if a fresh source gives only a number ("151"),
    # the old lettered canonical voyage ("W151") must not be suppressed —
    # canonicalization does fix digit-first forms (631W ->
    # W631) but cannot bring back a dropped letter from a number, and
    # the general merge rule (the new real value wins) would
    # silently suppress it (142G513024: W151 -> 151,
    # 142G512913: W085 -> 085). If the digits are the same, the old
    # canonical form itself is the real voyage; if the digits have changed,
    # then the new number will apply.
    _ovv = str(old_r.get("voyage") or "").strip()
    _mvv = str(merged.get("voyage") or "").strip()
    if _ovv and _mvv and re.fullmatch(r"\d+", _mvv):
        _om = re.fullmatch(r"(\d{1,4})([A-Za-z])", _ovv)
        _ocan = (_om.group(2).upper() + _om.group(1)) if _om \
            else _ovv
        _lm = re.fullmatch(r"([A-Za-z])(\d{1,4})", _ocan)
        if _lm and _lm.group(2) == _mvv:
            merged["voyage"] = _ocan
    # v104: POSITION-STAGE consistency — on a complete record
    # (gate_out recorded or return proven), a discharge-stage
    # position ('In Yard' etc.) cannot remain stuck:
    # position is derived from the stage, not from an old snapshot
    # (MBAQITS8502261015 / OOLU2337916330: gate_out +
    # 'In Yard' remained stuck alongside returned). The read
    # path also passes through here (_migrate_entry ->
    # _merge_result(r, {})), so the stored record itself
    # becomes correct.
    _pos104 = str(merged.get("position") or "").strip().lower()
    if (merged.get("gate_out") or merged.get("returned")) \
            and _pos104 in ("in yard", "examin area",
                            "examination area"):
        merged["position"] = "OUT" \
            if ENG.vir_terminal(merged.get("vir")) == "QICT" \
            else "Gate Out"
    _canon_voyage(merged)
    return merged


_OLD_LAYER_NAMES = {
    "Layer 0 — Carrier pehchano": "Layer 0 — Carrier identification",
    "Layer 3 — Karachi Terminals (KICT/SAPT)": "Layer 3 — Karachi Terminal",
}
_OLD_TOKENS = ("nahi", "karo", "mila", "rabta", "khulti", "maroof",
               "Neeche", "pehchano", "Namaloom", "ghalat", "sakta")


_merge_linked_containers_v111()
_merge_duplicate_bls_v112()
_fix_emkay_typo_v114()


def _fix_old_detail(d):
    """Translate or clear Roman-Urdu layer details stored by old
    versions, so they never surface in the current app."""
    if "allow nahi karta" in d:
        return ("Automated tracking is not allowed by this carrier "
                "(bot protection).")
    m = re.search(r"KICT/SAPT par (\d+) container", d)
    if m:
        return f"{m.group(1)} container(s) at Karachi terminal"
    if "rabta nahi ho saka" in d:
        return "The source could not be reached on that check."
    if any(t in d for t in _OLD_TOKENS):
        return ""
    return d


_T24_RE = re.compile(r"^(\d{2}/\d{2}) (\d{2}):(\d{2})$")


def _t12(s):
    """Convert a stored 'DD/MM HH:MM' (24-hour) stamp to 12-hour AM/PM
    (Yousuf's firm rule, 6 Nov 2026: in the Application
    time is always 12 hours AM/PM). Whatever is already 12h or not
    in this shape, leave it as it is."""
    m = _T24_RE.match(str(s or ""))
    if not m:
        return s
    hh = int(m.group(2))
    return "%s %02d:%s %s" % (m.group(1), hh % 12 or 12,
                              m.group(3), "AM" if hh < 12 else "PM")


_T24_ANY_RE = re.compile(
    r"\b(0\d|1[3-9]|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b"
    r"(?!\s*(?:AM|PM)\b)(?!:[0-5]\d)", re.I)


def _t12_any(s):
    """Convert any 24-hour time inside any text (13:36, 00:15,
    09:15) to 12-hour AM/PM — times coming from terminal/carrier
    (discharge, gate-out, ETA etc.) stayed in their original
    form as 24h, and the rule is 12h EVERYWHERE
    (correction of 6 Nov 2026: on '05-NOV-2026 14:36'). Times that
    already have AM/PM, or are in the ambiguous 10/11/12
    form, are not touched."""
    if not isinstance(s, str) or ":" not in s:
        return s

    def _rep(m):
        hh = int(m.group(1))
        out = "%02d:%s" % (hh % 12 or 12, m.group(2))
        if m.group(3):
            out += ":" + m.group(3)
        return out + (" AM" if hh < 12 else " PM")

    return _T24_ANY_RE.sub(_rep, s)



# --- Date/time DISPLAY standard (Yousuf, 8 Nov 2026): hamesha
# DD-MMM-YYYY aur waqt hamesha 12-hour AM/PM — poori Application
# mein, har record aur har information mein. ---
_MON3N = {m: i + 1 for i, m in enumerate(
    ("JAN", "FEB", "MAR", "APR", "MAY", "JUN",
     "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"))}


def _D(d):
    """date/datetime -> 'DD-MMM-YYYY' (caps month)."""
    return d.strftime("%d-%b-%Y").upper() if d else ""


def _DT(dt):
    """datetime -> 'DD-MMM-YYYY, hh:MM AM/PM'."""
    return dt.strftime("%d-%b-%Y, %I:%M %p").upper() if dt else ""


def _pdate2(s, yh=None):
    """Find a date inside s -> (date, span) or (None, None)."""
    if not isinstance(s, str):
        return None, None
    m = re.search(r"\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b", s)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)),
                        int(m.group(3))), m.span()
        except Exception:
            pass
    m = re.search(r"\b(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{2,4})\b", s)
    if m:
        mi = _MON3N.get(m.group(2)[:3].upper())
        if mi:
            y = int(m.group(3))
            if y < 100:
                y += 2000
            try:
                return date(y, mi, int(m.group(1))), m.span()
            except Exception:
                pass
    m = re.search(r"\b([A-Za-z]{3,9})\.??\s+(\d{1,2}),?\s+(\d{4})\b", s)
    if m:
        mi = _MON3N.get(m.group(1)[:3].upper())
        if mi:
            try:
                return date(int(m.group(3)), mi,
                            int(m.group(2))), m.span()
            except Exception:
                pass
    m = re.search(r"\b(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})\b", s)
    if m:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        try:
            return date(y, int(m.group(2)), int(m.group(1))), m.span()
        except Exception:
            pass
    if yh:
        m = re.search(r"\b([A-Za-z]{3,9})\s+(\d{1,2})\b", s)
        if m:
            mi = _MON3N.get(m.group(1)[:3].upper())
            if mi:
                try:
                    return date(int(yh), mi, int(m.group(2))), m.span()
                except Exception:
                    pass
        m = re.search(r"\b(\d{1,2})\s+([A-Za-z]{3,9})\b", s)
        if m:
            mi = _MON3N.get(m.group(2)[:3].upper())
            if mi:
                try:
                    return date(int(yh), mi, int(m.group(1))), m.span()
                except Exception:
                    pass
        m = re.search(r"\b(\d{1,2})[-/](\d{1,2})\b", s)
        if m:
            try:
                return date(int(yh), int(m.group(2)),
                            int(m.group(1))), m.span()
            except Exception:
                pass
    return None, None


def _dtfmt_s(s, yh=None):
    """A date[/time] string -> 'DD-MMM-YYYY[, hh:MM AM/PM]'.
    Unparseable text is returned unchanged."""
    if not isinstance(s, str) or not s.strip():
        return s
    d, _span = _pdate2(s, yh)
    if not d:
        return s
    out = _D(d)
    tm = re.search(r"\b(\d{1,2})[:.](\d{2})(?:[:.]\d{2})?\s*([AaPp][Mm])?\b", s)
    if tm:
        hh, mm = int(tm.group(1)), tm.group(2)
        ap = (tm.group(3) or "").upper()
        if not ap:
            ap = "PM" if hh >= 12 else "AM"
            hh = hh % 12 or 12
        else:
            hh = hh % 12 or 12
        out += ", %02d:%s %s" % (hh, mm, ap)
    return out


def _dfmt_embed(s, yh=None):
    """Convert date patterns INSIDE a longer string to DD-MMM-YYYY.
    Only patterns that carry a year are touched."""
    if not isinstance(s, str) or not s:
        return s
    st = s.strip()
    d, span = _pdate2(st, yh)
    if d and span and span[0] == 0 and span[1] >= len(st) - 14:
        return _dtfmt_s(st, yh)

    def _sub(m):
        dd, _sp = _pdate2(m.group(0))
        return _D(dd) if dd else m.group(0)
    s = re.sub(r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b", _sub, s)
    s = re.sub(r"\b\d{1,2}[- ][A-Za-z]{3,9}[- ]\d{2,4}\b", _sub, s)
    s = re.sub(r"\b[A-Za-z]{3,9}\.??\s+\d{1,2},?\s+\d{4}\b", _sub, s)
    s = re.sub(r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b", _sub, s)
    return s


_WALK_DFMT_KEYS = ("result", "milestones", "changes", "layers",
                   "journey", "notebook", "carrier_check", "scanbook",
                   "vessel_live")


def _walk_dfmt(h, yh=None):
    def cv(v):
        if isinstance(v, str):
            return _dfmt_embed(v, yh)
        if isinstance(v, list):
            return [cv(x) for x in v]
        if isinstance(v, dict):
            return {k: cv(x) for k, x in v.items()}
        return v
    if isinstance(h, dict):
        for k in _WALK_DFMT_KEYS:
            if k in h:
                h[k] = cv(h[k])

_WALK_T12_KEYS = ("result", "milestones", "changes", "layers",
                  "journey", "notebook")


def _walk_t12(h):
    """In all display parts of an entry (result, milestones,
    changes, layers, journey, notebook), convert every
    24h time to 12h AM/PM. Do NOT touch the BL copy or
    the user's notes — they are original documents/words."""
    def cv(v):
        if isinstance(v, str):
            return _t12_any(v)
        if isinstance(v, list):
            return [cv(x) for x in v]
        if isinstance(v, dict):
            return {k: cv(x) for k, x in v.items()}
        return v

    if isinstance(h, dict):
        for k in _WALK_T12_KEYS:
            if k in h:
                h[k] = cv(h[k])


def _migrate_entry(h):
    """Bring a stored history entry up to current standards: clean
    result (no combined terminal label, no placeholders), English
    carrier name, English layer names and details."""
    if not isinstance(h, dict):
        return h
    # Old 24-hour time stamps should appear as 12h AM/PM on display.
    for _k in ("time", "attempt_time"):
        if h.get(_k):
            h[_k] = _t12(h[_k])
    for _c in (h.get("changes") or []):
        if isinstance(_c, dict) and _c.get("time"):
            _c["time"] = _t12(_c["time"])
    # All times coming from the source (terminal/carrier) are also 12h.
    _walk_t12(h)
    # Dates bhi ek hi standard par: DD-MMM-YYYY (8 Nov 2026 ka usool).
    _yh = None
    for _tk in ("checked_ts", "attempt_ts", "first_seen"):
        _tv = h.get(_tk)
        if isinstance(_tv, (int, float)) and _tv > 0:
            try:
                _yh = datetime.fromtimestamp(_tv).year
                break
            except Exception:
                pass
    for _k in ("time", "attempt_time"):
        if h.get(_k):
            h[_k] = _dtfmt_s(h[_k], _yh)
    if isinstance(h.get("first_seen"), str) and h["first_seen"]:
        h["first_seen"] = _dtfmt_s(h["first_seen"],
                                    _yh or datetime.now().year)
    _walk_dfmt(h, _yh)
    # v103: previous-voyage cleanup — the stored ghost record
    # should be separated at read time itself (result shell + stale_alert),
    # so that every consumer gets a clean record.
    if _bl_confirmed(h.get("layers")):
        h["bl_confirmed_ever"] = True
    _sa = _stored_stale_check(h)
    if _sa:
        h["stale_alert"] = _sa
        h["result"] = {}
        h["found"] = False
        return h
    # v123: Data Source heal — the label always follows the record's
    # own terminal when terminal-grade evidence (VIR or discharge)
    # exists. Engine layers used to overwrite 'source' in run order,
    # so stored records could claim 'Karachi Terminal (Hutchison
    # Ports)' while their terminal was QICT (18 live records, incl.
    # EMKAYMBAKHI57873). In-transit records whose terminal is only
    # the carrier's stated destination (no VIR / discharge) keep
    # their honest carrier source; a manually verified label is
    # never touched. Runs at read time, so every stored record is
    # corrected by the Application itself — no hand edits.
    _r = h.get("result")
    if isinstance(_r, dict):
        _canon = {"QICT": "QICT (DP World)",
                  "KICT": "Karachi Terminal (Hutchison Ports)",
                  "SAPT": "Karachi Terminal (Hutchison Ports)",
                  "KGTL": "KGTL (Karachi Gateway Terminal)"}
        _t = _r.get("terminal")
        _s = str(_r.get("source") or "")
        if _t in _canon and (_r.get("vir") or _r.get("discharge_time")) \
                and _s != _canon[_t] and "verified by" not in _s.lower():
            _r["source"] = _canon[_t]
    # v115: rescue containers/fields trapped inside a legacy
    # scan-JSON "copy" — they never reached the record itself
    # (59285's CAAU2997122 existed only inside that JSON).
    _bcj = h.get("bl_copy")
    if isinstance(_bcj, dict):
        _bt = str(_bcj.get("text") or "").strip()
        if _bt.startswith("{"):
            try:
                _bj = json.loads(_bt)
            except Exception:
                _bj = None
            if isinstance(_bj, dict) and ("bl_no" in _bj
                                          or "containers" in _bj):
                _r0 = h.get("result")
                if not isinstance(_r0, dict):
                    _r0 = {}
                    h["result"] = _r0
                _have = list(_r0.get("containers") or [])
                for _c in (_bj.get("containers") or []):
                    if _c and _c not in _have:
                        _have.append(_c)
                if _have:
                    _r0["containers"] = _have
                _bf = _bj.get("fields") or {}
                for _k in ("vessel", "voyage", "pol", "pod"):
                    if _bf.get(_k) and not _r0.get(_k):
                        _r0[_k] = _bf[_k]
    try:
        if _bl_copy_needed(h.get("carrier"), h.get("found"),
                           h.get("result"), h.get("bl_copy")):
            h["bl_copy_needed"] = {"reason": "vessel"}
        else:
            h.pop("bl_copy_needed", None)
    except Exception:
        pass
    r = h.get("result")
    if isinstance(r, dict) and r:
        # v99fix2: if the merge retracted a wrong returned
        # then the entry marker should also be cleared with it, otherwise
        # the contradiction of result False and entry True remains.
        _was_ret = bool(r.get("returned"))
        h["result"] = _merge_result(r, {})
        if _was_ret and not (h["result"] or {}).get("returned"):
            h["returned"] = False
        elif not _was_ret and (h["result"] or {}).get("returned"):
            # v99fix4: if derivation at read time created returned
            # (for example export_reload) then the entry
            # marker should also be raised with it — otherwise the result
            # True / entry False contradiction remains (the other
            # side of the retraction symmetry above;
            # _record also performs this same lift).
            h["returned"] = True
    if h.get("carrier"):
        h["carrier"] = h["carrier"].replace(" (unverified)", "")
    for lay in h.get("layers") or []:
        if lay.get("name") in _OLD_LAYER_NAMES:
            lay["name"] = _OLD_LAYER_NAMES[lay["name"]]
        if lay.get("detail"):
            lay["detail"] = _fix_old_detail(lay["detail"])
    return h



def _fmt_disch(s):
    """'06-OCT-2026 22:34' / '06-OCT-26 08:48' -> '6 Oct 2026'."""
    m = re.match(r"\s*(\d{1,2})-([A-Za-z]{3})-(\d{2,4})", s or "")
    if not m:
        return s or ""
    y = m.group(3)
    if len(y) == 2:
        y = "20" + y
    return f"{int(m.group(1))} {m.group(2).title()} {y}"


def _eta_cell(r):
    """Report cell: the ETA while a shipment is on the way; once it
    has arrived, the date that matters is the discharge date (QICT
    and the Karachi terminals publish no ETA at all)."""
    if r.get("eta"):
        return _esc(r["eta"])
    if r.get("discharge_time"):
        return "Discharged " + _esc(_fmt_disch(r["discharge_time"]))
    return "—"

def _live_data_layers(layers):
    """The layers whose 'done' status proves real LIVE data.
    Only carrier identification (Layer 0 — offline prefix match)
    and manual-check guidance layers give no data; their 'done'
    status does not make a record 'live verified' (data audit FIX 2:
    on 142G513024/142G512913 not a single data layer had succeeded,
    yet the old record was still presented as 'found')."""
    out = []
    for l in layers or []:
        if (l or {}).get("status") != "done":
            continue
        if re.search(r"identification|manual check",
                     (l or {}).get("name") or "", re.I):
            continue
        out.append(l)
    return out


_NO_PORTAL_CARRIERS = ("Emkay Line", "RTW Shipping Lines")


def _real_bl_copy(bl_copy):
    """v115: the scan flow used to store its own result JSON
    ({"bl_no": ..., "containers": [...], "raw": ""}) AS the
    BL copy. That is not a BL copy: it carries no vessel name
    and, when raw is empty, no text at all. Treating it as a
    saved copy locked the record forever (EMKAYMBAKHI59285:
    no copy box, no vessel layer, always Not Found). A real
    copy is plain text, or a scan JSON whose raw holds the
    actual BL text."""
    if not bl_copy or not isinstance(bl_copy, dict):
        return None
    _t = str(bl_copy.get("text") or "").strip()
    if not _t:
        return None
    if _t.startswith("{"):
        try:
            _j = json.loads(_t)
        except Exception:
            _j = None
        if isinstance(_j, dict) and ("bl_no" in _j
                                     or "containers" in _j):
            return bl_copy if str(_j.get("raw") or "").strip() \
                else None
    return bl_copy


def _bl_copy_needed(carrier, found, result, bl_copy):
    """Lines like Emkay/RTW, which have no online tracking
    of their own: if the record is found nowhere, the vessel
    is also unknown and no BL copy is already saved — then
    the way forward is blocked without the copy (the vessel
    layer runs on the vessel name, and the name is only on the BL copy)."""
    if found or _real_bl_copy(bl_copy):
        return False
    if (carrier or "") not in _NO_PORTAL_CARRIERS:
        return False
    if ((result or {}).get("vessel") or "").strip():
        return False
    return True


# ---------- v118: Mombasa -> QICT journey + Note Book (Emkay/RTW) ----
# Yousuf's Safar Note Book system (5 Nov 2026): for every Emkay/RTW
# shipment whose vessel is known, the Application builds the whole
# journey chain (origin departure -> route -> transshipment port ->
# feeder -> QICT) with an honesty grade on every stage (Confirmed =
# backed by a document/terminal record, Estimate = schedule-based).
# The first build also writes the Note Book prediction; later
# refreshes fill the actuals and, at journey end, the score. Nothing
# estimated is ever presented as confirmed.
_JOURNEY_PREFIXES = ("EMKAYMBAKHI", "MBAQITS850")
_FEEDER_POOL = ("BSG BIMINI", "BSG BARBADOS", "SLS TOPAZ",
                "GSL MELINA", "GSL ROSSI")
_TS_PORTS = ("Salalah", "Fujairah", "Jebel Ali")
_INDIA_PORTS = ("Nhava Sheva", "Mundra", "Pipavav")
_FEEDER_CACHE = {"ts": 0.0, "data": {}}
_FEEDER_CACHE_FILE = DATA_DIR / "feeder_rotations.json"


def _j_d(s):
    """'YYYY-MM-DD' or a date -> date | None."""
    if not s:
        return None
    if isinstance(s, datetime):
        return s.date()
    try:
        from datetime import date as _d
        if isinstance(s, _d):
            return s
    except Exception:
        pass
    try:
        return datetime.strptime(str(s)[:10], "%Y-%m-%d").date()
    except Exception:
        return None


def _j_fmt(d):
    return _D(d) if d else ""


def _j_calls_norm(calls):
    out = []
    for c in calls or []:
        out.append({"port": c.get("port") or "",
                    "kind": c.get("kind") or "",
                    "d1": str(c.get("d1") or "")[:10],
                    "voyage": c.get("voyage") or ""})
    out.sort(key=lambda x: x["d1"])
    return out


def _feeder_rotations():
    """Feeder pool rotations — 6-hour cache (memory + file)."""
    now = time.time()
    if _FEEDER_CACHE["data"] and now - _FEEDER_CACHE["ts"] < 6 * 3600:
        return _FEEDER_CACHE["data"]
    try:
        saved = json.loads(_FEEDER_CACHE_FILE.read_text())
        if saved.get("data") and now - float(saved.get("ts") or 0) \
                < 6 * 3600:
            _FEEDER_CACHE.update(ts=float(saved["ts"]),
                                  data=saved["data"])
            return _FEEDER_CACHE["data"]
    except Exception:
        pass
    data = {}
    for name in _FEEDER_POOL:
        try:
            info = ENG.track_vessel_schedule(name)
            if info.get("found"):
                data[name] = _j_calls_norm(info.get("calls"))
        except Exception:
            pass
    if data:
        _FEEDER_CACHE.update(ts=now, data=data)
        try:
            _FEEDER_CACHE_FILE.write_text(json.dumps(
                {"ts": now, "data": data}))
        except Exception:
            pass
    return data


def _classify_journey(calls, pol):
    """Route from one vessel's rotation. Returns dict:
    {direct: date|None, ts_port, ts_date, mids: [(port, date)]}"""
    calls = _j_calls_norm(calls)
    pol_u = (pol or "").strip().lower()
    start = -1
    for i, c in enumerate(calls):
        if pol_u and c["port"].lower() == pol_u \
                and c["kind"] == "recent":
            start = i
    if start < 0:
        for i, c in enumerate(calls):
            if pol_u and c["port"].lower() == pol_u:
                start = i
    after = calls[start + 1:] if start >= 0 else calls
    direct = None
    direct_kind = ""
    ts_port = ts_date = None
    ts_kind = ""
    mids = []
    for c in after:
        p = c["port"]
        if "qasim" in p.lower():
            direct = _j_d(c["d1"])
            direct_kind = c["kind"]
            break
        if p in _TS_PORTS and ts_port is None:
            ts_port, ts_date = p, _j_d(c["d1"])
            ts_kind = c["kind"]
            break
        mids.append((p, _j_d(c["d1"]), c["kind"]))
    if direct is None and ts_port is not None:
        # Calls after TS are not mids; keep only the earlier ones
        pass
    return {"direct": direct, "direct_kind": direct_kind,
            "ts_port": ts_port, "ts_date": ts_date,
            "ts_kind": ts_kind, "mids": mids}


def _pick_feeder(ts_port, ts_date, pool):
    """The earliest-departing Qasim-bound feeder from the TS port.
    Returns (name, qasim_date, detail) — detail carries the feeder's own
    TS-port date + evidence kinds + intermediate calls, so the journey
    can show WHEN the feeder left and grade every stage by evidence."""
    best = None
    for name, calls in (pool or {}).items():
        calls = _j_calls_norm(calls)
        for i, c in enumerate(calls):
            if c["port"] != ts_port:
                continue
            d = _j_d(c["d1"])
            if d is None:
                continue
            if ts_date and (ts_date - d).days > 1:
                continue
            qd = None
            qd_kind = ""
            fmids = []
            for c2 in calls[i + 1:]:
                if "qasim" in c2["port"].lower():
                    qd = _j_d(c2["d1"])
                    qd_kind = c2["kind"]
                    break
                fmids.append((c2["port"], _j_d(c2["d1"]), c2["kind"]))
            if qd is None:
                continue
            if best is None or d < best[1]:
                best = (name, d, qd, {"ts_date": d, "ts_kind": c["kind"],
                                      "q_kind": qd_kind, "mids": fmids})
            break
    if best:
        return best[0], best[2], best[3]
    return None, None, {}


def _journey_of(entry):
    """True if the entry is Emkay/RTW and the vessel is known."""
    q = str(entry.get("query") or "").upper()
    if not q.startswith(_JOURNEY_PREFIXES):
        return False
    res = entry.get("result") or {}
    f = entry.get("bl_copy_fields") or {}
    return bool(res.get("vessel") or f.get("vessel"))


def _journey_done(entry):
    res = entry.get("result") or {}
    return bool(res.get("discharge_time") or res.get("vir"))


def _j_stage(label, d, kind, src_est, src_act):
    """One journey stage, graded by EVIDENCE: a port call the vessel
    has already made (kind 'recent' in the schedule record) is
    Confirmed with its real date; a future call stays an Estimate
    with a '~' date. (Yousuf's law, 8 Nov 2026: jo saboot se sabit
    ho gaya wo Estimate nahi rehna chahiye.)"""
    if kind == "recent":
        return {"label": label, "date": _j_fmt(d) if d else "",
                "grade": "Confirmed", "src": src_act}
    return {"label": label,
            "date": ("~" + _j_fmt(d)) if d else "",
            "grade": "Estimate", "src": src_est}


def _journey_build(entry):
    """Build the full journey dict (network: own vessel + feeder pool).
    Return None if it cannot be built."""
    res = entry.get("result") or {}
    f = entry.get("bl_copy_fields") or {}
    vessel = str(res.get("vessel") or f.get("vessel") or "").strip()
    if not vessel:
        return None
    voyage = str(res.get("voyage") or f.get("voyage") or "").strip()
    pol = str(res.get("pol") or f.get("pol") or "").strip()
    try:
        info = ENG.track_vessel_schedule(vessel)
    except Exception:
        info = None
    if not info or not info.get("found"):
        return None
    calls = _j_calls_norm(info.get("calls"))
    if not pol:
        rec = [c for c in calls if c["kind"] == "recent"]
        if rec:
            pol = rec[-1]["port"]
    if "mombasa" not in pol.lower() \
            and str(res.get("pod") or f.get("pod") or "").upper() \
            != "SALALAH":
        return None
    cls = _classify_journey(calls, pol)
    dep = None
    dep_src = "BL Copy" if f.get("vessel") else "Carrier Event"
    ms = entry.get("milestones") or []
    for m in ms:
        if isinstance(m, dict) and m.get("key") == "departed" \
                and m.get("when"):
            try:
                dep = datetime.strptime(m["when"], "%d %b %Y").date()
            except Exception:
                dep = None
    if dep is None and res.get("departed"):
        for fmw in ("%d %b %Y", "%d-%b-%Y"):
            try:
                dep = datetime.strptime(str(res["departed"]), fmw).date()
                break
            except Exception:
                pass
    stages = []
    dep_label = f"{pol.title()} — Departed · {vessel}" + \
        (f" ({voyage})" if voyage else "")
    stages.append({"label": dep_label,
                   "date": _j_fmt(dep) if dep else "",
                   "grade": "Confirmed" if dep else "Estimate",
                   "src": dep_src if dep else "Schedule"})
    route = ""
    ts_port, ts_date = cls["ts_port"], cls["ts_date"]
    feeder_name = feeder_qd = None
    fdet = {}
    if cls["direct"]:
        route = "Direct To QICT"
        for p, d, k in cls["mids"]:
            stages.append(_j_stage(f"{p} — Port Call", d, k,
                                   "Schedule", "Vessel Record"))
        stages.append(_j_stage("QICT (Port Qasim) — Arrival",
                               cls["direct"], cls["direct_kind"],
                               "Schedule", "Vessel Record"))
        feeder_name, feeder_qd = vessel, cls["direct"]
    elif ts_port:
        india = any(p in _INDIA_PORTS for p, _, _ in cls["mids"])
        route = ("India Loop" if india and ts_port == "Salalah"
                 else ("Salalah Direct" if ts_port == "Salalah"
                       else f"Via {ts_port}"))
        for p, d, k in cls["mids"]:
            stages.append(_j_stage(f"{p} — Port Call", d, k,
                                   "Schedule", "Vessel Record"))
        stages.append(_j_stage(f"{ts_port} — Transshipment",
                               ts_date, cls["ts_kind"],
                               "Schedule", "Vessel Record"))
        feeder_name, feeder_qd, fdet = _pick_feeder(
            ts_port, ts_date, _feeder_rotations())
        if feeder_name:
            stages.append(_j_stage(
                f"Feeder — {feeder_name} · Departed {ts_port}",
                fdet.get("ts_date"), fdet.get("ts_kind"),
                "Feeder Schedule", "Feeder Record"))
            for p, d, k in fdet.get("mids") or []:
                stages.append(_j_stage(f"{p} — Port Call (Feeder)",
                                       d, k, "Feeder Schedule",
                                       "Feeder Record"))
            stages.append(_j_stage("QICT (Port Qasim) — Arrival",
                                   feeder_qd, fdet.get("q_kind"),
                                   "Feeder Schedule", "Feeder Record"))
        else:
            stages.append({"label": "Feeder — Not Yet Decided",
                           "date": "", "grade": "Pending",
                           "src": f"Nearest Feeder At {ts_port}"})
            stages.append({"label": "QICT (Port Qasim) — Arrival",
                           "date": "", "grade": "Pending", "src": ""})
    else:
        return None
    total = ""
    if dep and (feeder_qd or cls["direct"]):
        end = feeder_qd or cls["direct"]
        total = f"~{(end - dep).days} Days"
    # Safar ki tafseel (Yousuf, 8 Nov 2026): har marhale ka waqt —
    # samandari leg, transshipment par container kitne din raha
    # (utara kab, feeder par load kab), aur feeder wali leg. Ye
    # tareekhein unhi stages se banti hain jo card par dikhti hain.
    safar = []
    _ftd = fdet.get("ts_date") if fdet else None
    if dep and ts_date:
        safar.append(f"Mombasa \u2192 {ts_port}: "
                     f"{(ts_date - dep).days} Days At Sea")
    if ts_date and _ftd:
        _dw = (_ftd - ts_date).days
        if _dw > 0:
            safar.append(
                f"Discharged At {ts_port} {_j_fmt(ts_date)} \u00b7 "
                f"Loaded On Feeder {_j_fmt(_ftd)} \u00b7 "
                f"Stayed {_dw} Day(s) In Between")
        else:
            safar.append(
                f"Discharged At {ts_port} And Loaded On The "
                f"Feeder The Same Day ({_j_fmt(_ftd)})")
    if _ftd and feeder_qd:
        safar.append(f"{ts_port} \u2192 QICT: "
                     f"{(feeder_qd - _ftd).days} Days")
    if dep and cls["direct"]:
        safar.append(f"Mombasa \u2192 QICT Direct: "
                     f"{(cls['direct'] - dep).days} Days At Sea")
    jr = {"route": route, "built_ts": time.time(), "safar": safar,
          "vessel": vessel, "ts_port": ts_port or "",
          "ts_date": ts_date.isoformat() if ts_date else "",
          "feeder": feeder_name or "",
          "qict_eta": (feeder_qd or cls["direct"]).isoformat()
          if (feeder_qd or cls["direct"]) else "",
          "departed": dep.isoformat() if dep else "",
          "total_est": total, "stages": stages, "complete": False}
    return jr


def _vir_date(vir):
    m = re.search(r"_(\d{2})(\d{2})(\d{2})\d{6}", str(vir or ""))
    if not m:
        return None
    try:
        return datetime(2000 + int(m.group(3)), int(m.group(2)),
                        int(m.group(1))).date()
    except Exception:
        return None


def _scanbook_info(ctx):
    """Scan Note Book: a snapshot of all information from the BL
    in one check (only the filled-in parts)."""
    r = ctx.get("result") or {}
    if not ctx.get("found") or not r:
        return {}
    info = {}
    for k in ("status", "vessel", "voyage", "line", "pol", "pod",
              "destination", "terminal", "vir", "eta",
              "discharge_time", "gate_out_time", "gate_out",
              "position", "holds", "source"):
        v = r.get(k)
        if v not in (None, "", []):
            info[k] = str(v)
    cs = [str(c).strip().upper()
          for c in (r.get("containers") or []) if str(c).strip()]
    if cs:
        info["containers"] = cs
    if r.get("returned"):
        info["returned"] = "Yes"
    if ctx.get("carrier"):
        info["carrier"] = str(ctx["carrier"])
    return info


def _scanbook_add(lst, kind, info):
    """One entry in the Scan Note Book — if it matches the previous
    one exactly, do not add it again (so auto re-check does not flood)."""
    if not info:
        return
    sig = json.dumps(info, sort_keys=True, default=str)
    if lst:
        last = lst[-1]
        if last.get("kind") == kind and json.dumps(
                last.get("info") or {}, sort_keys=True,
                default=str) == sig:
            return
    lst.append({"ts": int(time.time()),
                "time": _DT(datetime.now()),
                "kind": kind, "info": info})
    del lst[:-60]


SCAN_COPY_KEEP_DAYS = 30


def _scan_copies_dir():
    d = DATA_DIR / "scan_copies"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d


def _save_scan_image(q, data_url):
    """Scan Note Book: save the scanned BL copy photo (a data URL).
    Returns the file name, or None. JPG/PNG only, ~4 MB cap."""
    import base64
    try:
        if not data_url or not isinstance(data_url, str):
            return None
        m = re.match(r"data:image/(jpeg|jpg|png);base64,(.+)$",
                     data_url.strip(), re.S)
        if not m:
            return None
        raw = base64.b64decode(m.group(2))
        if not raw or len(raw) > 4_000_000:
            return None
        ext = ".png" if m.group(1) == "png" else ".jpg"
        name = re.sub(r"[^A-Z0-9]", "", str(q).upper()) + ext
        (_scan_copies_dir() / name).write_bytes(raw)
        return name
    except Exception:
        return None


def _scan_copies_cleanup():
    """Scan Note Book photos older than 30 days are deleted so the
    disk never fills up; the scan DETAIL always stays (Yousuf's
    order, 7 Nov 2026). Runs inside the re-check loop."""
    try:
        now = time.time()
        d = _scan_copies_dir()
        for _get, _file in ((get_history, HISTORY_FILE),
                            (_get_staff_history, STAFF_HISTORY_FILE)):
            try:
                hist = _get()
                dirty = False
                for e in hist:
                    ss = e.get("scanbook_scan") or {}
                    img = ss.get("img")
                    if img and now - float(ss.get("img_ts")
                                           or ss.get("ts") or now) > SCAN_COPY_KEEP_DAYS * 86400:
                        try:
                            (d / img).unlink(missing_ok=True)
                        except Exception:
                            pass
                        ss["img"] = None
                        ss["img_expired"] = True
                        dirty = True
                if dirty:
                    save_json(_file, hist)
            except Exception:
                pass
    except Exception:
        pass


# ---------------- scan-copy photo sync (v131) ----------------
# Yousuf's order (10 Nov 2026): a BL copy scanned on ANY copy (hub/IP,
# laptop ZIP, permanent link) must be available on EVERY copy. The
# copy's text and fields already travel inside the record; the photo
# file itself now travels too, through the hub, inside the normal
# sync cycle. Only photos a live entry still points at, and only
# while they are inside the 30-day keep window — an expired photo is
# never fetched back to life.

def _sync_photo_wanted():
    """File names of scan photos that local entries still reference
    and that have not aged out of the keep window."""
    want = set()
    try:
        now = time.time()
        for _get in (get_history, _get_staff_history):
            try:
                hist = _get()
            except Exception:
                continue
            for e in hist:
                ss = (e or {}).get("scanbook_scan") or {}
                img = ss.get("img")
                if not img or ss.get("img_expired"):
                    continue
                ts = float(ss.get("img_ts") or ss.get("ts") or 0)
                if ts and now - ts > SCAN_COPY_KEEP_DAYS * 86400:
                    continue
                if re.fullmatch(r"[A-Z0-9]+\.(jpg|png)", str(img)):
                    want.add(str(img))
    except Exception:
        pass
    return want


def _sync_photos_cycle(hub, token):
    """Joined copy: trade scan photos with the hub — download the
    ones this copy is missing, upload the ones the hub is missing.
    At most 6 transfers per cycle; the rest catch up next cycle."""
    import base64
    want = _sync_photo_wanted()
    if not want:
        return
    code, resp = _sync_http(hub + "/api/sync/photos", token)
    if code != 200 or not isinstance(resp, dict):
        return
    hub_has = {str(n) for n in (resp.get("names") or [])
               if re.fullmatch(r"[A-Z0-9]+\.(jpg|png)", str(n))}
    d = _scan_copies_dir()
    moved = 0
    for name in sorted(want):
        if moved >= 6:
            break
        f = d / name
        if f.exists():
            if name in hub_has:
                continue
            try:
                raw = f.read_bytes()
                if not raw or len(raw) > 4_200_000:
                    continue
                code, _r = _sync_http(hub + "/api/sync/photo", token, {
                    "name": name,
                    "data": base64.b64encode(raw).decode("ascii")})
                if code == 200:
                    moved += 1
            except Exception:
                continue
        elif name in hub_has:
            try:
                code, resp = _sync_http(
                    hub + "/api/sync/photo?name=" + name, token)
                if code != 200 or not isinstance(resp, dict):
                    continue
                raw = base64.b64decode(str(resp.get("data") or ""))
                if not raw or len(raw) > 4_200_000:
                    continue
                f.write_bytes(raw)
                moved += 1
            except Exception:
                continue


def _qict_arrival_date(entry):
    """QICT par ASAL aamad ki tareekh — terminal saboot se. VIR
    number ke andar ki tareekh KABHI nahi: wo berthing ki filing
    tareekh hoti hai jo safar se pehle ki ho sakti hai (59285:
    VIR 03-Nov ka tha, feeder Salalah se 05-Nov ko chala tha,
    asal aamad 10-Nov hui). Tartib: discharge_time, phir is
    safar ki changes mein pehla QICT saboot (hold / berth /
    discharge / gate out). Kuch na mile to None."""
    import re as _re
    res = entry.get("result") or {}

    def _lead(s):
        m = _re.search(r"(\d{1,2})-([A-Za-z]{3})-(\d{4})",
                       str(s or ""))
        if not m:
            return None
        try:
            return datetime.strptime(
                "%s-%s-%s" % (m.group(1), m.group(2).upper(),
                              m.group(3)), "%d-%b-%Y").date()
        except Exception:
            return None

    dd = _lead(res.get("discharge_time"))
    if dd:
        return dd
    jr = entry.get("journey") or {}
    dep = _lead(jr.get("departed"))
    for ch in reversed(entry.get("changes") or []):
        to = str((ch or {}).get("to") or "").lower()
        if not any(k in to for k in
                   ("qict", "hold", "discharg", "berth",
                    "gate out", "delivered")):
            continue
        cd = _lead((ch or {}).get("time"))
        if cd and (dep is None or cd >= dep):
            return cd
    return None


def _notebook_fill(entry, jr):
    """Note Book: prediction the first time, later actuals + score."""
    nb = entry.get("notebook") or {}
    res = entry.get("result") or {}
    changed = False
    if not nb:
        nb = {"written": _j_fmt(datetime.now().date()),
              "route": jr.get("route") or "",
              "ts_port": jr.get("ts_port") or "",
              "ts_date": jr.get("ts_date") or "",
              "feeder": jr.get("feeder") or "",
              "qict_eta": jr.get("qict_eta") or "",
              "actual": {}, "score": None}
        changed = True
    act = nb.setdefault("actual", {})
    if jr.get("safar") and nb.get("safar_actual") != jr["safar"]:
        nb["safar_actual"] = list(jr["safar"])
        changed = True
    if jr.get("departed") and not act.get("departed"):
        act["departed"] = jr["departed"]
        changed = True
    if _journey_done(entry):
        actual_date = _qict_arrival_date(entry)
        vd = _vir_date(res.get("vir"))
        _stored = _j_d(act.get("qict"))
        if _stored is None and act.get("qict"):
            try:
                _stored = datetime.strptime(
                    str(act["qict"]).strip()[:11].upper(),
                    "%d-%b-%Y").date()
            except Exception:
                _stored = None
        if (actual_date and vd and _stored == vd
                and actual_date != vd):
            # v132: purani mehfooz 'actual' tareekh VIR ki filing
            # tareekh thi — durust karo aur score dobara gino
            act["qict"] = None
            nb["score"] = None
            changed = True
        if actual_date and not act.get("qict"):
            act["qict"] = actual_date.isoformat()
            act["feeder"] = str(res.get("vessel") or "")
            changed = True
        if actual_date and nb.get("score") is None:
            pred_d = _j_d(nb.get("qict_eta"))
            sc = {}
            if nb.get("feeder"):
                sc["feeder_right"] = bool(
                    act.get("feeder")
                    and act["feeder"].upper().startswith(
                        nb["feeder"].upper()))
            if pred_d:
                sc["days_diff"] = (actual_date - pred_d).days
            nb["score"] = sc
            changed = True
    if changed:
        entry["notebook"] = nb
    return changed


def _vessel_live_refresh(entry):
    """Live position of the vessel CARRYING the container right now.
    Focus rule (Yousuf, 8 Nov 2026): once the transshipment is
    Confirmed, the mother vessel's chapter is closed — only the
    FEEDER is followed. The reading, WITH its report age, is stored
    on the record so the detail card shows it and the record keeps
    the history. A failed fetch never wipes a good earlier reading."""
    jr = entry.get("journey") or {}
    if not jr or jr.get("complete"):
        return False
    stages = jr.get("stages") or []
    ts_conf = any("Transshipment" in (s.get("label") or "")
                  and s.get("grade") == "Confirmed" for s in stages)
    feeder = (jr.get("feeder") or "").strip()
    mother = (jr.get("vessel") or "").strip()
    if ts_conf and feeder:
        focus, kind = feeder, "Feeder"
    else:
        focus, kind = mother, "Vessel"
    if not focus:
        return False
    old = entry.get("vessel_live") or {}
    now = time.time()
    if old.get("vessel") == focus \
            and now - float(old.get("ts") or 0) < 900:
        return False
    try:
        rv = ENG.vessel_live_position(focus)
    except Exception:
        return False
    if not rv or not rv.get("found"):
        return False
    new = {"vessel": focus, "kind": kind,
           "area": rv.get("area") or "",
           "destination": rv.get("destination") or "",
           "eta": rv.get("eta") or "",
           "speed": rv.get("speed") or "",
           "nav_status": rv.get("nav_status") or "",
           "position_time": rv.get("position_time") or "",
           "url": rv.get("url") or "",
           "src": rv.get("source") or "VesselFinder",
           "ts": now}
    if new != old:
        entry["vessel_live"] = new
        return True
    return False


def _vessel_live_refresh_any(entry):
    """Live vessel position for records WITHOUT a journey (Yousuf,
    8 Nov 2026: jo jahaz ki information mile, wo card par aaye — sirf
    Emkay/RTW nahi, har BL). Runs only while the cargo is still
    coming: once the vessel has berthed / the cargo is discharged,
    the vessel's live position no longer belongs to this shipment.
    Same reading shape + 15-minute cache as the journey path; a
    failed fetch never wipes a good earlier reading."""
    if entry.get("journey"):
        return False
    # A not-found record qualifies only with a carrier check on it —
    # that check is the proof the shipment exists (051GA16585).
    if not entry.get("found") and not entry.get("carrier_check"):
        return False
    res = entry.get("result") or {}
    vessel = (res.get("vessel") or "").strip()
    cc0 = entry.get("carrier_check") or {}
    if not vessel and cc0.get("ts_vessel"):
        vessel = str(cc0["ts_vessel"]).split("/")[0].strip()
    if not vessel:
        return False
    st = (res.get("status") or "").lower()
    if res.get("discharge_time") or res.get("berthing") \
            or any(k in st for k in ("discharg", "berth", "arriv",
                                     "at port", "gate out",
                                     "delivered", "hold",
                                     "released", "anchorage")):
        if entry.get("vessel_live"):
            entry["vessel_live"] = None
            return True
        return False
    voy = (res.get("voyage") or "").strip()
    if voy and vessel.upper().endswith(voy.upper()):
        vessel = vessel[: -len(voy)].strip(" -–")
    if not vessel:
        return False
    # CONFLICT LAW (Yousuf, 8 Nov 2026 — data aapas mein na
    # takraye): the live vessel followed must be the one CARRYING
    # the cargo now, never a vessel it has already left.
    # (i) A fresh carrier check naming the onward vessel wins —
    # the mother vessel's chapter is closed (the journey rule,
    # applied to every BL).
    kind = "Vessel"
    cc = entry.get("carrier_check") or {}
    if cc.get("ts_vessel") \
            and time.time() - float(cc.get("ts") or 0) < 4 * 86400:
        onward = str(cc["ts_vessel"]).split("/")[0].strip()
        if onward:
            vessel, kind = onward, "Onward Vessel"
    # (ii) If the vessel's own route has NO Karachi call, the
    # cargo leaves this vessel at a transshipment port — following
    # the mother vessel after that would show a sailing-away ship
    # for cargo sitting in a port. Show nothing instead.
    elif (entry.get("route") or {}).get("pod_eta") == "" \
            and entry.get("route"):
        if entry.get("vessel_live"):
            entry["vessel_live"] = None
            return True
        return False
    old = entry.get("vessel_live") or {}
    now = time.time()
    if old.get("vessel") == vessel \
            and now - float(old.get("ts") or 0) < 900:
        return False
    try:
        rv = ENG.vessel_live_position(vessel)
    except Exception:
        return False
    if not rv or not rv.get("found"):
        return False
    # A reading older than ~a day is NOT live (Yousuf's usool: report
    # ki umar parhe baghair 'live' kabhi nahi) — do not store it.
    _pt = (rv.get("position_time") or "").lower()
    import re as _re
    _dm = _re.search(r"(\d+)\s*day", _pt)
    if "month" in _pt or (_dm and int(_dm.group(1)) >= 2):
        return False
    new = {"vessel": vessel, "kind": kind,
           "area": rv.get("area") or "",
           "destination": rv.get("destination") or "",
           "eta": rv.get("eta") or "",
           "speed": rv.get("speed") or "",
           "nav_status": rv.get("nav_status") or "",
           "position_time": rv.get("position_time") or "",
           "url": rv.get("url") or "",
           "src": rv.get("source") or "VesselFinder",
           "ts": now}
    if new != old:
        entry["vessel_live"] = new
        return True
    return False


def _route_refresh(entry):
    """Vessel-schedule route for records WITHOUT a journey (Yousuf,
    8 Nov 2026: jahaz chalne se port tak ka roadmap HAR BL par laagu
    ho — sirf Emkay/RTW nahi). Fetches the carrying vessel's ShipsGo
    rotation and stores the calls IN ORDER on the record, so the
    card shows where the vessel has been and where it is going,
    with the Karachi / Port Qasim call (the ETA source) marked.
    If the vessel's rotation has NO Karachi call, the card says so
    plainly — the cargo will transship (the 051GA16585 lesson:
    WAN HAI 351 never comes to Karachi). 6-hour cache; a failed
    fetch never wipes a good earlier route."""
    if entry.get("journey"):
        return False
    res = entry.get("result") or {}
    vessel = (res.get("vessel") or "").strip()
    if not vessel:
        return False
    st = (res.get("status") or "").lower()
    if res.get("discharge_time") or res.get("berthing") \
            or any(k in st for k in ("discharg", "berth", "arriv",
                                     "at port", "gate out",
                                     "delivered", "hold",
                                     "released", "anchorage")):
        if entry.get("route"):
            entry["route"] = None
            return True
        return False
    old = entry.get("route") or {}
    now = time.time()
    # v132 (10 Nov 2026, 051GA16585 par sabit): carrier check mein
    # transshipment ka mukammal saboot ho — hub par discharge ho
    # chuki hai (status_date guzar chuki), onward vessel aur
    # Karachi ETA maloom hai — to route SHIPMENT ka bane ga,
    # mother vessel ki rotation ka nahi. 8 Nov ka usool: hub par
    # utarne ke baad mother vessel ka chapter band; us ki aage ki
    # calls (Tuticorin / Nhava Sheva / Laem Chabang / Qingdao)
    # is maal ka rasta nahi hain, aur "No Karachi Call — Will
    # Transship" wali warning bhi ghalat ho jati hai jab onward
    # vessel khud Karachi a raha ho. Route: POL (on-board,
    # Confirmed) -> hub (discharge, Confirmed) -> POD (ETA,
    # Estimate); pod_eta isi se aye gi taake ETA har jagah ek ho.
    cc = entry.get("carrier_check") or {}
    _ts_port = (cc.get("ts_port") or "").strip()
    _ts_ves = (cc.get("ts_vessel") or "").strip()
    _cc_eta = _pdate(cc.get("eta"))
    _cc_dis = _pdate(cc.get("status_date"))
    if _ts_port and _ts_ves and _cc_eta and _cc_dis \
            and _cc_dis <= date.today():
        _calls = []
        _pol = (cc.get("pol") or res.get("pol") or "").strip()
        _ob = _pdate(cc.get("onboard"))
        if _pol:
            _calls.append({"port": _pol, "kind": "recent",
                           "d1": _ob.isoformat() if _ob else "",
                           "voyage": ""})
        _calls.append({"port": _ts_port, "kind": "recent",
                       "d1": _cc_dis.isoformat(), "voyage": ""})
        _podn = (cc.get("pod") or res.get("pod")
                 or "Karachi").strip()
        _calls.append({"port": _podn, "kind": "upcoming",
                       "d1": _cc_eta.isoformat(), "voyage": ""})
        new = {"vessel": _ts_ves, "calls": _calls,
               "pod_eta": _cc_eta.isoformat(),
               "pod_kind": "upcoming",
               "via": "carrier_check", "built_ts": now}
        # built_ts har call par badalta hai — barabari sirf asal
        # content par (warna har refresh jhooti "tabdeeli" likhe ga)
        if old.get("via") == "carrier_check" \
                and old.get("vessel") == new["vessel"] \
                and old.get("calls") == new["calls"] \
                and old.get("pod_eta") == new["pod_eta"]:
            return False
        entry["route"] = new
        return True
    if old.get("vessel") == vessel \
            and now - float(old.get("built_ts") or 0) < 6 * 3600:
        return False
    try:
        info = ENG.track_vessel_schedule(vessel)
    except Exception:
        return False
    if not info or not info.get("found"):
        return False
    calls = _j_calls_norm(info.get("calls"))[:16]
    if not calls:
        return False
    # v129 (9 Nov): the pod call must belong to THIS voyage — a shuttle
    # vessel (BSG BIMINI waghera) calls at Karachi/Port Qasim on every
    # cycle, and the FIRST Karachi-ward call in the list can be the
    # PREVIOUS cycle's (274094021: footer 29-OCT dikha raha tha jab ke
    # asal aamad 10-NOV thi). Pehle upcoming calls, un mein POD se
    # milti hui pehle; upcoming na ho to sab se aakhri recent call.
    pod_eta = ""
    pod_kind = ""
    _podtxt = ((res.get("pod") or "") + " "
               + (res.get("terminal") or "")).lower()
    _want_qasim = ("qasim" in _podtxt or "qict" in _podtxt)
    _kw = [c for c in calls
           if "karachi" in (c.get("port") or "").lower()
           or "qasim" in (c.get("port") or "").lower()]
    def _kw_key(c):
        pl = (c.get("port") or "").lower()
        is_q = "qasim" in pl
        return 0 if is_q == _want_qasim else 1
    _up = [c for c in _kw if c.get("kind") == "upcoming"]
    _rc = [c for c in _kw if c.get("kind") != "upcoming"]
    _pick = None
    if _up:
        _pick = sorted(_up, key=_kw_key)[0]
    elif _rc:
        _matched = [c for c in _rc if _kw_key(c) == 0]
        _pick = _matched[-1] if _matched else _rc[-1]
    if _pick:
        pod_eta = _pick.get("d1") or ""
        pod_kind = _pick.get("kind") or ""
    # v129 (9 Nov, Yousuf ki shikayat): route list mein SIRF isi shipment
    # ke safar ki calls — pichle cycle ki Karachi/Port Qasim calls aur
    # POD aamad ke BAAD ki calls (agli rotation) gumrah karti hain
    # (274094021 par: Salalah 25 Oct + Qasim 29 Oct pichla cycle tha,
    # Salalah 15 Nov agli rotation). Safar pichli Karachi-ward call ke
    # baad se shuru, chuni hui POD call par khatam.
    if _pick and _pick in calls:
        _end = calls.index(_pick)
        _start = 0
        for _i in range(_end):
            _pl = (calls[_i].get("port") or "").lower()
            if ("karachi" in _pl or "qasim" in _pl) \
                    and calls[_i].get("kind") != "upcoming":
                _start = _i + 1
        if _start or _end < len(calls) - 1:
            calls = calls[_start:_end + 1]
    new = {"vessel": vessel, "calls": calls,
           "pod_eta": pod_eta, "pod_kind": pod_kind,
           "built_ts": now}
    if new != old:
        entry["route"] = new
        return True
    return False


def _journey_refresh(entry):
    """Refresh Journey + Note Book. The entry is mutated;
    returns True if anything changed."""
    if not _journey_of(entry):
        return False
    changed = False
    if _journey_done(entry):
        jr = entry.get("journey") or {}
        _ad = _qict_arrival_date(entry)
        if jr and jr.get("complete") and _ad:
            # v132 repair: jo journey pehle VIR ki filing tareekh
            # par 'Arrived' ho chuki hai, us ki stage tareekh asal
            # saboot wali tareekh se badal do
            for _s in (jr.get("stages") or []):
                if ("QICT" in (_s.get("label") or "")
                        and "Arrived" in (_s.get("label") or "")
                        and _s.get("date") != _j_fmt(_ad)):
                    jr = dict(jr)
                    _st = [dict(x) for x in jr.get("stages") or []]
                    for _x in _st:
                        if ("QICT" in (_x.get("label") or "")
                                and "Arrived" in (_x.get("label") or "")):
                            _x["date"] = _j_fmt(_ad)
                    jr["stages"] = _st
                    jr["built_ts"] = time.time()
                    entry["journey"] = jr
                    changed = True
                    break
        if jr and not jr.get("complete"):
            jr = dict(jr)
            jr["complete"] = True
            res = entry.get("result") or {}
            vd = _ad
            stages = list(jr.get("stages") or [])
            stages = [s for s in stages
                      if "QICT" not in s.get("label", "")
                      or s.get("grade") == "Confirmed"]
            stages.append({
                "label": "QICT (Port Qasim) — Arrived · "
                         + str(res.get("vessel") or ""),
                "date": _j_fmt(vd) if vd else "",
                "grade": "Confirmed", "src": "QICT Record"})
            jr["stages"] = stages
            jr["built_ts"] = time.time()
            entry["journey"] = jr
            changed = True
        if entry.get("journey"):
            changed = _notebook_fill(entry, entry["journey"]) or changed
        if entry.get("vessel_live"):
            entry["vessel_live"] = None
            changed = True
        return changed
    jr = _journey_build(entry)
    if jr is None:
        return False
    if entry.get("journey") != jr:
        keep_built = dict(jr)
        entry["journey"] = keep_built
        changed = True
    changed = _notebook_fill(entry, entry["journey"]) or changed
    changed = _vessel_live_refresh(entry) or changed
    return changed


def _journey_loop():
    """Every ~5 minutes: refresh the journey of in-transit Emkay/RTW
    records (sooner in the final leg, otherwise at ~50 minutes)."""
    time.sleep(60)
    while True:
        try:
            now = time.time()
            with _lock:
                hist = get_history()
                todo = []
                for h in hist:
                    if not _journey_of(h):
                        continue
                    if _journey_done(h):
                        jr = h.get("journey") or {}
                        nb = h.get("notebook") or {}
                        if jr and (not jr.get("complete")
                                   or nb.get("score") is None):
                            todo.append(h.get("query"))
                        continue
                    jr = h.get("journey") or {}
                    built = float(jr.get("built_ts") or 0)
                    ts_d = _j_d(jr.get("ts_date"))
                    final_leg = bool(ts_d and
                                     (ts_d - datetime.now().date()).days
                                     <= 4)
                    limit = 1500 if final_leg else 3000
                    if not built or now - built > limit:
                        todo.append(h.get("query"))
                todo_live = []
                for h in hist:
                    if _journey_of(h) or (not h.get("found")
                                          and not h.get("carrier_check")):
                        continue
                    lv = h.get("vessel_live") or {}
                    if not lv or now - float(lv.get("ts") or 0) > 900:
                        todo_live.append(h.get("query"))
                todo_route = []
                for h in hist:
                    if _journey_of(h) or h.get("journey"):
                        continue
                    rt = h.get("route") or {}
                    res = h.get("result") or {}
                    if res.get("vessel") and (
                            not rt or now - float(rt.get("built_ts")
                                                  or 0) > 6 * 3600):
                        todo_route.append(h.get("query"))
            for q in todo:
                try:
                    with _lock:
                        hist = get_history()
                        ent = next((x for x in hist
                                    if x.get("query") == q), None)
                        ent = dict(ent) if ent else None
                    if ent is None:
                        continue
                    if _journey_refresh(ent):
                        with _lock:
                            hist = get_history()
                            for i, x in enumerate(hist):
                                if x.get("query") == q:
                                    hist[i] = ent
                                    break
                            save_json(HISTORY_FILE, hist[:1000])
                except Exception:
                    continue
            for q in todo_live:
                try:
                    with _lock:
                        hist = get_history()
                        ent = next((x for x in hist
                                    if x.get("query") == q), None)
                        ent = dict(ent) if ent else None
                    if ent is None:
                        continue
                    if _vessel_live_refresh_any(ent):
                        with _lock:
                            hist = get_history()
                            for i, x in enumerate(hist):
                                if x.get("query") == q:
                                    hist[i] = ent
                                    break
                            save_json(HISTORY_FILE, hist[:1000])
                except Exception:
                    continue
            for q in todo_route:
                try:
                    with _lock:
                        hist = get_history()
                        ent = next((x for x in hist
                                    if x.get("query") == q), None)
                        ent = dict(ent) if ent else None
                    if ent is None:
                        continue
                    if _route_refresh(ent):
                        with _lock:
                            hist = get_history()
                            for i, x in enumerate(hist):
                                if x.get("query") == q:
                                    hist[i] = ent
                                    break
                            save_json(HISTORY_FILE, hist[:1000])
                except Exception:
                    continue
        except Exception:
            pass
        time.sleep(300)


# ---------------------------------------------------------------
# v132 KHUD-PARAKH (self-check) — Yousuf ka hukm, 10 Nov 2026:
# audit ne records ko DATA ke tor par check kiya tha, lekin
# Application route/journey/card khud BANATI hai — banane wale
# code ki ghalti hath ki parakh se nahi rukti. Ye parakh har
# record ke apne blocks ko usi record ke saboot se milati hai;
# takrao mile to pehle maujooda choke points se khud durust
# karti hai, phir bhi rahe to us block ko card se chhupa kar
# finding mehfooz karti hai (jhoota dikhane se behtar hai na
# dikhana). Findings entry par qc_flags mein rehti hain taake
# Nigran ki rozana parakh mein nazar aayen.
def _qc_date(s):
    """DD-MMM-YYYY ya ISO -> date | None (donon formats)."""
    if not s:
        return None
    d = _j_d(s)
    if d:
        return d
    try:
        return datetime.strptime(str(s).strip()[:11].upper(),
                                 "%d-%b-%Y").date()
    except Exception:
        return None


CYCLES_FILE = DATA_DIR / "container_cycles.json"
QC_INBOX_FILE = DATA_DIR / "qc_inbox.json"
_CYCLES_CACHE = {"data": None}


def _cycles_load():
    if _CYCLES_CACHE["data"] is None:
        try:
            _CYCLES_CACHE["data"] = json.loads(
                CYCLES_FILE.read_text(encoding="utf-8"))
        except Exception:
            _CYCLES_CACHE["data"] = {}
    return _CYCLES_CACHE["data"]


def _cycles_update(entry):
    """v132 khubi 4 — har container ke safar (cycles) ki apni
    tareekh: container dobara istemal hota hai; kis safar mein
    konsi tareekhein aayin, ye yaad-dasht ghost pehchanne ke
    kaam aati hai. _qc_loop se har parakh par taaza hoti hai."""
    res = entry.get("result") or {}
    ctns = res.get("containers") or []
    if not ctns:
        return False
    data = _cycles_load()
    changed = False
    for c in ctns:
        key = str(c).strip().upper()
        if not key:
            continue
        cyc = {"bl": entry.get("query"),
               "vir": res.get("vir") or "",
               "vessel": res.get("vessel") or "",
               "discharge": res.get("discharge_time") or "",
               "gate_out": res.get("gate_out") or "",
               "ts": time.time()}
        lst = data.setdefault(key, [])
        old = next((x for x in lst
                    if x.get("bl") == cyc["bl"]
                    and x.get("vir") == cyc["vir"]), None)
        if old is None:
            lst.append(cyc)
            changed = True
        else:
            for k in ("discharge", "gate_out", "vessel"):
                if cyc[k] and old.get(k) != cyc[k]:
                    old[k] = cyc[k]
                    changed = True
            old["ts"] = cyc["ts"]
        if len(lst) > 12:
            del lst[:-12]
    if changed:
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            CYCLES_FILE.write_text(
                json.dumps(data, ensure_ascii=False),
                encoding="utf-8")
        except Exception:
            pass
    return changed


def _qc_inbox_update(entry, flags):
    """v132 khubi 6 — jo takrao khud durust na ho, wo Shezi ki
    list (qc_inbox.json) mein jata hai taake wajah dhoond kar
    nayi parakh banayi ja sake; durust ho jane par khud nikal
    jata hai."""
    try:
        try:
            inbox = json.loads(
                QC_INBOX_FILE.read_text(encoding="utf-8"))
        except Exception:
            inbox = {}
        q = entry.get("query")
        if flags:
            inbox[q] = {"flags": flags, "ts": time.time()}
        else:
            inbox.pop(q, None)
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        QC_INBOX_FILE.write_text(
            json.dumps(inbox, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def _claim_grades(entry):
    """v132 khubi 2 — bare dawon (discharge / gate out) ka
    grade, carrier_check ki tasdeeq se. NOTE (10 Nov ki
    calibration): stored layers mein tasdeeq ginne ka reliable
    signal nahi mila — 'one-source' flag taqreeban har mukammal
    record par lagta, is liye use QC flag NAHI banaya gaya.
    Do-source usool ka asal amal khubi 1 (malik source) aur
    milestone certainty grades mein hai; ye function sirf
    carrier-tasdeeq wali 'confirmed' pehchan ke liye hai."""
    res = entry.get("result") or {}
    cc = entry.get("carrier_check") or {}
    ev = (str(cc.get("events") or "") + " "
          + str(cc.get("status") or "")).lower()
    out = {}

    def _g(name, present, words):
        if not present:
            return
        out[name] = "confirmed" if any(w in ev for w in words) \
            else "single-source"

    _g("discharge", res.get("discharge_time"),
       ("discharg", "unloaded"))
    _g("gate_out", res.get("gate_out"),
       ("gate out", "gate-out", "delivered"))
    return out


def _self_check(entry):
    """Record ke blocks ka usi ke saboot se muqabla.
    Findings: [{'check','block','detail'}] — block 'route' /
    'journey' / '' ('' = koi block nahi, sirf khabar)."""
    out = []
    res = entry.get("result") or {}
    rt = entry.get("route") or {}
    cc = entry.get("carrier_check") or {}
    jr = entry.get("journey") or {}
    today = datetime.now().date()
    arrived = bool(res.get("discharge_time") or res.get("berthing")
                   or res.get("gate_out"))
    pe = _qc_date(rt.get("pod_eta"))
    ce = _qc_date(cc.get("eta"))
    if rt:
        if cc.get("ts_vessel") and rt.get("via") != "carrier_check" \
                and (rt.get("vessel") or "") != cc.get("ts_vessel"):
            out.append({
                "check": "route_vessel_vs_carrier", "block": "route",
                "detail": "Route vessel %s hai, carrier saboot "
                          "onward %s ka hai" % (rt.get("vessel"),
                                                cc.get("ts_vessel"))})
        if pe and ce and abs((pe - ce).days) > 2:
            out.append({
                "check": "route_eta_vs_carrier", "block": "route",
                "detail": "Route ETA %s, carrier ETA %s — card par "
                          "do tareekhein" % (rt.get("pod_eta"),
                                              cc.get("eta"))})
        if pe and pe < today and not arrived:
            out.append({
                "check": "route_eta_past", "block": "route",
                "detail": "Route ki Karachi tareekh %s guzar chuki "
                          "hai, maal abhi raste mein hai"
                          % rt.get("pod_eta")})
        for i, c in enumerate(rt.get("calls") or []):
            pl = (c.get("port") or "").lower()
            if ("karachi" in pl or "qasim" in pl) \
                    and i < len(rt.get("calls") or []) - 1:
                out.append({
                    "check": "route_past_karachi", "block": "route",
                    "detail": "Route Karachi ke baad bhi aage "
                              "jata hai"})
                break
        if arrived:
            out.append({
                "check": "route_on_arrived", "block": "route",
                "detail": "Maal port par sabit hai lekin purana "
                          "route abhi chipka hai"})
    if jr:
        prev = None
        for s in (jr.get("stages") or []):
            d = _qc_date(s.get("date"))
            if d and prev and d < prev[0]:
                out.append({
                    "check": "journey_order", "block": "journey",
                    "detail": "Stage '%s' ki tareekh %s pichli "
                              "stage '%s' (%s) se pehle hai"
                              % (s.get("label"), s.get("date"),
                                 prev[1].get("label"), prev[1].get("date"))})
                break
            if d:
                prev = (d, s)
        if "NaN" in json.dumps(jr):
            out.append({
                "check": "journey_nan", "block": "journey",
                "detail": "Journey mein NaN value hai"})
    if res.get("discharge_time") \
            and (res.get("position") or "").upper() == "VESSEL":
        out.append({
            "check": "position_vs_discharge", "block": "",
            "detail": "Discharge sabit hai lekin position abhi "
                      "bhi VESSEL hai"})
    vl = entry.get("vessel_live") or {}
    if jr and not jr.get("complete"):
        feeder = (jr.get("feeder") or "").strip()
        ts_conf = any("Transshipment" in (s.get("label") or "")
                      and s.get("grade") == "Confirmed"
                      for s in (jr.get("stages") or []))
        if ts_conf and feeder and vl.get("vessel") \
                and vl.get("vessel") != feeder:
            out.append({
                "check": "live_focus", "block": "",
                "detail": "Live block %s par hai, maal feeder %s "
                          "par hai" % (vl.get("vessel"), feeder)})
    # ---- v132 izafa: poori lifecycle + card-wide parakhein ----
    # (Yousuf: "mukamal sahi karo — use har cheez ka pata ho")
    ms = entry.get("milestones") or []
    _order = ["departed", "berthed", "discharged", "gateout"]
    _done = {m.get("key"): m for m in ms if m.get("key")}
    _seq = [_done[k] for k in _order if k in _done]
    _dprev = None
    for m in _seq:
        if m.get("state") != "done":
            continue
        d = _qc_date(m.get("when"))
        if d and _dprev and d < _dprev[0]:
            out.append({
                "check": "ms_order", "block": "",
                "detail": "Milestone %s ki tareekh %s pichle "
                          "milestone %s (%s) se pehle hai"
                          % (m.get("key"), m.get("when"),
                             _dprev[1].get("key"), _dprev[1].get("when"))})
            break
        if d:
            _dprev = (d, m)
    _seen_pending = None
    for m in _seq:
        if m.get("state") != "done" and _seen_pending is None:
            _seen_pending = m.get("key")
        elif m.get("state") == "done" and _seen_pending:
            # sirf tab jab data khud discharge sabit karta ho —
            # QICT ke aam records mein discharge_time ka field
            # hota hi nahi, gate out hi aakhri saboot hota hai
            # (wo shakal aam hai, takrao nahi)
            if _seen_pending != "discharged" \
                    or res.get("discharge_time"):
                out.append({
                    "check": "ms_skip", "block": "",
                    "detail": "Milestone %s ho chuka hai lekin "
                              "us se pehle wala %s abhi pending "
                              "hai" % (m.get("key"), _seen_pending)})
            break
    _bd = _qc_date(res.get("berthing"))
    _dd = _qc_date(res.get("discharge_time"))
    _gd = _qc_date(res.get("gate_out"))
    if _bd and _dd and _dd < _bd:
        out.append({
            "check": "field_order", "block": "",
            "detail": "Discharge %s berthing %s se pehle hai"
                      % (res.get("discharge_time"), res.get("berthing"))})
    if _dd and _gd and _gd < _dd:
        out.append({
            "check": "field_order", "block": "",
            "detail": "Gate out %s discharge %s se pehle hai"
                      % (res.get("gate_out"), res.get("discharge_time"))})
    if res.get("gate_out") and not res.get("discharge_time"):
        out.append({
            "check": "gateout_no_discharge", "block": "",
            "detail": "Gate out darj hai lekin discharge ki "
                      "tareekh gayab hai"})
    _ob = _qc_date((entry.get("bl_copy_fields") or {}).get("issue_date")) \
        or _qc_date(cc.get("onboard"))
    if _dd and _ob and _dd < _ob:
        out.append({
            "check": "discharge_before_onboard", "block": "",
            "detail": "Discharge %s BL ki tareekh %s se pehle "
                      "hai — pichle safar ka saboot maujooda "
                      "record mein hai" % (res.get("discharge_time"),
                                           _ob)})
    if _gd and not (entry.get("returned") or res.get("returned")):
        _fresh = entry.get("checked_ts") \
            and (time.time() - float(entry["checked_ts"])) < 3 * 86400
        if _fresh and (today - _gd).days >= 14:
            out.append({
                "check": "return_overdue", "block": "",
                "detail": "Gate out ko %d din ho gaye, khaali "
                          "wapsi ka saboot abhi nahi mila"
                          % (today - _gd).days})
    _vir = (res.get("vir") or "").upper()
    _vt = next((t for t in ("QICT", "KICT", "SAPT")
                if t in _vir), None)
    _tm = (res.get("terminal") or "").upper()
    if _vt and _tm and _vt not in _tm and not (
            _vt == "QICT" and "QASIM" in _tm):
        out.append({
            "check": "terminal_vs_vir", "block": "",
            "detail": "VIR %s ka hai lekin terminal field %s "
                      "likhta hai" % (_vt, res.get("terminal"))})
    _re = _qc_date(res.get("eta"))
    if _re and ce and abs((_re - ce).days) > 2:
        out.append({
            "check": "eta_clash", "block": "",
            "detail": "Record ETA %s, carrier ETA %s — do "
                      "mukhtalif tareekhein" % (res.get("eta"),
                                                cc.get("eta"))})
    if _re and pe and abs((_re - pe).days) > 2:
        out.append({
            "check": "eta_clash", "block": "route",
            "detail": "Record ETA %s, route ETA %s — do "
                      "mukhtalif tareekhein" % (res.get("eta"),
                                                rt.get("pod_eta"))})
    for s in (jr.get("stages") or []):
        d = _qc_date(s.get("date"))
        if d and d > today and s.get("grade") == "Confirmed":
            out.append({
                "check": "future_confirmed", "block": "journey",
                "detail": "Stage '%s' Confirmed hai lekin tareekh "
                          "%s mustaqbil ki hai" % (s.get("label"),
                                                   s.get("date"))})
            break
    for c in (rt.get("calls") or []):
        d = _qc_date(c.get("d1"))
        if d and d > today and c.get("kind") == "recent":
            out.append({
                "check": "future_confirmed", "block": "route",
                "detail": "Route call %s 'recent' hai lekin "
                          "tareekh %s mustaqbil ki hai"
                          % (c.get("port"), c.get("d1"))})
            break
    if (_dd and _dd > today) or (_gd and _gd > today):
        out.append({
            "check": "future_confirmed", "block": "",
            "detail": "Discharge/gate out ki tareekh mustaqbil "
                      "ki hai"})
    _bc = entry.get("bl_copy") or {}
    _bt = (_bc.get("text") or "").strip()
    if _bt.startswith("{"):
        try:
            _bj = json.loads(_bt)
            if isinstance(_bj, dict) and ("raw" in _bj
                                          or "containers" in _bj):
                out.append({
                    "check": "copy_is_scan", "block": "",
                    "detail": "BL copy ki jagah scan ka result "
                              "mehfooz hai"})
        except Exception:
            pass
    if jr:
        _tsc = any("Transshipment" in (s.get("label") or "")
                   and s.get("grade") == "Confirmed"
                   for s in (jr.get("stages") or []))
        if _tsc and jr.get("feeder") and res.get("vessel") \
                and res.get("vessel") == (jr.get("vessel") or "") \
                and res.get("vessel") != jr.get("feeder"):
            out.append({
                "check": "vessel_vs_feeder", "block": "",
                "detail": "Transshipment sabit hai, maal feeder "
                          "%s par hai lekin card ka vessel abhi "
                          "bhi mother %s hai" % (jr.get("feeder"),
                                                 res.get("vessel"))})
    _cf = entry.get("bl_copy_fields") or {}
    if _cf.get("containers") and res.get("containers"):
        _have = {str(c).strip().upper() for c in res["containers"]}
        _miss = [c for c in _cf["containers"]
                 if str(c).strip().upper() not in _have]
        if _miss:
            out.append({
                "check": "containers_vs_copy", "block": "",
                "detail": "BL copy ke containers %s tracking "
                          "mein gayab hain" % ", ".join(_miss[:3])})
    _cyc = _cycles_load()
    _myvir = (res.get("vir") or "").upper()
    _myd = _qc_date(res.get("discharge_time"))
    for _c in (res.get("containers") or []):
        for _o in _cyc.get(str(_c).strip().upper(), []):
            if _o.get("bl") == entry.get("query"):
                continue
            _ov = (_o.get("vir") or "").upper()
            _od = _qc_date(_o.get("discharge"))
            if _myvir and _ov and _ov != _myvir and _myd and _od \
                    and _myd == _od:
                out.append({
                    "check": "cycle_clash", "block": "",
                    "detail": "Container %s ki discharge tareekh "
                              "doosre safar (BL %s, VIR %s) se "
                              "milti hai — ghost ka shak"
                              % (_c, _o.get("bl"), _o.get("vir"))})
                break
    return out


def _qc_apply(entry):
    """Khud-parakh chalao: pehle durusti ki koshish (route /
    journey ke maujooda choke points), phir dobara parakh.
    Jo takrao phir bhi rahe — block chhupao + finding mehfooz.
    Sab durust ho to purani hide/flags khud saaf. Returns
    True agar entry badli."""
    # found flag par gate NAHI: 051GA16585 jese records jin ka
    # aakhri taaza check 0-found tha lekin mehfooz record card
    # par dikhta hai — unhi par ye takrao banta hai
    if not (entry.get("result") or entry.get("route")
            or entry.get("journey")):
        return False
    if not _self_check(entry):
        _qc_inbox_update(entry, [])
        if entry.get("qc_hide") or entry.get("qc_flags"):
            entry["qc_hide"] = []
            entry["qc_flags"] = []
            return True
        return False
    try:
        _route_refresh(entry)
    except Exception:
        pass
    try:
        _journey_refresh(entry)
    except Exception:
        pass
    after = _self_check(entry)
    hide = sorted({f["block"] for f in after if f.get("block")})
    flags = [{"check": f["check"], "detail": f["detail"],
              "time": _DT(datetime.now())} for f in after]
    _qc_inbox_update(entry, flags)
    changed = False
    if entry.get("qc_hide") != hide:
        entry["qc_hide"] = hide
        changed = True
    if [f.get("check") for f in (entry.get("qc_flags") or [])] \
            != [f["check"] for f in flags]:
        entry["qc_flags"] = flags
        changed = True
    return changed


def _qc_loop():
    """Har ~5 minute tamam records ki khud-parakh; har record
    zyada se zyada har 30 minute mein ek baar."""
    time.sleep(120)
    while True:
        try:
            now = time.time()
            with _lock:
                hist = get_history()
                todo = [h.get("query") for h in hist
                        if (h.get("result") or h.get("route")
                            or h.get("journey"))
                        and now - float(h.get("qc_ts") or 0) > 1800]
            for q in todo:
                try:
                    with _lock:
                        hist = get_history()
                        ent = next((x for x in hist
                                    if x.get("query") == q), None)
                        ent = dict(ent) if ent else None
                    if ent is None:
                        continue
                    ent["qc_ts"] = time.time()
                    _cycles_update(ent)
                    _qc_apply(ent)
                    with _lock:
                        hist = get_history()
                        for i, x in enumerate(hist):
                            if x.get("query") == q:
                                hist[i] = ent
                                break
                        save_json(HISTORY_FILE, hist[:1000])
                except Exception:
                    continue
        except Exception:
            pass
        time.sleep(300)


def _bl_copy_fields(text):
    """Confirmed parts from the BL copy text: vessel, voyage,
    containers, loading/discharge ports. Only parts found
    with a label; the vessel name must pass the engine's
    looks_like_vessel check."""
    out = {}
    t = (text or "").replace("\r", "\n")
    lines = [ln.strip() for ln in t.split("\n")]

    def _after(pat):
        for i, ln in enumerate(lines):
            m = re.search(pat, ln, re.I)
            if m:
                rest = ln[m.end():].strip(" :\t-")
                if rest:
                    return rest
                for ln2 in lines[i + 1:i + 3]:
                    if ln2:
                        return ln2
        return ""

    try:
        for i, ln in enumerate(lines):
            m = re.search(r"precarried\s+by", ln, re.I)
            if m:
                rest = ln[m.end():].strip(" :\t-")
                _rsq = _sq(rest)
                if any(w in _rsq for w in ("PLACEOF", "ONWARD",
                                           "PORTOF", "DELIVERY",
                                           "VESSEL", "VOYAGE")):
                    # The label shares its line with other labels
                    # ("Precarried by PlaceofReceipt Onward...") —
                    # the value is on the next line, not in the
                    # labels' tail.
                    rest = ""
                if not rest:
                    for ln2 in lines[i + 1:i + 3]:
                        if ln2:
                            rest = ln2
                            break
                pv, pvy = rest.upper(), ""
                mm = re.match(r"^(.*?)[\s]+V\.?\s*([0-9I]{3,4}[A-Z])\b",
                              rest.upper())
                if not mm:
                    mm = re.match(
                        r"^(.*?)[\s]+(\d{3,4}[A-Z]|[A-Z]\d{3,4})\b",
                        rest.upper())
                if mm:
                    pv, pvy = mm.group(1).strip(" .,-"), mm.group(2)
                    # OCR 1/I confusion inside the voyage digits
                    pvy = re.sub(r"(?<=\d)I(?=\d|[A-Z]$)", "1", pvy)
                pv = pv.strip(" :\t-.,")
                if pv and len(pv) <= 40 and "clause" not in pv.lower():
                    out["precarriage"] = pv
                    if pvy:
                        out["precarriage_voyage"] = pvy
                break
    except Exception:
        pass
    try:
        v = ""
        for i, ln in enumerate(lines):
            if re.search(r"ocean\s+vessel|vessel", ln, re.I) \
                    and "precarried" not in ln.lower():
                rest = re.sub(r"\(see[^)]*\)", "",
                              ln[re.search(
                                  r"ocean\s+vessel|vessel",
                                  ln, re.I).end():])
                rest = rest.strip(" :\t-")
                if rest:
                    v = rest
                else:
                    for ln2 in lines[i + 1:i + 3]:
                        if ln2:
                            v = ln2
                            break
                break
        v = re.split(r"\bVOYAGE\b", v, flags=re.I)[0]
        v = v.strip(" :\t-.,")
        _vj = re.match(r"VOY\.?\s*(NO\.?)?\s*([A-Z0-9]{3,6})\b",
                       v.upper())
        if _vj and any(ch.isdigit() for ch in _vj.group(2)):
            # The label line's own tail ("Voy No.158W Port of
            # Loading") is not a vessel name — leave the field
            # empty so the scan/vision source can fill it.
            v = ""
        if v and out.get("precarriage") \
                and v.upper() == out["precarriage"]:
            v = ""   # the precarriage name is not the vessel
        if v and "clause" not in v.lower() \
                and len(v) <= 40 and ENG.looks_like_vessel(v):
            out["vessel"] = v.upper()
    except Exception:
        pass
    try:
        vy = _after(r"voyage")
        m = re.search(r"\b([A-Z0-9]{3,6})\b", (vy or "").upper())
        if m and any(ch.isdigit() for ch in m.group(1)):
            out["voyage"] = m.group(1)
    except Exception:
        pass
    try:
        # Phantom-container guards (11 Nov 2026, COAU6470870454 par
        # sabit — card par MBER0014780 naam ka nakli container tha):
        # (1) a candidate that is a SLICE of the BL number itself
        #     (COAU6470870, MJAS4302029, QITS8502269) is not a
        #     container; (2) a candidate whose letters are the tail
        #     of a long document word — 5+ letters before it, as in
        #     "AGREEMENTNUMBER00147800" -> "MBER0014780" — is not a
        #     container. NO blanket boundary rule and NO check-digit
        #     drop: asal containers aksar text mein chipke hue ate
        #     hain ("FCL/FCLYMAV6677101570PACKAGES") aur ek asal
        #     container (YMAV6677101) check-digit par fail bhi hai.
        _raw = (text or "").upper()
        # Alphanumeric runs: a candidate printed STANDALONE (a run
        # of exactly 11) is decisive — always kept. A candidate
        # that only ever appears as a slice of a BL-length run
        # (12-16 chars: the BL number itself, e.g. COAU6470870454
        # -> COAU6470870) is the BL's own shadow, not a container.
        _runs = re.findall(r"[A-Z0-9]{11,}", _raw)
        _standalone = {r for r in _runs if len(r) == 11}
        _bl_runs = [r for r in _runs if 12 <= len(r) <= 18]
        conts = []
        for _m in re.finditer(r"[A-Z]{4}\d{7}", _raw):
            _cand = _m.group(0)
            if _cand not in _standalone and \
                    any(_cand in r for r in _bl_runs):
                continue
            _before = 0
            _i = _m.start() - 1
            while _i >= 0 and _raw[_i].isalpha():
                _before += 1
                _i -= 1
            if _before >= 5:
                continue
            if _cand not in conts:
                conts.append(_cand)
        if conts:
            out["containers"] = conts
    except Exception:
        pass
    for key, pat in (("pol", r"port\s+of\s+loading"),
                     ("pod", r"port\s+of\s+discharge")):
        try:
            val = _after(pat).split(",")[0].strip(" :\t-.")
            _vsq = _sq(val)
            if any(w in _vsq for w in ("PLACEOF", "PORTOF",
                                       "DELIVERY", "DISCHARGE",
                                       "LOADING", "STATUS",
                                       "ONWARD", "CONTRACT",
                                       "FORMNO", "SERVICE")):
                # The label line's own tail — other labels, not a
                # port ("Place of Delivery Delivery status").
                val = ""
            def _wset(s):
                return set(re.split(r"[^A-Z]+",
                                    (s or "").upper())) - {""}
            _vwords = _wset(out.get("vessel")) | \
                _wset(out.get("precarriage"))
            if val and _vwords and any(
                    w in _vwords for w in _wset(val)):
                # The line under the labels holds the vessel value
                # and the port together ("YM EXCELLENCE
                # SURABAYA") — not a port; leave it empty for
                # the scan source to fill.
                val = ""
            if val and len(val) <= 40 and "@" not in val and \
                    sum(ch.isalpha() for ch in val) >= 3:
                out[key] = val.title()
        except Exception:
            pass
    # Label-ABOVE-value layout (Emkay BL form): the values
    # sit on the line ABOVE the printed labels, and OCR
    # garbles the labels ("Vessol", "Locding") — the generic
    # label searches miss or grab garbage there.
    try:
        for i, ln in enumerate(lines):
            low = ln.lower()
            if "voyage" in low and ("vess" in low
                                    or "ocean" in low) and i > 0:
                prev = ""
                for _p in range(i - 1, max(i - 4, -1), -1):
                    if lines[_p].strip():
                        prev = lines[_p].strip()
                        break
                m = re.match(
                    r"^([A-Z][A-Z0-9 .'-]{2,34}?)\s+(\d{3,4}[A-Z])$",
                    prev.upper())
                if m:
                    vv = re.sub(r"([A-Z])(\d+)$", r"\1 \2",
                                m.group(1).strip())
                    if ENG.looks_like_vessel(vv):
                        out["vessel"] = vv
                        out["voyage"] = m.group(2)
                break
    except Exception:
        pass
    try:
        for i, ln in enumerate(lines):
            low = ln.lower()
            if "port" in low and "discharge" in low and i > 0:
                toks = lines[i - 1].strip().upper().split()
                # Guards (YMJAS430202944, 11 Nov 2026): on a
                # label-BELOW-value form the line above is the
                # vessel row ("YM EXCELLENCE SURABAYA") — its first
                # token is a 2-letter carrier fragment or the
                # vessel/precarriage name's first word, never a
                # port. This block must not fire then; it overwrote
                # pol/pod with "Ym" / "Excellence Surabaya".
                _vfirst = ((out.get("vessel") or
                            out.get("precarriage") or "")
                           .upper().split() or [""])[0]
                if len(toks) >= 2 and "@" not in toks[0] \
                        and len(toks[0]) >= 3 \
                        and toks[0] != _vfirst:
                    rest = " ".join(toks[1:])
                    out["pol"] = toks[0].title()
                    out["pod"] = ("Port Qasim"
                                  if re.search(r"PORT\s*QASIM",
                                               rest)
                                  else rest.title())
                break
    except Exception:
        pass
    return out


def _apply_stale_guard(ctx):
    """Old-record guard also on no_save job contexts.
    In the scan flow, containers are first tracked with no_save
    and if the BL is not found, their card is shown — _record
    only ran on the save path, so a complete record from a
    previous voyage would reach the card without any alert
    (GLDU9608137, 4 Nov 2026). Now the guard applies on
    every path — this is the final common gateway through
    which every job ctx passes."""
    _walk_t12(ctx)
    try:
        _sa = _stale_trip_alert(
            ctx.get("result"), ctx.get("layers"),
            fallback_containers=_result_containers(
                ctx.get("result")))
        if _sa:
            _sa["ts"] = time.time()
            ctx["stale_alert"] = _sa
            if _sa["kind"] == "prev_trip":
                ctx["result"] = {}
                ctx["found"] = False
    except Exception:
        pass
    try:
        if _bl_copy_needed(ctx.get("carrier"), ctx.get("found"),
                           ctx.get("result"), ctx.get("bl_copy")):
            ctx["bl_copy_needed"] = {"reason": "vessel",
                                     "ts": time.time()}
    except Exception:
        pass


def _record(ctx):
    """Save to history (preserving the old entry's checklist/notes).

    Freshness honesty (v41 audit): checked_ts/time are only stamped
    when this check actually returned data — or when there was no
    earlier found record to protect. A refresh whose sources all
    failed must never make old data look freshly checked.

    The three meanings of time (v96, data audit FIX 2/3):
    attempt_ts/attempt_time = last ATTEMPT (when actually looked);
    checked_ts/time = last VERIFICATION (when live data confirmed/
    changed the record); live_ok/live_ts = whether a real data
    layer succeeded in this check. The user always sees the
    attempt time as 'Last checked'; the verification time stays separate
    so an old record does not look like a fresh check."""
    # Every time coming from the source is first made 12h AM/PM — the changes
    # text is also built from this same clean data.
    _walk_t12(ctx)
    got_new = bool(ctx.get("result"))
    live_ok = bool(got_new
                   and (not ctx.get("layers")
                        or _live_data_layers(ctx.get("layers"))))
    ctx["live_ok"] = live_ok
    if live_ok:
        ctx["live_ts"] = time.time()
    # v90: the time of each check is stored separately — on the card "Last checked"
    # (this attempt) and "record confirmed" (actual verification)
    # difference will be clearly visible; an old record will not look like a new check.
    ctx["attempt_ts"] = time.time()
    ctx["attempt_time"] = _DT(datetime.now())
    with _lock:
        hist = get_history()
        old = next((h for h in hist if h.get("query") == ctx["query"]), None)
        _shist = _get_staff_history()
        _s_old = next((h for h in _shist
                       if h.get("query") == ctx["query"]), None)
        _all = hist + _shist
        # v110 (Yousuf's order, 3 Nov): a container's NOT FOUND
        # separate entry, when that container is already in an existing BL
        # entry, is a second entry — do not save it
        # at all; the entry remains only the BL's.
        # v111 (Yousuf's order, 4 Nov 2026): a number that is written
        # in the containers of a BL entry, its separate entry
        # should not be saved at all — whether found or not-found, whatever the mode
        # may be; the entry is created only for the BL. (The result still
        # is shown to the user on the card; only a separate entry is not
        # created.) A container that is NOT in any BL, its
        # entry is created as before.
        import re as _re_rec
        if _re_rec.match(r"^[A-Z]{4}[0-9]{7}$",
                         str(ctx.get("query") or "").strip().upper()):
            _qn = str(ctx["query"]).strip().upper()
            if any(not _re_rec.match(
                        r"^[A-Z]{4}[0-9]{7}$",
                        str(h.get("query") or "").strip().upper())
                    and _qn in [str(c).strip().upper()
                                for c in ((h.get("result") or {})
                                          .get("containers") or [])]
                    for h in _all):
                return
        # v111 routing (Option 1, Yousuf 4 Nov): if the record is already in the main file
        # then update it there; if it is in the staff file
        # then there; if it is nowhere and staff did the tracking
        # then it will go to staff's own file — not to Admin's main
        # file.
        _to_staff = False
        if old is None and ctx.get("staff_owner"):
            # staff's track: if its own copy is found, update it there,
            # otherwise a new entry in its file.
            _to_staff = True
            hist = _shist
            old = next((h for h in _shist
                        if h.get("query") == ctx["query"]
                        and h.get("staff_owner")
                        == ctx.get("staff_owner")), None)
        elif old is None and _s_old is not None:
            # Admin tracked the same BL that was in the staff file
            # — now it will come into the main file and
            # the staff copy will be removed.
            old = _s_old
            _save_staff_history(
                [h for h in _shist if h.get("query") != ctx["query"]])
        elif old is not None and _s_old is not None:
            _save_staff_history(
                [h for h in _shist if h.get("query") != ctx["query"]])
        if old and not live_ok and old.get("live_ts"):
            ctx["live_ts"] = old["live_ts"]
        if old and old.get("found") and not got_new:
            ctx["time"] = old.get("time", ctx.get("time", ""))
            ctx["checked_ts"] = old.get("checked_ts")
            # v96 FIX 2: this presentation is a SAVED record, not a fresh find
            # — a separate marker, and the record's layers also remain those of
            # the last actual track that provided this data
            # (a failed check's empty list will not take their place;
            # this is what 'checks from its last track' means).
            ctx["saved_only"] = True
            if old.get("layers"):
                ctx["layers"] = old["layers"]
        else:
            ctx["checked_ts"] = time.time()
            ctx["saved_only"] = False
        if old:
            _sa = _stale_trip_alert(
                ctx.get("result"), ctx.get("layers"),
                fallback_containers=_result_containers(
                    (old or {}).get("result")))
            if _sa and _sa["kind"] == "prev_trip":
                # The container's previous voyage — adoption is forbidden.
                # The old actual record is preserved, only an alert will be applied
                # and this check will not be considered live verification.
                _sa["ts"] = time.time()
                ctx["stale_alert"] = _sa
                ctx["result"] = old.get("result")
                ctx["found"] = bool(old.get("found"))
                ctx["live_ok"] = False
                ctx.pop("live_ts", None)
            else:
                ctx["result"] = _merge_result(old.get("result"),
                                               ctx.get("result"))
                if _sa:
                    _sa["ts"] = time.time()
                    ctx["stale_alert"] = _sa
                elif old.get("stale_alert") and not got_new:
                    ctx["stale_alert"] = old["stale_alert"]
            # v99fix2: if the merge retracted a wrong returned
            # (XF turned out to be an export gate-in) then the entry
            # marker should also be cleared — otherwise the old True
            # OR-entry would live forever. Identification of retraction:
            # the old result had returned True,
            # in the merged it is False (no other path inside the merge
            # clears returned).
            _retracted = bool((old.get("result") or {}).get(
                "returned")) and not bool(
                    (ctx.get("result") or {}).get("returned"))
            if not ctx.get("carrier"):
                ctx["carrier"] = old.get("carrier")
            if ctx.get("carrier"):
                ctx["carrier"] = ctx["carrier"].replace(
                    " (unverified)", "")
            # Found latch: once an entry has been found, a later
            # empty/failed re-check must never flip it back to
            # not-found (the Recent dot turned red/green). Only the
            # proven prev-trip verdict may clear found, and that
            # path sets it explicitly before this point.
            if old.get("found"):
                ctx["found"] = True
            if old.get("bl_copy"):
                ctx["bl_copy"] = old["bl_copy"]
            if old.get("bl_copy_fields") \
                    and not ctx.get("bl_copy_fields"):
                ctx["bl_copy_fields"] = old["bl_copy_fields"]
            # v119 fix (proven on the v118 QA tour): journey/notebook
            # were being wiped on every re-track — _record was not
            # carrying them. The Note Book prediction's protection
            # also comes from this same carry: the old prediction
            # never becomes a new one.
            if old.get("journey") and not ctx.get("journey"):
                ctx["journey"] = old["journey"]
            if old.get("notebook") and not ctx.get("notebook"):
                ctx["notebook"] = old["notebook"]
            if old.get("vessel_live") and not ctx.get("vessel_live"):
                ctx["vessel_live"] = old["vessel_live"]
            if old.get("route") and not ctx.get("route"):
                ctx["route"] = old["route"]
            if old.get("carrier_check") and not ctx.get("carrier_check"):
                ctx["carrier_check"] = old["carrier_check"]
            # v132: khud-parakh ki halat (chhupaye hue blocks +
            # findings) re-track par zinda rahe — qc loop use
            # dobara parakh kar saaf/durust karta rehta hai
            for _qf in ("qc_hide", "qc_flags", "qc_ts"):
                if old.get(_qf) and not ctx.get(_qf):
                    ctx[_qf] = old[_qf]
            ctx["checklist"] = old.get("checklist", {})
            ctx["notes"] = old.get("notes", "")
            ctx["first_seen"] = old.get("first_seen", date.today().isoformat())
            ctx["photo"] = old.get("photo", "")
            for f in ("client", "amount", "received"):
                if not ctx.get(f):
                    ctx[f] = old.get(f, "")
            # v99: if proof of an actual empty-return has come in the fresh result
            # (the engine wrote from the terminal rows
            # result.returned) then also set the entry marker
            # — the previous flow never wrote this
            # so, even though a return was recorded,
            # 'returned' used to remain empty.
            ctx["returned"] = False if _retracted \
                else (bool(old.get("returned", False))
                      or bool((ctx.get("result") or {}).get("returned")))
            ctx["starred"] = bool(old.get("starred", False))
            old_r = old.get("result") or {}
            new_r = ctx.get("result") or {}
            old_status = old_r.get("status") or ""
            new_status = new_r.get("status") or ""
            old_pos = old_r.get("position") or ""
            new_pos = new_r.get("position") or ""
            # Identify the TYPE of change (v41) — so that the user's
            # own alert rules (idea 22) can decide whether
            # the bell should ring on this change or it should silently
            # just be recorded.
            rules = get_settings().get("alert_rules") or {}
            kind = None
            chg = None
            if (not old_r.get("discharge_time")
                    and new_r.get("discharge_time")):
                kind = "discharge"
                chg = {"time": ctx.get("time", ""),
                       "from": "Not discharged",
                       "to": "Discharged " + str(new_r["discharge_time"])}
            elif (new_r.get("holds") or "") != (old_r.get("holds") or "") \
                    and new_r.get("holds"):
                kind = "hold"
                chg = {"time": ctx.get("time", ""),
                       "from": old_r.get("holds") or "No hold",
                       "to": "Hold: " + str(new_r["holds"])}
            elif (not _status_final(old_r)) and _status_final(new_r):
                kind = "delivered"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status or "In progress",
                       "to": new_status or "Delivered"}
            elif old_status and new_status and old_status != new_status:
                kind = "status"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status, "to": new_status}
            elif (old_r.get("eta") and new_r.get("eta")
                    and old_r["eta"] != new_r["eta"]):
                kind = "eta"
                chg = {"time": ctx.get("time", ""),
                       "from": "ETA " + str(old_r["eta"]),
                       "to": "ETA " + str(new_r["eta"])}
            elif old_pos and new_pos and old_pos != new_pos:
                kind = "position"
                chg = {"time": ctx.get("time", ""),
                       "from": f"Position: {old_pos}",
                       "to": f"Position: {new_pos}"}
            _ov = (old_r.get("vessel") or "").strip()
            _nv = (new_r.get("vessel") or "").strip()
            vchg = None
            if _ov and _nv and _ov.upper() != _nv.upper():
                vchg = {"time": ctx.get("time", ""),
                        "from": "Vessel: " + _ov,
                        "to": "Vessel: " + _nv
                        + " — the previous ETA no longer applies; "
                        "a new ETA will be confirmed"}
            changes = old.get("changes") or []
            if chg:
                changes = ([chg] + changes)[:5]
                ctx["change_kind"] = kind
                # If the rule is off, the change should be recorded but
                # the bell should not ring (nor should the old bell be cleared).
                ctx["changed"] = (True if rules.get(kind, True)
                                  else bool(old.get("changed")))
            else:
                ctx["change_kind"] = old.get("change_kind")
                ctx["changed"] = bool(old.get("changed"))
            ctx["changes"] = changes
            if vchg:
                ctx["changes"] = ([vchg] + (ctx.get("changes")
                                             or []))[:6]
                ctx["changed"] = True
                ctx["change_kind"] = "vessel"
            if _to_staff:
                hist = [h for h in hist
                        if not (h.get("query") == ctx["query"]
                                and h.get("staff_owner")
                                == (ctx.get("staff_owner")
                                    or (old or {}).get("staff_owner")))]
            else:
                hist = [h for h in hist if h.get("query") != ctx["query"]]
        else:
            ctx["checklist"] = {}
            ctx["notes"] = ""
            ctx["first_seen"] = date.today().isoformat()
            ctx["changes"] = []
            ctx["changed"] = False
            _sa = _stale_trip_alert(
                ctx.get("result"), ctx.get("layers"),
                fallback_containers=_result_containers(
                    (old or {}).get("result")))
            if _sa and _sa["kind"] == "prev_trip":
                _sa["ts"] = time.time()
                ctx["stale_alert"] = _sa
                ctx["result"] = {}
                ctx["found"] = False
                ctx["live_ok"] = False
                ctx.pop("live_ts", None)
            elif _sa:
                _sa["ts"] = time.time()
                ctx["stale_alert"] = _sa
            # v99: if proof of return is found on the very first track
            # then set the marker (the same lift as above, for a new
            # record).
            ctx["returned"] = bool((ctx.get("result") or {}).get("returned"))
            ctx["starred"] = False
        # v111 (root of the Recent dots flip): the firm marker of BL verification
        # — once verification is done in a check via the BL/carrier route
        # it becomes permanent for this record;
        # later container-only check layers cannot erase it
        # (otherwise the old record would repeatedly be falsely declared stale
        # and keep turning red/green).
        if _bl_confirmed(ctx.get("layers")) or \
                (old and old.get("bl_confirmed_ever")):
            ctx["bl_confirmed_ever"] = True
        try:
            ctx["milestones"] = _milestones(ctx)
        except Exception:
            ctx["milestones"] = []
        # v114: Emkay/RTW — if no record is found anywhere and the vessel
        # is also not known, then the marker for needing a BL copy
        # (as soon as the copy arrives _bl_copy_needed will clear itself,
        # because bl_copy will exist or the vessel will be filled in).
        try:
            if _bl_copy_needed(ctx.get("carrier"),
                               ctx.get("found"),
                               ctx.get("result"),
                               ctx.get("bl_copy")):
                ctx["bl_copy_needed"] = {"reason": "vessel",
                                         "ts": time.time()}
            else:
                ctx.pop("bl_copy_needed", None)
        except Exception:
            pass
        # v121 Scan Note Book (Yousuf, 6 Nov 2026): on every
        # scan/track, all information coming from the BL is stored in this
        # record's own note book — the choke
        # point is this itself, every path passes through here.
        try:
            _sbk = list((old or {}).get("scanbook") or [])
            ctx["scanbook"] = _sbk
            # v122 Scan Note Book (Yousuf, 7 Nov 2026): entries are
            # made ONLY by a BL copy scan (see /api/bl-copy) — a plain
            # track no longer writes note-book entries. The scan
            # snapshot is carried over untouched.
            if (old or {}).get("scanbook_scan"):
                ctx["scanbook_scan"] = old["scanbook_scan"]
        except Exception:
            pass
        hist.insert(0, ctx)
        # v91 (#3): the voyage format is the SAME in every record —
        # it was scattered in two formats, "102W" and "W102"
        # (the position strip said one thing, the status change said another).
        try:
            _r91 = ctx.get("result") or {}
            _v91 = str(_r91.get("voyage") or "").strip()
            _m91 = re.fullmatch(r"(\d{1,4})([A-Za-z])", _v91)
            if _m91:
                _canon91 = _m91.group(2).upper() + _m91.group(1)
                if _canon91 != _v91:
                    _r91["voyage"] = _canon91
                    for _f91 in ("position", "status"):
                        _fv91 = str(_r91.get(_f91) or "")
                        if ("(" + _v91 + ")") in _fv91:
                            _r91[_f91] = _fv91.replace(
                                "(" + _v91 + ")", "(" + _canon91 + ")")
        except Exception:
            pass
        # v99: the engine's internal markers (veto's
        # provenance / rejected fields) are not part of the stored record
        # — the merge has done their work, now
        # clear them (merge does not run on a new record,
        # otherwise they would be stored there).
        if isinstance(ctx.get("result"), dict):
            ctx["result"].pop("position_via", None)
            ctx["result"].pop("_rejected_fields", None)
            ctx["result"].pop("cycle_closed", None)
            ctx["result"].pop("discharge_unconfirmed", None)
        if _to_staff:
            ctx["staff_owner"] = (ctx.get("staff_owner")
                                  or (old or {}).get("staff_owner")
                                  or "")
            save_json(STAFF_HISTORY_FILE, hist[:1000])
        else:
            ctx.pop("staff_owner", None)
            save_json(HISTORY_FILE, hist[:1000])  # F-11: was a silent 300-entry cap


# ---------------- reports (same generators as the Tk app, web version) -------
def _esc(s):
    return (str(s or "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")



_REPORT_BRANDS = [
    ("maersk", "M", "#2B7FB8"), ("msc", "MSC", "#111111"),
    ("mediterranean", "MSC", "#111111"), ("cosco", "CO", "#00529B"),
    ("oocl", "OO", "#007A3D"), ("cma", "CMA", "#1B2A6B"),
    ("evergreen", "EG", "#006B54"), ("hapag", "HL", "#D14D00"),
    ("ocean network", "ONE", "#B00062"), ("yang ming", "YM", "#AE0F27"),
    ("wan hai", "WH", "#003E73"), ("zim", "ZIM", "#3E1D63"),
    ("emkay", "EM", "#083D6B"), ("rtw", "RTW", "#4C1D95"),
    ("em-a", "EMA", "#92400E"), ("ema", "EMA", "#92400E"),
    ("kict", "KICT", "#115E59"), ("sapt", "SAPT", "#0A5356"),
    ("qict", "QICT", "#172554"), ("pict", "PICT", "#334155"),
]
_REPORT_LOGOS = [
    ("maersk", "maersk.svg"), ("mediterranean", "msc.svg"),
    ("msc", "msc.svg"), ("cosco", "cosco.svg"), ("oocl", "oocl.svg"),
    ("cma", "cma.svg"), ("evergreen", "evergreen.svg"),
    ("hapag", "hapag.svg"), ("ocean network", "one.svg"),
    ("yang ming", "yangming.png"), ("wan hai", "wanhai.png"),
    ("zim", "zim.svg"), ("emkay", "emkay.png"), ("rtw", "rtw.png"),
    ("hyundai", "hmm.svg"), ("hmm", "hmm.svg"),
    ("pacific international", "pil.svg"), ("em-a", "ema.webp"),
    ("rcl", "rcl.png"), ("seagem", "seagem.png"), ("sea gem", "seagem.png"),
    ("kmtc", "kmtc.svg"), ("monter", "monter.png"), ("prolog", "prolog.png"),
    ("feeder", "feeder.png"), ("samudera", "samudera.png"),
    ("kict", "kict.png"), ("sapt", "sapt.png"), ("qict", "qict.png"),
    ("dp world", "qict.png"), ("star lines", "starlines.png"),
    ("baltic", "baltic.png"), ("new golden", "newgoldensea.png"),
]
_REPORT_PALETTE = ["#475569", "#0E7490", "#7C3AED", "#B45309",
                   "#15803D", "#1D4ED8", "#BE185D", "#0F766E"]

def full_report_html(hist):
    _co = (get_settings().get("company_name") or "").strip()
    _co_tag = (get_settings().get("company_tagline") or "").strip()

    def badge(name):
        n = (name or "").lower()
        for key, mono, col in _REPORT_BRANDS:
            if key in n:
                return (f'<span style="display:inline-block;min-width:26px;height:20px;line-height:20px;vertical-align:middle;'
                        f'text-align:center;background:{col};color:#fff;'
                        f'font-weight:600;font-size:9.5px;border-radius:5px;'
                        f'padding:0 5px;margin-right:6px">{mono}</span>')
        words = [w for w in re.split(r"[^A-Za-z]+", name or "") if w]
        mono = ((words[0][0] if words else "C")
                + (words[1][0] if len(words) > 1 else "")).upper()
        col = _REPORT_PALETTE[abs(hash(name or "?")) % len(_REPORT_PALETTE)]
        return (f'<span style="display:inline-block;min-width:26px;height:20px;line-height:20px;vertical-align:middle;'
                f'text-align:center;background:{col};color:#fff;'
                f'font-weight:600;font-size:9.5px;border-radius:5px;'
                f'padding:0 5px;margin-right:6px">{mono}</span>')

    def logo_html(name):
        n = (name or "").lower()
        for key, f in _REPORT_LOGOS:
            if key in n:
                return (f'<img src="/logos/{f}" alt="" style="height:20px;'
                        f'width:auto;max-width:68px;object-fit:contain;'
                        f'vertical-align:middle;margin-right:6px">')
        return badge(name)

    _MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
            "Aug", "Sep", "Oct", "Nov", "Dec"]

    def _eta_fill(h, r):
        cell = _eta_cell(r)
        if cell != "—":
            return cell
        # Complete shipment, ETA/discharged both empty —
        # but VIR is present: that is the terminal's own vessel
        # arrival, write that same date as 'Arrived' and return it.
        m = re.search(r"_(\d{2})(\d{2})(\d{2})\d{6}",
                      str(r.get("vir") or ""))
        if m:
            return (f"Arrived {int(m.group(1))} "
                    f"{_MON[int(m.group(2)) - 1]} 20{m.group(3)}")
        return cell

    def _term_fill(r):
        if r.get("terminal"):
            return r["terminal"]
        vir = str(r.get("vir") or "").upper()
        for t in ("QICT", "KICT", "SAPT", "KGTL"):
            if t in vir:
                return t
        return "—"

    def _pos_fill(r):
        if r.get("position"):
            return r["position"]
        st = (r.get("status") or "").lower()
        if r.get("gate_out") or r.get("returned") \
                or "deliver" in st or st.startswith("released"):
            return "OUT"
        if r.get("discharge_time"):
            return "In Yard"
        if "transit" in st or "departed" in st \
                or "on board" in st:
            return "In Transit"
        return "—"

    def _disch_fill(h, r):
        if r.get("discharge_time"):
            return _fmt_disch(r["discharge_time"])
        for m in (h.get("milestones") or []):
            if isinstance(m, dict) and m.get("key") == "discharged" \
                    and m.get("when"):
                return _fmt_disch(m["when"]) or m["when"]
        return "—"

    def row(h):
        r = h.get("result") or {}
        ok = h.get("found")
        carrier = (h.get("carrier") or "—").replace(" (unverified)", "")
        vessel = r.get("vessel") or "—"
        if r.get("voyage"):
            vessel += f" ({r['voyage']})"
        ctns = ", ".join(r.get("containers") or [])
        status = r.get("status") or "—"
        return (f"<tr><td>{_esc(h.get('time',''))}</td>"
                f"<td><b>{_esc(h.get('query',''))}</b></td>"
                f"<td>{logo_html(h.get('carrier'))}{_esc(carrier)}</td>"
                f"<td title=\"{_esc(vessel)}\">{_esc(vessel)}</td>"
                f"<td title=\"{_esc(ctns or '—')}\">{_esc(ctns or '—')}</td>"
                f"<td>{_eta_fill(h, r)}</td>"
                f"<td>{_esc(_disch_fill(h, r))}</td>"
                f"<td>{_esc(_term_fill(r))}</td>"
                f"<td>{_esc(_pos_fill(r))}</td>"
                f"<td title=\"{_esc(status)}\">{_esc(status)}</td>"
                f"<td>{'✅' if ok else '❌'}</td></tr>")
    found = [h for h in hist if h.get("found")]
    notf = [h for h in hist if not h.get("found")]
    th = ("<tr><th>Time</th><th>BL / Query</th><th>Carrier</th><th>Vessel</th>"
          "<th>Containers</th><th>ETA</th><th>Discharged</th><th>Terminal</th>"
          "<th>Position</th><th>Status</th><th></th></tr>")
    colgroup = ("<colgroup><col style='width:5.5%'><col style='width:10.5%'>"
                "<col style='width:13%'><col style='width:11.5%'>"
                "<col style='width:11%'><col style='width:8.5%'>"
                "<col style='width:7.5%'><col style='width:5%'>"
                "<col style='width:6%'><col style='width:19%'>"
                "<col style='width:2.5%'></colgroup>")
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>CargoTrack — Full Tracking Report</title><style>
body{{text-transform:capitalize}}

body{{font-family:'Segoe UI',Arial,sans-serif;margin:18px;color:#1F2937}}
h1{{color:#5B21B6}} h2{{margin-top:28px}}
table{{border-collapse:collapse;width:100%;table-layout:fixed}}
th{{background:#EDE9FE;color:#5B21B6;text-align:left;padding:5px 6px;font-size:11px;white-space:nowrap;overflow:hidden}}
td{{border-bottom:1px solid #E5E7EB;padding:4px 5px;vertical-align:middle;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}} .muted{{color:#6B7280}}
@page{{size:A4 landscape;margin:8mm}}
@media print{{body{{margin:6px}} td{{font-size:10.5px}} th{{font-size:10.5px}}}}</style></head><body>
<h1>◆ {_esc(_co) + " — " if _co else ""}CargoTrack — Full Tracking Report</h1>{f'<p style="color:#6B7280;margin:2px 0 0">{_esc(_co_tag)}</p>' if _co_tag else ""}
<p class="muted">Generated {_DT(datetime.now())}</p>
<h2>✅ Found ({len(found)})</h2><table>{colgroup}{th}{''.join(row(h) for h in found)}</table>
<h2>❌ Not found ({len(notf)})</h2><table>{colgroup}{th}{''.join(row(h) for h in notf)}</table>
<p class="muted">Tip: Print → Save as PDF to keep a copy.</p></body></html>"""


# ---------------- auto re-check ----------------
def _status_final(result):
    r = result or {}
    st = (r.get("status") or "").lower()
    # v63: only 'delivered' is final — from 'deliver', statuses like 'delivery
    # order' also used to become final and they were
    # never checked again.
    return bool(r.get("gate_out")) or "delivered" in st


def _final_age_days(r):
    """Days since a final record's gate-out (or discharge), parsed from
    the stored display strings. 0 when unparseable — the record then
    stays on the return watch rather than falling off it."""
    import re as _re
    raw = (r.get("gate_out_time") or r.get("gate_out")
           or r.get("discharge_time") or "")
    m = _re.search(r"(\d{1,2})[- ]([A-Za-z]{3})[- ](\d{2,4})", str(raw))
    if not m:
        return 0
    try:
        mon = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug",
               "sep", "oct", "nov", "dec"].index(m.group(2).lower()) + 1
        yr = int(m.group(3))
        if yr < 100:
            yr += 2000
        d = datetime(yr, mon, int(m.group(1))).date()
        return (datetime.now().date() - d).days
    except Exception:
        return 0


def _entry_due(h, now_ts, hrs):
    """Should this entry be tracked again or not?
    The time basis is the last ATTEMPT, not the last verification
    (v96 FIX 3): a record that was just looked at — even if the
    sources gave nothing new — does not immediately become due
    again; previously, on checked_ts, these records kept being
    tried again and again in every cycle."""
    ts = h.get("attempt_ts") or h.get("checked_ts")
    age = (now_ts - float(ts)) if ts else None
    if _status_final(h.get("result")):
        # v122 (Yousuf's order, 7 Nov 2026): 'final' no longer ends the
        # watch. A container's story has one chapter AFTER gate-out —
        # the empty return, which the terminal may post days later
        # (COAU6468022890: returned 3 Nov, never seen because the
        # record left the queue the moment it turned final). Final
        # records whose containers have NOT come back stay on a slow
        # daily watch until the return lands; the watch stops 60 days
        # after gate-out. Returned records rest for good.
        r = h.get("result") or {}
        if h.get("returned") or r.get("returned"):
            return False
        if _final_age_days(r) > 60:
            return False
        return age is None or age >= 24 * 3600
    mult = 0.5 if h.get("starred") else 1.0
    if not h.get("found"):
        # Not-found entries should also be re-checked occasionally (a BL may
        # enter the system later) — but 4 times more slowly.
        return age is None or age >= hrs * 4 * 3600 * mult
    return age is None or age >= hrs * 3600 * mult


_TRACK_EX = ThreadPoolExecutor(max_workers=6,
                                thread_name_prefix="ct-track")


def _track_all_timed(timeout=240, **kw):
    """Run track_all with a strict time limit. A hung
    source cannot block the caller; at the limit, _FutTimeout
    is raised and the caller keeps the old record safe."""
    fut = _TRACK_EX.submit(ENG.track_all, **kw)
    return fut.result(timeout=timeout)


_RECHECK_STATS = {"last_run": 0, "last_cycle": "",
                  "checked": 0, "updated": 0, "cycles": 0,
                  "timeouts": 0}


def _recheck_public():
    try:
        hrs = float(get_settings().get("recheck_hours", 6) or 6)
    except Exception:
        hrs = 6
    return dict(_RECHECK_STATS, hours=hrs)


def _recheck_loop():
    time.sleep(120)  # first check about ~2 minutes after start
    while True:
        try:
            hrs = float(get_settings().get("recheck_hours", 6) or 6)
        except Exception:
            hrs = 6
        try:
            # v96 Data Doctor: in every cycle, one complete
            # local sweep (no network) — catch incorrect data,
            # fix what is proven correct, report the rest to Shezi.
            try:
                _doctor_run("auto")
            except Exception:
                pass
            try:
                _scan_copies_cleanup()
            except Exception:
                pass
            now_ts = time.time()
            due = [h for h in get_history()
                   if h.get("query") and _entry_due(h, now_ts, hrs)]
            # v118 (Yousuf's order, 5 Nov): in-transit Emkay/RTW
            # BLs in the fast queue — separate from the normal
            # schedule (recheck_hours), every ~1 hour (~30 min
            # in the final stage) must be checked, for a prompt voyage update.
            _dueq = {h.get("query") for h in due}
            for h in get_history():
                q = h.get("query")
                if not q or q in _dueq or not _journey_of(h) \
                        or _journey_done(h):
                    continue
                _jr = h.get("journey") or {}
                _tsd = _j_d(_jr.get("ts_date"))
                _fin = bool(_tsd and (_tsd - datetime.now().date()).days
                            <= 4)
                _lim = 1800 if _fin else 3300
                _att = float(h.get("attempt_ts")
                             or h.get("checked_ts") or 0)
                if not _att or now_ts - _att > _lim:
                    due.append(h)
                    _dueq.add(q)
            def _prio(h):
                r = h.get("result") or {}
                # v63 order: first those discharged at the port
                # with gate-out still pending (the real window), then the remaining
                # found ones, and not-found at the end.
                atport = bool(r.get("discharge_time")) \
                    and not _status_final(r)
                # v118: in-transit Emkay/RTW first of all
                _jact = _journey_of(h) and not _journey_done(h)
                return (0 if _jact else (1 if atport else
                        (2 if h.get("found") else 3)),
                        0 if h.get("starred") else 1,
                        float(h.get("attempt_ts")
                              or h.get("checked_ts") or 0))
            due.sort(key=_prio)
            _RECHECK_STATS["cycles"] += 1
            _RECHECK_STATS["last_run"] = int(now_ts)
            _RECHECK_STATS["last_cycle"] = _DT(datetime.fromtimestamp(now_ts))
            for h in due[:11]:
                mode = h.get("mode", "bl")
                _old = h.get("result") or {}
                _oldkey = ((_old.get("status") or ""),
                           (_old.get("gate_out") or ""))
                try:
                    res = _track_all_timed(
                        240,
                        bl=h["query"] if mode == "bl" else None,
                        ctn=h["query"] if mode == "container" else None,
                        vessel_name=h["query"] if mode == "vessel" else None,
                        carrier_hint=h.get("carrier") or None,
                        # v99: stored containers container-legs
                        # to it — even if BL-Inquiry is closed (cycle closed)
                        # the record can still be corrected.
                        known_containers=((h.get("result") or {})
                                          .get("containers")
                                          or None),
                        known_vessel=((h.get("result") or {})
                                      .get("vessel") or None),
                        traqo_key=str(get_settings().get("traqo_key")
                                      or "").strip() or None)
                except _FutTimeout:
                    # v63: a hung source — skip this entry,
                    # keep the old record safe; the loop will move
                    # on (before, it always used to get stuck here).
                    _RECHECK_STATS["timeouts"] += 1
                    continue
                except Exception:
                    continue
                _RECHECK_STATS["checked"] += 1
                ctx = {"query": h["query"], "mode": mode,
                       "client": h.get("client", ""),
                       "carrier": res.get("carrier"),
                       "prefix": res.get("prefix"),
                       "result": res.get("result", {}),
                       "layers": res.get("layers", []),
                       "contacts": res.get("contacts"),
                       "found": bool(res.get("result")),
                       "time": _DT(datetime.now())}
                try:
                    _record(ctx)
                except Exception:
                    continue
                try:
                    _new = next((x for x in get_history()
                                 if x.get("query") == h["query"]), {})
                    _nr = _new.get("result") or {}
                    if ((_nr.get("status") or ""),
                            (_nr.get("gate_out") or "")) != _oldkey:
                        _RECHECK_STATS["updated"] += 1
                except Exception:
                    pass
        except Exception:
            pass
        time.sleep(1200)  # next check after 20 minutes


# ---------------- v96: Data Doctor ----------------
# The user's order (29 Oct 2026): inside the Application, a
# system that IMMEDIATELY identifies wrong/false data, fixes
# what is proven correct by evidence, and reports the rest to Shezi
# so that he can resolve it permanently. Three duties:
#   1. IDENTIFICATION — the proven rules of the data audit (29 Oct) now
#      run in code form on every stored record.
#   2. CORRECTION — only evidence-proven classes (terminal from the VIR,
#      voyage canonical, status up to its own stamped evidence,
#      'Partially' on complete gate-out, the ETA after discharge,
#      departed field, returned mark). Every correction
#      is LOGGED — no change is ever made silently.
#      Uncertain classes (suspected false Delivered, shared
#      container, cross-cycle marks) are NEVER changed
#      by itself — they become findings.
#   3. REPORT — findings + correction log DATA_DIR/
#      remain in doctor_report.json; new findings go into Shezi's
#      queue (dedupe: stable ID — the same finding does
#      not alert again; if values change, the ID changes and
#      a new alert is created) and, at the first opportunity, are sent via the existing
#      Send-to-Shezi (email) route; if email is
#      not set, they stay waiting in the queue — a false
#      'sent' is never claimed.
# The sweep is entirely local: no network call.
DOCTOR_FILE = DATA_DIR / "doctor_report.json"
_DOCTOR_CORR_CAP = 300
_DOCTOR_QUEUE_CAP = 200
_DOCTOR_ALERTED_CAP = 2000


def _dd_now():
    return _DT(datetime.now())


def _dd_fid(query, rule, sig):
    """A finding's stable ID: record + rule + a signature of the
    values the finding is based on. If the values stay the same,
    the ID stays the same — no repeat alert; if they change, a new ID."""
    raw = f"{query}|{rule}|{sig}"
    return "dd_" + hashlib.md5(raw.encode("utf-8")).hexdigest()[:12]


def _doctor_check_entry(h, shared, now_ts):
    """All Data Doctor rules on one stored entry.
    Corrects the entry IN PLACE (only evidence-confirmed
    corrections) and returns (corrections, findings).
    shared = {container: [queries]} — a map of containers
    shared with other entries."""
    corr, finds = [], []
    q = h.get("query") or ""
    r = h.get("result")
    if not h.get("found") or not isinstance(r, dict) or not r:
        return corr, finds
    st = str(r.get("status") or "")
    stl = st.lower()
    tstage = ENG.status_text_stage(st)

    def F(rule, sev, detail, sig):
        finds.append({"id": _dd_fid(q, rule, sig), "query": q,
                      "rule": rule, "severity": sev,
                      "detail": detail, "time": _dd_now()})

    def C(field, before, after, rule):
        corr.append({"query": q, "field": field, "before": before,
                     "after": after, "rule": rule, "time": _dd_now()})

    dis_d = _pdate(r.get("discharge_time"))
    go_d = _pdate(r.get("gate_out"))

    # --- check cross-cycle marks FIRST: raising such a record's
    # status automatically is dangerous (data from another voyage
    # may get attached) — this will only become a finding.
    smell = False
    if r.get("gate_out"):
        eta_d0 = _pdate(r.get("eta"))
        dep_d0 = _pdate(r.get("departed"))
        pos0 = (r.get("position") or "").lower()
        if "loaded on vessel" in pos0 or "in transit" in stl \
                or "at sea" in stl \
                or (eta_d0 and go_d and eta_d0 > go_d) \
                or (dep_d0 and go_d and dep_d0 > go_d):
            smell = True
            F("cross-cycle-smell", "high",
              "Gate-Out Is Stamped But Some Fields Look Like They "
              "Belong To Another Voyage (Status/Position/ETA Do "
              "Not Match This Cycle) — Shezi Should Check.",
              f"go={r.get('gate_out')}|st={st}"
              f"|eta={r.get('eta') or ''}")

    # --- CORRECTION 1: terminal always from the VIR (merge FIX A rule)
    vt = ENG.vir_terminal(r.get("vir"))
    if vt:
        term = (r.get("terminal") or "").strip()
        if term in ("KICT", "SAPT", "QICT", "KGTL") and term != vt:
            r["terminal"] = vt
            C("terminal", term, vt, "terminal-vir")
            m = re.search(r"\bat (KICT|SAPT|QICT|KGTL)\b", st)
            if m and m.group(1) != vt:
                new_st = st[:m.start(1)] + vt + st[m.end(1):]
                r["status"] = new_st
                C("status", st, new_st, "terminal-vir")
                st, stl = new_st, new_st.lower()
                tstage = ENG.status_text_stage(st)
        elif not term:
            r["terminal"] = vt
            C("terminal", "", vt, "terminal-vir")

    # --- SAHI 2: voyage canonical (631W -> W631)
    _bv = r.get("voyage")
    _canon_voyage(r)
    if _bv and r.get("voyage") != _bv:
        C("voyage", _bv, r.get("voyage"), "voyage-canon")

    # --- CORRECTION 3: departed date preserved in its own field
    if not _real(r.get("departed")):
        _dd = ENG.departed_date(st)
        if _dd:
            r["departed"] = _dd
            C("departed", "", _dd, "departed-field")

    # --- CORRECTION 4: raise the status only up to its own stamped evidence
    # (the engine's _reconcile_status rule; a hold is not
    # touched, and not on a record with a cross-cycle smell either —
    # raising it there would mean confirming incorrect data)
    if not smell and "hold" not in stl:
        ev = ENG.status_stage(r)
        if ev > tstage:
            term = (r.get("terminal") or "").strip()
            if ev >= 5:
                new_st = "Released — Delivered"
            elif ev >= 4:
                new_st = "Gate out"
            else:
                new_st = (f"Discharged at {term}" if term
                          else "Discharged")
            if new_st != st:
                r["status"] = new_st
                C("status", st, new_st, "status-evidence")
                st, stl = new_st, new_st.lower()
                tstage = ENG.status_text_stage(st)

    # --- CORRECTION 5: on a complete record, the ETA after discharge
    # is a schedule artifact, not the shipment's ETA
    eta_d = _pdate(r.get("eta"))
    if dis_d and eta_d and eta_d > dis_d and any(
            w in stl for w in ("discharg", "released", "delivered",
                               "gate out", "hold")):
        C("eta", r.get("eta"), "", "eta-after-discharge")
        r.pop("eta", None)

    # --- CORRECTION 6: if the status text itself says the container
    # returned empty, also set the entry's returned mark
    # (the lifecycle actually reads that same field).
    # v99fix3: ONLY when the result itself says returned —
    # otherwise old status text (268607384: 'returned empty
    # to depot 31 Aug 2026', whose return _settle retracted)
    # poisons the entry flag all over again.
    # The result is the source of returned, not the status text.
    if not h.get("returned") and r.get("returned") \
            and ("empty returned" in stl
                 or "returned empty" in stl):
        h["returned"] = True
        C("returned", "", "True", "returned-flag")

    # The actual state after the corrections
    final = bool(r.get("gate_out")) or tstage >= 5

    # --- FINDING: Delivered is claimed, evidence incomplete
    if tstage >= 5 and not r.get("gate_out") \
            and not h.get("live_ok"):
        _strong = (r.get("position") or "").strip().upper() \
            in ("OUT", "GATE OUT", "GATE-OUT") \
            and (r.get("truck") or "").strip().lower() == "delivered"
        F("false-delivered-suspect",
          "medium" if _strong else "high",
          "The Status Says 'Delivered' But There Is No Gate-Out "
          "Date Mark In The Record And This Claim Was Never "
          "Live-Verified — The Container May Actually Still Be "
          "In The Yard. Shezi Should Check In Container Mode.",
          f"st={st}|pos={r.get('position') or ''}"
          f"|dis={r.get('discharge_time') or ''}")

    # --- FINDING: one container, two BLs (always a finding —
    # the data itself cannot tell which BL is the real one)
    for c in r.get("containers") or []:
        cn = str(c or "").strip().upper()
        others = [o for o in shared.get(cn, []) if o != q]
        if cn and others:
            F("shared-container", "high",
              f"Container {cn} Also Appears On These BLs: "
              f"{', '.join(others)} — One Container Cannot "
              f"Belong To Two Shipments.",
              f"c={cn}|others={','.join(others)}")

    # --- FINDING: silence/conflict between holds and status
    holds = r.get("holds")
    if _real(holds) and "hold" not in stl:
        F("holds-silent", "medium",
          f"Holds Are Recorded ({holds}) But The Status Does "
          f"Not Mention Them.",
          f"holds={holds}|st={st}")
    if "hold" in stl and not _real(holds):
        F("hold-no-detail", "medium",
          "The Status Says Hold But The Holds Detail (Holds "
          "Field) Is Empty.",
          f"st={st}")

    # --- FINDING: impossible ordering of dates
    if dis_d and go_d and go_d < dis_d:
        F("date-order", "medium",
          "The Gate-Out Date Is Before The Discharge Date — "
          "One Of The Dates Is Wrong.",
          f"dis={r.get('discharge_time')}|go={r.get('gate_out')}")
    dep_d = _pdate(r.get("departed"))
    if dep_d and dis_d and dis_d < dep_d:
        F("date-order", "medium",
          "The Discharge Date Is Before The Departure "
          "(Departed) Date — One Of The Dates Is Wrong.",
          f"dep={r.get('departed')}"
          f"|dis={r.get('discharge_time')}")

    # --- FINDING: 14+ days since discharge, record not final
    if dis_d and not final:
        days = (date.today() - dis_d).days
        if days >= 14:
            F("stuck-nonfinal", "high" if days >= 60 else "medium",
              f"{days} Days Have Passed Since Discharge But The "
              f"Record Is Still Not Final — Either The Gate-Out "
              f"Was Missed In Capture Or The Container Is Still "
              f"At The Port.",
              f"dis={r.get('discharge_time')}")

    # --- FINDING: basic parts of a discharged record are missing
    if dis_d and not (r.get("terminal") or "").strip():
        F("terminal-missing", "medium",
          "Discharge Is Recorded But The Terminal Name Is "
          "Empty (And There Is No VIR To Fill It From).",
          f"dis={r.get('discharge_time')}")
    if dis_d and not r.get("containers"):
        F("containers-missing", "medium",
          "Discharge Is Recorded But The Containers List Is "
          "Empty.",
          f"dis={r.get('discharge_time')}")
    if dis_d and not (r.get("vessel") or "").strip():
        F("vessel-missing", "minor",
          "The Vessel Name Is Missing On A Found Record.",
          f"dis={r.get('discharge_time')}")

    # --- FINDING: never re-checked / very old check
    if not final:
        if not h.get("attempt_ts") and not h.get("live_ts"):
            F("never-rechecked", "minor",
              "This Record Was Never Checked Again After "
              "Import/Seed.",
              "no-attempt")
        else:
            ats = h.get("attempt_ts") or h.get("checked_ts")
            try:
                if ats and now_ts - float(ats) > 30 * 86400:
                    F("stale-check", "minor",
                      "The Last Check Of This Non-Final Record Is "
                      "More Than 30 Days Old.",
                      f"ts={int(float(ats))}")
            except Exception:
                pass
    return corr, finds


def _doctor_update_report(prev, findings, corrections, records_n,
                          now_ts):
    """Add sweep results to the report — DEDUPE happens here:
    if a finding's stable ID has already been alerted, it does
    not go to the Shezi-queue again; if the underlying values
    change, the ID changes and the finding goes to the queue
    as a new one. Corrections are always logged."""
    prev = prev if isinstance(prev, dict) else {}
    alerted = set(prev.get("alerted_ids") or [])
    queue = list(prev.get("shezi_queue") or [])
    prev_by_id = {f.get("id"): f
                  for f in prev.get("findings") or []}
    for f in findings:
        old = prev_by_id.get(f["id"])
        f["first_seen"] = (old or {}).get("first_seen") \
            or f.get("time") or _dd_now()
        if f["id"] not in alerted:
            alerted.add(f["id"])
            queue.append({"id": f["id"], "query": f["query"],
                          "rule": f["rule"],
                          "severity": f["severity"],
                          "detail": f["detail"],
                          "time": f["time"]})
    log = list(prev.get("corrections") or []) + list(corrections)
    sev_rank = {"high": 0, "medium": 1, "minor": 2}
    findings = sorted(
        findings,
        key=lambda f: (sev_rank.get(f["severity"], 3),
                       f["query"], f["rule"]))
    return {
        "version": 1,
        "last_run": _dd_now(),
        "last_run_ts": now_ts,
        "records": records_n,
        "findings": findings,
        "corrections": log[-_DOCTOR_CORR_CAP:],
        "shezi_queue": queue[-_DOCTOR_QUEUE_CAP:],
        "alerted_ids": sorted(alerted)[-_DOCTOR_ALERTED_CAP:],
        "queued": bool(queue),
        "last_sent": prev.get("last_sent"),
        "last_send_result": prev.get("last_send_result"),
    }


def _doctor_run(source="auto"):
    """Full sweep: run the rules on the raw stored history,
    persist the corrections there, and update the report.
    With source='auto' (re-check loop), the Shezi-queue email
    is also attempted; not in other cases (sending is always
    an explicit action)."""
    with _lock:
        hist = load_json(HISTORY_FILE, [])
        if not isinstance(hist, list):
            hist = []
        now_ts = time.time()
        cmap = {}
        for h in hist:
            if isinstance(h, dict):
                rr = h.get("result") or {}
                for c in rr.get("containers") or []:
                    cn = str(c or "").strip().upper()
                    if cn:
                        cmap.setdefault(cn, set()).add(
                            h.get("query") or "")
        shared = {c: sorted(qs) for c, qs in cmap.items()
                  if len(qs) > 1}
        all_corr, all_finds, changed = [], [], False
        seen_q = {}
        for h in hist:
            if not isinstance(h, dict):
                continue
            q = h.get("query") or ""
            seen_q[q] = seen_q.get(q, 0) + 1
            if q and seen_q[q] > 1:
                all_finds.append({
                    "id": _dd_fid(q, "duplicate-entry",
                                  f"n={seen_q[q]}"),
                    "query": q, "rule": "duplicate-entry",
                    "severity": "medium",
                    "detail": "This number is recorded in the "
                              "history more than once.",
                    "time": _dd_now()})
            c1, f1 = _doctor_check_entry(h, shared, now_ts)
            if c1:
                changed = True
            all_corr += c1
            all_finds += f1
        # Fake fragment entry (2 Nov 2026, Yousuf's report):
        # an entry that is a fragment of a FOUND BL number
        # (it would cut a container-like fragment from the scan BL token
        # and create one — COAU6470268 is actually part of COAU6470268490
        # itself) and is itself not-found — it is not a real
        # shipment — remove the entry, in the correction log.
        try:
            found_qs = set()
            for h2 in hist:
                if isinstance(h2, dict) and h2.get("found"):
                    qq = _sq(str(h2.get("query") or ""))
                    if qq:
                        found_qs.add(qq)
            kept_hist = []
            for h2 in hist:
                q0 = _sq(str(h2.get("query") or "")) \
                    if isinstance(h2, dict) else ""
                if (q0 and isinstance(h2, dict)
                        and not h2.get("found")
                        and re.fullmatch(r"[A-Z]{4}\d{7}", q0)
                        and _iso_ok(q0)
                        and any(q0 != fq and q0 in fq
                                for fq in found_qs)):
                    all_corr.append({
                        "query": h2.get("query"),
                        "field": "entry",
                        "before": "stored (not found)",
                        "after": "removed",
                        "rule": "bl-fragment-entry",
                        "time": _dd_now()})
                    changed = True
                    continue
                kept_hist.append(h2)
            if len(kept_hist) != len(hist):
                hist = kept_hist
        except Exception:
            pass
        if changed:
            save_json(HISTORY_FILE, hist)
        prev = load_json(DOCTOR_FILE, {})
        rep = _doctor_update_report(prev, all_finds, all_corr,
                                    len(hist), now_ts)
        save_json(DOCTOR_FILE, rep)
    if source == "auto" and rep.get("shezi_queue"):
        try:
            _doctor_send_now()
        except Exception:
            pass
    return rep


def _doctor_report_text(rep):
    """Clean text of the report for Shezi (email body)."""
    finds = rep.get("findings") or []
    queue = rep.get("shezi_queue") or []
    lines = ["CargoTrack Data Doctor report — the Application "
             "found these findings itself; whatever was proven "
             "by evidence has been corrected right there (the "
             "correction log is in the report), and Shezi will "
             "provide the permanent fix for the rest.",
             f"Records sweep huwe: {rep.get('records', 0)} · "
             f"Findings: {len(finds)} · "
             f"New (in this report): {len(queue)}",
             ""]
    items = queue or finds
    for it in items:
        lines.append(f"- [{it.get('severity', '')}] "
                     f"{it.get('query', '')} — "
                     f"{it.get('rule', '')}: {it.get('detail', '')}")
    if not items:
        lines.append("(No findings — the data is clean)")
    return "\n".join(lines)


def _doctor_send_now():
    """Send the findings waiting in the queue via the existing
    Send-to-Shezi (Gmail) route. If email is not set, the queue
    stays as it is and the response clearly returns 'not_set' + queued
    — never a false 'sent'."""
    with _lock:
        rep = load_json(DOCTOR_FILE, {})
        queue = list(rep.get("shezi_queue") or [])
    if not queue:
        return {"ok": False, "reason": "nothing_to_send",
                "queued": False}
    res = _send_escalation(
        [{"role": "user", "text": _doctor_report_text(rep)}],
        "Data Doctor — data quality findings")
    with _lock:
        rep = load_json(DOCTOR_FILE, {})
        if res.get("ok"):
            rep["shezi_queue"] = []
            rep["queued"] = False
            rep["last_sent"] = _dd_now()
        else:
            rep["queued"] = True
        rep["last_send_result"] = res
        save_json(DOCTOR_FILE, rep)
    if not res.get("ok"):
        return {"ok": False, "reason": res.get("reason"),
                "queued": True}
    return {"ok": True}


def _doctor_public(rep=None):
    """Response for GET /api/doctor-data: a summary of the report —
    findings (needs-Shezi) and corrections (auto-corrected)
    separately, along with items ready for rail Alerts."""
    rep = rep if isinstance(rep, dict) \
        else load_json(DOCTOR_FILE, {})
    finds = rep.get("findings") or []
    corr = rep.get("corrections") or []
    alerts = []
    for f in finds[:60]:
        alerts.append({
            "q": f["query"],
            "cls": "red" if f["severity"] == "high"
                   else ("amber" if f["severity"] == "medium"
                         else ""),
            "txt": "🩺 Data Doctor: " + f["detail"],
            "t": f.get("first_seen") or f.get("time") or ""})
    return {
        "ok": True,
        "last_run": rep.get("last_run"),
        "counts": {
            "records": rep.get("records", 0),
            "findings": len(finds),
            "corrected_total": len(corr),
            "high": sum(1 for f in finds
                        if f["severity"] == "high"),
            "medium": sum(1 for f in finds
                          if f["severity"] == "medium"),
            "minor": sum(1 for f in finds
                         if f["severity"] == "minor"),
        },
        "findings": finds,
        "needs_shezi": finds,
        "corrected": corr[-50:],
        "queued": bool(rep.get("shezi_queue")),
        "queue_count": len(rep.get("shezi_queue") or []),
        "last_sent": rep.get("last_sent"),
        "last_send_result": rep.get("last_send_result"),
        "alerts": alerts,
    }


# ---------------- HTTP ----------------
MIME = {".html": "text/html; charset=utf-8", ".png": "image/png",
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml",
        ".webp": "image/webp",
        ".json": "application/json; charset=utf-8"}


# ---------------- v50: latest-version check (Item 14) ----------------
_VER_CACHE = {"t": 0.0, "latest": None}
_VERSION_URL = ("https://raw.githubusercontent.com/"
                "cargotrack-app/cargotrack-app/main/version.txt")


def _latest_version():
    """Newest published CargoTrack version, or None when unknown.

    Cached: 6 hours after a successful read, 10 minutes after a
    failure — fail-silent by design: any network problem simply
    leaves the UI showing the running version on its own.
    """
    now = time.time()
    ttl = 6 * 3600 if _VER_CACHE["latest"] is not None else 600
    if now - _VER_CACHE["t"] < ttl and _VER_CACHE["t"]:
        return _VER_CACHE["latest"]
    latest = None
    try:
        import urllib.request as _u
        req = _u.Request(_VERSION_URL,
                         headers={"User-Agent": "CargoTrack/" + str(APP_VERSION)})
        with _u.urlopen(req, timeout=4) as resp:
            txt = resp.read().decode("utf-8", "replace")
        m = re.search(r"\d+", txt)
        if m:
            latest = int(m.group())
    except Exception:
        latest = None
    _VER_CACHE.update(t=now, latest=latest)
    return latest


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8",
              headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        # v110 (Yousuf, 3 Nov): send large text responses (the page itself,
        # history JSON) gzipped — the first load on a phone is
        # many times lighter (1.5MB page -> ~350KB).
        _enc = []
        try:
            if (len(body) > 1024
                    and "gzip" in (self.headers.get("Accept-Encoding")
                                   or "")
                    and any(t in ctype for t in
                            ("text/", "json", "javascript", "css"))):
                import gzip as _gz
                body = _gz.compress(body, 6)
                _enc = [("Content-Encoding", "gzip"),
                        ("Vary", "Accept-Encoding")]
        except Exception:
            _enc = []
        self.send_response(code)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or []) + _enc:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            n = 0  # F-15: a malformed header must not kill the handler
        n = max(0, min(n, 32 * 1024 * 1024))
        raw = self.rfile.read(n) if n else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    # ---- v48 auth helpers ----
    def _cookie_token(self):
        raw = self.headers.get("Cookie") or ""
        for part in raw.split(";"):
            part = part.strip()
            if part.startswith("ct_sess="):
                return part[len("ct_sess="):]
        return ""

    def _client_ip(self):
        try:
            return self.client_address[0]
        except Exception:
            return ""

    def _auth_state(self):
        """None = locked out; "unlocked" = no password set;
        otherwise the caller's session token-hash. Also touches the
        session's last_seen (throttled inside _touch_session)."""
        if not _app_pass_hash():
            return "unlocked"
        tok = self._cookie_token()
        if not tok:
            return None
        th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
        with _lock:
            known = th in _load_sessions()["sessions"]
        if not known:
            return None
        _touch_session(th, self.headers.get("User-Agent") or "",
                       self._client_ip())
        return th

    def _locked_out(self, p):
        """True (and a denial response already sent) when this request
        must not proceed. The denial is a 401 JSON — the client turns
        a 401 on its data calls into a full reload, and the server
        then serves the login page for GET /."""
        self._send(401, {"error": "locked"})
        return True

    # ---- v110: staff roles ----
    # Admin = the app password (or no password set at all);
    # staff = a named staff login. Sessions created before
    # v110 carry no role and count as admin.
    STAFF_BLOCKED_GET = frozenset({
        "/api/sessions", "/api/backup", "/api/doctor-data",
        "/api/staff-users", "/api/staff-activity",
        "/api/staff-scanbooks"})
    STAFF_BLOCKED_POST = frozenset({
        "/api/settings", "/api/password", "/api/sessions/kick",
        "/api/sessions/kick_all", "/api/sync/make-hub",
        "/api/sync/set-client", "/api/sync/leave", "/api/sync/now",
        "/api/history/delete", "/api/history/update",
        "/api/doctor-data", "/api/photo", "/api/profile/photo",
        "/api/escalate", "/api/staff-users",
        "/api/staff-activity/clear", "/api/carrier-check"})

    def _who(self, auth):
        """(role, name) for this request."""
        if not auth or auth == "unlocked":
            return ("admin", "")
        with _lock:
            s = _load_sessions()["sessions"].get(auth) or {}
        if s.get("role") == "staff":
            return ("staff", str(s.get("name") or ""))
        return ("admin", "")

    def _staff_denied(self, auth, p, blocked):
        """True (403 already sent) when a staff session tries an
        admin-only route. The block lives here, on the server —
        hidden buttons in the UI are only the visible half."""
        role, _n = self._who(auth)
        if role == "staff" and p in blocked:
            self._send(403, {"error": "staff accounts cannot do this"})
            return True
        return False

    # ---- v98 Stage B: sync routes ----
    # The token alone protects these — they have nothing to do
    # with the browser session/lock (even if the hub has an app password,
    # joined copies connect via the token). Wrong/missing token
    # = 401; hub not enabled on this copy = 403.
    def _sync_gate(self, u=None):
        if _sync_role() != "hub" \
                or not str(get_settings().get("sync_token_hash") or ""):
            self._send(403, {"error": "sync hub is not enabled "
                                      "on this copy"})
            return False
        tok = self.headers.get("X-Sync-Token") or ""
        if not tok and u is not None:
            tok = (parse_qs(u.query).get("token") or [""])[0]
        if not _sync_token_ok(tok):
            self._send(401, {"error": "bad sync token"})
            return False
        return True

    def _carrier_check_save(self):
        """Store a carrier-website check on a record (Yousuf, 8 Nov
        2026: jo check Shezi apne browser se carrier ki site par
        kare, us ka natija card par mehfooz ho). Some carrier sites
        sit behind human CAPTCHAs that no server program can pass;
        the check is done in a real browser and lands here as an
        evidence layer — it never overwrites the engine's own
        result. Access: the hub sync token, or an admin session."""
        tok = self.headers.get("X-Sync-Token") or ""
        ok = _sync_role() == "hub" and _sync_token_ok(tok)
        if not ok:
            auth = self._auth_state()
            if auth is not None:
                role, _nm = self._who(auth)
                ok = role == "admin"
        if not ok:
            return self._send(401, {"error": "not authorized"})
        b = self._body()
        q = str(b.get("query") or "").strip().upper()
        chk = b.get("check") or {}
        if not q or not isinstance(chk, dict) or not chk.get("carrier"):
            return self._send(400, {"error": "query + check.carrier "
                                            "required"})
        keep = {}
        for k in ("carrier", "status", "status_date", "pol", "pod",
                  "vessel", "voyage", "onboard", "ts_port", "ts_vessel",
                  "ts_etd", "eta", "total", "checked", "by"):
            if chk.get(k):
                keep[k] = str(chk[k])[:200]
        evs = []
        for ev in (chk.get("events") or [])[:12]:
            if isinstance(ev, dict) and (ev.get("text") or
                                         ev.get("date")):
                evs.append({"date": str(ev.get("date") or "")[:40],
                            "text": str(ev.get("text") or "")[:220],
                            "place": str(ev.get("place") or "")[:120]})
        keep["events"] = evs
        # Date/time standard (Yousuf, 8 Nov 2026): jo check save ho
        # wo pehle se DD-MMM-YYYY + 12h AM/PM mein ho.
        for _dk in ("eta", "ts_etd", "onboard", "status_date", "checked"):
            if keep.get(_dk):
                keep[_dk] = _dtfmt_s(keep[_dk])
        for _ev in evs:
            if _ev.get("date"):
                _ev["date"] = _dtfmt_s(_ev["date"])
        keep["ts"] = time.time()
        with _lock:
            hist = get_history()
            hit = None
            for e in hist:
                if str(e.get("query") or "").upper() == q:
                    hit = e
                    break
            if hit is None:
                return self._send(404, {"error": "record not found"})
            hit["carrier_check"] = keep
            save_json(HISTORY_FILE, hist[:1000])
        return self._send(200, {"ok": True, "query": q})

    def _sync_pull(self, u):
        if not self._sync_gate(u):
            return
        try:
            since = float((parse_qs(u.query).get("since")
                           or ["0"])[0])
        except (TypeError, ValueError):
            since = 0.0
        with _lock:
            _sync_note_peer(self.headers.get("X-Sync-Client") or "",
                            self.headers.get("X-Sync-Label") or "")
            snap = _sync_snapshot(since)
        return self._send(200, snap)

    def _sync_join(self):
        if not self._sync_gate():
            return
        b = self._body()
        with _lock:
            _sync_note_peer(str(b.get("client_id") or ""),
                            str(b.get("label") or ""))
            snap = _sync_snapshot(0.0)
        return self._send(200, snap)

    def _sync_push(self):
        if not self._sync_gate():
            return
        b = self._body()
        recs_in = b.get("records") or []
        tombs_in = b.get("tombstones") or []
        with _lock:
            _sync_note_peer(str(b.get("client_id") or ""),
                            str(b.get("label") or ""))
            _sync_stamp_core(mark_clean=True)
            _sync_apply_profile(b.get("profile"))
            _sync_apply_staff(b.get("staff"))
            hist = get_history()
            _sync_apply(hist, recs_in, tombs_in)
            save_json(HISTORY_FILE, hist[:1000])
            # of what was sent, whatever turned out different on the hub
            # is returned — so the sender also becomes the same at once
            by_q = {h.get("query"): h for h in hist}
            st = _sync_state()
            tombs = {t.get("query"): t for t in st["tombstones"]}
            back, back_t = [], []
            for rec in recs_in:
                q = (rec or {}).get("query")
                if not q:
                    continue
                cur = by_q.get(q)
                if cur is None:
                    if q in tombs:
                        back_t.append(tombs[q])
                elif _sync_rec_hash(cur) != _sync_rec_hash(rec):
                    back.append(cur)
            # hub's baseline = current state (the stamp pass
            # must not impose a new ts on these)
            st["last_sent"] = {h.get("query"): _sync_rec_hash(h)
                               for h in hist if h.get("query")}
            _sync_state_save(st)
            out = {"ok": True, "records": back,
                   "tombstones": back_t,
                   "profile": _sync_profile_payload(),
                   "staff": _sync_staff_payload(),
                   "max_ts": float(st.get("max_ts") or 0)}
        return self._send(200, out)

    def _sync_photos_list(self, u):
        # v131: names of the scan photos this (hub) copy holds.
        if not self._sync_gate(u):
            return
        names = []
        try:
            for f in _scan_copies_dir().iterdir():
                if f.is_file() and re.fullmatch(
                        r"[A-Z0-9]+\.(jpg|png)", f.name):
                    names.append(f.name)
        except Exception:
            pass
        return self._send(200, {"names": sorted(names)})

    def _sync_photo_get(self, u):
        # v131: one scan photo, base64 inside JSON like the rest of
        # sync — only for a valid sync token.
        if not self._sync_gate(u):
            return
        import base64
        name = (parse_qs(u.query).get("name") or [""])[0]
        if not re.fullmatch(r"[A-Z0-9]+\.(jpg|png)", name):
            return self._send(400, {"error": "bad photo name"})
        f = _scan_copies_dir() / name
        if not f.exists():
            return self._send(404, {"error": "no such photo"})
        try:
            raw = f.read_bytes()
        except Exception:
            return self._send(404, {"error": "no such photo"})
        return self._send(200, {
            "name": name,
            "data": base64.b64encode(raw).decode("ascii")})

    def _sync_photo_post(self):
        # v131: a joined copy uploads a scan photo the hub lacks.
        if not self._sync_gate():
            return
        import base64
        b = self._body()
        name = str(b.get("name") or "")
        if not re.fullmatch(r"[A-Z0-9]+\.(jpg|png)", name):
            return self._send(400, {"error": "bad photo name"})
        try:
            raw = base64.b64decode(str(b.get("data") or ""))
        except Exception:
            return self._send(400, {"error": "bad photo data"})
        if not raw or len(raw) > 4_200_000:
            return self._send(400, {"error": "photo size out of range"})
        with _lock:
            _sync_note_peer(str(b.get("client_id") or ""),
                            str(b.get("label") or ""))
            f = _scan_copies_dir() / name
            if not f.exists() or f.stat().st_size != len(raw):
                f.write_bytes(raw)
        return self._send(200, {"ok": True})

    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        # v48: the app logo stays public — the login page shows it.
        if p == "/logos/ct-logo.png":
            f = BASE / "logos" / "ct-logo.png"
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME[".png"])
            return self._send(404, {"error": "no logo"})
        if p in ("/favicon.svg", "/favicon.ico", "/favicon.png"):
            # Tab icon per copy: the hub (public IP host) gets the IP mark;
            # any other host (laptop / local) gets the ZIP mark.
            # Real ICO/PNG files are also kept — some browsers do not pick up SVG icons.
            host = (self.headers.get("Host") or "").split(":")[0]
            stem = "favicon_ip" if host == "141.145.152.85" else "favicon_zip"
            ext, mime = (".ico", "image/x-icon") if p.endswith(".ico") else (".png", "image/png") if p.endswith(".png") else (".svg", "image/svg+xml")
            f = BASE / "static" / (stem + ext)
            if f.is_file():
                return self._send(200, f.read_bytes(), mime)
            return self._send(404, {"error": "no icon"})
        # PWA: manifest + service worker + app icons (public —
        # must also be available before login for installation).
        if p == "/manifest.webmanifest":
            f = BASE / "manifest.webmanifest"
            if f.is_file():
                return self._send(200, f.read_bytes(),
                                  "application/manifest+json")
            return self._send(404, {"error": "no manifest"})
        if p == "/sw.js":
            f = BASE / "sw.js"
            if f.is_file():
                return self._send(200, f.read_bytes(), "text/javascript")
            return self._send(404, {"error": "no sw"})
        if p in ("/icon-192.png", "/icon-512.png"):
            f = BASE / "static" / p[1:]
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME[".png"])
            return self._send(404, {"error": "no icon"})
        if p == "/api/sync/pull":
            return self._sync_pull(u)
        if p == "/api/sync/photos":
            return self._sync_photos_list(u)
        if p == "/api/sync/photo":
            return self._sync_photo_get(u)
        auth = self._auth_state()
        if p == "/" or p == "/index.html":
            if auth is None:
                # locked and not signed in -> the login page
                return self._send(200, LOGIN_HTML, MIME[".html"])
            f = BASE / "static" / "index.html"
            return self._send(200, f.read_bytes(), MIME[".html"])
        if p.startswith("/avatar/"):
            name = p.rsplit("/", 1)[-1]
            if name in ("hatch.jpg", "hatch.mp4", "hatch_working.mp4",
                        "hatch_making_something.mp4",
                        "hatch_milestone_level_up.mp4",
                        "hatch-call-light-idle.mp4"):
                f = BASE / "avatar" / name
                if f.exists():
                    mime = "video/mp4" if name.endswith(".mp4") else "image/jpeg"
                    return self._send(200, f.read_bytes(), mime)
            return self._send(404, {"error": "no avatar"})
        if auth is None:
            return self._locked_out(p)
        if self._staff_denied(auth, p, self.STAFF_BLOCKED_GET):
            return
        if p == "/profile/photo":
            # v96 Profile photo (DATA_DIR file) — only for a signed-in session.
            f = _profile_photo_path()
            if f is None:
                return self._send(404, {"error": "no profile photo"})
            mime = {".jpg": "image/jpeg", ".png": "image/png",
                    ".webp": "image/webp"}[f.suffix]
            return self._send(200, f.read_bytes(), mime)
        if p == "/api/scan-copy":
            # Scan Note Book photo — only for a signed-in session.
            _sbq = re.sub(r"[^A-Z0-9]", "",
                          (parse_qs(u.query).get("bl")
                           or [""])[0].upper())
            _scrole, _scnm = self._who(auth)
            if _scrole == "staff" and _staff_access(_scnm) == "own" \
                    and _sbq not in {
                        re.sub(r"[^A-Z0-9]", "",
                               str(h.get("query") or "").upper())
                        for h in _staff_own_entries(_scnm)}:
                return self._send(404, {"error": "no scan copy"})
            _sf2 = None
            for _ext in (".jpg", ".png"):
                _cand = _scan_copies_dir() / (_sbq + _ext)
                if _cand.exists():
                    _sf2 = _cand
                    break
            if _sf2 is None:
                return self._send(404, {"error": "no scan copy"})
            return self._send(200, _sf2.read_bytes(),
                              "image/png" if _sf2.suffix == ".png"
                              else "image/jpeg")
        if p == "/api/sessions":
            d = _load_sessions()
            sess = []
            for th, s in sorted(
                    d["sessions"].items(),
                    key=lambda kv: kv[1].get("created", 0), reverse=True):
                sess.append({
                    "id": th[:10],
                    "who": (str(s.get("name")) + " (Staff)")
                           if s.get("role") == "staff" else "Admin",
                    "device": device_label(s.get("ua", "")),
                    "ua": s.get("ua", ""),
                    "ip": s.get("ip", ""),
                    "created": s.get("created"),
                    "last_seen": max(float(s.get("last_seen") or 0),
                                     _SESS_SEEN.get(th, 0)),
                    "current": th == auth,
                    "tag": _sess_tag(s, th == auth)})
            atts = [{"ts": a.get("ts"), "ip": a.get("ip", ""),
                     "device": device_label(a.get("ua", "")),
                     "ok": bool(a.get("ok"))}
                    for a in d["attempts"][-15:]][::-1]
            return self._send(200, {
                "locked": bool(_app_pass_hash()),
                "count": len(sess), "sessions": sess, "attempts": atts})
        if p == "/api/whoami":
            # v110: the client asks who it is, so a staff session
            # can hide the admin-only controls (the server still
            # blocks the actions themselves).
            role, nm = self._who(auth)
            return self._send(200, {"role": role, "name": nm,
                                    "locked": bool(_app_pass_hash())})
        if p == "/api/staff-scanbooks":
            # Admin only (staff blocked above): the staff members'
            # Scan Note Book entries, so the admin can see every
            # staff note book in full (Yousuf, 7 Nov 2026).
            _out = []
            try:
                for _h in _get_staff_history():
                    _ss = _h.get("scanbook_scan")
                    if _ss:
                        _out.append({
                            "staff": _h.get("staff_owner") or "",
                            "query": _h.get("query") or "",
                            "scanbook_scan": _ss})
            except Exception:
                pass
            return self._send(200, {"books": _out})
        if p == "/api/staff-users":
            # Admin only — staff sessions were denied above.
            # online = actual presence: a staff session under this name
            # has been active in the last 15 minutes. Merely having the account
            # enabled is NOT "Active" (Yousuf, 6 Nov 2026).
            _now = time.time()
            _seen = {}
            try:
                for _th, _sv in (_load_sessions().get("sessions")
                                 or {}).items():
                    if _sv.get("role") != "staff":
                        continue
                    _nm = str(_sv.get("name") or "").lower()
                    _ls = max(_SESS_SEEN.get(_th, 0),
                              _sv.get("last_seen") or 0)
                    if _ls > _seen.get(_nm, 0):
                        _seen[_nm] = _ls
            except Exception:
                _seen = {}
            return self._send(200, {"users": [
                {"name": x.get("name"),
                 "access": ("own" if str(x.get("access") or "")
                            == "own" else "full"),
                 "disabled": bool(x.get("disabled")),
                 "created": x.get("created"),
                 "online": bool(
                     _now - _seen.get(str(x.get("name") or "").lower(),
                                      0) <= 900)}
                for x in _staff_users()]})
        if p == "/api/staff-activity":
            # Admin only — staff sessions were denied above.
            d = load_json(STAFF_ACTIVITY_FILE, [])
            if not isinstance(d, list):
                d = []
            return self._send(200, {"lines": list(reversed(d[-200:]))})
        if p == "/demo.html":
            f = BASE / "static" / "demo.html"
            if f.exists():
                return self._send(200, f.read_bytes(), MIME[".html"])
            return self._send(404, {"error": "no demo"})
        if p.startswith("/vendor/"):
            # v96: capture libraries vendored locally (no CDN dependency —
            # a blocked CDN used to kill every Pdf/Jpg button at once).
            name = Path(p).name
            if name in ("html2canvas.min.js", "jspdf.umd.min.js",
                        "pdf.min.js", "pdf.worker.min.js"):
                f = BASE / "static" / "vendor" / name
                if f.is_file():
                    return self._send(200, f.read_bytes(), "text/javascript")
            return self._send(404, {"error": "no vendor"})
        if p.startswith("/logos/"):
            f = (BASE / "logos" / Path(p).name)
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME.get(f.suffix, "image/png"))
            return self._send(404, {"error": "no logo"})
        if p.startswith("/photos/"):
            f = (PHOTOS_DIR / Path(p).name)
            if f.is_file():  # F-16: ".." resolved to the dir itself and crashed read_bytes
                return self._send(200, f.read_bytes(),
                                  MIME.get(f.suffix.lower(), "image/jpeg"))
            return self._send(404, {"error": "no photo"})
        if p == "/api/version":
            return self._send(200, {"app": APP_VERSION,
                                    "built": APP_BUILT,
                                    "latest": _latest_version()})
        if p == "/api/sync/status":
            return self._send(200, _sync_public())
        if p == "/api/weather":
            # v98 (S3): the SERVER contract for top-bar weather.
            # (up to v97 there was no server endpoint at all — the widget
            # fetched Open-Meteo directly from the browser and
            # the localStorage cache rendered without any check:
            # the icon would appear, temperature text missing.)
            # Rule: with success (ok:True), an actual numeric
            # temp is MANDATORY; if no data, a clear ok:False —
            # never an empty success-shaped payload, so that
            # the UI can honestly hide the capsule.
            w = _wx_fetch("Karachi")
            if not w or w.get("temp") is None:
                return self._send(200, {"ok": False,
                                        "error": "weather "
                                                 "unavailable"})
            return self._send(200, {"ok": True,
                                    "city": w.get("name"),
                                    "temp": w.get("temp"),
                                    "code": w.get("code"),
                                    "hum": w.get("hum"),
                                    "wind": w.get("wind")})
        if p == "/api/ocr/setup-status":
            return self._send(200, _ocr_setup_status())
        if p == "/api/doctor-data":
            return self._send(200, _doctor_public())
        if p == "/api/history":
            _hrole, _hnm = self._who(auth)
            _own_only = (_hrole == "staff"
                         and _staff_access(_hnm) == "own")
            hist60 = [] if _own_only else get_history()
            for _h60 in hist60:
                try:
                    _h60["milestones"] = _milestones(_h60)
                except Exception:
                    _h60["milestones"] = []
                try:
                    _h60["lifecycle"] = _lifecycle(_h60)
                except Exception:
                    _h60["lifecycle"] = {"stage": "active",
                                         "empty_certainty": "none",
                                         "gate_out": "",
                                         "gate_out_certainty": "none",
                                         "empty": "pending"}
            if _hrole == "staff":
                _main_qs = {h.get("query") for h in hist60}
                for _sh in _get_staff_history():
                    if _sh.get("staff_owner") != _hnm \
                            or _sh.get("query") in _main_qs:
                        continue
                    try:
                        _sh["milestones"] = _milestones(_sh)
                    except Exception:
                        _sh["milestones"] = []
                    try:
                        _sh["lifecycle"] = _lifecycle(_sh)
                    except Exception:
                        _sh["lifecycle"] = {"stage": "active",
                                            "empty_certainty": "none",
                                            "gate_out": "",
                                            "gate_out_certainty": "none",
                                            "empty": "pending"}
                    _sh["staff_own"] = True
                    hist60.append(_sh)
                hist60.sort(key=lambda h: (h.get("attempt_ts")
                                           or h.get("checked_ts")
                                           or 0), reverse=True)
            return self._send(200, {"history": hist60,
                                    "settings": _public_settings(),
                                    "recheck": _recheck_public(),
                                    "carriers": sorted(set(ENG.CARRIERS.values()))})
        if p == "/api/job":
            jid = (parse_qs(u.query).get("id") or [""])[0]
            job = JOBS.get(jid)
            if not job:
                return self._send(404, {"error": "job not found"})
            return self._send(200, {"done": job["done"], "current": job["current"],
                                    "events": job["events"],
                                    "results": job["results"]})
        if p == "/api/report/full":
            _rrole, _rnm = self._who(auth)
            if _rrole == "staff" and _staff_access(_rnm) == "own":
                return self._send(200, full_report_html(
                    _staff_own_entries(_rnm)), MIME[".html"])
            return self._send(200, full_report_html(get_history()), MIME[".html"])
        if p == "/api/backup":
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                if HISTORY_FILE.exists():
                    z.write(HISTORY_FILE, HISTORY_FILE.name)
                if SETTINGS_FILE.exists():
                    # F-13 fix (v46 audit): the backup used to ship the
                    # plaintext AI key to anyone on the LAN who asked.
                    # The key is stripped from the backup copy; it can
                    # be re-entered in Settings after a restore.
                    safe = {k: v for k, v in load_json(SETTINGS_FILE, {}).items()
                            if k not in ("ai_key", "gemini_key", "groq_key", "app_pass", "traqo_key", "mail_pass")}
                    z.writestr(SETTINGS_FILE.name,
                               json.dumps(safe, ensure_ascii=False, indent=1))
                if PHOTOS_DIR.exists():
                    for pf in sorted(PHOTOS_DIR.iterdir()):
                        if pf.is_file():
                            z.write(pf, f"photos/{pf.name}")
            data = buf.getvalue()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition",
                             'attachment; filename="cargotrack_backup.zip"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        p = u.path
        # v98 Stage B: sync routes before the session lock — their
        # protection is the sync token (just like the hub).
        if p == "/api/sync/join":
            return self._sync_join()
        if p == "/api/sync/push":
            return self._sync_push()
        if p == "/api/sync/photo":
            return self._sync_photo_post()
        if p == "/api/carrier-check":
            return self._carrier_check_save()
        if p == "/api/login":
            # the only API route open while locked — it IS the key.
            b = self._body()
            stored = _app_pass_hash()
            if not stored:
                return self._send(400, {"error": "no password set"})
            ua = self.headers.get("User-Agent") or ""
            ip = self._client_ip()
            if b.get("staff"):
                # v110 staff sign-in: own name + own password.
                user = _staff_find(b.get("name"))
                if user is None or not _verify_pass(
                        str(b.get("password") or ""),
                        str(user.get("pass") or "")):
                    _record_attempt(ip, ua, False)
                    return self._send(401, {"error": "wrong password"})
                if user.get("disabled"):
                    _record_attempt(ip, ua, False)
                    return self._send(403, {"error": "disabled"})
                _record_attempt(ip, ua, True)
                token = _create_session(ua, ip, role="staff",
                                        name=str(user.get("name")))
                _staff_log(str(user.get("name")), ip, "Signed in")
                return self._send(200, {"ok": True},
                                  headers=[("Set-Cookie",
                                            _sess_cookie(token))])
            if not _verify_pass(str(b.get("password") or ""), stored):
                _record_attempt(ip, ua, False)
                return self._send(401, {"error": "wrong password"})
            _record_attempt(ip, ua, True)
            token = _create_session(ua, ip)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _sess_cookie(token))])
        auth = self._auth_state()
        if auth is None:
            return self._locked_out(p)
        b = self._body()
        if self._staff_denied(auth, p, self.STAFF_BLOCKED_POST):
            return
        if p == "/api/logout":
            tok = self._cookie_token()
            if tok:
                th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
                with _lock:
                    d = _load_sessions()
                    d["sessions"].pop(th, None)
                    _save_sessions(d)
                _SESS_SEEN.pop(th, None)
                _SESS_WRITTEN.pop(th, None)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/password":
            if b.get("remove") is True:
                # v51: remove the app lock — delete the password hash
                # and clear all saved sessions. The caller
                # is already authenticated (this route is behind
                # the lock gate). The set/change path below
                # is exactly the same as it was before.
                s = get_settings()
                s.pop("app_pass", None)
                if not save_json(SETTINGS_FILE, s):
                    return self._send(500, {"error": "could not save"})
                with _lock:
                    d = _load_sessions()
                    d["sessions"] = {}
                    _save_sessions(d)
                _SESS_SEEN.clear()
                _SESS_WRITTEN.clear()
                return self._send(200, {"ok": True},
                                  headers=[("Set-Cookie",
                                            _SESS_COOKIE_CLEAR)])
            new = str(b.get("new") or "")
            if len(new) < 6:
                return self._send(400, {
                    "error": "Password must be at least 6 characters"})
            stored = _app_pass_hash()
            if stored and not _verify_pass(str(b.get("current") or ""),
                                           stored):
                return self._send(401, {"error": "wrong password"})
            s = get_settings()
            s["app_pass"] = _make_pass_hash(new)
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            if not stored:
                # First password ever: sign this browser in right away
                # so the owner is not locked out of his own app.
                token = _create_session(
                    self.headers.get("User-Agent") or "", self._client_ip())
                return self._send(200, {"ok": True, "first": True},
                                  headers=[("Set-Cookie",
                                            _sess_cookie(token))])
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick":
            kid = str(b.get("id") or "")
            if not kid:
                return self._send(400, {"error": "no session id"})
            with _lock:
                d = _load_sessions()
                target = next((k for k in d["sessions"]
                               if k.startswith(kid)), None)
                if target is None:
                    return self._send(404, {"error": "session not found"})
                if target == auth:
                    return self._send(400, {
                        "error": "That is this browser — use Log out"})
                d["sessions"].pop(target, None)
                _save_sessions(d)
            _SESS_SEEN.pop(target, None)
            _SESS_WRITTEN.pop(target, None)
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick_all":
            with _lock:
                d = _load_sessions()
                d["sessions"] = {}
                _save_sessions(d)
            _SESS_SEEN.clear()
            _SESS_WRITTEN.clear()
            return self._send(200, {"ok": True, "reload": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/assistant":
            q = (b.get("q") or "").strip()
            if not q:
                return self._send(400, {"error": "empty question"})
            _arole, _anm = self._who(auth)
            _ASSISTANT_SCOPE.hist = (
                _staff_own_entries(_anm)
                if _arole == "staff" and _staff_access(_anm) == "own"
                else None)
            try:
                try:
                    return self._send(200, assistant_answer(
                        q, b.get("history"), b.get("attach")))
                except Exception as e:
                    return self._send(200, {"answer":
                        "Something went wrong while checking: "
                        + str(e), "actions": []})
            finally:
                _ASSISTANT_SCOPE.hist = None
        if p == "/api/escalate":
            return self._send(200, _send_escalation(
                b.get("turns"), str(b.get("title") or "")))
        if p == "/api/ping":
            return self._send(200, {"v": APP_VERSION})
        if p == "/api/doctor":
            q = str(b.get("q") or "")
            if not q.strip():
                return self._send(400, {"error": "empty"})
            return self._send(200, doctor_number(q))
        if p == "/api/doctor-data":
            # v96 Data Doctor: with no action = run the sweep now
            # run; action='send' = send the queue to Shezi
            # (if email is not set, it stays queued).
            if (b.get("action") or "") == "send":
                res = _doctor_send_now()
                return self._send(200, dict(
                    _doctor_public(), send=res))
            rep = _doctor_run("manual")
            return self._send(200, _doctor_public(rep))
        if p == "/api/transcribe":
            import base64
            data = b.get("data") or ""
            _mime = ""
            if data.startswith("data:"):
                _mime = data[5:].split(";", 1)[0].strip().lower()
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=False)
            except Exception:
                return self._send(400, {"error": "bad audio"})
            if len(raw) > 12 * 1024 * 1024:
                return self._send(400, {"error": "recording too long"})
            if len(raw) < 800:
                return self._send(200, {"ok": False, "error":
                    "Recording too short — speak the number clearly."})
            ok, val = _transcribe_audio(raw, _mime)
            return self._send(200, {"ok": True, "text": val} if ok
                              else {"ok": False, "error": val})
        if p == "/api/track":
            items = [ENG.norm(str(x)) for x in (b.get("items") or []) if str(x).strip()]
            if not items:
                return self._send(400, {"error": "empty"})
            if len(items) > 40:
                return self._send(400, {"error": "too many numbers — 40 at a time, please"})
            if b.get("mode", "bl") not in ("bl", "container", "vessel"):
                return self._send(400, {"error": "bad mode"})
            job_id = f"job{int(time.time()*1000)}{threading.get_ident() % 997}"
            JOBS[job_id] = {"done": False, "current": "", "events": [], "results": [],
                            "no_save": bool(b.get("no_save"))}
            # F-14 fix (v46 audit): finished jobs were kept forever —
            # prune so only the newest 50 done jobs stay in memory.
            done_ids = [k for k, v in JOBS.items() if v.get("done")]
            for old in done_ids[:-50]:
                JOBS.pop(old, None)
            _trole, _tnm = self._who(auth)
            JOBS[job_id]["staff"] = _tnm if _trole == "staff" else ""
            _known = {h.get("query") for h in get_history()} \
                if _trole == "staff" else set()
            threading.Thread(target=_run_job,
                             args=(job_id, items, b.get("mode", "bl"),
                                   b.get("carrier") or None,
                                   (b.get("client") or "").strip()),
                             daemon=True).start()
            if _trole == "staff":
                for _it in items:
                    _staff_log(_tnm, self._client_ip(),
                               ("Re-tracked " if _it in _known
                                else "Tracked ") + _it)
            return self._send(200, {"job": job_id})
        if p == "/api/history/update":
            q = b.get("query")
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                _ufile = HISTORY_FILE
                if hit is None:
                    # v111: staff's own entry is in their separate
                    # file — update it there. Staff
                    # can only touch their own entry.
                    _urole, _unm = self._who(auth)
                    _sh2 = _get_staff_history()
                    _shit = next((h for h in _sh2
                                  if h.get("query") == q), None)
                    if _shit is not None and (
                            _urole != "staff"
                            or _shit.get("staff_owner") == _unm):
                        hit = _shit
                        hist = _sh2
                        _ufile = STAFF_HISTORY_FILE
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                if "checklist" in b:
                    hit["checklist"] = b["checklist"]
                if "notes" in b:
                    hit["notes"] = b["notes"]
                for f in ("client", "amount", "received"):
                    if f in b:
                        hit[f] = b[f]
                if "returned" in b:
                    hit["returned"] = bool(b["returned"])
                if "starred" in b:
                    hit["starred"] = bool(b["starred"])
                if b.get("seen"):
                    hit["changed"] = False
                if not save_json(_ufile, hist):
                    return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/history/delete":
            q = b.get("query")
            with _lock:
                hist = get_history()
                gone = next((h for h in hist if h.get("query") == q), None)
                if gone is None:
                    return self._send(404, {"error": "entry not found"})
                rest = [h for h in hist if h.get("query") != q]
                if not save_json(HISTORY_FILE, rest):
                    return self._send(500, {"error": "could not save"})
                # v98 Stage B: delete tombstone — on other
                # copies this record will not come back to life.
                _st98 = _sync_state()
                _sync_add_tombstone(_st98, q)
                _sync_state_save(_st98)
                ph = gone.get("photo")
                if ph and not any(h.get("photo") == ph for h in rest):
                    try:
                        (PHOTOS_DIR / Path(ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True})
        if p == "/api/settings":
            b = b or {}
            # v48: the password hash is managed ONLY via /api/password —
            # a settings save must never overwrite or inject it.
            b.pop("app_pass", None)
            # v110: staff accounts are managed ONLY via
            # /api/staff-users — a settings save must never
            # overwrite or inject them either.
            b.pop("staff_users", None)
            # v98 Stage B: sync keys change only through their own
            # routes — a normal settings save cannot
            # even touch them.
            for _sk in ("sync_role", "sync_hub_url",
                        "sync_token_hash", "sync_client_token",
                        "sync_instance_id", "profile_sync_ts",
                        "profile_photo_removed_ts"):
                b.pop(_sk, None)
            try:
                if "recheck_hours" in b:
                    rh = float(b["recheck_hours"])
                    if rh not in (3, 6, 12, 24):
                        raise ValueError("recheck_hours")
                    b["recheck_hours"] = rh
                if "free_days" in b:
                    fd = float(b["free_days"])
                    if not (0 <= fd <= 60):
                        raise ValueError("free_days")
                    b["free_days"] = fd
                if "demurrage_rate" in b:
                    dr = float(b["demurrage_rate"])
                    if dr < 0:
                        raise ValueError("demurrage_rate")
                    b["demurrage_rate"] = dr
                if "return_days" in b:
                    rd = float(b["return_days"])
                    if not (1 <= rd <= 60):
                        raise ValueError("return_days")
                    b["return_days"] = rd
            except (TypeError, ValueError) as e:
                return self._send(400, {"error": f"invalid setting: {e}"})
            for k in ("company_name", "company_tagline", "profile_name"):
                if k in b:
                    b[k] = str(b[k]).strip()[:80]
            if "ai_key" in b:
                _k = str(b["ai_key"] or "").strip()
                if _k:
                    b["ai_key"] = _k[:220]
                else:
                    b.pop("ai_key")
            if "gemini_key" in b:
                _k = str(b["gemini_key"] or "").strip()
                if _k:
                    b["gemini_key"] = _k[:220]
                else:
                    b.pop("gemini_key")
            if "groq_key" in b:
                _k = str(b["groq_key"] or "").strip()
                if _k:
                    b["groq_key"] = _k[:220]
                else:
                    b.pop("groq_key")
            if "traqo_key" in b:
                _k = str(b["traqo_key"] or "").strip()
                if _k:
                    b["traqo_key"] = _k[:220]
                else:
                    b.pop("traqo_key")
            if "mail_user" in b:
                b["mail_user"] = str(b["mail_user"] or "").strip()[:80]
            if "mail_pass" in b:
                _k = str(b["mail_pass"] or "").strip()
                if _k:
                    b["mail_pass"] = _k[:220]
                else:
                    b.pop("mail_pass")
            s = get_settings()
            _prof_changed = ("profile_name" in b and str(
                b.get("profile_name") or "").strip()
                != str(s.get("profile_name") or "").strip())
            s.update(b)
            if _prof_changed:
                # the profile sync clock — on other copies this
                # name will win only when this stamp is the newest
                s["profile_sync_ts"] = _sync_next_ts()
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/staff-users":
            # Admin only — staff sessions were denied above.
            act = str(b.get("action") or "")
            nm = str(b.get("name") or "").strip()
            users = _staff_users()
            s = get_settings()

            def _save_users():
                s["staff_users"] = users
                return save_json(SETTINGS_FILE, s)

            if act == "create":
                if len(nm) < 2 or len(nm) > 40:
                    return self._send(400, {
                        "error": "name must be 2-40 characters"})
                if _staff_find(nm) is not None:
                    return self._send(400, {
                        "error": "a staff login with this name "
                                 "already exists"})
                pw = str(b.get("password") or "")
                if len(pw) < 6:
                    return self._send(400, {
                        "error": "password must be at least "
                                 "6 characters"})
                users.append({"name": nm,
                              "pass": _make_pass_hash(pw),
                              "access": ("full" if str(
                                  b.get("access") or "") == "full"
                                  else "own"),
                              "disabled": False,
                              "created": time.time(),
                              "upd": time.time()})
                # v132: a re-created account buries its old delete
                # mark for good (see _sync_apply_staff) — otherwise
                # the stale mark keeps circulating and can wipe the
                # new account again on a later sync.
                s["staff_deleted"] = [
                    x for x in (s.get("staff_deleted") or [])
                    if not (isinstance(x, dict) and str(
                        x.get("name") or "").strip().lower()
                        == nm.lower())]
                if not _save_users():
                    return self._send(500, {"error": "could not save"})
                return self._send(200, {"ok": True})
            # The user must be found INSIDE this handler's own
            # list — _staff_find returns a dict from a separate
            # settings parse, and mutating that copy would be
            # thrown away on save.
            user = next((x for x in users
                         if str(x.get("name") or "").strip().lower()
                         == nm.lower()), None)
            if user is None:
                return self._send(404, {"error": "staff user not found"})
            if act == "access":
                user["access"] = ("own" if str(
                    b.get("access") or "") == "own" else "full")
                user["upd"] = time.time()
            elif act == "disable":
                user["disabled"] = True
                user["upd"] = time.time()
            elif act == "enable":
                user["disabled"] = False
                user["upd"] = time.time()
            elif act == "password":
                pw = str(b.get("password") or "")
                if len(pw) < 6:
                    return self._send(400, {
                        "error": "password must be at least "
                                 "6 characters"})
                user["pass"] = _make_pass_hash(pw)
                user["upd"] = time.time()
            elif act == "delete":
                users = [x for x in users if x is not user]
                _dl = [x for x in (s.get("staff_deleted") or [])
                       if isinstance(x, dict)]
                _dl.append({"name": nm, "ts": time.time()})
                s["staff_deleted"] = _dl[-50:]
                # a deleted staff member signs out everywhere
                with _lock:
                    d = _load_sessions()
                    gone = [k for k, v in d["sessions"].items()
                            if v.get("role") == "staff"
                            and str(v.get("name") or "").lower()
                            == nm.lower()]
                    for k in gone:
                        d["sessions"].pop(k, None)
                    if gone:
                        _save_sessions(d)
            else:
                return self._send(400, {"error": "bad action"})
            if not _save_users():
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/staff-activity/clear":
            # Admin only — staff sessions were denied above.
            save_json(STAFF_ACTIVITY_FILE, [])
            return self._send(200, {"ok": True})
        if p == "/api/activity":
            # The client reports view-only actions (opening an
            # entry, searching) for the staff register. Only
            # staff sessions are ever written; admin calls are
            # accepted and ignored.
            role, nm = self._who(auth)
            if role == "staff":
                label = {"open": "Opened ", "search": "Searched "}
                lab = label.get(str(b.get("action") or ""))
                if lab:
                    _staff_log(nm, self._client_ip(),
                               lab + str(b.get("detail") or "")[:120])
            return self._send(200, {"ok": True})
        if p == "/api/sync/make-hub":
            # Make this copy the central hub: a new token is
            # created, settings keep only its HASH;
            # the real token appears in this response only ONCE.
            token = secrets.token_urlsafe(24)
            s = get_settings()
            s["sync_role"] = "hub"
            s["sync_token_hash"] = hashlib.sha256(
                token.encode("utf-8")).hexdigest()
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True, "token": token,
                                    "note": "Shown only once — "
                                    "copy it into the other "
                                    "copies now."})
        if p == "/api/sync/set-client":
            hub = str(b.get("hub_url") or "").strip().rstrip("/")
            tok = str(b.get("token") or "").strip()
            if not hub.startswith(("http://", "https://")):
                return self._send(400, {
                    "error": "hub address must start with "
                             "http:// or https://"})
            if len(tok) < 10:
                return self._send(400, {
                    "error": "paste the sync token from the hub"})
            s = get_settings()
            s["sync_role"] = "joined"
            s["sync_hub_url"] = hub
            s["sync_client_token"] = tok
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            ok, msg = _sync_join_now()
            return self._send(200 if ok else 502,
                              {"ok": ok, "message": msg,
                               "sync": _sync_public()})
        if p == "/api/sync/leave":
            s = get_settings()
            s["sync_role"] = ""
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/sync/now":
            if _sync_role() == "joined":
                _sync_cycle()
            elif _sync_role() == "hub":
                _sync_stamp_pass(mark_clean=True)
            return self._send(200, {"ok": True,
                                    "sync": _sync_public()})
        if p == "/api/photo":
            import base64
            q = ENG.norm(str(b.get("query") or ""))
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            if len(raw) > 8 * 1024 * 1024:
                return self._send(400, {"error": "photo too large (8 MB max)"})
            # The payload must really be an image — trust the file
            # signature, never the caller's word (v41 audit fix).
            fmt = None
            if raw[:3] == b"\xff\xd8\xff":
                fmt = ".jpg"
            elif raw[:8] == b"\x89PNG\r\n\x1a\n":
                fmt = ".png"
            elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                fmt = ".webp"
            if not fmt:
                return self._send(400, {"error": "that file is not an image"})
            name = f"{q}{fmt}"
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                old_ph = hit.get("photo")
                (PHOTOS_DIR / name).write_bytes(raw)
                hit["photo"] = name
                if not save_json(HISTORY_FILE, hist):
                    return self._send(500, {"error": "could not save"})
                if old_ph and old_ph != name:
                    try:
                        (PHOTOS_DIR / Path(old_ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True, "photo": name})
        if p == "/api/profile/photo":
            # v96 Profile photo: arrives shrunk to 512px from the client canvas
            # ; here a strict signature + size check, then
            # a single file in DATA_DIR (old file with other ext deleted).
            import base64
            if b.get("remove"):
                for ext in PROFILE_PHOTO_EXTS:
                    try:
                        (DATA_DIR / ("profile_photo" + ext)).unlink(
                            missing_ok=True)
                    except Exception:
                        pass
                _sp = get_settings()
                _st = _sync_next_ts()
                _sp["profile_sync_ts"] = _st
                _sp["profile_photo_removed_ts"] = _st
                save_json(SETTINGS_FILE, _sp)
                return self._send(200, {"ok": True,
                                        "profile_photo_set": False})
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            if len(raw) > 2 * 1024 * 1024:
                return self._send(400, {"error": "photo too large (2 MB max)"})
            fmt = None
            if raw[:3] == b"\xff\xd8\xff":
                fmt = ".jpg"
            elif raw[:8] == b"\x89PNG\r\n\x1a\n":
                fmt = ".png"
            elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                fmt = ".webp"
            if not fmt:
                return self._send(400, {"error": "that file is not an image"})
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            for ext in PROFILE_PHOTO_EXTS:
                if ext != fmt:
                    try:
                        (DATA_DIR / ("profile_photo" + ext)).unlink(
                            missing_ok=True)
                    except Exception:
                        pass
            (DATA_DIR / ("profile_photo" + fmt)).write_bytes(raw)
            _sp = get_settings()
            _sp["profile_sync_ts"] = _sync_next_ts()
            _sp["profile_photo_removed_ts"] = 0
            save_json(SETTINGS_FILE, _sp)
            return self._send(200, {"ok": True, "profile_photo_set": True})
        if p == "/api/bl-copy":
            # v112 (Yousuf, 4 Nov): once a BL copy is given,
            # it is SAVED on the record — never asked again.
            # If the copy is found in the main file, there; in the staff
            # file, there; if found nowhere, then as per the caller
            # (a staff copy goes in the staff file).
            _q = str(b.get("query") or "").strip().upper()
            _txt = str(b.get("text") or "")[:20000]
            if not _q:
                return self._send(400, {"error": "no query"})
            # v115: the scan flow sometimes posts its result
            # JSON instead of copy text — unwrap it: the copy
            # is the raw text, fields/containers come from the
            # JSON. Empty raw = NOT a real copy: never store it
            # as bl_copy (it would lock the record), but still
            # merge whatever fields/containers it carried.
            _scan_meta = None
            _strip = _txt.strip()
            if _strip.startswith("{"):
                try:
                    _j = json.loads(_strip)
                    if isinstance(_j, dict) and ("bl_no" in _j
                                                  or "containers"
                                                  in _j):
                        _scan_meta = _j
                except Exception:
                    _scan_meta = None
            _store_copy = True
            if _scan_meta is not None:
                _txt = str(_scan_meta.get("raw") or "")[:20000]
                _store_copy = bool(_txt.strip())
            elif isinstance(b.get("fields"), dict) \
                    or isinstance(b.get("containers"), list):
                # Scan flow now posts the fields it read next to
                # the raw text (either may be present alone).
                _scan_meta = {"fields": b.get("fields") or {},
                              "containers": b.get("containers")
                              or [],
                              "containers_detail":
                              b.get("containers_detail") or []}
            _stamp = {"ts": int(time.time()), "text": _txt}
            # Scan Note Book photo (scan flow only; a pasted copy
            # sends no image).
            _img_name = _save_scan_image(_q, b.get("img"))
            # v114: extract vessel/voyage/containers from the copy text
            # and fill them into the record — the vessel layer
            # will run from these on the next re-track.
            _fields = {}
            try:
                _fields = _bl_copy_fields(_txt)
                if _scan_meta is not None:
                    _sf = _scan_meta.get("fields") or {}
                    # ALL the information from the scan — the party's
                    # name (shipper/consignee), goods, weight
                    # etc. as well; not just vessel/ports
                    # (Yousuf, 6 Nov 2026: "the party name
                    # etc., everything, should be in the note book").
                    for _k in ("vessel", "voyage", "precarriage",
                               "precarriage_voyage", "pol", "pod",
                               "carrier", "shipper", "consignee",
                               "ts_port", "on_board", "issue_date",
                               "goods", "packages", "gross_kg",
                               "net_kg", "cbm", "freight",
                               "free_days"):
                        if _sf.get(_k) not in (None, "") and not _fields.get(_k):
                            _fields[_k] = _sf[_k]
                    _cd = _scan_meta.get("containers_detail") or []
                    if _cd:
                        _fields["containers_detail"] = _cd
                    _sc = [str(c).strip().upper()
                           for c in (_scan_meta.get("containers")
                                     or []) if str(c).strip()]
                    if _sc:
                        _hv = list(_fields.get("containers") or [])
                        for _c in _sc:
                            if _c not in _hv:
                                _hv.append(_c)
                        _fields["containers"] = _hv
                _qs = re.sub(r"[^A-Z0-9]", "", _q)
                if _fields.get("containers"):
                    _fields["containers"] = [
                        c for c in _fields["containers"]
                        if re.sub(r"[^A-Z0-9]", "", c) not in _qs]
                    if not _fields["containers"]:
                        _fields.pop("containers")
            except Exception:
                _fields = {}

            # Copy was provided and read (fields came back)
            # but no raw text exists (vision-only read): store
            # the read details as the copy text, so the record
            # counts as "copy provided" and is never asked again.
            if not _store_copy and any(
                    _fields.get(_k)
                    for _k in ("vessel", "voyage", "pol", "pod",
                               "containers")):
                _lines = ["Details read from the BL copy "
                          "provided by the user:",
                          "BL Number: " + _q]
                for _k, _lab in (("vessel", "Vessel"),
                                 ("voyage", "Voyage"),
                                 ("pol", "Port of Loading"),
                                 ("pod", "Port of Discharge")):
                    if _fields.get(_k):
                        _lines.append(_lab + ": "
                                      + str(_fields[_k]))
                if _fields.get("containers"):
                    _lines.append("Containers: " + ", ".join(
                        _fields["containers"]))
                _txt = "\n".join(_lines)[:20000]
                _stamp = {"ts": int(time.time()), "text": _txt}
                _store_copy = True

            def _merge_copy_fields(_ent):
                if not isinstance(_ent, dict):
                    return
                # Scan Note Book (Yousuf, 7 Nov 2026): ONLY a BL copy
                # scan makes an entry — one per BL, holding the FULL
                # detail read at scan time (parties, cargo, weights,
                # dates) plus the scanned photo, which is kept for
                # 30 days. A re-scan refreshes the same single entry.
                try:
                    if _scan_meta is not None:
                        _ssf = {}
                        for _k, _v in _fields.items():
                            if _v in (None, "", []):
                                continue
                            _ssf[str(_k)] = _v
                        _old_ss = _ent.get("scanbook_scan") or {}
                        _ss = {"ts": int(time.time()),
                               "time": _DT(datetime.now()),
                               "fields": _ssf}
                        if _img_name:
                            _ss["img"] = _img_name
                            _ss["img_ts"] = int(time.time())
                        elif _old_ss.get("img"):
                            _ss["img"] = _old_ss["img"]
                            _ss["img_ts"] = (_old_ss.get("img_ts")
                                             or _old_ss.get("ts"))
                        elif _old_ss.get("img_expired"):
                            _ss["img_expired"] = True
                        _ent["scanbook_scan"] = _ss
                except Exception:
                    pass
                if not _fields:
                    return
                _r = _ent.get("result")
                if not isinstance(_r, dict):
                    _r = {}
                    _ent["result"] = _r
                for _k in ("vessel", "voyage", "pol", "pod"):
                    if _fields.get(_k) and not _r.get(_k):
                        _r[_k] = _fields[_k]
                if _fields.get("containers"):
                    _have = list(_r.get("containers") or [])
                    for _c in _fields["containers"]:
                        if _c not in _have:
                            _have.append(_c)
                    _r["containers"] = _have
                _ent["bl_copy_fields"] = _fields

            with _lock:
                _hist = get_history()
                _e = next((h for h in _hist
                           if (h.get("query") or "").upper() == _q),
                          None)
                if _e is not None:
                    if _store_copy:
                        _e["bl_copy"] = _stamp
                    _merge_copy_fields(_e)
                    save_json(HISTORY_FILE, _hist)
                else:
                    _sh = _get_staff_history()
                    _se = next((h for h in _sh
                                if (h.get("query") or "").upper()
                                == _q), None)
                    if _se is not None:
                        if _store_copy:
                            _se["bl_copy"] = _stamp
                        _merge_copy_fields(_se)
                        _save_staff_history(_sh)
                    elif _store_copy:
                        _wrole, _wname = self._who(auth)
                        _ne = {"query": _q, "mode": "bl",
                               "found": False, "result": {},
                               "layers": [], "changes": [],
                               "checklist": {}, "notes": "",
                               "first_seen": date.today()
                               .isoformat(),
                               "bl_copy": _stamp}
                        # Fields must land on a brand-new entry
                        # too (copy given before any track) —
                        # otherwise the vessel is lost and the
                        # vessel layer never runs for it.
                        _merge_copy_fields(_ne)
                        if _wrole == "staff":
                            _ne["staff_owner"] = _wname
                            _sh.append(_ne)
                            _save_staff_history(_sh)
                        else:
                            _hist.insert(0, _ne)
                            save_json(HISTORY_FILE, _hist)
            return self._send(200, {"ok": True,
                                    "fields": _fields})
        if p == "/api/ocr":
            # v49 photo scan: the OCR engine bundled inside the app
            # (RapidOCR, ocr/venv) + the learned BL extractor
            # (bl-formats-learned.md). No Tesseract at all.
            import base64
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            tmp = DATA_DIR / (f"ocr_tmp_{int(time.time()*1000)}_"
                              f"{threading.get_ident()}.png")
            try:
                tmp.write_bytes(raw)
                d, err = _run_ocr_items(tmp)
            finally:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass
            if err:
                # v51: local engine not ready (missing / setup
                # running / setup failed) and if settings have a Groq
                # key, create the record via the vision fallback —
                # otherwise the same clear error as before.
                vrec = None
                if not _ocr_python():
                    try:
                        _key = _ai_key_single()
                    except Exception:
                        _key = ""
                    if _key:
                        if raw[:8] == b"\x89PNG\r\n\x1a\n":
                            _mime = "image/png"
                        elif raw[:3] == b"\xff\xd8\xff":
                            _mime = "image/jpeg"
                        elif raw[:4] == b"RIFF" \
                                and raw[8:12] == b"WEBP":
                            _mime = "image/webp"
                        else:
                            _mime = "image/png"
                        vrec = _vision_extract_record(
                            raw, _mime, _key)
                if vrec:
                    return self._send(200, _finalize_scan(vrec))
                return self._send(200, {"ok": False, "error": err})
            rec, meta = extract_bl_record(d["items"], d["w"], d["h"])
            engine = "rapidocr-onnxruntime"
            # OPTIONAL vision booster: only for cross-check/enrichment;
            # the offline result is always the basis and no vision
            # error ever blocks the scan.
            try:
                vb = _vision_bl_extract(
                    "data:image/png;base64,"
                    + base64.b64encode(raw).decode(), rec, meta)
            except Exception:
                vb = None
            if vb:
                warns = list(rec.get("warnings") or [])
                if rec["bl_no"] \
                        and _sq(str(vb.get("bl_no"))) != rec["bl_no"]:
                    warns.append(
                        "The AI vision check read a different BL "
                        "number (" + str(vb.get("bl_no")) + ") — "
                        "please verify against the document.")
                merged = dict(rec)
                # v84: "bl_no" is out of this list — the number read by vision
                # never replaces the original OCR number
                # (27 Oct 2026, the FRLS I/1 error).
                for k in ("carrier", "vessel", "voyage",
                          "precarriage", "precarriage_voyage",
                          "shipper", "consignee", "pol", "pod",
                          "ts_port", "on_board", "issue_date",
                          "goods", "packages", "freight"):
                    val = vb.get(k)
                    if val not in (None, ""):
                        merged[k] = val
                for k in ("gross_kg", "net_kg", "cbm", "free_days"):
                    val = vb.get(k)
                    if val not in (None, ""):
                        merged[k] = _num_or_blank(val) or val
                vc = []
                for c in vb.get("containers") or []:
                    if isinstance(c, dict) and c.get("no"):
                        no = _sq(str(c["no"]))
                        vc.append({"no": no,
                                   "seal": _sq(str(c.get("seal")
                                                    or "")),
                                   "type": str(c.get("type") or ""),
                                   "check_ok": _iso_ok(no)})
                if vc:
                    have = {c["no"] for c in merged["containers"]}
                    merged["containers"] = merged["containers"] + \
                        [c for c in vc if c["no"] not in have]
                if merged.get("bl_no"):
                    merged["proforma"] = False
                merged["warnings"] = warns
                rec = merged
                engine = "gemini-vision+rapidocr"
            # v86: variant + rescue are now at the FINAL GATE
            # (_finalize_scan) — every path passes through
            # there, there is no bypass.
            try:
                _vbno = str(vb.get("bl_no") or "") \
                    if vb else ""
            except Exception:
                _vbno = ""
            rec = _finalize_scan(rec, _vbno)
            rec["ok"] = True
            rec["engine"] = engine
            # The copy text itself must travel with the scan
            # result: the client saves it with the record (the
            # BL-copy save reads j.raw_text). Without it the
            # provided copy was never stored and the app kept
            # asking for it again.
            try:
                rec["raw_text"] = "\n".join(
                    str(ln.get("text") or "")
                    for ln in _ocr_lines(d["items"], d["h"]))
            except Exception:
                pass
            return self._send(200, rec)
        return self._send(404, {"error": "not found"})



def _iso_ok(s):
    """Validation of the ISO 6346 check digit."""
    VAL = {"A": 10, "B": 12, "C": 13, "D": 14, "E": 15, "F": 16,
           "G": 17, "H": 18, "I": 19, "J": 20, "K": 21, "L": 23,
           "M": 24, "N": 25, "O": 26, "P": 27, "Q": 28, "R": 29,
           "S": 30, "T": 31, "U": 32, "V": 34, "W": 35, "X": 36,
           "Y": 37, "Z": 38}
    try:
        tot = 0
        for i, ch in enumerate(s[:10]):
            v = int(ch) if ch.isdigit() else VAL[ch]
            tot += v * (2 ** i)
        return (tot % 11) % 10 == int(s[10])
    except Exception:
        return False


def _lev(a, b):
    if abs(len(a) - len(b)) > 3:
        return 99
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1,
                           prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def doctor_number(raw):
    """Number Doctor (idea 20): check the number BEFORE the search
    — whether it is a BL or a container, which line it appears
    to belong to, whether the digit is correct, and whether it
    resembles any number in the list."""
    import re as _re
    n = ENG.norm(str(raw or ""))
    out = {"input": raw, "normalized": n, "type": "Not recognized",
           "carrier": None, "valid": None, "notes": [],
           "suggestion": None, "expanded": None}
    if not n:
        out["notes"].append("Nothing was entered.")
        return out
    if _re.fullmatch(r"\d{5}", n) and n[0] == "5":
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True, expanded="EMKAYMBAKHI" + n)
        out["notes"].append("5 digits starting with 5 — by the "
                            "standing rule this is an Emkay Lines "
                            "BL; TRACK adds EMKAYMBAKHI by itself.")
        return out
    if n.startswith("EMKAY") or n.startswith("MBAK"):
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True)
        out["notes"].append("This is an Emkay Lines BL.")
        return out
    if _re.fullmatch(r"[A-Z]{4}\d{7}", n):
        ok = _iso_ok(n)
        out.update(type="Container", valid=ok,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if ok:
            out["notes"].append("The container number's shape and its "
                                "final check digit are both correct.")
        else:
            out["notes"].append("The final digit (check digit) does not "
                                "match the calculation — there is "
                                "likely a typing mistake in the number.")
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} usually belongs to "
                                f"{out['carrier']}.")
        return out
    if _re.fullmatch(r"[A-Z]{4}[A-Z0-9]{5,}", n):
        out.update(type="BL", valid=True,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} — this looks like a "
                                f"{out['carrier']} BL.")
        else:
            out["notes"].append("BL-shaped number, but the prefix does "
                                "not match a well-known line — the "
                                "search will still try every route.")
        return out
    if _re.fullmatch(r"\d{9,12}", n):
        out.update(type="BL (digits only)",
                   carrier="COSCO Shipping (likely)", valid=True)
        out["notes"].append("Digits-only BLs are usually COSCO — "
                            "the app will search by the digits.")
        return out
    if _re.fullmatch(r"[A-Z ]{3,}", n) and " " in n.strip():
        out.update(type="Vessel name", valid=True)
        out["notes"].append("This looks like a vessel name — "
                            "search it in Vessel mode.")
        return out
    out["notes"].append("The shape is unclear — it does not look "
                        "like a BL, a container or a vessel name.")
    best = None
    for h in get_history():
        q = (h.get("query") or "").upper()
        if q and abs(len(q) - len(n)) <= 2:
            d = _lev(n, q)
            if best is None or d < best[0]:
                best = (d, q)
    if best and 0 < best[0] <= 2:
        out["suggestion"] = best[1]
        out["notes"].append(f"This closely matches {best[1]} in your "
                            "list — could it be the same one?")
    return out


def _parse_doc_fields(text):
    """Full details from the BL photo's text (idea 26): vessel,
    voyage, weight, quantity, goods — whatever is found, honestly."""
    import re as _re
    t = text or ""
    f = {}
    m = _re.search(r"VESSEL[:\s]*([A-Za-z][A-Za-z ]{2,28})", t)
    if m:
        f["vessel"] = m.group(1).strip().upper()
    m = _re.search(r"(?:VOYAGE|VOY\.?|V\.)[:\s]*([A-Za-z0-9]{2,10})", t)
    if m:
        f["voyage"] = m.group(1).upper()
    m = _re.search(r"([\d.,]+)\s*KGS?\b", t, _re.I)
    if m:
        f["weight"] = m.group(1) + " KGS"
    m = _re.search(r"(\d+)\s*(PACKAGES|PKGS|CARTONS|BAGS|PCS|UNITS)",
                   t, _re.I)
    if m:
        f["packages"] = m.group(1) + " " + m.group(2).upper()
    for label in ("DESCRIPTION OF GOODS", "DESCRIPTION",
                  "PARTICULARS", "COMMODITY"):
        m = _re.search(label + r"[:\s]*([^\n]{4,90})", t, _re.I)
        if m:
            f["commodity"] = m.group(1).strip(" :-").upper()
            break
    return f


def _ast_date(v):
    """Convert the App's various date formats into a date."""
    if not v:
        return None
    t = str(v).strip()
    for f in ("%d %b %Y", "%d-%b-%Y", "%d %b %y", "%Y-%m-%d",
              "%d/%m/%Y", "%d-%m-%Y", "%d %B %Y"):
        try:
            return datetime.strptime(t.title()
                                     if f in ("%d %b %Y", "%d %b %y")
                                     else t, f).date()
        except Exception:
            continue
    m = re.match(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{4})", t)
    if m:
        try:
            return datetime.strptime(
                f"{m.group(1)} {m.group(2)[:3]} {m.group(3)}",
                "%d %b %Y").date()
        except Exception:
            return None
    return None


def _ast_completed(h):
    r = h.get("result") or {}
    if bool(r.get("gate_out")) or "deliver" in (
            r.get("status") or "").lower() or (
            (r.get("position") or "").upper() == "OUT"):
        return True
    return ((r.get("position") or "").strip().lower() == "departed"
            and bool(r.get("discharge_time"))
            and (r.get("terminal") or "") in (
                "KGTL", "KICT", "SAPT", "QICT"))



def _milestones(h):
    """v60: strict window — Departed / Berthed / Discharged /
    Gate out. Each stage: state, when, certainty, note.
    PRINCIPLE (Yousuf's correction, 25 Oct): data is NEVER hidden
    — whatever is found is shown; but the truth level (final /
    confirmed / single / estimate) must always be written with
    each stage, and a record that breaks the sequence appears
    as a CONFLICT, never as final."""
    from datetime import timedelta, timezone
    today = datetime.now(timezone(timedelta(hours=5))).date()
    r = h.get("result") or {}
    st = (r.get("status") or "").lower()
    ok_names = [str((l or {}).get("name") or "")
                for l in (h.get("layers") or [])
                if (l or {}).get("status") == "done"
                and "identification" not in str((l or {}).get("name") or "").lower()]
    term_ok = any(("terminal" in n.lower() or "qict" in n.lower()
                   or "kict" in n.lower() or "sapt" in n.lower())
                  for n in ok_names)
    n_src = len([n for n in ok_names if n])
    def _d60(v):
        if not v:
            return None
        t = str(v)
        m = re.search(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{2,4})", t)
        if m:
            yy = int(m.group(3))
            if yy < 100:
                yy += 2000
            try:
                return datetime.strptime(
                    f"{m.group(1)} {m.group(2)[:3].title()} {yy}",
                    "%d %b %Y").date()
            except Exception:
                return None
        return _ast_date(v)
    eta_d = _d60(r.get("eta"))
    etd_d = _d60(r.get("etd"))
    dis_d = _d60(r.get("discharge_time"))
    gate_d = _d60(r.get("gate_out"))
    M = []
    dep = {"key": "departed", "label": "Vessel departed",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    mdep = re.search(r"departed[^.]*?(\d{1,2}[-\s]+[A-Za-z]{3,9}[-\s]+\d{4})",
                     r.get("status") or "", re.I)
    dep_when = mdep.group(1) if mdep else None
    if not dep_when and r.get("departed"):
        # v96 FIX B: the date now stays saved in its own 'departed'
        # field too — even when the status text becomes 'Arrived',
        # the milestone still shows the same date that the carrier
        # had confirmed (COAU6468022200: '09 Oct 2026').
        dep_when = str(r["departed"])
    # On-board date: a BL-document record carries its loading date
    # in the status text / carrier check / BL fields even when no
    # 'departed' field exists — the step must not claim the date
    # is "not in record" then (YMJAS430202944, 11 Nov 2026).
    dep_ob = None
    mob = re.search(r"on board[^.]*?(\d{1,2}[-\s]+[A-Za-z]{3,9}[-\s]+\d{4})",
                    r.get("status") or "", re.I)
    if mob:
        dep_ob = mob.group(1)
    if not dep_ob:
        _cc = h.get("carrier_check") or {}
        _bf = h.get("bl_copy_fields") or {}
        for _v in (_cc.get("onboard"), _bf.get("on_board")):
            if not _v:
                continue
            _d = _d60(_v)
            if not _d:
                _ms = re.match(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})",
                               str(_v))
                if _ms:
                    try:
                        _d = datetime(int(_ms.group(3)),
                                      int(_ms.group(2)),
                                      int(_ms.group(1))).date()
                    except Exception:
                        _d = None
            if _d:
                dep_ob = _d.strftime("%d-%b-%Y").upper()
                break
    arrived_ev = bool(r.get("vir") or r.get("discharge_time")
                      or r.get("gate_out"))
    if dep_when:
        dep.update(state="done", when=dep_when,
                   certainty="confirmed" if n_src >= 2 else "single",
                   note="Carrier event")
    elif dep_ob:
        dep.update(state="done", when=dep_ob,
                   certainty="single",
                   note="On board date in record")
    elif arrived_ev:
        dep.update(state="done", certainty="single",
                   note="Vessel arrived - departure certain, "
                   "date not in record")
    elif etd_d and etd_d <= today:
        dep.update(state="done", when=str(r.get("etd") or ""),
                   certainty="single", note="ETD passed")
    elif ("in transit" in st or "on board" in st or "loaded" in st
          or eta_d or r.get("discharge_time") or r.get("vir")):
        dep.update(state="done", certainty="single",
                   note="In transit - departure date not in record")
    M.append(dep)
    ber = {"key": "berthed", "label": "Vessel berthed",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    if r.get("vir") or r.get("discharge_time") or r.get("gate_out"):
        ber.update(state="done", certainty="final",
                   note="Terminal record"
                   + (f" - VIR {r['vir']}" if r.get("vir") else ""))
    elif ("at " in st and ("terminal" in st or "qict" in st
                           or "kict" in st or "sapt" in st)
          and "expected" not in st):
        ber.update(state="done", certainty="single",
                   note="At terminal - VIR not in record")
    elif eta_d:
        ber.update(state="expected", when=str(r.get("eta") or ""),
                   certainty="estimate",
                   note="ETA is an estimate - not an arrival")
    M.append(ber)
    dis = {"key": "discharged", "label": "Container discharged",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    if r.get("gate_out"):
        dis.update(state="done",
                   when=str(r.get("discharge_time") or ""),
                   certainty="final" if term_ok else "single",
                   note="Gate out recorded - discharge certain")
    elif r.get("discharge_time"):
        dis.update(state="partial" if st.startswith("partially")
                   else "done",
                   when=str(r.get("discharge_time") or ""),
                   certainty="final" if term_ok else "single",
                   note="Terminal record" if term_ok
                   else "terminal confirmation pending")
        if st.startswith("partially"):
            dis["note"] = ("some containers only - full count "
                           "is in the terminal record")
    elif "discharged" in st:
        dis.update(state="done", certainty="single",
                   note="Status only - exact time not in record")
    if dis_d:
        dd = _d60(dep.get("when"))
        if dd and dis_d < dd:
            dis.update(state="conflict",
                       note="Discharge is BEFORE departure - "
                       "records disagree, not final")
        elif dis_d > today:
            dis.update(state="conflict",
                       note="Discharge date is in the future - "
                       "records disagree, not final")
    M.append(dis)
    gat = {"key": "gateout", "label": "Gate out",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    if r.get("gate_out"):
        gat.update(state="done", when=str(r.get("gate_out") or ""),
                   certainty="final" if term_ok else "single",
                   note="Terminal record" if term_ok
                   else "terminal confirmation pending")
    elif (r.get("position") or "").strip().upper() == "OUT" \
            and (r.get("truck") or "").strip().lower() \
            == "delivered":
        # v99 (user's order 30 Oct 2026): QICT BL-Inquiry's
        # POSITION=OUT + TRUCK_IN_YARD=delivered is the terminal's
        # own gate-out proof — the container has left
        # the terminal and the truck has taken it away.
        # QICT does not give the gate-out DATE, so
        # 'when' stays empty — a date is never fabricated
        # (the strict window principle).
        gat.update(state="done",
                   certainty="confirmed" if term_ok else "single",
                   note="Terminal record: position OUT and "
                        "the collecting truck marked "
                        "delivered — gate-out certain, the "
                        "terminal gives no exact time for it")
    elif "gate out" in st:
        gat.update(state="done", certainty="single",
                   note="Status only - exact time not in record")
    elif "deliver" in st:
        gat.update(state="done", certainty="single",
                   note="Marked delivered - terminal gate "
                   "record pending")
    elif (r.get("position") or "").strip().lower() == "departed" \
            and r.get("discharge_time") \
            and (r.get("terminal") or "") in (
                "KGTL", "KICT", "SAPT", "QICT"):
        gat.update(state="done", certainty="single",
                   note="The terminal's own record shows this "
                   "container as Departed (left the terminal) - "
                   "the terminal did not give an exact gate-out "
                   "time")
    if gate_d and dis_d and gate_d < dis_d:
        gat.update(state="conflict",
                   note="Gate out is BEFORE discharge - records "
                   "disagree, not final")
    M.append(gat)
    return M


def _milestones_line(h):
    # v67 fix: compact codes — the verbose line was ~50% of the context and
    # collided with Groq free TPM (8000/min), shutting down the Assistant.
    kmap = {"departed": "dep", "berthed": "ber",
            "discharged": "dis", "gateout": "out"}
    sym = {"done": "\u2713", "partial": "\u25d0", "expected": "~",
           "pending": "\u2026", "conflict": "!"}
    cert = {"final": "F", "confirmed": "C", "single": "1",
            "estimate": "E", "none": ""}
    import re as _re67

    def _sw(w):
        w = str(w or "").strip()
        if not w:
            return ""
        md = _re67.search(r"(\d{1,2})[- ]([A-Za-z]{3})", w)
        mt = _re67.search(r"(\d{1,2})[.:](\d{2})(?:[.:]\d{2})?\s*(AM|PM)?",
                           w, _re67.I)
        out = ""
        if md:
            out = f"{md.group(1)}-{md.group(2).title()}"
        if mt:
            t = f"{int(mt.group(1))}:{mt.group(2)}"
            if mt.group(3):
                t += mt.group(3).upper()
            out = (out + " " + t).strip()
        return out or w[:11]

    parts = []
    for m in _milestones(h):
        pp = (kmap.get(m["key"], str(m["key"])[:3])
              + sym.get(m["state"], "?") + cert.get(m["certainty"], ""))
        sw = _sw(m.get("when"))
        if sw:
            pp += " " + sw
        parts.append(pp)
    return "MS[" + " ".join(parts) + "]"


def _lifecycle(h):
    """v62: the shipment's lifecycle stage. Once gate out occurs,
    stage 'out' — the record goes to the Completed section and
    no demurrage / empty-return warning is created for it;
    the record remains fully preserved (the empty container's
    return is recorded by the h['returned'] marker, or by a record
    of 'empty returned' in some source's text)."""
    r = h.get("result") or {}
    out = _ast_completed(h)
    when = str(r.get("gate_out") or "")
    cert = "single" if out else "none"
    try:
        for m in _milestones(h):
            if m.get("key") == "gateout" and m.get("state") == "done":
                out = True
                when = when or str(m.get("when") or "")
                cert = m.get("certainty") or cert
    except Exception:
        pass
    empty = "returned" if h.get("returned") else "pending"
    if empty == "pending":
        try:
            blob = (json.dumps(h.get("layers") or [])
                    + " " + str(r.get("status") or "")).lower()
            if ("empty returned" in blob or "returned empty" in blob
                    or "empty container returned" in blob):
                empty = "returned"
        except Exception:
            pass
    empty_certainty = "final" if empty == "returned" else "none"
    if empty == "pending" and out and when:
        # v96 — user's 2+ day rule (29 Oct 2026, his trade knowledge):
        # a container that gates out comes back empty in 1-2 days (often
        # the same day). If the gate-out is older than 2 days
        # and no check has found an empty-return record, then
        # the return is PRESUMED — certainty grade 'estimate', never
        # terminal-confirmed. Once the real return record is found, the above
        # 'returned' takes its place.
        try:
            from datetime import timedelta, timezone
            gd = None
            mg = re.search(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{2,4})",
                           str(when))
            if mg:
                yy = int(mg.group(3))
                if yy < 100:
                    yy += 2000
                gd = datetime.strptime(
                    f"{mg.group(1)} {mg.group(2)[:3].title()} {yy}",
                    "%d %b %Y").date()
            if gd is None:
                gd = _ast_date(when)
            if gd is not None and (datetime.now(
                    timezone(timedelta(hours=5))).date() - gd).days > 2:
                empty = "presumed"
                empty_certainty = "estimate"
        except Exception:
            pass
    return {"stage": "out" if out else "active",
            "gate_out": when,
            "gate_out_certainty": cert if out else "none",
            "empty": empty,
            "empty_certainty": empty_certainty}


def _computed_facts(found):
    """v57: the app's COUNTED facts for the Assistant — days and
    counts are not left to the model's guess. Arrivals,
    hold, late and no-ETA lists are built from ALL records,
    so the bot cannot call a partial list complete (v56's
    mistake: only the first 25 records went into context)."""
    from datetime import timedelta, timezone
    today = datetime.now(timezone(timedelta(hours=5))).date()
    arr, late, noeta, holds = [], [], [], []
    for h in found:
        r = h.get("result") or {}
        st = (r.get("status") or "").lower()
        if _ast_on_hold(h):
            holds.append(h)
        if _ast_completed(h):
            continue
        d = _ast_date(r.get("eta"))
        if d and d >= today:
            arr.append((d, h))
        elif d:
            late.append((d, h))
        elif "discharg" not in st and "deliver" not in st \
                and "arriv" not in st and "berthed" not in st \
                and "terminal" not in st:
            noeta.append(h)
    arr.sort(key=lambda x: x[0])
    L = ["",
         "COMPUTED FACTS - counted by the app itself from ALL "
         f"{len(found)} found records (today: "
         f"{_D(today)}, Karachi time). For ANY "
         "question about arrivals, holds or totals, answer ONLY "
         "from this section: list EVERY matching shipment and "
         "state the total number. Never do your own date maths "
         "and never present a partial list as complete."]
    if arr:
        L.append(f"Upcoming arrivals ({len(arr)} total, "
                 "soonest first):")
        for d, h in arr:
            r = h.get("result") or {}
            n = (d - today).days
            when = ("today" if n == 0 else
                    "tomorrow" if n == 1 else f"in {n} days")
            L.append(f"- {h.get('query')} - ETA {r.get('eta')} "
                     f"({when}) - {r.get('vessel') or 'vessel n/a'}"
                     f" - {r.get('terminal') or ''} - "
                     f"{r.get('status') or ''}")
        for w in (7, 14, 20, 30):
            sub = [str(h.get("query")) for d, h in arr
                   if (d - today).days <= w]
            L.append(f"Arriving within {w} days: {len(sub)}"
                     + (": " + ", ".join(sub) if sub else ""))
        nm_first = (today.replace(day=28)
                    + timedelta(days=4)).replace(day=1)
        nm = [str(h.get("query")) for d, h in arr
              if d.year == nm_first.year and d.month == nm_first.month]
        L.append(f"Arriving next month ({nm_first.strftime('%B %Y')}, "
                 "calendar month - keep this SEPARATE from this week): "
                 f"{len(nm)}"
                 + (": " + ", ".join(nm) if nm else ""))
    else:
        L.append("Upcoming arrivals: none with a future ETA.")
    if late:
        L.append("ETA date already passed, still in transit "
                 "(no new date yet): "
                 + ", ".join(str(h.get("query")) for _, h in late))
    if noeta:
        L.append("In transit with NO ETA recorded yet (never "
                 "invent a date for these): "
                 + ", ".join(str(h.get("query")) for h in noeta))
    if holds:
        dis_l, gate_l, conf_l = [], [], []
        for _h in found:
            _ms = {m["key"]: m for m in _milestones(_h)}
            if _ms["discharged"]["state"] in ("done", "partial"):
                dis_l.append(str(_h.get("query")))
            if _ms["gateout"]["state"] == "done":
                gate_l.append(str(_h.get("query")))
            if any(m["state"] == "conflict" for m in _ms.values()):
                conf_l.append(str(_h.get("query")))
        L.append(f"Discharged so far ({len(dis_l)}): "
                 + (", ".join(dis_l) if dis_l else "none"))
        L.append(f"Gate out so far ({len(gate_l)}): "
                 + (", ".join(gate_l) if gate_l else "none"))
        if conf_l:
            L.append("RECORD CONFLICTS - never present these as "
                     "final; say the records disagree: "
                     + ", ".join(conf_l))
        L.append(f"ON HOLD right now ({len(holds)}): "
                 + ", ".join(str(h.get("query")) for h in holds))
    _out62 = [str(h.get("query")) for h in found
              if _lifecycle(h)["stage"] == "out"]
    if _out62:
        L.append(f"OUT OF PORT — Completed section ({len(_out62)}): "
                 + ", ".join(_out62)
                 + " — these shipments are finished (container out "
                 "of the port). NEVER raise demurrage, free-time "
                 "or empty-return warnings for them; their full "
                 "record is kept in the Completed section.")
    return L


def _arrivals_rows(days=30):
    """v59: clean rows of upcoming shipments - for building a file
    (PDF/CSV/TXT). Only real data, no guesswork."""
    from datetime import timedelta, timezone
    today = datetime.now(timezone(timedelta(hours=5))).date()
    rows = []
    for h in get_history():
        if not h.get("found") or _ast_completed(h):
            continue
        r = h.get("result") or {}
        d = _ast_date(r.get("eta"))
        if d and today <= d and (d - today).days <= days:
            rows.append((d, {"bl": str(h.get("query")),
                             "vessel": r.get("vessel") or "-",
                             "eta": r.get("eta") or "-",
                             "terminal": r.get("terminal") or "-",
                             "status": r.get("status") or "-"}))
    rows.sort(key=lambda x: x[0])
    return [r for _, r in rows]


def _assistant_context(lean=False):
    hist = _scoped_history()
    found = [h for h in hist if h.get("found")]
    nf = [h for h in hist if not h.get("found")]
    lines = [f"Shipments in the app: {len(hist)} tracked, "
             f"{len(found)} found, {len(nf)} not found.",
             f"COMPLETE LIST of found shipments (all "
             f"{len(found)} - nothing is cut off):"]
    lines.append(
        "MS[...] milestone codes: dep=vessel departed, ber=berthed, "
        "dis=container discharged, out=gate out; \u2713=done, "
        "\u25d0=partial, ~=expected, \u2026=pending, !=conflict; "
        "F=final (terminal record), C=confirmed (2+ sources), "
        "1=1 source only (unconfirmed), E=estimate. Exact times "
        "are in the app record.")
    for h in found:
        r = h.get("result") or {}
        if _ast_completed(h):
            _cl = (f"- {h.get('query')} ({h.get('carrier') or 'carrier unknown'}): "
                   f"COMPLETED")
            if r.get("vessel"):
                _cl += f", vessel {r['vessel']}"
            if r.get("terminal"):
                _cl += f", terminal {r['terminal']}"
            _cl += f", gate out {r.get('gate_out') or 'done'}"
            lines.append(_cl)
            continue
        row = (f"- {h.get('query')} ({h.get('carrier') or 'carrier unknown'}): "
               f"{r.get('status') or 'status unknown'}")
        if r.get("vessel"):
            row += f", vessel {r['vessel']}"
        if r.get("eta"):
            row += f", ETA {r['eta']}"
        if r.get("terminal"):
            row += f", terminal {r['terminal']}"
        if r.get("containers"):
            row += f", containers {', '.join(r['containers'])}"
        g59 = r.get("goods") or h.get("goods")
        if g59:
            row += f", goods: {g59}"
        row += " || " + _milestones_line(h)
        lines.append(row)
    if nf:
        lines.append("Not found so far: " + ", ".join(
            str(h.get("query")) for h in nf))
    lines.extend(_computed_facts(found))
    st = get_settings()
    lines.append(f"Free days before demurrage: {st.get('free_days')}; "
                 f"auto re-check every {st.get('recheck_hours')} hours.")
    lines.append("Photo scanning (OCR) on this computer: "
                 + ("ready (engine built into the app)"
                    if _ocr_python() else
                    "not set up on this device yet - it installs "
                    "itself automatically the first time you scan "
                    "a photo (one-time, a few minutes)"))
    return "\n".join(lines)

def _ocr_image_bytes(raw):
    """Text from photo bytes — v49: the app's own bundled OCR engine
    (RapidOCR, subprocess). (True, text) or (False, reason)."""
    tmp = DATA_DIR / (f"ocr_tmp_{int(time.time()*1000)}_"
                      f"{threading.get_ident()}.png")
    try:
        tmp.write_bytes(raw)
        d, err = _run_ocr_items(tmp)
        if err:
            return False, err
        items = sorted(d["items"],
                       key=lambda i: (_it_cy(i), _it_cx(i)))
        lines = _ocr_lines(items, d["h"])
        return True, "\n".join(ln["text"] for ln in lines)
    except Exception as e:
        return False, str(e)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def _pdf_text(raw):
    """v46: text from PDF — no library, use stdlib zlib to open FlateDecode
    streams and collect Tj/TJ text operators. On a scanned-image
    PDF it will be empty (the caller honestly says the same)."""
    import re as _re
    import zlib as _zlib
    out = []
    for m in _re.finditer(rb"stream\r?\n(.*?)endstream", raw, _re.S):
        data = m.group(1)
        try:
            data = _zlib.decompress(data)
        except Exception:
            pass
        for t in _re.findall(rb"\((?:\\.|[^\\)])*\)\s*Tj", data):
            out.append(t[1:t.rindex(b")")])
        for arr in _re.findall(rb"\[(.*?)\]\s*TJ", data, _re.S):
            parts = _re.findall(rb"\((?:\\.|[^\\)])*\)", arr)
            if parts:
                out.append(b"".join(p[1:-1] for p in parts))
    txt = b" ".join(out).decode("latin-1", "replace")
    txt = txt.replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\")
    return " ".join(txt.split())


_GLOCAL = threading.local()


_THINK_LVL = {"gemini-3.5-flash-lite": "minimal",
              "gemini-3.8-flash": "low"}
_MODELS = ("gemini-3.5-flash-lite", "gemini-3.8-flash")


def _gemini_try(key, body, model, timeout, tmo_retry=True):
    """One model's attempts: first with its minimum thinking
    level; if 400 comes or (only in chat/race) time runs out,
    retry without thinking. Returns: (dict|None, path, code,
    thoughts_tokens) — thoughts measures Google's real thinking."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    body = dict(body)
    base_gc = dict(body.get("generationConfig") or {})
    short = "lite" if "lite" in model else "3.8"
    lvl = _THINK_LVL[model]
    parts = []
    for use_think in (True, False):
        gc = dict(base_gc)
        if use_think:
            gc["thinkingConfig"] = {"thinkingLevel": lvl}
        body["generationConfig"] = gc
        req = _u.Request(
            "https://generativelanguage.googleapis.com/v1beta/"
            f"models/{model}:generateContent?key={key}",
            data=_j.dumps(body).encode(),
            headers={"Content-Type": "application/json"})
        ta = time.time()
        tag = f"{short}/{lvl if use_think else 'none'}"
        try:
            with _u.urlopen(req, timeout=timeout) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
                th = int(((d.get("usageMetadata") or {})
                          .get("thoughtsTokenCount")) or 0)
                parts.append(f"{tag} {time.time() - ta:.1f}s ok th{th}")
                return d, " > ".join(parts), "", th
        except _ue.HTTPError as e:
            parts.append(f"{tag} {time.time() - ta:.1f}s http{e.code}")
            if e.code == 400 and use_think:
                continue
            return None, " > ".join(parts), e.code, 0
        except Exception:
            parts.append(f"{tag} {time.time() - ta:.1f}s fail")
            if use_think and tmo_retry:
                continue
            return None, " > ".join(parts), "timeout", 0
    return None, " > ".join(parts), "", 0


def _gemini_gen(key, body, timeout=35):
    """Sequential path (for mic/scan): first lite, then 3.8.
    No timeout-retry here (tmo_retry=False) — so delay does not double."""
    paths = []
    last = ""
    for model in _MODELS:
        d, pth, code, th = _gemini_try(key, body, model, timeout,
                                       tmo_retry=False)
        paths.append(pth)
        if d:
            _GLOCAL.path = " > ".join(paths)
            _GLOCAL.model = "lite" if "lite" in model else "3.8"
            _GLOCAL.code = ""
            _GLOCAL.thoughts = th
            return d, ""
        last = code
    _GLOCAL.path = " > ".join(paths)
    _GLOCAL.model = ""
    _GLOCAL.code = last
    _GLOCAL.thoughts = 0
    return None, last


def _gemini_gen_race(key, body, timeout=45):
    """For chat, BOTH models run TOGETHER — whichever replies
    first, wins. v74: if Google gives a TEMPORARY reason like 503 (overload) /
    429 / 5xx / timeout, the whole race runs again
    — up to 3 rounds, with a pause in between (6s, then 10s),
    all within a total limit of ~75s. On a key (401/403) or request (400)
    error, no retry — that does not get fixed."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    RETRYABLE = (429, 500, 502, 503, 504, "timeout")
    t_start = time.time()
    all_paths = []
    last = ""
    rnd = 0
    while True:
        rnd += 1
        ex = ThreadPoolExecutor(max_workers=2)
        futs = {ex.submit(_gemini_try, key, body, m, timeout): m
                for m in _MODELS}
        paths = {}
        codes = []
        try:
            for fut in as_completed(futs, timeout=timeout + 15):
                m = futs[fut]
                try:
                    d, pth, code, th = fut.result()
                except Exception:
                    d, pth, code, th = None, "", "timeout", 0
                paths[m] = pth
                if code:
                    codes.append(code)
                if d:
                    _GLOCAL.path = " > ".join(
                        all_paths + [pth])
                    _GLOCAL.model = "lite" if "lite" in m else "3.8"
                    _GLOCAL.code = ""
                    _GLOCAL.thoughts = th
                    ex.shutdown(wait=False)
                    return d, ""
        except Exception:
            codes.append("timeout")
        ex.shutdown(wait=False)
        all_paths += [p for p in paths.values() if p]
        if codes:
            last = codes[-1]
        if any(c in (401, 403) for c in codes):
            break
        if not any(c in RETRYABLE for c in codes):
            break
        if rnd >= 3 or time.time() - t_start > 75:
            break
        time.sleep(6 if rnd == 1 else 10)
    _GLOCAL.path = " > ".join(all_paths)
    _GLOCAL.model = ""
    _GLOCAL.code = last
    _GLOCAL.thoughts = 0
    return None, last


def _ai_fail_note():
    """The real reason for AI failure in plain words — on the banner,
    instead of 'key failed', the confirmed reason + record of each attempt."""
    code = getattr(_GLOCAL, "code", "")
    path = getattr(_GLOCAL, "path", "")
    if code == 503 or "http503" in path:
        why = ("The AI service is overloaded right now "
               "(503) - the app retried; it usually recovers "
               "within a minute")
    elif code == 429 or "http429" in path:
        why = ("The AI free limit is full right now (429) - "
               "wait a few minutes and ask again")
    elif code in (401, 403):
        why = (f"The saved AI key was rejected ({code}) - "
               "re-paste the key in Settings")
    elif code == 400:
        why = "The AI service rejected the request (400)"
    elif code == "timeout" or " fail" in path:
        why = ("The AI service took too long to answer this time - "
               "its free service is slow right now")
    elif code:
        why = f"AI service error {code}"
    else:
        why = "Google did not answer"
    return why + (f" [{path}]" if path else "")


def _ai_fail_category():
    """v98 (S1b): the real TYPE of AI failure — in the fallback reply,
    instead of the generic '(an internet hiccup or the free limit)'
    shrug, this type is clearly written. Types:
    timeout / rate limit / invalid key / network."""
    code = getattr(_GLOCAL, "code", "")
    path = getattr(_GLOCAL, "path", "")
    if code in (401, 403) or "http401" in path \
            or "http403" in path:
        return "invalid key"
    if code == 429 or "http429" in path:
        return "rate limit"
    if code == "timeout" or " fail" in path:
        return "timeout"
    return "network"


_AI_WHY_PHRASE = {
    "timeout": "a timeout — the AI service took too "
               "long to respond",
    "rate limit": "a rate limit — the free AI limit is "
                  "full right now",
    "invalid key": "an invalid key — the AI key saved "
                   "in Settings was rejected",
    "network": "a network error — the AI service could "
               "not be reached",
}


def _gemini_text(d):
    """Only real text from the generateContent response — thinking
    (thought) parts are not included in the response."""
    try:
        parts = d["candidates"][0]["content"]["parts"]
        return "".join(x.get("text", "") for x in parts
                       if not x.get("thought")).strip()
    except Exception:
        return ""



def _ai_key_single():
    """v68 — the SINGLE key rule: all the app's AI work (chat,
    mic, photo scan) runs on one Gemini key. If in the old
    ai_key a Gemini key is present (NOT a gsk_ one —
    Groq keys are discontinued) then that one works."""
    try:
        s = get_settings()
    except Exception:
        return ""
    k = str(s.get("gemini_key") or "").strip()
    if k:
        return k
    k2 = str(s.get("ai_key") or "").strip()
    if k2 and not k2.startswith("gsk_"):
        return k2
    return ""


def _transcribe_audio(raw, mime=""):
    """v75: first Groq Whisper (fastest transcription),
    if unavailable or it fails, the Gemini path."""
    gk = _groq_key()
    if gk:
        ok, val = _groq_transcribe(gk, raw, mime)
        if ok:
            return ok, val
        if not _ai_key_single():
            return ok, val
    return _transcribe_gemini(raw, mime)


def _transcribe_gemini(raw, mime=""):
    """Convert recorded voice to text with Gemini (v68). The browser
    sends the recording converted to WAV so every browser's
    format works; if another format comes, the mime is forwarded
    as is."""
    import base64 as _b64
    import urllib.request as _u, urllib.error as _ue, json as _j
    key = _ai_key_single()
    if not key:
        return False, ("Voice typing needs the free Gemini key \u2014 "
                       "add it in Settings first.")
    m = (mime or "").strip().lower()
    if "wav" in m:
        gmime = "audio/wav"
    elif "ogg" in m:
        gmime = "audio/ogg"
    elif m.startswith("audio/"):
        gmime = m
    else:
        gmime = "audio/wav"
    prompt = ("Transcribe this audio exactly, word for word, and "
              "return ONLY the transcription text. The speaker may "
              "speak English, Urdu or Roman Urdu, and may read out "
              "shipping numbers (bill of lading or container "
              "numbers) digit by digit \u2014 write digits as numbers "
              "(0-9). If there is no speech, return nothing.")
    body = {"contents": [{"role": "user", "parts": [
                {"text": prompt},
                {"inline_data": {"mime_type": gmime,
                                 "data": _b64.b64encode(
                                     raw).decode()}}]}],
            "generationConfig": {"temperature": 0}}
    d, code = _gemini_gen(key, body, timeout=40)
    if d:
        txt = _gemini_text(d)
        if txt:
            return True, txt
        return False, ("Nothing was heard in that recording \u2014 "
                       "try again, a little closer to the mic.")
    if code in (401, 403):
        return False, ("The AI key was refused by Google \u2014 "
                       "check the key in Settings.")
    return False, (f"Voice service error ({code}) \u2014 "
                   "please try again.")



def _groq_answer(q, hist, key, extra=""):
    """Real conversation via Groq (free tier, Llama models). The key
    starts with 'gsk_'. On error, None — the local reply
    will handle it, never false reassurance."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    sys_txt = (
        "You are CargoTrack Assistant, the assistant built into this app - not ChatGPT or any other product, never introduce yourself as one. This is a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. FORMAT: put each fact on its OWN line - for a shipment: the BL on one line, then Vessel, ETA, Terminal and Status each on its own line; never cram several facts into one long sentence, and use bold sparingly. When he asks about different periods (this week, next month), answer in SEPARATE sections, one per period, each with its own heading and count; next month means the next calendar month only - never merge periods or repeat an item in two sections. When he asks what goods or items are inside a container, answer ONLY from the goods recorded in the data; if no goods are recorded for it, say so plainly in your FIRST sentence - never answer an item question with vessel details. For the four critical stages (vessel departed, vessel berthed, container discharged, gate out) answer ONLY from the MILESTONES data and always state its certainty in your reply (final / confirmed / 1 source only / estimate); call every ETA an estimate, never a fact; if a milestone says CONFLICT, tell him the records disagree instead of picking one. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. Answer EXACTLY the question he asked - never substitute a different answer. When he asks for all / every / tamaam / sab, enumerate the COMPLETE matching list from the data below and state how many there are; presenting a partial list as complete is the worst possible answer. The COMPUTED FACTS section was counted by the app from ALL records - trust it over your own counting and date maths. If he asks for a photo, image, card or report but has NOT named a shipment in this conversation, ask in ONE short line which BL he means - never pick a shipment for him, and never volunteer information he did not ask for. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app attaches the real file button under your reply when a shipment is identified - so say only one short line such as: the file button is below. NEVER claim a file is ready when no shipment was identified - in that case ask which BL he means. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically." + _today_line() + _profile_line() + _NO_WEB_RULE + "\n\nLIVE APP DATA:\n"
        + _assistant_context() + extra)
    msgs = [{"role": "system", "content": sys_txt}]
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:500]
        if t:
            msgs.append({"role": "user" if h.get("role") == "user"
                         else "assistant", "content": t})
    msgs.append({"role": "user", "content": q})
    # Groq's catalog keeps changing — on 21 Oct 2026, on this
    # account Llama models were not available at all, only
    # the gpt-oss / qwen family. So those first, then
    # the old names (for accounts that have them).
    for model in ("openai/gpt-oss-120b", "qwen/qwen3.8-27b",
                  "openai/gpt-oss-20b"):
        try:
            body = {"model": model, "messages": msgs,
                    "temperature": 0.2, "max_tokens": 900}
            if model.startswith("openai/"):
                # gpt-oss reasoning models: low effort so the answer
                # comes in the content within max_tokens, not empty.
                body["reasoning_effort"] = "low"
            req = _u.Request(
                "https://api.groq.com/openai/v1/chat/completions",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}",
                         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; "
                         "Win64; x64) AppleWebKit/537.36 (KHTML, "
                         "like Gecko) Chrome/130.0 Safari/537.36"})
            with _u.urlopen(req, timeout=35) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            txt = (d["choices"][0]["message"].get("content")
                   or "").strip()
            if txt:
                return txt
        except _ue.HTTPError as e:
            if e.code in (404, 400, 403, 408, 413, 429):
                continue
            return None
        except Exception:
            continue  # F-12: one model's network hiccup must not skip the rest
    return None


# ================= v75: fast AI (Groq) + question-matched data =================

_GREET_SET = {"hi", "hello", "hey", "salam", "slam", "aoa",
              "kese ho", "kaise ho", "kese hi", "kese ho bhai",
              "hello bhai", "assalam o alaikum",
              "assalamualaikum"}


def _kw_match(ql, words=(), stems=()):
    """Keyword check on WORD BOUNDARIES: inside 'call me',
    'all', inside 'detail' 'eta', inside 'important' 'port'
    will never match (v79 — code review bug fix).
    stems are fragments that, if they come at the START of a word,
    will work (arriv -> arriving, kitn -> kitne)."""
    for w in words:
        if re.search(r"\b" + re.escape(w) + r"\b", ql):
            return True
    for s in stems:
        if re.search(r"\b" + re.escape(s), ql):
            return True
    return False


def _is_pure_greeting(q):
    n = re.sub(r"[^a-z ]", "", (q or "").lower())
    n = re.sub(r"\s+", " ", n).strip()
    return n in _GREET_SET


def _groq_key():
    try:
        return str(get_settings().get("groq_key") or "").strip()
    except Exception:
        return ""


def _assistant_context_for(q, hay=""):
    """v75's firm rule (his instructions, 26 Oct): data will ONLY
    go when the question is about data. On a general question (weather etc.)
    ZERO data; on one shipment's question, only that record;
    only on a list/all question, the full summary (otherwise the list
    will remain incomplete)."""
    if _is_pure_greeting(q):
        return ""
    ql = " " + (q or "").lower() + " "
    ql = ql.replace(" hold on ", " ")  # English sentence, not hold
    if _kw_match(ql,
                 words=("sab", "all", "every", "tamaam", "list",
                        "hold", "holds", "gate out", "discharge",
                        "discharged", "this week", "is week",
                        "is month", "next week", "next month",
                        "agle", "report", "reports", "summary",
                        "overview", "demurrage"),
                 stems=("arriv", "kitn")):
        return _assistant_context()
    full = _assistant_context()
    lines = full.split("\n")
    head0 = lines[0] if lines else ""
    matched = []
    in_rec = False
    hayu = ((hay or "") + " " + (q or "")).upper()
    for ln in lines:
        if ln.startswith("COMPLETE LIST"):
            in_rec = True
            continue
        if ln.startswith("COMPUTED FACTS"):
            break
        if in_rec and ln.startswith("- "):
            tok = ln[2:].split(" ")[0].split("(")[0].strip().upper()
            if tok and len(tok) >= 5 and tok in hayu:
                matched.append(ln)
    if matched:
        return "\n".join([head0] + matched)
    return ""


def _oai_chat_try(key, model, messages, timeout=30, effort=None):
    """One attempt at OpenAI-compatible chat (Groq).
    Returns (text|None, path, code)."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    body = {"model": model, "messages": messages,
            "temperature": 0.2, "max_tokens": 1000}
    if effort:
        body["reasoning_effort"] = effort
    short = ("groq120" if "120b" in model else
             "groq20" if "20b" in model else "groq")
    ta = time.time()
    try:
        req = _u.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=_j.dumps(body).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + key})
        with _u.urlopen(req, timeout=timeout) as r:
            d = _j.loads(r.read().decode("utf-8", "replace"))
        txt = (((d.get("choices") or [{}])[0].get("message")
                or {}).get("content") or "").strip()
        if txt:
            return txt, f"{short} {time.time() - ta:.1f}s ok", ""
        return None, f"{short} {time.time() - ta:.1f}s empty", "empty"
    except _ue.HTTPError as e:
        return None, f"{short} {time.time() - ta:.1f}s http{e.code}", e.code
    except Exception:
        return None, f"{short} {time.time() - ta:.1f}s fail", "timeout"


def _groq_leg(q, hist, gk, model, extra, ctx):
    body = _gemini_body(q, hist, extra, ctx_override=ctx)
    sys_txt = body["systemInstruction"]["parts"][0]["text"]
    msgs = [{"role": "system", "content": sys_txt}]
    for c in body["contents"]:
        msgs.append({
            "role": "user" if c["role"] == "user" else "assistant",
            "content": "".join(p.get("text", "")
                               for p in c["parts"])})
    txt, pth, code = _oai_chat_try(gk, model, msgs, timeout=30,
                                   effort="low")
    return txt, pth, code, 0


def _gemini_leg(gemkey, body, model):
    d, pth, code, th = _gemini_try(gemkey, body, model, 45)
    return (_gemini_text(d) if d else None), pth, code, th


def _multi_race(legs, per_timeout=45):
    """All providers TOGETHER — the first correct reply wins.
    On temporary failure (503/429/5xx/timeout), race again, up to 3
    rounds; on a key error, no retry."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    RETRYABLE = (429, 500, 502, 503, 504, "timeout")
    t_start = time.time()
    all_paths = []
    last = ""
    rnd = 0
    while True:
        rnd += 1
        ex = ThreadPoolExecutor(max_workers=max(2, len(legs)))
        futs = {ex.submit(lg["fn"]): lg for lg in legs}
        paths = {}
        codes = []
        try:
            for fut in as_completed(futs, timeout=per_timeout + 15):
                lg = futs[fut]
                try:
                    txt, pth, code, th = fut.result()
                except Exception:
                    txt, pth, code, th = None, "", "timeout", 0
                paths[id(lg)] = pth
                if code:
                    codes.append(code)
                if txt:
                    _GLOCAL.path = " > ".join(
                        all_paths + [pth])
                    _GLOCAL.model = lg["model"]
                    _GLOCAL.code = ""
                    _GLOCAL.thoughts = th
                    ex.shutdown(wait=False)
                    return txt
        except Exception:
            codes.append("timeout")
        ex.shutdown(wait=False)
        all_paths += [p for p in paths.values() if p]
        if codes:
            last = codes[-1]
        if any(c in (401, 403) for c in codes):
            break
        if not any(c in RETRYABLE for c in codes):
            break
        if rnd >= 3 or time.time() - t_start > 80:
            break
        time.sleep(5 if rnd == 1 else 8)
    _GLOCAL.path = " > ".join(all_paths)
    _GLOCAL.model = ""
    _GLOCAL.code = last
    _GLOCAL.thoughts = 0
    return None


def _ai_answer_any(q, hist, gk, gemkey, extra=""):
    """Chat's main path (v75): Groq (fast) + Gemini
    (backup / PDF / full data) — in a single race."""
    hay = " ".join(str((h or {}).get("text") or "")
                   for h in (hist or [])[-4:])
    ctx = _assistant_context_for(q, hay)
    legs = []
    if gk:
        gctx = ctx[:9000]
        for model in ("openai/gpt-oss-120b", "openai/gpt-oss-20b"):
            legs.append({"model": "Groq", "fn": (
                lambda m=model: _groq_leg(q, hist, gk, m,
                                          extra, gctx))})
    if gemkey:
        body = _gemini_body(q, hist, extra, ctx_override=ctx)
        for model in _MODELS:
            legs.append({
                "model": "lite" if "lite" in model else "3.8",
                "fn": (lambda m=model: _gemini_leg(gemkey,
                                                   body, m))})
    if not legs:
        return None
    return _multi_race(legs, 45)


def _groq_vision_text(key, prompt, mime, b64):
    """Photo text/JSON via Groq's vision model (scan)."""
    import urllib.request as _u, json as _j
    try:
        body = {"model": "meta-llama/llama-4-scout-17b-16e-instruct",
                "messages": [{"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {
                        "url": f"data:{mime};base64,{b64}"}}]}],
                "temperature": 0, "max_tokens": 1500}
        req = _u.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=_j.dumps(body).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + key})
        with _u.urlopen(req, timeout=40) as r:
            d = _j.loads(r.read().decode("utf-8", "replace"))
        return (((d.get("choices") or [{}])[0].get("message")
                 or {}).get("content") or "").strip() or None
    except Exception:
        return None


def _vision_text_any(prompt, mime, b64):
    """Photo check: first Groq vision (fast), if not, Gemini."""
    gk = _groq_key()
    if gk:
        t = _groq_vision_text(gk, prompt, mime, b64)
        if t:
            return t
    key = _ai_key_single()
    if not key:
        return None
    d, _c = _gemini_gen(key, {"contents": [{"role": "user",
                        "parts": [{"text": prompt},
                        {"inline_data": {"mime_type": mime,
                                         "data": b64}}]}],
                    "generationConfig": {"temperature": 0}},
                    timeout=45)
    return _gemini_text(d) if d else None


def _groq_transcribe(key, raw, mime=""):
    """Voice text via Groq Whisper (mic) — the fastest."""
    import urllib.request as _u, urllib.error as _ue
    import json as _j, uuid
    try:
        bnd = "----ct" + uuid.uuid4().hex
        fn, ct = "voice.wav", "audio/wav"
        m = (mime or "").lower()
        if "ogg" in m:
            fn, ct = "voice.ogg", "audio/ogg"
        elif "webm" in m:
            fn, ct = "voice.webm", "audio/webm"
        elif "mp4" in m or "m4a" in m:
            fn, ct = "voice.m4a", "audio/mp4"
        parts = []
        for name, val in (("model", "whisper-large-v3-turbo"),
                          ("response_format", "json")):
            parts.append(
                f"--{bnd}\r\nContent-Disposition: form-data; "
                f"name=\"{name}\"\r\n\r\n{val}\r\n".encode())
        head = (f"--{bnd}\r\nContent-Disposition: form-data; "
                f"name=\"file\"; filename=\"{fn}\"\r\n"
                f"Content-Type: {ct}\r\n\r\n").encode()
        body = (b"".join(parts) + head + raw
                + f"\r\n--{bnd}--\r\n".encode())
        req = _u.Request(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            data=body,
            headers={"Authorization": "Bearer " + key,
                     "Content-Type":
                         f"multipart/form-data; boundary={bnd}"})
        with _u.urlopen(req, timeout=35) as r:
            d = _j.loads(r.read().decode("utf-8", "replace"))
        txt = (d.get("text") or "").strip()
        if txt:
            return True, txt
        return False, ("Nothing was heard in that recording "
                       "- try again, a little closer to the mic.")
    except _ue.HTTPError as e:
        if e.code in (401, 403):
            return False, ("The Groq key was refused - check "
                           "the key in Settings.")
        return False, f"Voice service error ({e.code}) - please try again."
    except Exception:
        return False, "Voice service error (network) - please try again."


_DATA_WORDS = ("hold", "holds", "gate out", "gateout",
               "discharge", "discharged", "eta", "vessel",
               "terminal", "demurrage", "berth", "berths",
               "status", "list", "container", "shipment",
               "shipments", "kab", "kahan", "kon se", "port",
               "sapt", "kict", "qict", "kgtl", "late", "delay",
               "release", "custom", "customs", "delivery order",
               "tracking", "track")
_DATA_STEMS = ("arriv", "kitn", "depart")


def _looks_data_q(q):
    """Does the question seem to be about the app's data? (a numbered
    token or a data word)"""
    t = q or ""
    if re.search(r"[A-Za-z]{2,}\d{4,}|\d{6,}", t):
        return True
    ql = " " + t.lower() + " "
    return _kw_match(ql, words=_DATA_WORDS, stems=_DATA_STEMS)


def _local_substantive(out):
    """Is the local reply based on real data or a generic 'I am just
    an assistant' statement? Fast-lane only on a real reply."""
    t = ((out or {}).get("answer") or "").strip()
    if len(t) < 40:
        return False
    if "I am the built-in assistant" in t[:120]:
        return False
    if "Hello! I watch your shipments" in t[:120]:
        return False
    return True


# ================= v77: greeting + weather — the app itself =================


_WX_WORDS = ("mosam", "mausam", "weather", "garmi", "barish",
             "baarish", "sardi", "rain", "dhund", "fog")
_WX_CODES = {0: "Clear sky", 1: "Mostly clear", 2: "Partly cloudy",
             3: "Overcast", 45: "Fog", 48: "Fog",
             51: "Light drizzle", 53: "Drizzle",
             55: "Drizzle", 61: "Light rain",
             63: "Rain", 65: "Heavy rain", 71: "Light snow",
             73: "Snow", 75: "Heavy snow", 80: "Light rain",
             81: "Rain", 82: "Torrential rain",
             95: "Thunderstorm", 96: "Thunderstorm",
             99: "Thunderstorm"}


_WX_CITIES = ("karachi", "lahore", "islamabad", "rawalpindi",
              "faisalabad", "multan", "peshawar", "quetta",
              "hyderabad", "sukkur", "sialkot", "gujranwala",
              "bahawalpur", "sargodha", "mardan", "swat", "abbottabad",
              "mingora", "gilgit", "skardu", "muzaffarabad",
              "jhelum", "okara", "sahiwal", "larkana",
              "nawabshah", "gwadar", "turbat", "khuzdar",
              "dubai", "abu dhabi", "sharjah", "doha", "muscat",
              "riyadh", "jeddah", "kuwait city", "london",
              "new york", "toronto", "singapore", "kuala lumpur",
              "bangkok", "hong kong", "tokyo", "delhi", "mumbai",
              "beijing", "shanghai", "sydney")
_WX_PANEL = ("Karachi", "Lahore", "Islamabad", "Rawalpindi",
             "Faisalabad", "Multan", "Peshawar", "Quetta",
             "Hyderabad", "Mardan", "Sukkur", "Sialkot")
_WX_FAIL_MSG = ("Live Weather Information Is Not Available Right "
                "Now — Please Try Again In A Little While. I Will "
                "Not Guess Without Real Data.")
_WX_GEO_CACHE = {}


def _wx_geocode(city):
    import urllib.request as _u, urllib.parse as _up
    import json as _j
    key = city.lower()
    if key in _WX_GEO_CACHE:
        return _WX_GEO_CACHE[key]
    url = ("https://geocoding-api.open-meteo.com/v1/search?"
           + _up.urlencode({"name": city, "count": 6,
                            "language": "en", "format": "json"}))
    with _u.urlopen(url, timeout=6) as r:
        g = _j.loads(r.read().decode("utf-8", "replace"))
    _res = g.get("results") or []
    res = (next((x for x in _res
                 if x.get("country_code") == "PK"), None)
           or next((x for x in _res
                    if (x.get("name") or "").lower() == key),
                   None))
    _WX_GEO_CACHE[key] = res
    return res


def _wx_fetch(city):
    """Real weather for one city (Open-Meteo). If not found, None —
    a number is never fabricated."""
    import urllib.request as _u, urllib.parse as _up
    import json as _j
    try:
        res = _wx_geocode(city)
        if not res:
            return None
        tz = res.get("timezone") or "Asia/Karachi"
        url = ("https://api.open-meteo.com/v1/forecast?"
               + _up.urlencode({
                   "latitude": res["latitude"],
                   "longitude": res["longitude"],
                   "current": ("temperature_2m,relative_"
                               "humidity_2m,apparent_"
                               "temperature,weather_code,"
                               "wind_speed_10m"),
                   "daily": ("temperature_2m_max,"
                             "temperature_2m_min,weather_code,"
                             "precipitation_probability_max"),
                   "timezone": tz, "forecast_days": 3,
                   "past_days": 1}))
        with _u.urlopen(url, timeout=6) as r:
            f = _j.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return None
    cur = f.get("current") or {}
    day = f.get("daily") or {}
    if cur.get("temperature_2m") is None:
        return None

    def _at(lst, i):
        try:
            return (lst or [])[i]
        except Exception:
            return None
    return {"name": res.get("name") or city.title(),
            "temp": cur.get("temperature_2m"),
            "feels": cur.get("apparent_temperature"),
            "hum": cur.get("relative_humidity_2m"),
            "wind": cur.get("wind_speed_10m"),
            "code": cur.get("weather_code"),
            "max": [_at(day.get("temperature_2m_max"), 1),
                    _at(day.get("temperature_2m_max"), 2)],
            "min": [_at(day.get("temperature_2m_min"), 1),
                    _at(day.get("temperature_2m_min"), 2)],
            "pop": [_at(day.get("precipitation_probability_max"), 1),
                    _at(day.get("precipitation_probability_max"), 2)],
            "yest": (_at(day.get("temperature_2m_max"), 0),
                     _at(day.get("temperature_2m_min"), 0),
                     _at(day.get("weather_code"), 0))}


def _wx_block(w, kal=False):
    idx = 1 if kal else 0
    desc = _WX_CODES.get(w["code"], "")
    lines = [f"{w['name']} weather (now): {w['temp']:.0f}°C"
             + (f" — {desc}" if desc else "")]
    extra = []
    if w["feels"] is not None:
        extra.append(f"Feels like: {w['feels']:.0f}°C")
    if w["hum"] is not None:
        extra.append(f"Humidity: {w['hum']:.0f}%")
    if w["wind"] is not None:
        extra.append(f"Wind: {w['wind']:.0f} km/h")
    if extra:
        lines.append(" • ".join(extra))
    if w["max"][idx] is not None and w["min"][idx] is not None:
        lab = "Tomorrow" if kal else "Today"
        lines.append(f"{lab}: high {w['max'][idx]:.0f}°C, "
                     f"low {w['min'][idx]:.0f}°C")
    if w["pop"][idx] is not None:
        lines.append(f"Chance of rain: {w['pop'][idx]:.0f}%")
    return "\n".join(lines)


def _wx_line(w, kal=False):
    idx = 1 if kal else 0
    desc = _WX_CODES.get(w["code"], "")
    s = f"{w['name']}: now {w['temp']:.0f}°C"
    if desc:
        s += f", {desc}"
    if w["max"][idx] is not None and w["min"][idx] is not None:
        s += f" — {'tomorrow' if kal else 'today'} {w['max'][idx]:.0f}°/{w['min'][idx]:.0f}°C"
    if w["pop"][idx] is not None:
        s += f", chance of rain {w['pop'][idx]:.0f}%"
    return s


def _weather_answer(q):
    """Weather question: however many cities are in the question, real data
    for ALL. Cities via geocoding — list is only for identification,
    not a limit. If not found/failed, an honest reply (if sent to AI,
    it will fabricate a number — this lesson has been learned)."""
    ql = " " + (q or "").lower() + " "
    if not _wx_hit(q):
        return None
    kal = (" kal " in ql or "tomorrow" in ql)
    idx = 1 if kal else 0
    hits = []
    for c in _WX_CITIES:
        pos = ql.find(" " + c)
        if pos >= 0:
            hits.append((pos, c))
    hits.sort()
    cities = [c for _, c in hits]
    where_q = any(k in ql for k in ("kahan", "kidhar", "kis jaga",
                                     "kis city", "kis sheher",
                                     "kon se", "where"))
    rain_q = any(k in ql for k in ("barish", "baarish")) \
        or _kw_match(ql, words=("rain",))
    if where_q and rain_q:
        # v98 (S1e): the answer to 'WHERE can it rain' is NOT
        # one city's today-weather card — even if the question
        # names a city, the panel (major cities,
        # ordered by chance) is the answer. If panel data is not
        # found, None — the question will go to the AI; a single-city
        # card will never become the answer to this question.
        rows = []
        for c in _WX_PANEL:
            w = _wx_fetch(c)
            if w:
                rows.append(w)
        if not rows:
            return None
        rows.sort(key=lambda w: (w["pop"][idx] or 0),
                  reverse=True)
        lab = "Tomorrow" if kal else "Today"
        lines = [f"{lab} rain chance — major cities "
                 f"(real data, highest chance first):"]
        for w in rows:
            pop = w["pop"][idx]
            lines.append(f"{w['name']}: "
                         + (f"{pop:.0f}%" if pop is not None
                            else "no data"))
        return "\n".join(lines)
    if not cities and where_q:
        rows = []
        for c in _WX_PANEL:
            w = _wx_fetch(c)
            if w:
                rows.append(w)
        if not rows:
            return _WX_FAIL_MSG
        rows.sort(key=lambda w: (w["pop"][idx] or 0), reverse=True)
        lab = "Tomorrow" if kal else "Today"
        lines = [f"{lab} rain chance — major cities "
                 f"(real data, highest chance first):"]
        for w in rows:
            pop = w["pop"][idx]
            lines.append(f"{w['name']}: "
                         + (f"{pop:.0f}%" if pop is not None
                            else "no data"))
        return "\n".join(lines)
    notes = []
    if cities:
        stop2 = set(_WX_WORDS) | {
            "ka", "ki", "ke", "mein", "me", "hai", "hy", "aaj",
            "kal", "aur", "and", "batao", "batabo", "bata", "do",
            "kesa", "kaisa", "kya", "kia", "haal", "the", "what",
            "is", "today", "tomorrow", "please", "plz", "abhi",
            "imkaan", "imkan", "chance", "ho", "hogi", "sakti",
            "bhi", "mosam", "mausam"}
        for c in cities:
            for part in c.split():
                stop2.add(part)
        probed = 0
        _words80 = ql.split()
        for tok in re.findall(r"[a-z]{3,}", ql):
            if probed >= 2:
                break
            if tok in stop2:
                continue
            _i80 = (_words80.index(tok) if tok in _words80
                    else -1)
            _nxt = (_words80[_i80 + 1]
                    if 0 <= _i80 < len(_words80) - 1 else "")
            _nx2 = (_words80[_i80 + 2]
                    if 0 <= _i80 < len(_words80) - 2 else "")
            _prv = _words80[_i80 - 1] if _i80 > 0 else ""
            _cityctx = ((_nxt in ("ka", "ki")
                         and _nx2 in ("mosam", "mausam",
                                      "weather", "haal", "hal"))
                        or (_prv == "aur"
                            and _nxt in ("ka", "ki", "ke",
                                         "mein", "me")))
            if not _cityctx:
                continue
            probed += 1
            try:
                res = _wx_geocode(tok)
            except Exception:
                res = None
            if res:
                cities.append(tok)
            else:
                notes.append(tok.title())
    if not cities:
        stop = set(_WX_WORDS) | {
            "ka", "ki", "ke", "mein", "me", "hai", "hy", "aaj",
            "kal", "aur", "batao", "batabo", "bata", "do", "kesa",
            "kaisa", "kesy", "kya", "kia", "haal", "hal", "the",
            "what", "is", "today", "tomorrow", "weather", "please",
            "plz", "abhi", "ka", "imkaan", "imkan", "chance",
            "ho", "hogi", "sakti", "wala", "wali"}
        tried = False
        for tok in re.findall(r"[a-z]{3,}", ql):
            if tok in stop:
                continue
            tried = True
            try:
                res = _wx_geocode(tok)
            except Exception:
                res = None
            if res:
                cities = [tok]
                break
        if not cities:
            if tried:
                return ("This City Was Not Found In The Weather "
                        "Records — Please Check The City Name And "
                        "Try Again.")
            cities = ["karachi"]
    blocks = []
    multi = len(cities) > 1
    for c in cities[:4]:
        w = _wx_fetch(c)
        if w:
            if multi:
                blocks.append(_wx_line(w, kal))
            elif _wx_detail_asked(ql):
                blocks.append(_wx_detail_block(w))
            else:
                blocks.append(_wx_block(w, kal))
    for n in notes:
        blocks.append(f"The Weather For {n} Could Not Be Loaded — "
                      f"This City Was Not Found In The Records.")
    if not blocks:
        return _WX_FAIL_MSG
    return "\n".join(blocks)


# ================= v80: date, web search, file =================

def _today_line():
    from datetime import timedelta, timezone
    now = datetime.now(timezone(timedelta(hours=5)))
    return ("\nTODAY'S DATE: " + now.strftime("%A %d %B %Y")
            + " (Pakistan time). Use THIS date for every "
            "date-relative question (next Ramzan, kal, "
            "deadlines) — never answer dates from old memory. "
            "APP FILES: this app creates REAL downloadable "
            "files — PDF, Excel (CSV) and Text — for a "
            "shipment, for lists, and on ANY other topic the "
            "user names; the app attaches the real file "
            "button itself. If he ASKS whether you can make "
            "a file or PDF, say YES and ask the topic — never "
            "claim you cannot make files. REFERENCE MATERIAL: "
            "the app sometimes attaches reference material "
            "with a question — use its facts, but never claim "
            "you browsed or searched the web yourself and "
            "never cite 'web results' as your source; if no "
            "material is attached and a fact needs live data, "
            "say plainly that it is not available in the app. "
            "If he asks a "
            "question, ANSWER it — only DO something when "
            "he asks you to do it.\n")


def _profile_line():
    """v98 (S1c): the user's saved Profile name must go into the AI's system
    context — the answer to 'what is my name' must come
    from the app's Profile, never from AI memory/guess.
    If there is no name, that is clearly written so the AI does not
    fabricate a name."""
    try:
        name = str(get_settings().get("profile_name")
                   or "").strip()
    except Exception:
        name = ""
    if name:
        return ("\nUSER PROFILE: the user's name, saved in "
                "this app's Profile (Settings), is " + name
                + ". If he asks his name (e.g. 'mera naam "
                "kya hai'), answer with THIS name.\n")
    return ("\nUSER PROFILE: no name is saved in this app's "
            "Profile yet. If he asks his name, say plainly "
            "that no name is saved in the Profile — never "
            "guess or invent one.\n")


_NO_WEB_RULE = (
    "WEB HONESTY (hard rule): you cannot browse the web "
    "and you never have. Never claim to have browsed, "
    "searched or checked the web, and never cite 'web "
    "results' as a source — in any language (e.g. never "
    "write 'Web results ke mutabiq'). The only outside "
    "information you have is material the app itself "
    "attaches to the question; use it without calling it "
    "your own browsing. If a fact needs live data that "
    "the app has not provided in this conversation, say "
    "plainly that it is not available in the app.\n")


def _wx_hit(q):
    ql = " " + (q or "").lower() + " "
    # v98 (S1e): questions with 'temperature'/'forecast'/'humidity'
    # are also weather — before, these words were outside the lane,
    # so such a question went to the AI and brought back a 'no live
    # internet' answer, while a 'weather' question in the lane
    # brought live data (an inconsistency).
    return bool(any(w in ql for w in
                    ("mosam", "mausam", "garmi", "barish",
                     "baarish", "sardi", "dhund"))
                or _kw_match(ql, words=("weather", "rain",
                                        "fog", "temperature",
                                        "forecast", "humidity")))


def _is_capability_q(q):
    ql = " " + (q or "").lower() + " "
    return any(s in ql for s in
               ("sakte ho", "sakta hai", "sakti hai",
                "sakte hain", "can you", "kya tum", "kia tum",
                "kya aap", "ho sakta", "mumkin hai",
                "possible hai"))


def _generic_file_req(q, local_q=None):
    """A clear request for a file on a topic outside shipments —
    (format, topic) or None. On a question ('can you make it?')
    None — asking does not create a file."""
    if not _media_ask(q) or _is_capability_q(q):
        return None
    if _find_mentioned_entry(local_q or q):
        return None
    ql = " " + (q or "").lower() + " "
    if any(s in ql for s in ("shipment", "arriving", "arrivals",
                             " list ", "sab ki", "in sab")):
        return None
    fmt = ("txt" if (_kw_match(ql, words=("txt",))
                     or "text file" in ql) else "pdf")
    topic = ql
    for w in ("text file", "pdf", "file", "txt"):
        topic = topic.replace(" " + w + " ", " ")
    topic = " ".join(topic.split()).strip()
    tails = ("bana do", "de do", "banao", "banana", "bana",
             "chahiye", "download", "do", "de", "par", "mein",
             "report")
    changed = True
    while changed:
        changed = False
        for tword in tails:
            if topic.endswith(" " + tword):
                topic = topic[: -len(tword)].strip()
                changed = True
        if topic in tails:
            topic = ""
    for lead in ("ek", "mujhe", "mujhy", "please", "plz"):
        if topic.startswith(lead + " "):
            topic = topic[len(lead):].strip()
    topic = topic.strip(" ?.")
    if len(topic) < 3:
        return None
    return fmt, topic


def _web_search(q, hist=None):
    """Live internet search (DuckDuckGo — free, without a key)
    so AI answers from real results, not from memory.
    If not found, an empty string."""
    import urllib.request as _u, urllib.parse as _up
    import html as _html
    ql = " " + (q or "").lower() + " "
    skip = ("tum kon", "tumhara naam", "your name", "shukriya",
            "thank", "tum sunao", "apne bare", "kaise ho",
            "kese ho", "acha laga", "theek ho", "zinda ho")
    if any(s in ql for s in skip):
        return ""
    query = (q or "").strip()
    words = query.split()
    if len(words) <= 4 and hist:
        for t in reversed(hist):
            if (t or {}).get("role") == "user" \
                    and (t.get("text") or "").strip():
                query = (t["text"].strip() + " " + query)[:200]
                break
    _hdr = {"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; "
                           "Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/126.0 "
                           "Safari/537.36"),
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9"}

    def _fetch(u):
        req = _u.Request(u, headers=_hdr)
        with _u.urlopen(req, timeout=7) as r:
            return r.read().decode("utf-8", "replace")

    def _ddg():
        page = _fetch("https://lite.duckduckgo.com/lite/?q="
                      + _up.quote_plus(query))
        got = []
        for m in re.finditer(
                r"<a[^>]*class='result-link'[^>]*>(.*?)</a>",
                page, re.S):
            tag = m.group(0)
            hm = re.search(r'href="([^"]+)"', tag)
            href = hm.group(1) if hm else ""
            title = _html.unescape(
                re.sub(r"<[^>]+>", "", m.group(1))).strip()
            rest = page[m.end():m.end() + 3000]
            sm = re.search(
                r"class='result-snippet'[^>]*>(.*?)</td>",
                rest, re.S)
            snip = (_html.unescape(re.sub(r"<[^>]+>", "",
                                          sm.group(1))).strip()
                    if sm else "")
            dom = ""
            um = re.search(r"uddg=([^&]+)", href)
            if um:
                dom = _up.urlparse(_up.unquote(um.group(1))).netloc
            elif href.startswith("http"):
                dom = _up.urlparse(href).netloc
            if title:
                got.append(f"- {title} ({dom})\n  {snip}")
            if len(got) >= 8:
                break
        return got

    def _bing():
        page = _fetch("https://www.bing.com/search?q="
                      + _up.quote_plus(query))
        got = []
        for m in re.finditer(r'<li class="b_algo".*?</li>',
                             page, re.S):
            blk = m.group(0)
            am = re.search(
                r'<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                blk, re.S)
            if not am:
                continue
            title = _html.unescape(
                re.sub(r"<[^>]+>", "", am.group(2))).strip()
            pm = re.search(r"<p[^>]*>(.*?)</p>", blk, re.S)
            snip = (_html.unescape(re.sub(r"<[^>]+>", "",
                                          pm.group(1))).strip()
                    if pm else "")
            dom = _up.urlparse(am.group(1)).netloc
            if title:
                got.append(f"- {title} ({dom})\n  {snip}")
            if len(got) >= 8:
                break
        return got

    import time as _time
    out = []
    for _att, _fn in enumerate((_ddg, _ddg, _bing)):
        if _att:
            _time.sleep(1.0)
        try:
            out = _fn()
        except Exception:
            out = []
        if out:
            break
    if not out:
        return ""
    return ("\n\nWEB RESULTS (from today's live internet "
            "search — base your answer on these, and name "
            "the source):\n" + "\n".join(out))[:4500]


def _wx_detail_block(w):
    lines = [f"{w['name']} weather — detailed report:"]
    yest = w.get("yest") or (None, None, None)
    if yest[0] is not None and yest[1] is not None:
        desc = _WX_CODES.get(yest[2], "")
        lines.append(
            f"Yesterday: high {yest[0]:.0f}°C, "
            f"low {yest[1]:.0f}°C"
            + (f" — {desc}" if desc else ""))
    lines.append(_wx_block(w, False))
    if w["max"][1] is not None and w["min"][1] is not None:
        s = (f"Tomorrow: high {w['max'][1]:.0f}°C, "
             f"low {w['min'][1]:.0f}°C")
        if w["pop"][1] is not None:
            s += f"; chance of rain {w['pop'][1]:.0f}%"
        lines.append(s)
    return "\n".join(lines)


def _wx_detail_asked(ql):
    return any(k in ql for k in
               ("guzra", "guzre", "guzri", "yesterday", "pichla",
                "peechla", "beeta", "detail", "tafseel",
                "teen din", "3 din", "three days",
                "poori report"))


def _gemini_body(q, hist, extra="", ctx_override=None):
    """Real answer from Google Gemini (free tier). If any error occurs,
    None — never false reassurance."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    contents = []
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:800]
        if t:
            contents.append({"role": "user" if h.get("role") == "user"
                             else "model",
                             "parts": [{"text": t}]})
    contents.append({"role": "user", "parts": [{"text": q}]})
    # v73: do not send live data on a clear greeting (a light, fast
    # request); recognise after stripping punctuation — if money or a shipment
    # word is present, never skip.
    _qn = re.sub(r"[^a-z ]", "", (q or "").lower())
    _qn = re.sub(r"\s+", " ", _qn).strip()
    _greet = _qn in (
        "hi", "hello", "hey", "salam", "slam", "aoa",
        "kese ho", "kaise ho", "kese hi", "kese ho bhai",
        "hello bhai", "assalam o alaikum", "assalamualaikum")
    context_data = "" if _greet else (ctx_override if ctx_override is not None else _assistant_context_for(q, " ".join(str((h or {}).get("text") or "") for h in (hist or [])[-4:])))
    sys_txt = (
        "You are CargoTrack Assistant, the assistant built into this app - not ChatGPT or any other product, never introduce yourself as one. This is a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. FORMAT: put each fact on its OWN line - for a shipment: the BL on one line, then Vessel, ETA, Terminal and Status each on its own line; never cram several facts into one long sentence, and use bold sparingly. When he asks about different periods (this week, next month), answer in SEPARATE sections, one per period, each with its own heading and count; next month means the next calendar month only - never merge periods or repeat an item in two sections. When he asks what goods or items are inside a container, answer ONLY from the goods recorded in the data; if no goods are recorded for it, say so plainly in your FIRST sentence - never answer an item question with vessel details. For the four critical stages (vessel departed, vessel berthed, container discharged, gate out) answer ONLY from the MILESTONES data and always state its certainty in your reply (final / confirmed / 1 source only / estimate); call every ETA an estimate, never a fact; if a milestone says CONFLICT, tell him the records disagree instead of picking one. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. Answer EXACTLY the question he asked - never substitute a different answer. When he asks for all / every / tamaam / sab, enumerate the COMPLETE matching list from the data below and state how many there are; presenting a partial list as complete is the worst possible answer. The COMPUTED FACTS section was counted by the app from ALL records - trust it over your own counting and date maths. If he asks for a photo, image, card or report but has NOT named a shipment in this conversation, ask in ONE short line which BL he means - never pick a shipment for him, and never volunteer information he did not ask for. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app attaches the real file button under your reply when a shipment is identified - so say only one short line such as: the file button is below. NEVER claim a file is ready when no shipment was identified - in that case ask which BL he means. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically." + _today_line() + _profile_line() + _NO_WEB_RULE + "\n\nLIVE APP DATA:\n"
        + context_data + extra)
    body = {"systemInstruction": {"parts": [{"text": sys_txt}]},
            "contents": contents,
            "generationConfig": {"temperature": 0.2,
                                 "maxOutputTokens": 1000}}
    return body


def _gemini_answer(q, hist, key, extra=""):
    """Only the Gemini path (old behaviour retained)."""
    body = _gemini_body(q, hist, extra)
    d, _code = _gemini_gen_race(key, body, timeout=45)
    if not d:
        return None
    return _gemini_text(d) or None


def _find_mentioned_entry(text):
    t = ENG.norm(text or "")
    if not t:
        return None
    for h in get_history():
        if h.get("query") and h["query"].upper() in t:
            return h
        for c in ((h.get("result") or {}).get("containers") or []):
            if c and c.upper() in t:
                return h
    return None


_MEDIA_WORDS = ("image", "photo", "tasveer", "picture", "pic", "jpg",
                "jpeg", "png", "card", "pdf", "report", "file", "download",
                "excel", "csv", "spreadsheet", "txt", "text file")


def _media_ask(q):
    """v47: media (image/card/PDF/report) is created ONLY when the user
    has clearly asked for it in this question. On just asking for a BL's status,
    no card/report is created — only a text reply."""
    ql = (q or "").lower()
    return any(re.search(r"\b" + w + r"\b", ql) for w in _MEDIA_WORDS)


def _media_intent_actions(q, local_q, hist=None):
    """For the shipment being discussed — whether mentioned in this question
    or in the previous conversation — full options for it:
    Image, Report, Copy, WhatsApp. BUT since v47, these
    actions only appear when the user has clearly asked for media
    (_media_ask) — otherwise the reply is only text."""
    media = _media_ask(q)
    entry = _find_mentioned_entry(local_q)
    if not entry and media:
        # look at the previous conversation in reverse order — the most
        # recently mentioned shipment is the topic (only when media
        # is requested; in normal conversation do not bring up old talk)
        for turn in reversed(hist or []):
            if (turn or {}).get("role") == "user":
                entry = _find_mentioned_entry(turn.get("text"))
                if entry:
                    break
    if entry and not media:
        # Shipment was identified but media was not requested —
        # v47: only a compact text reply, no action.
        return []
    if not entry:
        if media:
            rec = []  # v57: no card is created for any shipment without asking for the BL
            # (the old code used to create Image/Report buttons for the first
            #  3 shipments on its own - the same mistake the user caught)
            acts_r = []
            for h in rec:
                acts_r.append({"label": "\U0001F5BC Image — "
                               + h["query"], "act": "image",
                               "arg": h["query"]})
                acts_r.append({"label": "\U0001F4C4 Report — "
                               + h["query"], "act": "report",
                               "arg": h["query"]})
            if acts_r:
                return acts_r
        m = re.search(r"\b[A-Z0-9][A-Z0-9\-]{5,}\b",
                      (local_q or "").upper())
        if m and any(c.isdigit() for c in m.group(0)):
            return [{"label": "\U0001F50D Track — " + m.group(0),
                     "act": "track", "arg": m.group(0),
                     "mode": "bl"}]
        return []
    qy = entry["query"]
    # v47 fix: only the media that was requested is created — only an image
    # request also used to create a report tile (QA finding D3).
    ql = (q or "").lower()

    def _has(words):
        return any(re.search(r"\b" + w + r"\b", ql) for w in words)

    want_img = _has(("image", "photo", "tasveer", "picture",
                     "pic", "jpg", "jpeg", "png", "card"))
    want_rep = _has(("pdf", "report", "file"))
    want_csv = _has(("excel", "csv", "spreadsheet"))
    want_txt = _has(("txt", "text"))
    if _has(("download",)) and not want_img and not want_rep:
        want_img = want_rep = True
    if not want_img and not want_rep:
        want_img = want_rep = True
    acts = []
    if want_img:
        acts.append({"label": "\U0001F5BC Image — " + qy,
                     "act": "image", "arg": qy})
    if want_rep:
        acts.append({"label": "\U0001F4C4 Report — " + qy,
                     "act": "report", "arg": qy})
    if want_csv:
        acts.append({"label": "\U0001F4CA Excel (CSV) — " + qy,
                     "act": "csv", "arg": qy})
    if want_txt:
        acts.append({"label": "\U0001F4DD Text file — " + qy,
                     "act": "txt", "arg": qy})
    acts.append({"label": "\U0001F4CB Copy — " + qy, "act": "copy",
                 "arg": qy})
    acts.append({"label": "\U0001F4AC WhatsApp — " + qy,
                 "act": "wa", "arg": qy})
    return acts


def _send_escalation(turns, title=""):
    """v59: Sending the Assistant chat to the user's OWN email
    (from there Shezi reads it and finds a solution). The Gmail App
    Password is in Settings - without it, not_set."""
    st = get_settings()
    user = str(st.get("mail_user")
               or "officeuseonlydell@gmail.com").strip()
    pw = str(st.get("mail_pass") or "").strip()
    if not pw:
        return {"ok": False, "reason": "not_set"}
    lines = []
    for t in (turns or [])[-60:]:
        who = "You" if (t or {}).get("role") == "user" else "Assistant"
        lines.append(f"{who}: {str((t or {}).get('text') or '')}")
    body = ("CargoTrack Assistant chat - the user needs help "
            "with this.\nChat: " + (title or "Assistant chat")
            + "\n\n" + "\n\n".join(lines))
    import smtplib
    from email.mime.text import MIMEText
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = "CargoTrack Assistant - chat sent"
    msg["From"] = user
    msg["To"] = user
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=30) as sm:
            sm.login(user, pw)
            sm.send_message(msg)
        return {"ok": True}
    except Exception:
        return {"ok": False, "reason": "send_failed"}


def assistant_answer(q, hist=None, attach=None):
    extra = ""
    local_q = q
    if attach:
        if attach.get("kind") == "image" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            if raw:
                ok, val = _ocr_image_bytes(raw)
                if ok:
                    nums = re_find_numbers(val)
                    extra = ("\n\nATTACHED PHOTO — text read "
                             "from it:\n" + val[:1500])
                    if nums:
                        extra += ("\nNumbers found in the photo: "
                                  + ", ".join(nums))
                        local_q = q + " " + " ".join(nums)
                else:
                    extra = ("\n\nThe user attached a photo, but "
                             "this computer could not read it: "
                             + val)
        elif attach.get("kind") == "pdf" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            ptxt = _pdf_text(raw) if raw else ""
            if ptxt:
                nums = re_find_numbers(ptxt)
                extra = ("\n\nATTACHED PDF ("
                         + str(attach.get("name") or "file")[:60]
                         + ") — text read from it:\n" + ptxt[:4000])
                if nums:
                    extra += ("\nNumbers found in the PDF: "
                              + ", ".join(nums))
                    local_q = q + " " + " ".join(nums)
            else:
                extra = ("\n\nThe user attached a PDF, but no text "
                         "could be read from it on this computer (it "
                         "may be a scanned-image PDF). Say so honestly "
                         "in one line and suggest sending a photo of "
                         "the page instead.")
        elif attach.get("kind") == "file":
            extra = ("\n\nATTACHED FILE ("
                     + str(attach.get("name") or "file")[:60]
                     + ") — its text:\n"
                     + str(attach.get("text") or "")[:4000])
    if not attach and _media_ask(q) and _is_capability_q(q):
        return {"answer": "Yes — I Can Create A Real File: "
                "PDF, Excel (CSV) Or Text — For One Shipment, "
                "A List Of Shipments, Or Any Other Topic. To "
                "Create One, Tell Me The Topic And Say 'Create "
                "It'; I Will Prepare The Content And Give You "
                "The Actual File Button.",
                "actions": [], "mode": "local"}
    acts = _media_intent_actions(q, local_q, hist)
    # v59: if file/media is requested and no shipment has been
    # identified, the AI's false claim ("it is ready") will not work - the app
    # itself decides: if it is a file from the list, the real file action,
    # otherwise a clear question asking which BL's file is needed.
    if (_media_ask(q) and not acts and not attach
            and not _wx_hit(q)
            and not _generic_file_req(q, local_q)):
        ql59 = (q or "").lower()
        prev_list = False
        if len((q or "").split()) <= 5:
            for t59 in reversed(hist or []):
                if (t59 or {}).get("role") == "model":
                    _pt = (t59.get("text") or "")
                    prev_list = ("shipment(s)" in _pt
                                 or "Arriving" in _pt)
                    break
        list_cue = any(w in ql59 for w in
                       ("list", "tamaam", "aane wal", "shipment",
                        "arriving", "arrivals", "in sab", "sab ki"))
        if list_cue or prev_list:
            rows59 = _arrivals_rows(30)
            if rows59:
                fmt59 = ("csv" if ("excel" in ql59 or "csv" in ql59)
                         else "txt" if ("txt" in ql59
                                        or "text file" in ql59)
                         else "pdf")
                lbl59 = ("📊 Excel (CSV) — Arriving shipments"
                         if fmt59 == "csv" else
                         "📝 Text file — Arriving shipments"
                         if fmt59 == "txt" else
                         "📄 PDF — Arriving shipments")
                return {"answer": "The file button is below - it has "
                        f"{len(rows59)} arriving shipment(s).",
                        "actions": [{"label": lbl59, "act": "filelist",
                                     "fmt": fmt59,
                                     "title": "Arriving shipments",
                                     "rows": rows59}],
                        "mode": "local"}
        return {"answer": "For a photo, image, report or file, type "
                "the shipment's BL number - which BL do you need? "
                "Example: 'pdf of 142G513366'.",
                "actions": [], "mode": "local"}
    # v82: prepared greeting lane ENDED (his firm instruction of
    # 26 Oct) — the real AI will now also reply to greetings/prayers.
    if not attach:
        _wx = _weather_answer(q)
        if _wx:
            return {"answer": _wx, "actions": acts,
                    "mode": "fast"}
    if not attach and _looks_data_q(local_q):
        _fl = _assistant_local(local_q)
        if _local_substantive(_fl):
            _fl["mode"] = "fast"
            _fl["actions"] = (_fl.get("actions") or []) + acts
            return _fl
    key = _ai_key_single()
    gk = _groq_key()
    want_file = None if attach else _generic_file_req(q, local_q)
    if key or gk:
        _t0 = time.time()
        extra2 = (extra or "") + _web_search(q, hist)
        if want_file:
            extra2 += ("\n\nFILE REQUEST: the user wants a "
                       "downloadable file on the topic '"
                       + want_file[1] + "'. Write the COMPLETE "
                       "file content as your reply: first line "
                       "the title, then the full, well-organized "
                       "content. The app attaches the real "
                       "download button under your reply.")
        try:
            txt = _ai_answer_any(q, hist, gk, key, extra2)
        except Exception:
            txt = None
        if not txt and _ai_fail_category() != "invalid key":
            # v98 (S1a): BEFORE any fallback, try those same
            # providers once again — on a temporary
            # timeout/error, do not give up immediately.
            # A retry on an invalid key is useless (the key does not
            # get fixed), so that case is an exception.
            try:
                txt = _ai_answer_any(q, hist, gk, key, extra2)
            except Exception:
                txt = None
        if txt:
            _acts80 = acts
            if want_file:
                _f80, _t80 = want_file
                _acts80 = acts + [{
                    "label": (("📄 PDF — " if _f80 == "pdf"
                               else "📝 Text file — ")
                              + _t80.title()[:44]),
                    "act": "textfile", "fmt": _f80,
                    "title": _t80.title(), "text": txt}]
            return {"answer": txt, "actions": _acts80,
                    "mode": "ai",
                    "ai_secs": round(time.time() - _t0, 1),
                    "ai_model": getattr(_GLOCAL, "model", ""),
                    "ai_path": getattr(_GLOCAL, "path", ""),
                    "ai_thoughts": getattr(_GLOCAL, "thoughts", 0)}
        out = _assistant_local(local_q,
                               _ai_why=_ai_fail_category())
        out["mode"] = "local"
        out["ai_error"] = True
        out["ai_note"] = _ai_fail_note()
        out["actions"] = (out.get("actions") or []) + acts
        return out
    out = _assistant_local(local_q)
    out["mode"] = "local"
    out["actions"] = (out.get("actions") or []) + acts
    return out


def _norm_status_s(s):
    """Exact copy of the Frontend's normStatus — so the Assistant's
    counts always match the Dashboard's counts."""
    s = (s or "").lower()
    if any(k in s for k in ("discharg", "unload", "gate out",
                            "delivered")):
        return "discharged"
    if "hold" in s:
        return "hold"
    if "released" in s:
        return "discharged"
    if any(k in s for k in ("arriv", "berth", "at port",
                            "anchorage")):
        return "arrived"
    if any(k in s for k in ("depart", "sail", "on board",
                            "loaded")):
        return "departed"
    if "tranship" in s or "transship" in s:
        return "transhipment"
    return "in_transit"


def _is_completed_s(h):
    r = h.get("result") or {}
    lc = h.get("lifecycle")
    if lc:
        return (lc.get("stage") == "out")
    s = (r.get("status") or "").lower()
    return bool(r.get("gate_out")) or ("deliver" in s) \
        or ((r.get("position") or "").strip().upper()
            == "OUT")


def _ast_on_hold(h):
    """The ONE hold rule for every Assistant count — the exact mirror
    of the client's ctOnHold, so the Assistant, the stat card and the
    Alerts panel can never give different numbers for the same data:
    not completed, and the terminal has placed holds on the cargo
    (the holds list) or the status itself is the hold family."""
    r = h.get("result") or {}
    if _is_completed_s(h):
        return False
    return bool(r.get("holds")) or \
        _norm_status_s(r.get("status")) == "hold"


def _assistant_local(q, _rec=False, _ai_why=None):
    from datetime import timedelta, timezone
    """The in-app helper: its answers are always built from the
    app's OWN data and the system's real state — never a guess.
    Where something is beyond it, it clearly says to ask Shezi."""
    ql = q.lower()
    hist = _scoped_history()
    st = get_settings()
    today = datetime.now(timezone(timedelta(hours=5))).date()
    acts = []
    lines = []

    def track_act(query, mode, label=None):
        acts.append({"label": label or f"Track {query}",
                     "act": "track", "arg": query, "mode": mode})

    # v91 (as promised, 27 Oct): identifying a record by its last digits (suffix),
    # and building a list of several numbers directly from the records —
    # these replies do not stop at the AI limit/mode.
    if not _rec:
        _full91 = [t.upper() for t in
                   re.findall(r"[A-Za-z0-9]{8,20}", q)
                   if any(ch.isdigit() for ch in t)]
        # v115: a digit run INSIDE a longer alphanumeric token
        # (the tail of a full BL/container number) is not a
        # standalone suffix — counting it as one made the
        # replace below mangle a full number typed in the
        # question (EMKAYMBAKHI + EMKAYMBAKHI59203 doubling).
        _sfx91 = re.findall(r"(?<![A-Za-z0-9])[0-9]{5,7}(?![0-9A-Za-z])", q)
        _want_list = (len(_full91) > 1 or len(_sfx91) > 1 or any(
            w in ql for w in ("list", "mukammal", "sab ke", "sab ki",
                              "tamam", "saare", "saari")))

        def _resolve91(num):
            hits = []
            for h in hist:
                hq = str(h.get("query") or "").upper()
                if hq.endswith(num):
                    hits.append(h)
                    continue
                for c in ((h.get("result") or {}).get("containers")
                          or []):
                    if str(c).upper().endswith(num):
                        hits.append(h)
                        break
            return hits

        if _want_list and (_full91 or _sfx91):
            _entries91, _miss91, _seen91 = [], [], set()
            for t in _full91:
                h = next((x for x in hist
                          if x["query"].upper() == t), None) or \
                    next((x for x in hist if t in
                          ((x.get("result") or {}).get("containers")
                           or [])), None)
                if h and h["query"] not in _seen91:
                    _entries91.append(h)
                    _seen91.add(h["query"])
                elif not h:
                    _miss91.append(t)
            for sf in _sfx91:
                hs = _resolve91(sf)
                if not hs:
                    _miss91.append("…" + sf)
                for h in hs:
                    if h["query"] not in _seen91:
                        _entries91.append(h)
                        _seen91.add(h["query"])
            if _entries91:
                lines.append("Full numbers from your tracked "
                             "shipments:")
                for h in _entries91:
                    r = h.get("result") or {}
                    cs = (", ".join(r.get("containers") or [])
                          or "no container recorded")
                    lines.append(
                        f"• {h['query']} — containers: {cs}"
                        + (f" — {r['status']}" if r.get("status")
                           else "")
                        + (f" — ETA {r['eta']}" if r.get("eta")
                           else ""))
                    track_act(h["query"], h.get("mode") or "bl",
                              f"↻ Check {h['query']}")
                for m in _miss91:
                    lines.append(f"• {m} — no tracked record ends "
                                 "with these digits.")
                return {"answer": "\n".join(lines), "actions": acts}
        elif _sfx91:
            hs = _resolve91(_sfx91[0])
            if len(hs) == 1:
                # v115: never rewrite a question that already
                # carries the full number.
                if hs[0]["query"] in q:
                    return _assistant_local(q, _rec=True)
                return _assistant_local(
                    q.replace(_sfx91[0], hs[0]["query"], 1), _rec=True)
            if len(hs) > 1:
                lines.append(f"More than one tracked shipment ends "
                             f"with {_sfx91[0]} — which one do you "
                             "mean?")
                for h in hs:
                    r = h.get("result") or {}
                    lines.append(f"• {h['query']}"
                                 + (f" — {r['status']}"
                                    if r.get("status") else ""))
                    track_act(h["query"], h.get("mode") or "bl",
                              f"Open {h['query']}")
                return {"answer": "\n".join(lines), "actions": acts}

    # 1) if the question contains a number, its full report
    # number = at least 8 characters/digits AND a digit is mandatory in it
    # (otherwise common words like "shipments" also used to become numbers)
    token = None
    for cand in re.findall(r"[A-Za-z0-9]{8,20}", q):
        if any(ch.isdigit() for ch in cand):
            token = cand.upper()
            break
    if token and not any(k in ql for k in
                         ("how", "what", "why", "kaise", "kya")):
        h = next((x for x in hist if x["query"].upper() == token),
                 None)
        if not h:
            h = next((x for x in hist
                      if token in ((x.get("result") or {})
                                   .get("containers") or [])), None)
        if h:
            r = h.get("result") or {}
            lines.append(f"{h['query']} — "
                         f"{'FOUND' if h['found'] else 'NOT FOUND'}"
                         f" ({h.get('carrier') or 'carrier unknown'})")
            if r.get("status"):
                lines.append(f"Status: {r['status']}")
            if r.get("vessel"):
                lines.append("Vessel: " + r["vessel"] +
                             (f" ({r['voyage']})" if r.get("voyage")
                              else ""))
            if r.get("eta"):
                lines.append(f"ETA: {r['eta']}")
            if r.get("terminal"):
                lines.append(f"Terminal: {r['terminal']}")
            if r.get("position"):
                lines.append(f"Position: {r['position']}")
            if r.get("holds"):
                lines.append(f"Holds: {r['holds']}")
            if (r.get("containers") or []):
                lines.append("Containers: "
                             + ", ".join(r["containers"]))
            if h.get("found"):
                _st60 = []
                for _m in _milestones(h):
                    _lb = {"departed": "Departed",
                           "berthed": "Berthed",
                           "discharged": "Discharged",
                           "gateout": "Gate out"}[_m["key"]]
                    if _m["state"] == "done":
                        _st60.append(_lb + ": YES"
                                     + (f" ({_m['when']})"
                                        if _m["when"] else "")
                                     + {"final": " [final — "
                                        "terminal record]",
                                        "confirmed": " [confirmed]",
                                        "single": " [1 source only]"}
                                     .get(_m["certainty"], ""))
                    elif _m["state"] == "partial":
                        _st60.append(_lb + ": PARTIAL"
                                     + (f" ({_m['when']})"
                                        if _m["when"] else ""))
                    elif _m["state"] == "expected":
                        _st60.append(_lb + ": expected "
                                     + _m["when"] + " (estimate)")
                    elif _m["state"] == "conflict":
                        _st60.append(_lb + ": RECORDS CONFLICT — "
                                     "not final")
                    else:
                        _st60.append(_lb + ": not yet")
                lines.append("Stages: " + " · ".join(_st60))
            _lc62 = _lifecycle(h)
            if _lc62["stage"] == "out":
                lines.append("Stage: OUT OF PORT — this shipment "
                             "is in the Completed section"
                             + (f" (gate out {_lc62['gate_out']})"
                                if _lc62["gate_out"] else "")
                             + ". No demurrage or empty-return "
                             "warnings apply to it; the full "
                             "record is kept.")
            # v96 FIX 3: 'Last checked' means = the last
            # ATTEMPT, not the old verified time —
            # otherwise the user thinks the record was never checked
            # again (data audit: checked was stuck on 22 Oct
            # even though a check had been done).
            lines.append(f"Last checked: "
                         f"{h.get('attempt_time') or h.get('time') or '—'}")
            if h.get("live_ok") is False and h.get("attempt_ts") \
                    and h.get("checked_ts") \
                    and (h["attempt_ts"] - h["checked_ts"]) > 180:
                lines.append("(That check found nothing newer — "
                             "the record shown was confirmed at "
                             f"{h.get('time') or '—'}.)")
            track_act(h["query"], h.get("mode") or "bl",
                      "↻ Check again now")
            return {"answer": "\n".join(lines), "actions": acts}
        lines.append(f"{token} is not in your tracked shipments yet.")
        track_act(token, "container"
                  if re.fullmatch(r"[A-Z]{4}\d{7}", token) else "bl",
                  f"Track {token} now")
        return {"answer": "\n".join(lines), "actions": acts}

    # 13) terminology / "what is it" — every common term in shipping
    GLOSS = {
      "demurrage": "Demurrage: the charge for keeping a container at the terminal BEYOND the free days after discharge. Counted per day, per container. Your free days are set in Settings (currently {fd}).",
      "detention": "Detention: the charge for keeping the container OUTSIDE the terminal (at your godown) beyond the allowed days after gate-out.",
      "bill of lading": "Bill of Lading (BL): the shipment's main document — the contract and receipt for the cargo. Its number tracks the whole shipment: vessel, route, containers, status.",
      " bl ": "BL (Bill of Lading): the shipment's main document and tracking number — one BL can carry several containers.",
      "eta": "ETA (Estimated Time of Arrival): the date the vessel is expected to reach the destination port. It is an estimate — it can move as the voyage progresses.",
      "etd": "ETD (Estimated Time of Departure): the date the vessel is expected to leave the loading port.",
      "gate pass": "Gate Pass: the terminal's permission for a truck to collect the container. 'GatePass Not Issued' means the release steps (delivery order, payments, holds) are not complete yet.",
      "delivery order": "Delivery Order (DO): the shipping line's order telling the terminal to release the cargo to you. It has an expiry date — after that it must be renewed.",
      "vir": "VIR (Vessel Inward Report): the terminal's arrival record for a vessel visit. The VIR number also tells the terminal honestly — PKKHIKICT means KICT, PKKHISAPT means SAPT, PKBQMQICT means QICT.",
      "hold": "Hold: the terminal, customs or the line has stopped the release — billing hold, customs hold or line hold. Cargo cannot move until the hold is cleared.",
      "yard": "Yard: the container's storage area inside the terminal. 'Position: YARD' means the container is physically inside, waiting for release steps.",
      "discharge": "Discharge: unloading the container from the vessel at the port. Your free days start counting from the discharge date.",
      "transhipment": "Transhipment (transshipment): the cargo changes vessel at an in-between port before reaching Karachi.",
      "transshipment": "Transhipment: the cargo changes vessel at an in-between port before reaching Karachi.",
      "free days": "Free days: the days after discharge during which the terminal charges no demurrage. Set yours in Settings — currently {fd} days.",
      "nvocc": "NVOCC: a carrier that books space on other lines' vessels instead of owning ships (like Emkay Line). Their house BLs are tracked through the terminal and the master line.",
      "teu": "TEU: Twenty-foot Equivalent Unit — the standard measure of container capacity. A 40ft container is 2 TEU.",
      "container": "Container number: 4 letters + 7 digits (like CSNU6961392). The last digit is a check digit — this app verifies it with the ISO 6346 formula.",
    }
    for term, definition in GLOSS.items():
        if (term in ql and any(w in ql for w in
                              ("kya hota", "kya hai", "what is",
                               "meaning", "matlab", "samjha",
                               "explain"))
                and not any(w in ql for w in
                            ("which", "list", "kons", "show me",
                             "kitn", "on hold", "batao", "konsi",
                             "konse", "kitne", "kitni", "kab "))):
            lines.append(definition.replace("{fd}",
                                            str(st.get("free_days", 7))))
            return {"answer": "\n".join(lines), "actions": acts}


    found = [h for h in hist if h["found"]]
    notfound = [h for h in hist if not h["found"]]

    # 1c) v57: media was requested but no shipment was identified
    # - no card is created by guesswork, first ask which BL's
    if _media_ask(q) and not _find_mentioned_entry(q):
        lines.append("For a photo, image or report, type the "
                     "shipment's BL number - which BL do you need? "
                     "Example: 'photo of 142G513366'.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 2) holds
    if _kw_match(ql, words=('hold', 'ruk', 'stuck', 'holds'), stems=()):
        hs = [h for h in found if _ast_on_hold(h)]
        if hs:
            lines.append(f"{len(hs)} shipment(s) on hold:")
            for h in hs:
                r = h["result"]
                lines.append(f"• {h['query']} — {r.get('status')}"
                             + (f" — hold: {r['holds']}"
                                if r.get("holds") else "")
                             + (f" ({r['terminal']})"
                                if r.get("terminal") else ""))
        else:
            lines.append("No shipment is on hold right now. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 3) arriving soon - v57: understanding the day-window in the question (20 days /
    # 2 week / week), provide the complete list along with the count
    if _kw_match(ql, words=('eta', 'kab aay', 'coming', 'expected', 'aane wal', 'aayenge', 'aayega', 'a raha', 'aa raha', 'tamaam', 'aane', 'dinon', 'agle din', 'lagne', 'lagega', 'aa rahi', 'aa rahe', 'aane wale', 'pohnch'), stems=('arriv',)):
        arr = []
        for h in found:
            d = _ast_date((h["result"] or {}).get("eta"))
            if d and d >= today and not _ast_completed(h):
                arr.append((d, h))
        arr.sort(key=lambda x: x[0])
        has_num = re.search(r"\d+\s*(day|days|din|roz|week|haft|month|mahin)", ql)
        nm_want = ("next month" in ql or "agle mahine" in ql
                   or "agla mahina" in ql or "next mahine" in ql)
        wk_want = ("week" in ql or "haft" in ql)
        if (nm_want or wk_want) and not has_num:
            def _fmt59(rows):
                out = []
                for d, h in rows:
                    r = h["result"]
                    out.append(str(h["query"]))
                    out.append(f"Vessel: {r.get('vessel') or '-'}")
                    out.append(f"ETA: {r.get('eta')}")
                    out.append(f"Terminal: {r.get('terminal') or '-'}")
                    out.append(f"Status: {r.get('status') or '-'}")
                    out.append("")
                return out
            if wk_want:
                rows = [(d, h) for d, h in arr
                        if (d - today).days <= 7]
                lines.append("Arriving this week (next 7 days) - "
                             f"{len(rows)} shipment(s):")
                lines.extend(_fmt59(rows) or ["None this week."])
            if nm_want:
                nmf = (today.replace(day=28)
                       + timedelta(days=4)).replace(day=1)
                rows = [(d, h) for d, h in arr
                        if d.year == nmf.year and d.month == nmf.month]
                lines.append(f"Arriving next month "
                             f"({nmf.strftime('%B %Y')}) - "
                             f"{len(rows)} shipment(s):")
                lines.extend(_fmt59(rows) or ["None next month."])
            while lines and lines[-1] == "":
                lines.pop()
            return {"answer": "\n".join(lines), "actions": acts}
        win = None
        m = re.search(r"(\d+)\s*(day|days|din|roz|week|hafte|"
                      r"hafta|month|mahin|maah)", ql)
        if m:
            u = m.group(2)
            win = int(m.group(1)) * (7 if u.startswith(("week",
                     "haft")) else 30 if u.startswith(("month",
                     "mahin", "maah")) else 1)
        elif "week" in ql or "haft" in ql:
            win = 7
        sel = [(d, h) for d, h in arr
               if win is None or (d - today).days <= win]
        if sel:
            lines.append("Arriving"
                         + (f" in the next {win} days" if win
                            else " (soonest first)")
                         + f" - {len(sel)} shipment(s):")
            for d, h in sel[:30]:
                r = h["result"]
                lines.append(str(h["query"]))
                lines.append(f"Vessel: {r.get('vessel') or '-'}")
                lines.append(f"ETA: {r.get('eta')}")
                lines.append(f"Terminal: {r.get('terminal') or '-'}")
                lines.append(f"Status: {r.get('status') or '-'}")
                lines.append("")
            if len(sel) > 30:
                lines.append(f"... and {len(sel) - 30} more.")
        else:
            lines.append("No upcoming arrivals with an ETA in "
                         "your list"
                         + (f" in the next {win} days." if win
                            else "."))
        return {"answer": "\n".join(lines), "actions": acts}

    # 4) delivered
    if _kw_match(ql, words=('pohanch', 'completed', 'done'), stems=('deliver',)):
        ds = [h for h in found if _ast_completed(h)]
        lines.append(f"{len(ds)} shipment(s) completed / delivered:")
        for h in ds[:10]:
            lines.append(f"• {h['query']} — "
                         f"{h['result'].get('status')}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 5) demurrage risk
    if _kw_match(ql, words=('demurrage', 'risk', 'late charge', 'free day'), stems=()):
        fd = st.get("free_days", 7)
        risk = []
        for h in found:
            if _ast_completed(h):
                continue
            d = _ast_date((h["result"] or {}).get("discharge_time"))
            if d and (today - d).days > fd:
                risk.append(((today - d).days - fd, h))
        risk.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if risk:
            lines.append("Demurrage risk (free days over):")
            for over, h in risk[:10]:
                lines.append(f"• {h['query']} — {over} day(s) over "
                             f"the {fd} free days")
        else:
            lines.append("No demurrage risk right now — nothing is "
                         "past its free days. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 6) not found help
    if _kw_match(ql, words=('not found', 'nahi mil', 'missing', 'no record'), stems=()):
        lines.append(f"You have {len(notfound)} not-found number(s):")
        for h in notfound[:10]:
            lines.append(f"• {h['query']}")
        lines.append("Common reasons: one letter typed wrong (the "
                     "app now suggests the close match from your "
                     "history), the carrier has not published the "
                     "record yet, or the system did not respond — "
                     "a 'not found' here never proves your number "
                     "is wrong. Retry after a while.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 15) the oldest pending shipment
    if _kw_match(ql, words=('oldest', 'purani', 'sab se pehle', 'longest waiting'), stems=()):
        pend = []
        for h in found:
            if _ast_completed(h):
                continue
            dd = _ast_date((h["result"] or {}).get("discharge_time"))
            if dd:
                pend.append(((today - dd).days, h))
        pend.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if pend:
            lines.append("Longest-waiting shipments (discharged, "
                         "not yet delivered):")
            for days, h in pend[:5]:
                lines.append(f"• {h['query']} — {days} day(s) since "
                             f"discharge • {h['result'].get('status')}")
        else:
            lines.append("No discharged-and-waiting shipments.")
        return {"answer": "\n".join(lines), "actions": acts}


    # 7) payments
    if _kw_match(ql, words=('payment', 'paisa', 'pending', 'receive', 'client', 'payments'), stems=()):
        from collections import defaultdict
        agg = defaultdict(lambda: [0, 0])
        for h in hist:
            c = (h.get("client") or "").strip()
            if not c:
                continue
            try:
                agg[c][0] += float(h.get("amount") or 0)
                agg[c][1] += float(h.get("received") or 0)
            except Exception:
                pass
        pend = [(c, a - r) for c, (a, r) in agg.items() if a - r > 0]
        if pend:
            lines.append("Pending payments:")
            for c, p in pend[:10]:
                lines.append(f"• {c}: PKR {p:,.0f} pending")
        else:
            lines.append("No pending payments in your records. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 8) OCR / photo
    if _kw_match(ql, words=('ocr', 'photo', 'scan', 'camera', 'tasveer', 'photos'), stems=()):
        if _ocr_python():
            lines.append("Photo scanning (OCR) is READY — the "
                         "engine is built into the app itself, "
                         "nothing needs to be installed.")
            lines.append("Use 'Scan photo' on the search box, or "
                         "attach a photo to any result.")
        else:
            lines.append("Photo scanning is not set up on this "
                         "device yet. Nothing to install by hand: "
                         "scan any BL photo once and the engine "
                         "sets itself up automatically (one-time, "
                         "a few minutes, internet needed); after "
                         "that every scan works directly.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 9) system health — "keeping an eye on the system"
    if _kw_match(ql, words=('system', 'health', 'halat', 'report', 'kais'), stems=()):
        stale = [h for h in found if not _ast_completed(h)
                 and h.get("checked_ts")
                 and time.time() - h["checked_ts"] > 3 * 3600]
        lines.append("System health:")
        lines.append(f"• Tracked shipments: {len(hist)} "
                     f"({len(found)} found, {len(notfound)} not found)")
        lines.append(f"• On hold: "
                     f"{len([h for h in found if _ast_on_hold(h)])}")
        lines.append(f"• Data older than 3 hours (press TRACK to "
                     f"refresh): {len(stale)}")
        lines.append(f"• Auto re-check: every "
                     f"{st.get('recheck_hours', 6)} hours")
        lines.append(f"• Photo scanning (OCR): "
                     f"{'ready ✓' if _ocr_python() else 'not set up yet — automatic on first photo scan'}")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 10) backup
    if "backup" in ql:
        lines.append("Your data (history, settings, photos) lives "
                     "outside the app folder, so updates never "
                     "erase it. A backup ZIP can be downloaded any "
                     "time:")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 11) delete / clear help
    if _kw_match(ql, words=('delete', 'clear', 'hata', 'remove'), stems=()):
        lines.append("Every row in the Logs lists now has a 🗑 "
                     "Delete button, and the Not Found card has a "
                     "'Clear all' button that removes all not-found "
                     "entries at once (it asks first). Found "
                     "shipments can also be deleted from their "
                     "result card.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 12) greeting / help
    if (re.search(r"\b(hi|hello|salam|aoa|help|madad)\b", ql)
            or "what can" in ql):
        lines.append("I am the built-in assistant. I watch your "
                     "shipments and this app, and answer from your "
                     "own data. Try:")
        lines.append("• 'Which shipments are on hold?'")
        lines.append("• 'What is arriving soon?'")
        lines.append("• 'System health'")
        lines.append("• Type any BL / container number for its "
                     "full report")
        lines.append("• 'Why is my number not found?'")
        return {"answer": "\n".join(lines), "actions": acts}

    # 14) today's brief
    if _kw_match(ql, words=('brief', 'aaj ka', 'today', 'summary'), stems=()):
        arr_today = [h for h in found
                     if _ast_date((h["result"] or {}).get("eta")) == today]
        holds = [h for h in found if _ast_on_hold(h)]
        lines.append(f"Today's brief — {len(hist)} tracked, "
                     f"{len(found)} found, {len(notfound)} not found.")
        lines.append(f"• Arriving today: {len(arr_today)}"
                     + (": " + ", ".join(h["query"] for h in arr_today[:5])
                        if arr_today else ""))
        lines.append(f"• On hold: {len(holds)}"
                     + (": " + ", ".join(h["query"] for h in holds[:5])
                        if holds else ""))
        lines.append(f"• Completed / delivered: "
                     f"{len([h for h in found if _ast_completed(h)])}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 16) count by carrier
    if _kw_match(ql, words=('per carrier', 'carrier wise', 'kis carrier', 'by carrier'), stems=()):
        from collections import Counter
        cc = Counter(h.get("carrier") or "Unknown" for h in hist)
        lines.append("Shipments by carrier:")
        for name, cnt in cc.most_common(10):
            lines.append(f"• {name}: {cnt}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 17) small talk
    if _kw_match(ql, words=('thank', 'shukriya', 'great', 'acha'), stems=()):
        lines.append("You are welcome! Ask me anything else — "
                     "holds, arrivals, a report for any number, "
                     "or system health.")
        return {"answer": "\n".join(lines), "actions": acts}
    if _kw_match(ql, words=('tum kon', 'who are you', 'tumhara naam', 'your name'), stems=()):
        lines.append("I am the CargoTrack assistant — I live inside "
                     "this app, watch your shipments and answer from "
                     "your own data. Shezi (in your chat) is the one "
                     "who built me and can do everything beyond this "
                     "app.")
        return {"answer": "\n".join(lines), "actions": acts}

    # fallback — honestly. v98 (S1b): if the AI actually
    # failed, clearly write the TYPE of reason (timeout / rate
    # limit / invalid key / network) — never a generic shrug.
    if _ai_why:
        lines.append("That question needs the full AI, which "
                     "could not answer this time because of "
                     + _AI_WHY_PHRASE.get(
                         _ai_why, _AI_WHY_PHRASE["network"])
                     + ". My built-in answers only cover this "
                     "app and your shipments, so please ask "
                     "again in a little while.")
    else:
        lines.append("That question needs the full AI, and it is not "
                     "answering right now (an internet hiccup or the "
                     "free limit) — my built-in answers only cover "
                     "this app and your shipments, so please ask "
                     "again in a little while.")
    lines.append("What I CAN do right now: holds, arrivals, "
                 "demurrage risk, payments, not-found help, OCR "
                 "status and a full system health report.")
    lines.append("Or tap below — your question will be copied, "
                 "paste it in your chat with Shezi and he will "
                 "answer it there.")
    acts.append({"label": "📋 Copy this question for Shezi",
                 "act": "copyq", "arg": q})
    return {"answer": "\n".join(lines), "actions": acts}


# OCR digit-confusion repair: Tesseract often reads 0 as O, 1 as I, 5 as S
# — in the digit part of a container, these are swapped and the check
# digit is verified again.
_OCR_DIG_FIX = str.maketrans({"O": "0", "Q": "0", "I": "1", "L": "1",
                              "S": "5", "B": "8", "Z": "2", "G": "6"})


def _iso_repair(tok):
    if len(tok) != 11 or not tok[:4].isalpha():
        return None
    fixed = tok[4:].translate(_OCR_DIG_FIX)
    if not fixed.isdigit():
        return None
    cand = tok[:4] + fixed
    return cand if _iso_ok(cand) else None


def re_extract_doc_numbers(text):
    """v46 Phase C — new rule for extracting numbers from a document.

    Document order taught by Yousuf: first the CONTAINER number,
    then size (20'/40'), then SEAL number — often without a heading.
    Therefore:
    - A container is only one that passes the ISO check-digit (or
      passes after fixing an OCR digit error).
    - The number on the SEAL line, and a bare number of 6-8 digits on
      the line after the container, never becomes a BL.
    - A BL is the alphanumeric number that is recognised (carrier
      prefix) or looks like a house BL; 9-10 bare digits
      can be a Maersk/COSCO BL.
    - OCR often inserts a space/dash inside a number — the token
      is formed by joining them.
    """
    import re
    bls, cons, seals, others = [], [], [], []
    seen = set()

    def push(lst, v):
        if v and v not in seen:
            seen.add(v)
            lst.append(v)

    def classify(tok):
        """(score, type, value) for one clean token. Score: container 3,
        recognised BL 2, ordinary BL/other 1, junk 0. A mixed line
        longer than 17 is never a number."""
        if len(tok) > 17 or not re.fullmatch(r"[A-Z0-9]+", tok):
            return 0, None, tok
        if re.fullmatch(r"[A-Z]{4}\d{7}", tok):
            if _iso_ok(tok):
                return 3, "container", tok
            rep = _iso_repair(tok)
            if rep:
                return 3, "container", rep
            return 1, "other", tok
        if tok.isdigit():
            if len(tok) in (9, 10):
                return 2, "bl", tok         # Maersk 9-digit / COSCO digits
            if len(tok) == 11:
                return 1, "other", tok      # phone-like — last hope
            return 0, None, tok
        if len(tok) >= 9 and re.search(r"[A-Z]", tok) \
                and re.search(r"\d", tok):
            try:
                _pfx, cname = ENG.identify_carrier(tok)
            except Exception:
                cname = None
            return (2, "bl", tok) if cname else (1, "bl", tok)
        return 0, None, tok

    for line in (text or "").upper().splitlines():
        seal_line = "SEAL" in line
        groups = [g.strip(".,;:()") for g in line.split()]
        groups = [g for g in groups if g]
        if seal_line:
            # Do not force the Seal line — "SEAL NO PK123456"
            # made into one used to form a wrong value. Each part should be
            # treated as a separate seal (leaving out the label word).
            for g in groups:
                solo = ENG.norm(g)
                if len(solo) >= 5 and re.search(r"\d", solo) \
                        and solo not in ("SEAL", "SEALNO"):
                    push(seals, solo)
            continue
        line_has_container = False
        i = 0
        while i < len(groups):
            hit = None
            # OCR often breaks a single number with spaces — join 1, 2
            # and 3 parts and check them, and take the window with the best
            # recognition (score); on a tie, the longer window
            # (the full number) wins.
            best = (0, 0, None, None)       # score, w, kind, val
            # A part starting with a size/type code (40HC, 20GP...)
            # is not the start of any number — do not make it part of a join.
            size_first = re.fullmatch(r"(20|40|45)(GP|HC|HQ|RF|DC|DV|OT|FR)?",
                                      ENG.norm(groups[i]))
            for w in (1, 2, 3):
                if size_first:
                    break
                if i + w > len(groups):
                    continue
                joined = ENG.norm("".join(groups[i:i + w]))
                if len(joined) < 6:
                    continue
                sc, kind, val = classify(joined)
                if w >= 2 and sc < 2:
                    continue  # after joining, only a confirmed identification will pass — a common line like "WEIGHT 24500" does not become a BL
                if sc > best[0] or (sc == best[0] and sc > 0 and w > best[1]):
                    best = (sc, w, kind, val)
            if best[0] > 0:
                hit = (best[1], best[2], best[3])
            if hit:
                w, kind, val = hit
                if seal_line:
                    push(seals, val)
                elif kind == "container":
                    push(cons, val)
                    line_has_container = True
                elif kind == "bl":
                    push(bls, val)
                else:
                    push(others, val)
                i += w
                continue
            # nothing was identified: a bare 6-8 digit number
            # is a seal if it is on a container line, otherwise leave it.
            solo = ENG.norm(groups[i])
            if solo.isdigit() and 6 <= len(solo) <= 8 and line_has_container:
                push(seals, solo)
            elif seal_line and len(solo) >= 5:
                push(seals, solo)
            i += 1
    numbers = bls + cons + others
    return {"numbers": numbers[:12], "bls": bls,
            "containers": cons, "seals": seals}


def re_find_numbers(text):
    return re_extract_doc_numbers(text)["numbers"]


def main():
    threading.Thread(target=_recheck_loop, daemon=True).start()
    threading.Thread(target=_journey_loop, daemon=True).start()
    threading.Thread(target=_qc_loop, daemon=True).start()
    threading.Thread(target=_sync_loop, daemon=True).start()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    print(f"CargoTrack is running: http://127.0.0.1:{PORT}")
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        print(f"On your phone (same WiFi): http://{s.getsockname()[0]}:{PORT}")
        s.close()
    except Exception:
        pass
    print("To stop CargoTrack, close this window.")
    try:
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
