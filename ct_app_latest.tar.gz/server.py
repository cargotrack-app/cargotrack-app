#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CargoTrack v51 — Web UI server (stdlib only).
Tracking engine: bl_track.py. Data lives outside the app folder:
  ~/CargoTrack_Data/history.json + settings.json
Run:  python server.py   (your browser opens automatically)
"""
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shutil
import sys
import threading
import time
import zipfile
from datetime import datetime, date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bl_track as ENG

DATA_DIR = Path.home() / "CargoTrack_Data"
DATA_DIR.mkdir(exist_ok=True)
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
PHOTOS_DIR = DATA_DIR / "photos"
PHOTOS_DIR.mkdir(exist_ok=True)
PORT = 8765
APP_VERSION = 57

_lock = threading.Lock()


def load_json(p, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(p, obj):
    # F-05 fix (v46 audit): write to a temp file, then atomically
    # replace — a crash/power-cut mid-write used to corrupt the file,
    # and load_json then silently returned empty (whole history lost).
    try:
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        os.replace(tmp, p)
        return True
    except Exception:
        return False


APP_DIR = Path(__file__).resolve().parent


def _apply_seed_once():
    """v44 FINAL one-time seed: replace history with the verified 78-BL
    record shipped beside server.py. The old history is first copied to a
    dated backup in the data dir; a marker stops any re-application."""
    seed = APP_DIR / "seed_history.json"
    marker = DATA_DIR / "seed_v44final.done"
    try:
        if seed.exists() and not marker.exists():
            data = load_json(seed, None)
            if isinstance(data, list) and data:
                if HISTORY_FILE.exists():
                    bak = DATA_DIR / "history_backup_2026-10-22.json"
                    if not bak.exists():
                        bak.write_bytes(HISTORY_FILE.read_bytes())
                if save_json(HISTORY_FILE, data):
                    marker.write_text("done", encoding="utf-8")
                    seed.unlink()
    except Exception:
        pass


_apply_seed_once()


def _remove_lock_once():
    """v51 one-time lock removal (Yousuf ka hukm): update package
    ke sath aayi ct_remove_lock.flag server.py ke sath mojood ho
    aur data dir mein marker na ho, to settings se SIRF app_pass
    key hatao — Groq key aur baqi har setting mehfooz rehti hai.
    Marker dobara chalne se rokta hai aur flag file bhi delete
    ho jati hai. Kabhi raise nahi karta."""
    flag = APP_DIR / "ct_remove_lock.flag"
    marker = DATA_DIR / "ct_lock_removed_v51.done"
    try:
        if flag.exists() and not marker.exists():
            s = load_json(SETTINGS_FILE, {})
            if isinstance(s, dict) and "app_pass" in s:
                s.pop("app_pass", None)
                save_json(SETTINGS_FILE, s)
            marker.write_text("done", encoding="utf-8")
            flag.unlink()
    except Exception:
        pass


_remove_lock_once()


def _enrich_history_once():
    """v54/v55 one-time record ENRICH (24 Oct 2026): enrich data
    files mein diye gaye verified fields maujooda entries mein
    sirf wahan bhare jate hain jahan wo khaali hain — koi bhari
    hui field overwrite nahi hoti, siwa un ke jo item ki
    'force' list mein hain (masalan purana placeholder status).
    Entry maujood na ho to nayi bana di jati hai. Har file ka
    apna marker dobara chalne se rokta hai; data file apply ke
    baad delete. Kabhi raise nahi karta."""
    for _fname, _mname in (
            ("ct_enrich_history.json", "ct_enrich_v54.done"),
            ("ct_enrich_history_v55.json", "ct_enrich_v55.done")):
        data_file = APP_DIR / _fname
        marker = DATA_DIR / _mname
        try:
            if data_file.exists() and not marker.exists():
                raw = load_json(data_file, {})
                items = raw.get("enrich") if isinstance(raw, dict) else raw
                if isinstance(items, list) and items:
                    hist = load_json(HISTORY_FILE, [])
                    if not isinstance(hist, list):
                        hist = []
                    by_q = {(e.get("query") or ""): e for e in hist
                            if isinstance(e, dict)}
                    changed = False
                    for it in items:
                        q = (it.get("query") or "").strip()
                        if not q:
                            continue
                        fill = it.get("result") or {}
                        force = set(it.get("force") or [])
                        e = by_q.get(q)
                        if e is None:
                            now = time.time()
                            stamp = time.strftime(
                                "%d %b %Y, %I:%M %p",
                                time.localtime(now))
                            e = {"query": q, "mode": "bl", "client": "",
                                 "carrier": it.get("carrier", ""),
                                 "prefix": "", "contacts": None,
                                 "amount": "", "received": "",
                                 "returned": "", "notes": "",
                                 "photo": "", "starred": False,
                                 "checklist": {}, "changes": [],
                                 "change_kind": "", "changed": False,
                                 "found": bool(it.get("found")),
                                 "result": dict(fill),
                                 "layers": [{
                                     "name": "Shezi — record update "
                                             "(24 Oct 2026)",
                                     "status": "done",
                                     "detail": "Verified details added "
                                               "by Shezi; recheck in "
                                               "the app for live "
                                               "status."}],
                                 "checked_ts": int(now), "time": stamp,
                                 "first_seen": stamp}
                            hist.append(e)
                            by_q[q] = e
                            changed = True
                            continue
                        r = e.get("result")
                        if not isinstance(r, dict):
                            r = {}
                            e["result"] = r
                        for k, v in fill.items():
                            if k in force or r.get(k) in (None, "", []):
                                if r.get(k) != v:
                                    r[k] = v
                                    changed = True
                        if it.get("found") and not e.get("found"):
                            e["found"] = True
                            changed = True
                        if it.get("carrier") and not e.get("carrier"):
                            e["carrier"] = it["carrier"]
                            changed = True
                    if changed:
                        save_json(HISTORY_FILE, hist)
                marker.write_text("done", encoding="utf-8")
                data_file.unlink()
        except Exception:
            pass


def _merge_extra_history_once():
    """v51 one-time record merge (Yousuf ka hukm, 24 Oct 2026):
    update package ke sath aayi ct_extra_history.json mein jo BL
    records hain, un mein se jo history mein pehle se NAHI hain
    sirf wohi jama karo — maujooda koi entry kabhi overwrite
    nahi hoti. Marker dobara chalne se rokta hai, data file
    apply hone ke baad delete ho jati hai. Kabhi raise nahi
    karta."""
    data_file = APP_DIR / "ct_extra_history.json"
    marker = DATA_DIR / "ct_extra_history_v51.done"
    try:
        if data_file.exists() and not marker.exists():
            raw = load_json(data_file, [])
            entries = raw.get("history") if isinstance(raw, dict) else raw
            if isinstance(entries, list) and entries:
                hist = load_json(HISTORY_FILE, [])
                if not isinstance(hist, list):
                    hist = []
                have = {(e.get("query") or "") for e in hist
                        if isinstance(e, dict)}
                added = [e for e in entries
                         if isinstance(e, dict)
                         and (e.get("query") or "")
                         and (e.get("query") or "") not in have]
                if added:
                    save_json(HISTORY_FILE, hist + added)
            marker.write_text("done", encoding="utf-8")
            data_file.unlink()
    except Exception:
        pass


_merge_extra_history_once()
_enrich_history_once()


def get_history():
    h = load_json(HISTORY_FILE, [])
    if not isinstance(h, list):
        return []
    return [_migrate_entry(x) for x in h]


# ---------------- v49: bundled OCR engine + BL record extractor ------------
# Photo scan ab app ke ANDAR band engine (RapidOCR/onnxruntime)
# se chalta hai — Tesseract ki koi zaroorat nahi. Har scan ek
# chhote subprocess mein hota hai taake model ki memory scan ke
# baad khali ho jaye.
# v50: engine do jagah mil sakta hai — (a) app ke sath aya
# ocr/venv, ya (b) ocr/pylibs, jo pehli scan par ONE-TIME
# AUTO-SETUP khud bana deta hai (ocr/setup_state.json +
# ocr/setup.log dekho). Is liye bilkul nayi machine (fresh
# server / fresh laptop) par bhi user ko kuch install nahi
# karna parta: pehli photo par setup chand minute mein khud
# ho jata hai, agli scans seedha chalti hain.
# Extractor ke usool Yousuf ki 43 BL photos se seekhe gaye hain
# (~/workspace/bl-formats-learned.md): BL number hamesha LABEL ke
# paas se; booking/S-O/serial kabhi BL nahi; container ISO check
# digit se; seal kabhi BL nahi; PROFORMA par BL hota hi nahi.
OCR_DIR = BASE / "ocr"
OCR_PYLIBS = OCR_DIR / "pylibs"
OCR_BOOTSTRAP_DIR = OCR_DIR / "_bootstrap"
OCR_SETUP_STATE = OCR_DIR / "setup_state.json"
OCR_SETUP_LOG = OCR_DIR / "setup.log"
OCR_SETUP_MSG = ("Photo-scan engine is being set up on this device "
                 "(one-time setup, a few minutes). Please try again "
                 "shortly.")
OCR_FAILED_MSG = ("Photo-scan engine setup could not be completed "
                  "on this device. Please check the internet "
                  "connection and try again later.")
_ocr_cache = {"py": None, "env": None, "ts": 0.0}
_ocr_setup = {"proc": None}
_ocr_setup_lock = threading.Lock()


def _ocr_probe(py, env_extra=None):
    """Ek interpreter par rapidocr import ki quick jaanch.
    env_extra (masalan PYTHONPATH=ocr/pylibs) subprocess ko milta
    hai. File na ho / import fail ho to False."""
    import subprocess
    if not py or not os.path.isfile(py):
        return False
    env = None
    if env_extra:
        env = dict(os.environ)
        for k, v in env_extra.items():
            if k == "PYTHONPATH" and env.get("PYTHONPATH"):
                env[k] = v + os.pathsep + env["PYTHONPATH"]
            else:
                env[k] = v
    try:
        r = subprocess.run([py, "-c", "import rapidocr_onnxruntime"],
                           capture_output=True, timeout=60, env=env)
        return r.returncode == 0
    except Exception:
        return False


def _ocr_resolve(force=False):
    """Engine resolution: (python_path, env_extra) ya (None, None).
    Order: (0) CT_OCR_PYTHON override, (1) app ka ocr/venv —
    bilkul waisa hi jaisa v49 mein tha, (2) ocr/pylibs app ke
    apne Python (sys.executable) + PYTHONPATH ke sath,
    (3) yehi Python agar us mein rapidocr pehle se mojood ho,
    (4) developer machine ka ocrvenv.
    Kaamyab resolution hamesha cached; na-kaam sirf 20 second
    cached taake har request par mehngi probe na chale aur
    auto-setup ke baad engine foran mil jaye."""
    now = time.time()
    if _ocr_cache["py"]:
        return _ocr_cache["py"], _ocr_cache["env"]
    if not force and now - _ocr_cache["ts"] < 20:
        return None, None
    cands = []
    env_py = os.environ.get("CT_OCR_PYTHON")
    if env_py:
        cands.append((env_py, None))
    cands.append((str(OCR_DIR / "venv" / (
        "Scripts/python.exe" if os.name == "nt" else "bin/python")),
        None))
    if OCR_PYLIBS.is_dir():
        cands.append((sys.executable,
                      {"PYTHONPATH": str(OCR_PYLIBS)}))
    cands.append((sys.executable, None))
    cands.append((str(Path.home() / "workspace" / "ocrvenv"
                      / "bin" / "python"), None))
    py = envx = None
    seen = set()
    for c, e in cands:
        key = (c, (e or {}).get("PYTHONPATH", ""))
        if key in seen:
            continue
        seen.add(key)
        if _ocr_probe(c, e):
            py, envx = c, e
            break
    _ocr_cache.update(py=py, env=envx, ts=now)
    return py, envx


def _ocr_python():
    """OCR engine ka Python (path) ya None. Baqi callers ise
    sirf ready / not-ready jaanch ke liye istemal karte hain;
    asal scan _run_ocr_items se hota hai jo env bhi sambhalta
    hai (pylibs wale raste par PYTHONPATH chahiye hota hai)."""
    return _ocr_resolve()[0]


# ------------- v51: one-time OCR auto-setup (detached worker) -------------
# Nayi machine par na ocr/venv hota hai na aksar python3-venv /
# ensurepip (Debian/Ubuntu unhein neuter kar dete hain) — is
# liye setup venv par NAHI, sirf stdlib par chalta hai:
#   1. PyPI JSON API se pip ka latest stable wheel download
#      karke ocr/_bootstrap/ mein unzip karo (wheel khud ek
#      zip hai; unzip ki hui pip `python -m pip` se chalti hai).
#   2. Usi pip se ocr/requirements.txt ko ocr/pylibs mein
#      --target install karo (system Python ko haath nahi
#      lagta, --break-system-packages PEP 668 wale servers ke
#      liye hai jahan --target bhi kabhi rok diya jata hai).
#   3. cv2 import probe: GUI-wali opencv-python aa gayi ho aur
#      headless server par import fail ho (libGL nahi hoti)
#      to cv2 ke package dirs saaf karke SIRF headless dobara
#      install karo, phir dobara probe karo.
#   4. Asal probe: app ke Python se pylibs import karke dekho.
# v51 tabdeeli: asal kaam ab ocr/setup_worker.py karta hai —
# server use DETACHED process (start_new_session=True) mein
# chalata hai taake app/service ka restart setup ko beech
# mein na mar sake. Halat ocr/setup_state.json mein, tafseel
# ocr/setup.log mein (aakhri lines state ke 'log_tail' mein
# bhi mehfooz hoti hain taake failure ki wajah app ke error
# mein nazar aaye). Fail ho jaye to 120 second baad agli scan
# par NAYI koshish ho sakti hai — purani "ek server-run mein
# sirf ek koshish" wali rok khatam; retry loop phir bhi nahi,
# har koshish user ki scan se hi shuru hoti hai.


def _ocr_setup_state():
    st = load_json(OCR_SETUP_STATE, None)
    return st if isinstance(st, dict) else {"state": "idle"}


def _ocr_setup_log(msg):
    try:
        OCR_DIR.mkdir(parents=True, exist_ok=True)
        with open(OCR_SETUP_LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S  ")
                    + str(msg) + "\n")
    except Exception:
        pass


def _ocr_set_setup_state(**kw):
    st = _ocr_setup_state()
    st.update(kw)
    try:
        OCR_SETUP_STATE.write_text(json.dumps(st, indent=1),
                                   encoding="utf-8")
    except Exception:
        pass


def _ocr_setup_pid_alive(st):
    """state file mein darj worker pid zinda hai ya nahi.
    Server restart ke baad bhi yehi jaanch kaam karti hai —
    Popen handle to restart mein kho jata hai, pid rehta hai."""
    try:
        pid = int(st.get("pid") or 0)
    except Exception:
        pid = 0
    if pid <= 0:
        return False
    if os.name == "nt":
        # Windows par os.kill(pid, 0) doosre process ko signal
        # bhej sakta hai — wahan sirf apne spawn kiye huwe
        # handle par bharosa karo.
        p = _ocr_setup.get("proc")
        return p is not None and p.poll() is None
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _ocr_log_tail(n=15):
    """ocr/setup.log ki aakhri n saaf lines (timestamp hata
    kar) — failure ki wajah dhoondhne ke liye."""
    try:
        lines = OCR_SETUP_LOG.read_text(
            encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    out = []
    for ln in lines[-max(n * 3, n):]:
        ln = ln.strip()
        m = re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\s+",
                     ln)
        if m:
            ln = ln[m.end():].strip()
        if ln:
            out.append(ln)
    return out[-n:]


def _ocr_failed_msg():
    """Setup fail hone par saaf error + asal wajah ki ek line
    (state ke log_tail se, warna setup.log se, warna state ke
    error se) — taake user ka screenshot hi diagnosis ke liye
    kaafi ho. Wajah ~200 chars par trim hoti hai."""
    reason = ""
    st = _ocr_setup_state()
    tail = st.get("log_tail")
    if isinstance(tail, list) and tail:
        reason = str(tail[-1]).strip()
    if not reason:
        t2 = _ocr_log_tail(15)
        if t2:
            reason = t2[-1]
    if not reason:
        reason = str(st.get("error") or "").strip()
    reason = re.sub(r"\s+", " ", reason).strip()
    if len(reason) > 200:
        reason = reason[:197].rstrip() + "..."
    if reason:
        return OCR_FAILED_MSG + f" (Reason: {reason})"
    return OCR_FAILED_MSG


_ocr_pylibs_size = {"mb": 0.0, "ts": 0.0}


def _ocr_pylibs_mb():
    """ocr/pylibs ka size MB mein (5s cache — hazaaron files
    ki walk har poll par mehngi parti hai)."""
    now = time.time()
    if _ocr_pylibs_size["mb"] and \
            now - _ocr_pylibs_size["ts"] < 5:
        return _ocr_pylibs_size["mb"]
    total = 0
    try:
        for root, _dirs, files in os.walk(OCR_PYLIBS):
            for fn in files:
                try:
                    total += os.path.getsize(
                        os.path.join(root, fn))
                except OSError:
                    pass
    except Exception:
        pass
    _ocr_pylibs_size.update(mb=round(total / 1048576.0, 1),
                            ts=now)
    return _ocr_pylibs_size["mb"]


def _ocr_setup_activity(tail):
    """setup.log ki aakhri lines se insaani jumla: abhi kya
    ho raha hai (konsa package download/install ho raha
    hai) — taake user ko andhere mein intezar na pare."""
    for ln in reversed(tail or []):
        s = str(ln).strip()
        m = re.search(r"Downloading\s+(\S+?)-(\d[\d.]*)-", s)
        if m:
            sz = re.search(r"\(([\d.]+\s*[MG]B)\)", s)
            return ("Downloading " +
                    m.group(1).replace("_", "-") +
                    (" (" + sz.group(1) + ")" if sz else ""))
        m = re.search(r"Collecting\s+(\S+)", s)
        if m:
            return "Collecting " + m.group(1)
        if "Installing collected packages" in s:
            return "Installing the downloaded packages"
        if "Successfully installed" in s:
            return "Install complete — final check running"
        if "setup READY" in s:
            return "Setup complete"
    if tail:
        return str(tail[-1]).strip()[:120]
    return "Starting"


def _ocr_setup_status():
    """Photo-scan setup ki LIVE halat (v52): state, kitna
    waqt huwa, abhi kya ho raha hai, kitne MB aa gaye,
    kitni koshishein huin, fail ho to wajah. Yousuf ki
    hidayat par — setup ka saboot app ke andar nazar aaye,
    user ko ocr folder ki files na kholni paren."""
    st = _ocr_setup_state()
    ready = False
    try:
        ready = bool(_ocr_python())
    except Exception:
        ready = False
    state = str(st.get("state") or "idle")
    if ready:
        state = "ready"
    tail = _ocr_log_tail(15)
    elapsed = None
    if state == "running":
        try:
            t0 = datetime.fromisoformat(
                str(st.get("started") or "")).timestamp()
            elapsed = max(0, int(time.time() - t0))
        except Exception:
            elapsed = None
    reason = ""
    if state == "failed":
        t = st.get("log_tail")
        if isinstance(t, list) and t:
            reason = str(t[-1]).strip()
        if not reason and tail:
            reason = str(tail[-1]).strip()
        if not reason:
            reason = str(st.get("error") or "").strip()
        reason = re.sub(r"\s+", " ", reason)[:200]
    return {
        "state": state,
        "engine_ready": ready,
        "started": st.get("started") or "",
        "finished": st.get("finished") or "",
        "elapsed_s": elapsed,
        "attempts": int(st.get("attempts") or 0),
        "activity": (_ocr_setup_activity(tail)
                     if state in ("running", "failed")
                     else ("Setup complete"
                           if state == "ready" else "")),
        "pylibs_mb": _ocr_pylibs_mb(),
        "log_tail": [str(x)[:160] for x in tail[-3:]],
        "reason": reason,
    }


def _ocr_trigger_setup():
    """Detached setup worker chalao agar zaroorat ho.
    Return 'running' (chal raha hai / abhi shuru huwa) ya
    'failed' (haal hi mein fail huwa — 120 second ke andar
    dobara koshish nahi; us ke baad agli scan par nayi
    koshish khud ho jayegi)."""
    import subprocess
    with _ocr_setup_lock:
        st = _ocr_setup_state()
        state = st.get("state")
        if state == "running":
            if _ocr_setup_pid_alive(st):
                return "running"
            state = "failed"   # worker beech mein mar gaya
        if state == "failed":
            fin = 0.0
            try:
                fin = datetime.fromisoformat(
                    str(st.get("finished") or "")).timestamp()
            except Exception:
                fin = 0.0
            if fin and time.time() - fin <= 120:
                return "failed"
        try:
            OCR_DIR.mkdir(parents=True, exist_ok=True)
            lf = open(OCR_SETUP_LOG, "a", encoding="utf-8")
            proc = subprocess.Popen(
                [sys.executable,
                 str(OCR_DIR / "setup_worker.py")],
                cwd=str(BASE), stdout=lf,
                stderr=subprocess.STDOUT,
                start_new_session=True)
            _ocr_setup["proc"] = proc
            _ocr_set_setup_state(
                state="running",
                started=datetime.now().isoformat(
                    timespec="seconds"),
                pid=proc.pid, error="",
                attempts=int(st.get("attempts") or 0) + 1)
            return "running"
        except Exception:
            return "failed"


def _run_ocr_items(img_path):
    """OCR subprocess: (result_dict, None) ya (None, wajah).
    result = {"items":[{box,text,score}], "w":W, "h":H}
    Engine kahin na mile (na ocr/venv, na ocr/pylibs) to one-time
    auto-setup background mein shuru ho jata hai aur client ko
    'setting up' wala saaf jawab milta hai — koi traceback ya
    install ki hidayat user ko nahi dikhti."""
    import subprocess
    py, envx = _ocr_resolve()
    if not py:
        if _ocr_trigger_setup() == "running":
            return None, OCR_SETUP_MSG
        return None, _ocr_failed_msg()
    env = None
    if envx:
        env = dict(os.environ)
        for k, v in envx.items():
            if k == "PYTHONPATH" and env.get("PYTHONPATH"):
                env[k] = v + os.pathsep + env["PYTHONPATH"]
            else:
                env[k] = v
    try:
        out = subprocess.run(
            [py, str(OCR_DIR / "ocr_runner.py"), str(img_path)],
            capture_output=True, timeout=120, env=env)
    except subprocess.TimeoutExpired:
        return None, ("Photo scanning took too long — please try a "
                      "clearer, closer photo.")
    except Exception as e:
        return None, str(e)
    txt = out.stdout.decode("utf-8", "replace").strip()
    d = None
    for line in reversed(txt.splitlines()):
        try:
            d = json.loads(line)
            break
        except Exception:
            continue
    if not d or d.get("error") or "items" not in d:
        return None, ("OCR could not read that photo — please try a "
                      "clearer, closer photo.")
    return d, None


def _sq(s):
    """Squash: sirf A-Z0-9 — OCR ke space/punctuation jhanjhat se azad."""
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def _it_cx(it):
    b = it["box"]
    return (b[0][0] + b[2][0]) / 2.0


def _it_cy(it):
    b = it["box"]
    return (b[0][1] + b[2][1]) / 2.0


def _ocr_lines(items, page_h):
    """OCR items ko reading lines mein joro (y qareeb = ek line)."""
    its = sorted(items, key=lambda i: (_it_cy(i), _it_cx(i)))
    heights = sorted((i["box"][2][1] - i["box"][0][1]) for i in its)
    med = heights[len(heights) // 2] if heights else 20
    tol = max(9.0, med * 0.72)
    lines = []
    for it in its:
        cy = _it_cy(it)
        if lines and abs(cy - lines[-1]["cy"]) <= tol:
            lines[-1]["items"].append(it)
            n = len(lines[-1]["items"])
            lines[-1]["cy"] = (lines[-1]["cy"] * (n - 1) + cy) / n
        else:
            lines.append({"cy": cy, "items": [it]})
    for ln in lines:
        ln["items"].sort(key=_it_cx)
        ln["text"] = " ".join(i["text"] for i in ln["items"])
        ln["squash"] = _sq(ln["text"])
    return lines


# Carrier BL formats — bl-formats-learned.md se. Kuch jagah digit
# ginti document ke asal number se milti rakhi hai (Monter ke 8-10,
# KMTC ke 7-8, RCL ke 8-9) warna asal BL hi miss ho jata.
_BL_PATTERNS = [
    (r"EMKAYMBAKHI\d{5}", "Emkay Line"),
    (r"\d{3}G\d{6,7}", "Wan Hai Lines"),
    (r"C[O0]AU\d{10}", "COSCO Shipping"),
    (r"[O0]{2}LU\d{10}", "OOCL"),
    (r"MEDU[TS]\d{7}", "MSC"),
    (r"YMJAS\d{9}", "Yang Ming"),
    (r"KMTC[A-Z]{3}\d{7,8}", "KMTC Line"),
    (r"PELMSA[A-Z]{6}\d{6}", "Prolog Express Line (PEL)"),
    (r"MBAQITS\d{10}", "RTW Shipping & Logistics"),
    (r"STS[A-Z]{3,}\d{5}", "Star Lines"),
    (r"BAL[A-Z]{3,}\d{7}", "Baltic Lines"),
    (r"FRL[A-Z]{3,}\d{6}", "Feeder Logistics DMCC"),
    (r"EMA[A-Z]{3,}\d{6}", "EM-A Shipping"),
    (r"SGS\d{4}SINKHI\d?", "SeaGem Shipping"),
    (r"SSL[A-Z]{3,}\d{4,}", "Samudera Shipping Line"),
    (r"MCL[A-Z]{3}\d{8,10}", "Monter Container Line"),
    (r"HAICB\d{8,9}", "RCL (Regional Container Lines)"),
]

_LETTERHEAD_CARRIERS = [
    ("MAXTOP", "MAXTOP Logistics"),
    ("MONTER", "Monter Container Line"),
    ("MEDITERRANEANSHIPPING", "MSC"),
    ("NEWGOLDENSEA", "COSCO Shipping"),
    ("ORIENTOVERSEAS", "OOCL"),
    ("KOREAMARINE", "KMTC Line"),
    ("PROLOGEXPRESS", "Prolog Express Line (PEL)"),
    ("SEAGEM", "SeaGem Shipping"),
    ("SAMUDERA", "Samudera Shipping Line"),
    ("FEEDERLOGISTICS", "Feeder Logistics DMCC"),
    ("REGIONALCONTAINER", "RCL (Regional Container Lines)"),
    ("YANGMING", "Yang Ming"),
    ("WANHAI", "Wan Hai Lines"),
    ("BALTICLINES", "Baltic Lines"),
    ("STARLINES", "Star Lines"),
    ("EMKAY", "Emkay Line"),
    ("MAERSK", "Maersk"),
]


def _bl_pattern_fix(m, pat):
    """OCR ki 0/O ghalti prefix mein theek karo (0OLU -> OOLU)."""
    if pat in (r"C[O0]AU\d{10}", r"[O0]{2}LU\d{10}"):
        head = m[:4].replace("0", "O")
        return head + m[4:]
    return m


_MONTHS = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
           "JUL": 7, "AUG": 8, "SEP": 9, "SEPT": 9, "OCT": 10,
           "NOV": 11, "DEC": 12,
           "JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4,
           "JUNE": 6, "JULY": 7, "AUGUST": 8, "SEPTEMBER": 9,
           "OCTOBER": 10, "NOVEMBER": 11, "DECEMBER": 12}
_MONTH_ABBR = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
               "Aug", "Sep", "Oct", "Nov", "Dec"]


def _norm_date(s):
    """Date wali string ko '18 Sep 2026' banao; na bane to raw."""
    t = (s or "").strip().upper().replace(",", " ")
    m = re.search(r"(\d{1,2})[-/. ](\d{1,2})[-/. ](\d{2,4})", t)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{d:02d} {_MONTH_ABBR[mo]} {y}"
    m = re.search(r"(\d{1,2})[-/. ]([A-Z]{3,9})[-/. ](\d{2,4})", t)
    if m:
        mon = _MONTHS.get(m.group(2)) or _MONTHS.get(m.group(2)[:3])
        if mon:
            d, y = int(m.group(1)), int(m.group(3))
            if y < 100:
                y += 2000
            return f"{d:02d} {_MONTH_ABBR[mon]} {y}"
    m = re.search(r"([A-Z]{3,9})\.?\s+(\d{1,2})\s+(\d{4})", t)
    if m and m.group(1) in _MONTHS:
        return (f"{int(m.group(2)):02d} "
                f"{_MONTH_ABBR[_MONTHS[m.group(1)]]} {m.group(3)}")
    m = re.search(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", t)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12:
            return f"{d:02d} {_MONTH_ABBR[mo]} {y}"
    return (s or "").strip()


_DATE_RE = (r"\d{1,2}[-/. ](?:\d{1,2}|[A-Z]{3,9})[-/. ]\d{2,4}"
            r"|[A-Z]{3,9}\.?\s+\d{1,2},?\s+\d{4}"
            r"|\d{4}[-/.]\d{1,2}[-/.]\d{1,2}")


def _num_or_blank(s):
    """'54,108.000' -> 54108 (int); na bane to ''."""
    if s is None:
        return ""
    t = str(s).replace(",", "").replace(" ", "").strip()
    try:
        f = float(t)
    except Exception:
        return ""
    return int(f) if f == int(f) else f


_LABEL_KEYS = [
    ("bl", ("BILLOFLADINGNO", "BLNO")),
    ("booking", ("BOOKINGNO", "BOOKINGREF")),
    ("sono", ("SONO",)),
    ("serial", ("SERIALNO",)),
    ("reference", ("SHIPMENTREFERENCE", "CARRIERSREFERENCE",
                   "CARRIERREFERENCE", "EXPORTREFERENCE",
                   "SHIPPERSREF", "SHIPPERREFERENCE")),
    ("shipper", ("SHIPPER",)),
    ("consignee", ("CONSIGNEE", "CONSIGNED")),
    ("notify", ("NOTIFY",)),
    ("vessel", ("VESSEL",)),
    ("voyage", ("VOYAGE", "VOYNO")),
    ("pol", ("PORTOFLOADING",)),
    ("pod", ("PORTOFDISCHARGE", "PORTOFLANDING")),
    ("receipt", ("PLACEOFRECEIPT", "PLACEOFACCEPTANCE")),
    ("delivery", ("PLACEOFDELIVERY", "PLACEOFFINALDELIVERY")),
    ("tranship", ("TRANSHIPMENT", "TRANSSHIPMENT")),
    ("issue", ("DATEOFISSUE", "PLACEANDDATEOFISSUE")),
    ("containers", ("CONTAINER",)),
    ("goods", ("DESCRIPTION", "PARTICULARS")),
    ("gross", ("GROSSWEIGHT", "GROSSWT")),
    ("net", ("NETWEIGHT", "NETTWEIGHT", "NETWT")),
    ("measure", ("MEASUREMENT",)),
    ("freight", ("FREIGHT",)),
    ("marks", ("MARKSAND", "MARKS")),
    ("seal", ("SEAL",)),
]


def _item_label_kind(it):
    """Ek OCR item kis label ka hai (ya None)."""
    sq = _sq(it["text"])
    if not sq:
        return None
    if "CONSIGNEE" in sq:
        return "consignee"  # lamba negotiable wala label bhi yahi hai
    for kind, keys in _LABEL_KEYS:
        for k in keys:
            if k in sq:
                if kind == "shipper" and (
                        "LOAD" in sq or "STOW" in sq
                        or len(sq) > 26):
                    continue  # SHIPPER'S LOAD... party nahi hai
                if kind == "bl" and "FOROCEAN" in sq:
                    continue  # document ka title, number box nahi
                return kind
    return None


def _line_label_kinds(ln):
    return {k for k in (_item_label_kind(i) for i in ln["items"]) if k}


def extract_bl_record(items, page_w, page_h):
    """OCR items se mukammal BL record.
    (record, meta) — meta mein extractor ki androoni maloomat
    (excluded values waghera) jo API jawab mein nahi jati."""
    W = float(page_w or 1000)
    H = float(page_h or 1400)
    lines = _ocr_lines(items, H)
    full_sq = "".join(_sq(i["text"]) for i in
                      sorted(items, key=lambda i: (_it_cy(i), _it_cx(i))))
    warnings = []
    rec = {"bl_no": "", "containers": [], "carrier": "", "vessel": "",
           "voyage": "", "shipper": "", "consignee": "", "pol": "",
           "pod": "", "ts_port": "", "on_board": "", "issue_date": "",
           "goods": "", "packages": "", "gross_kg": "", "net_kg": "",
           "cbm": "", "freight": "", "free_days": "", "proforma": False}

    # ---- 1) labels aur un ke paas wale values (claiming) ----
    labels = []       # (kind, cx, cy)
    for ln in lines:
        for it in ln["items"]:
            k = _item_label_kind(it)
            if k in ("bl", "booking", "sono", "serial", "reference"):
                labels.append((k, _it_cx(it), _it_cy(it), it))
    # glued label+value ek hi item mein (masalan "B/LNoYMJAS430202944",
    # "S/O No: KCT60910727") — pehle yahi se pakro
    inline_bl, inline_excl = "", set()
    for it in items:
        t = it["text"]
        m = re.search(r"(?i)B\s*/\s*L\s*\.?\s*NO\.?\s*:?\s*"
                      r"([A-Z0-9][A-Z0-9\-]{5,19})$", t.strip())
        if m and not inline_bl:
            inline_bl = _sq(m.group(1))
        m = re.search(r"(?i)S\s*/\s*O\s*\.?\s*NO\.?\s*:?\s*"
                      r"([A-Z0-9][A-Z0-9\-]{3,19})", t)
        if m:
            inline_excl.add(_sq(m.group(1)))
    cands = []        # (squash, cx, cy)
    for it in items:
        sq = _sq(it["text"])
        if 6 <= len(sq) <= 20 and re.search(r"\d", sq) \
                and not _item_label_kind(it):
            cands.append((sq, _it_cx(it), _it_cy(it)))
    # Jis label ki value usi item mein ghuli ho (masalan
    # "S/O No: KCT60910727") wo label geometric claiming mein
    # hissa nahi leta — warna wo paas wala asal BL bhi hadap
    # karke use exclusion mein daal deta hai (Wan Hai par huwa).
    def _label_has_inline(k, it):
        sq = _sq(it["text"])
        for kk in ("BILLOFLADINGNO", "BLNO", "BOOKINGNO",
                   "BOOKINGREF", "SONO", "SERIALNO",
                   "SHIPMENTREFERENCE", "CARRIERSREFERENCE",
                   "CARRIERREFERENCE", "EXPORTREFERENCE",
                   "SHIPPERSREF", "SHIPPERREFERENCE"):
            sq = sq.replace(kk, "", 1) if sq.startswith(kk) else sq
        return len(sq) >= 4 and bool(re.search(r"\d", sq))

    # Claiming: har candidate apne QAREEB TAREEN label ko jata
    # hai; BL label sirf tab jeet-ta hai jab wo taqreeban utna hi
    # qareeb ho (warna PROFORMA par booking number BL label hadap
    # leta hai, aur Wan Hai par S/O asal BL ko exclusion mein
    # daal deta hai).
    raw_pairs = []
    for li, (k, lx, ly, _it) in enumerate(labels):
        if k != "bl" and _label_has_inline(k, _it):
            continue
        for ci, (sq, cx, cy) in enumerate(cands):
            dx = abs(cx - lx) / W
            dy = abs(cy - ly) / H
            if dx < 0.36 and dy < 0.065:
                raw_pairs.append((dx + dy, li, ci))
    best_for_c = {}
    for d, li, ci in raw_pairs:
        if ci not in best_for_c or d < best_for_c[ci]:
            best_for_c[ci] = d
    pairs = []
    for d, li, ci in raw_pairs:
        k = labels[li][0]
        prio = 0 if (k == "bl" and d <= best_for_c[ci] + 0.02) else 1
        pairs.append((prio, d, li, ci))
    pairs.sort()
    claimed_c, claimed_l = {}, {}
    for _p, _d, li, ci in pairs:
        if li in claimed_l or ci in claimed_c:
            continue
        claimed_l[li] = ci
        claimed_c[ci] = li
    excluded_soft, excluded_hard = set(inline_excl), set(inline_excl)
    label_bl_value = ""
    bl_label_seen = booking_seen = False
    for li, (k, _x, _y, _it) in enumerate(labels):
        if k == "bl":
            bl_label_seen = True
            if li in claimed_l:
                label_bl_value = cands[claimed_l[li]][0]
        elif k == "booking":
            booking_seen = True
            if li in claimed_l:
                excluded_soft.add(cands[claimed_l[li]][0])
        elif li in claimed_l:
            excluded_hard.add(cands[claimed_l[li]][0])
    if inline_bl:
        label_bl_value = inline_bl

    # ---- 2) containers (ISO + check digit) aur seals ----
    stream = []       # (token_raw, line_idx)
    for li, ln in enumerate(lines):
        for it in ln["items"]:
            for tok in re.split(r"[\s/,;()]+", it["text"]):
                tok = tok.strip(".:")
                if tok:
                    stream.append((tok, li, it))
    cont_hits = []    # (stream_idx, number, check_ok, item)
    seen_cont = set()
    for si, (tok, li, it) in enumerate(stream):
        if re.search(r"\d{1,2}-\d{1,2}-\d{2,4}", tok) \
                or "DATED" in _sq(it["text"]):
            continue  # date wala token container nahi ho sakta
        if "-" in tok:
            continue  # hyphen wala number seal hota hai (ML-KE…),
            # container kabhi hyphen ke sath nahi chhupta
        sq = _sq(tok)
        for m in re.finditer(r"[A-Z]{4}\d{7}", sq):
            num = m.group(0)
            if num[:4] == "CODE":
                continue  # "HS CODE 0909..." ghul kar bana hua jhoota
                # container — asal prefix CODE kabhi nahi hota
            ok = _iso_ok(num)
            if not ok:
                rep = _iso_repair(num)
                if rep:
                    num, ok = rep, True
            if num in seen_cont:
                continue
            if not ok:
                ctx = (it["text"] + " " + lines[li]["text"]).upper()
                if not ("CONTAINER" in ctx or "SEAL" in ctx
                        or re.search(r"(20|40|45)\s?'?\s?"
                                     r"(GP|HC|HQ|SD|DC|DV|RF|G1)", ctx)):
                    continue  # check digit fail + context bhi nahi — fazool
            seen_cont.add(num)
            cont_hits.append((si, num, ok, it))
    cont_pos = {si for si, _n, _o, _i in cont_hits}

    def _size_of(it, li):
        ctx = it["text"] + " " + lines[li]["text"]
        m = re.search(r"(20|40|45)\s?'?\s?(GP|HC|HQ|SD|DC|DV|RF|G1|G2)",
                      ctx.upper())
        return (m.group(1) + m.group(2)) if m else ""

    cont_numbers = {n for _s, n, _o, _i in cont_hits}
    # Seals: har container ki apni line ya agli 2 lines mein pehla
    # seal-numa token. Raw token mein '.' ya ',' ho to wo weight ka
    # tukra hai, seal nahi. Date wala token bhi seal nahi.
    line_tokens = []
    for ln in lines:
        toks = []
        for it in ln["items"]:
            for tok in re.split(r"[\s/,;()]+", it["text"]):
                tok = tok.strip(".:")
                if tok:
                    toks.append(tok)
        line_tokens.append(toks)

    def _seal_shape(tok):
        if "." in tok or "," in tok:
            return ""
        raw = tok.upper()
        sq = _sq(tok)
        if sq.startswith("DATED"):
            return ""
        if re.fullmatch(r"ML-[A-Z]{2}\d{5,}", raw):
            return raw  # ML-KE0272798 — hyphen ke sath asal shakal
        if re.fullmatch(r"[A-Z]{2,6}\d{4,8}", sq):
            return sq
        m = re.search(r"(?:20|40|45)(?:GP|HC|HQ|SD|DC|DV|RF|G1|G2)"
                      r"\d{0,2}([A-Z]{4}\d{5,8})$", sq)
        if m:
            return m.group(1)  # size ke sath ghula seal:
            # "40SD96WHAD001536" -> WHAD001536
        return ""

    def _seal_ok(sq, raw=""):
        if not sq or sq == label_bl_value \
                or sq in excluded_hard or sq in excluded_soft \
                or sq in cont_numbers:
            return False
        if "-" in raw:
            return True  # hyphen wala number seal hi hota hai,
            # container kabhi hyphen ke sath nahi chhupta
        return not re.fullmatch(r"[A-Z]{4}\d{7}", sq) \
            and not any(re.fullmatch(p, sq)
                        for p, _c in _BL_PATTERNS)

    containers = []
    used_seals = set()
    for si, num, ok, it in cont_hits:
        li = next(l for l, ln in enumerate(lines)
                  if it in ln["items"])
        seal = ""
        for j in range(li, min(li + 3, len(lines))):
            for tok in line_tokens[j]:
                s = _seal_shape(tok)
                if s and _seal_ok(s, tok) and s not in used_seals:
                    seal = s
                    break
            if seal:
                break
        if seal:
            used_seals.add(seal)
        containers.append({"no": num, "seal": seal,
                           "type": _size_of(it, li), "check_ok": ok})
        if not ok:
            warnings.append(f"Container {num}: check digit could not "
                            "be verified — please confirm the number.")
    seal_hits = []
    for j, toks in enumerate(line_tokens):
        if "SEAL" in lines[j]["squash"]:
            for tok in toks:
                s = _seal_shape(tok) or (
                    _sq(tok) if re.fullmatch(r"\d{5,8}", _sq(tok))
                    and "." not in tok and "," not in tok else "")
                if s and _seal_ok(s, tok) and s not in used_seals:
                    seal_hits.append((j, s))
    for _j, s in seal_hits:
        warnings.append(f"Seal {s} was read but could not be "
                        "paired with a container.")
    rec["containers"] = containers
    seal_numbers = {s for _j, s in seal_hits} \
        | {c["seal"] for c in containers if c["seal"]}

    # ---- 3) BL number: label wala pehle, phir carrier formats ----
    def _bl_sane(v):
        return bool(v) and v not in cont_numbers \
            and v not in seal_numbers and v not in excluded_hard \
            and 8 <= len(v) <= 20

    bl, bl_from_label = "", False
    if label_bl_value:
        v = label_bl_value
        for pat, _c in _BL_PATTERNS:
            m = re.fullmatch(pat, v)
            if m:
                v = _bl_pattern_fix(m.group(0), pat)
                break
        if _bl_sane(v):
            bl, bl_from_label = v, True
    # Carrier-format ki pakki hit label wale ghair-format value
    # (masalan barcode) par hamesha jeetti hai
    pattern_bl = ""
    for pat, _c in _BL_PATTERNS:
        hits = []
        for it in items:
            for m in re.finditer(pat, _sq(it["text"])):
                hits.append(_bl_pattern_fix(m.group(0), pat))
        if not hits:
            hits = [_bl_pattern_fix(m.group(0), pat)
                    for m in re.finditer(pat, full_sq)]
        for v in hits:
            if _bl_sane(v) and v not in excluded_soft:
                pattern_bl = v
                break
        if pattern_bl:
            break
    if pattern_bl and pattern_bl != bl:
        if not bl or not any(re.fullmatch(p, bl)
                             for p, _c in _BL_PATTERNS):
            bl, bl_from_label = pattern_bl, False
    if not bl and booking_seen and bl_label_seen:
        # Maersk usool: booking aur B/L number EK hi hota hai.
        for v in excluded_soft:
            if "MAERSK" in full_sq and re.fullmatch(r"\d{9}", v):
                bl = v
                warnings.append("BL and booking number are the same "
                                "on this document (Maersk style).")
                break
    rec["bl_no"] = bl

    # ---- 4) PROFORMA ----
    if not bl and ("PROFORMA" in full_sq
                   or (bl_label_seen and booking_seen)):
        rec["proforma"] = True
    if not bl and not rec["proforma"]:
        warnings.append("BL number could not be read from this photo.")

    # ---- 5) carrier ----
    carrier = ""
    for pat, cname in _BL_PATTERNS:
        if bl and re.fullmatch(pat, bl):
            carrier = cname
            break
    if not carrier:
        for key, cname in _LETTERHEAD_CARRIERS:
            if key in full_sq:
                carrier = cname
                break
    if not carrier and bl:
        try:
            _pfx, cname = ENG.identify_carrier(bl)
            carrier = cname or ""
        except Exception:
            carrier = ""
    rec["carrier"] = carrier

    # ---- 6) labeled fields ----
    def label_item_of(ln, kinds):
        for it in ln["items"]:
            if _item_label_kind(it) in kinds:
                return it
        return None

    def after_label(kinds, max_lines=1, joiner=" "):
        for li, ln in enumerate(lines):
            lab = label_item_of(ln, kinds)
            if lab is None:
                continue
            band = (_it_cx(lab) - 0.30 * W, _it_cx(lab) + 0.30 * W)
            multi = len(_line_label_kinds(ln)) >= 2
            vals = []
            # pehle label ke NEECHE wale values (merged line mein
            # label ke neeche chipka item bhi shamil) — label ki
            # line par DAayein taraf aksar reference number hota
            # hai, asal value nahi
            below0 = [i for i in ln["items"]
                      if _it_cy(i) > _it_cy(lab) + 4
                      and band[0] <= _it_cx(i) <= band[1]
                      and _item_label_kind(i) is None]
            if below0:
                vals.append(" ".join(i["text"] for i in below0))
            for j in range(li + 1, min(li + 1 + max_lines + 2,
                                       len(lines))):
                if len(vals) >= max_lines:
                    break
                lk = _line_label_kinds(lines[j])
                if lk and not lk.issubset(kinds):
                    break  # doosra label aa gaya; apna hi label
                    # (masalan "SAME AS CONSIGNEE") value hai
                cand = [i for i in lines[j]["items"]
                        if band[0] <= _it_cx(i) <= band[1]]
                if not cand and not multi:
                    cand = lines[j]["items"]
                if not cand:
                    break
                vals.append(" ".join(i["text"] for i in cand))
            if vals:
                return joiner.join(vals).strip()
            right = [i for i in ln["items"]
                     if _it_cx(i) > _it_cx(lab) + 4
                     and abs(_it_cy(i) - _it_cy(lab)) <= 6
                     and _item_label_kind(i) is None]
            if right:
                return " ".join(i["text"] for i in right).strip()
            return ""
        return ""

    def column_value(kind):
        """Header row (kai labels ek line) — neeche wali line ke
        items qareeb tareen label ko milte hain."""
        for li, ln in enumerate(lines):
            kinds_here = _line_label_kinds(ln)
            if kind not in kinds_here or len(kinds_here) < 2:
                continue
            labs = [( _item_label_kind(i), _it_cx(i))
                    for i in ln["items"] if _item_label_kind(i)]
            for j in range(li + 1, len(lines)):
                if not lines[j]["items"]:
                    continue
                got = []
                for i in lines[j]["items"]:
                    near = min(labs, key=lambda t: abs(t[1] - _it_cx(i)))
                    if near[0] == kind:
                        got.append(i["text"])
                if got:
                    return " ".join(got).strip()
                break
        return ""

    # vessel / voyage
    vessel_raw = column_value("vessel") or after_label({"vessel"})
    voy = after_label({"voyage"})
    if vessel_raw:
        v = vessel_raw.strip(" .,-")
        m = re.split(r"\s*/\s*", v, maxsplit=1)
        if len(m) == 2 and m[1]:
            v, voy = m[0].strip(), (voy or m[1].strip())
        else:
            m2 = re.match(r"^(.*?)[\s]+(\d{3,4}[A-Z]|[A-Z]\d{3,4}|"
                          r"\d{3}[A-Z]{2}|[A-Z]{2}\d{4}[A-Z])$", v)
            if m2:
                v, voy = m2.group(1).strip(), (voy or m2.group(2))
        rec["vessel"] = v.upper()
    if voy:
        rec["voyage"] = voy.strip().upper()
    if not rec["vessel"]:
        m = re.search(r"SHIPPEDONBOARDBY([A-Z]{4,30}?)"
                      r"(CS\d{4}[A-Z]|\d{3,4}[A-Z]\b|\d{3,4}[A-Z])",
                      full_sq)
        if m:
            rec["vessel"] = m.group(1)
            rec["voyage"] = rec["voyage"] or m.group(2)

    # parties (pehli 2-3 lines, agle label tak)
    for kinds, key in (({"shipper"}, "shipper"),
                       ({"consignee"}, "consignee")):
        val = after_label(kinds, max_lines=3, joiner=", ")
        val = re.sub(r"\s+", " ", val).strip(" ,")
        if val and "SAME AS" not in val.upper()[:9]:
            rec[key] = val

    rec["pol"] = (column_value("pol") or after_label({"pol"})
                  or after_label({"receipt"}))
    rec["pod"] = column_value("pod") or after_label({"pod"})
    rec["ts_port"] = (column_value("tranship")
                      or after_label({"tranship"}))
    for k in ("pol", "pod", "ts_port"):
        rec[k] = re.sub(r"\s+", " ", rec[k]).strip(" ,").upper()

    # dates
    def _date_near(pred, span=3):
        for li, ln in enumerate(lines):
            if pred(ln):
                for j in range(li, min(li + span, len(lines))):
                    m = re.search(_DATE_RE, lines[j]["text"], re.I)
                    if m:
                        return _norm_date(m.group(0))
                return ""
        return ""

    rec["on_board"] = _date_near(
        lambda ln: "ONBOARD" in ln["squash"]
        or "LADENONBOARD" in ln["squash"]
        or "SHIPPEDONBOARD" in ln["squash"])
    rec["issue_date"] = _date_near(
        lambda ln: "DATEOFISSUE" in ln["squash"]
        or "PLACEANDDATEOFISSUE" in ln["squash"])

    # ---- 7) goods / packages / weights / freight / free time ----
    spaced = " ".join(ln["text"] for ln in lines)
    best_pkg = None
    for m in re.finditer(r"(\d[\d,]*)\s*(BAGS?|PACKAGES?|CARTONS?|"
                          r"BOXES|PKGS|PCS)\b", spaced, re.I):
        n = int(m.group(1).replace(",", ""))
        if best_pkg is None or n > best_pkg[0]:
            best_pkg = (n, m.group(1) + " " + m.group(2).upper())
    if best_pkg:
        rec["packages"] = best_pkg[1]
    m = re.search(r"(\d[\d,]*)\s*(?:BAGS?|PACKAGES?|CARTONS?|BOXES)"
                  r"\s+OF\s+([A-Z][A-Z .&/'-]{2,40})", spaced)
    if not m:
        m2 = re.search(r"(\d+)(BAGS|PACKAGES|CARTONS|BOXES)OF"
                       r"([A-Z]{3,30})", full_sq)
        if m2:
            m = None
            rec["goods"] = m2.group(3)
            if not rec["packages"]:
                rec["packages"] = m2.group(1) + " " + m2.group(2)
    if m:
        rec["goods"] = re.sub(r"\s+", " ",
                              m.group(2)).strip(" .,-").upper()
    if not rec["goods"]:
        m = re.search(r"(?:SAID TO CONTAIN|STC)\s*[:\-]?\s*"
                      r"([A-Z][A-Z ]{3,30})", spaced)
        if m and "CONTAINER" not in m.group(1):
            rec["goods"] = m.group(1).strip().upper()

    def _weight(kinds_keys, pats):
        # Pehle saaf TOTAL/label patterns; phir label ke paas ke
        # candidates mein SAB SE BARA number (total hamesha
        # per-container weight se bara hota hai). Sirf woh number
        # jo KGS ke sath ho ya decimal wala ho — container/seal
        # ke digits weight nahi ban sakte.
        for p in pats:
            m = re.search(p, spaced, re.I)
            if m:
                return _num_or_blank(m.group(1))
        best = None
        for li, ln in enumerate(lines):
            if _line_label_kinds(ln) & kinds_keys:
                for j in range(li, min(li + 9, len(lines))):
                    for m in re.finditer(
                            r"([\d,]+\.\d+|\d[\d,]*)\s*\(?(KGS?)?\)?",
                            lines[j]["text"]):
                        has_unit = bool(m.group(2)) or "KGS" in \
                            lines[j]["text"][m.end():m.end() + 5].upper()
                        if "." in m.group(1) or has_unit:
                            v = _num_or_blank(m.group(1))
                            if isinstance(v, (int, float)) and (
                                    best is None or v > best):
                                best = v
                if best is not None:
                    return best
        return ""

    rec["gross_kg"] = _weight({"gross"}, [
        r"TOTAL\s*GROSS\s*(?:WT|WEIGHT)?[:\s.]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"GROSS\s*WEIGHT[:\s]*([\d,]+\.?\d*)"])
    rec["net_kg"] = _weight({"net"}, [
        r"TOTAL\s*NET\s*(?:WT|WEIGHT)?[:\s.]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"NET\s*WEIGHT[:\s]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"NETT\s*WEIGHT[:\s]*([\d,]+\.?\d*)"])
    # v54 CBM fix: pehle GEOMETRY se — form par CBM ki value
    # aksar 'CBM' label ke seedha UPAR hoti hai aur OCR unhe
    # alag items deta hai; text-join par adjacency toot jati
    # hai aur line-merge se 'EXPIRYDATE:07/2029 CBM' jaisi
    # line ban kar saal (2029) CBM uth jata tha (Wan Hai BL
    # par asal 65.0000 ki jagah 2029 aaya). Label ke column
    # mein us ke upar sab se qareebi number hi asal value hai.
    _cbm_done = False
    for it in items:
        if str(it.get("text", "")).strip().upper() not in ("CBM", "M3"):
            continue
        lx0, ly0 = it["box"][0][0], it["box"][0][1]
        lx1 = it["box"][2][0]
        best_v, best_gap = None, None
        for jt in items:
            if jt is it:
                continue
            t = str(jt.get("text", "")).strip().replace(",", "")
            if not re.fullmatch(r"\d+\.\d+|\d+", t):
                continue
            jx0, jy1 = jt["box"][0][0], jt["box"][2][1]
            jx1 = jt["box"][2][0]
            if jx1 < lx0 - 0.06 * W or jx0 > lx1 + 0.06 * W:
                continue  # doosra column
            gap = ly0 - jy1
            if gap < -0.02 * H or gap > 0.08 * H:
                continue  # label ke upar hi hona chahiye
            v = _num_or_blank(t)
            if isinstance(v, (int, float)) and 0 < v < 10000:
                if best_gap is None or abs(gap) < best_gap:
                    best_v, best_gap = v, abs(gap)
        if best_v is not None:
            rec["cbm"] = best_v
            _cbm_done = True
            break
    if not _cbm_done:
        m = re.search(r"(?<![\d/,.\-])([\d,]+\.\d+)\s*(CBM|M3)\b",
                      spaced) \
            or re.search(r"(?<![\d/,.\-])([\d,]+\.?\d*)\s*(CBM|M3)\b",
                         spaced)
        if m:
            v = _num_or_blank(m.group(1))
            # HS code ghul jaye to karoron wala jhoota CBM ata
            # hai; khaalis saal (2029 waghera) bhi CBM nahi —
            # asal CBM hamesha chhota hota hai
            if isinstance(v, (int, float)) and v < 10000 \
                    and not (float(v).is_integer()
                             and 1900 <= v <= 2099):
                rec["cbm"] = v
    if "FREIGHTPREPAID" in full_sq or re.search(
            r"FREIGHT\s+PREPAID", spaced, re.I):
        rec["freight"] = "Prepaid"
    elif "FREIGHTCOLLECT" in full_sq:
        rec["freight"] = "Collect"
    m = (re.search(r"(\d+)\s*DAYS?\s*(?:FREE\s*)?(?:FREETIME|FREE\s*TIME|"
                   r"DETENTION|DEMURRAGE)", spaced, re.I)
         or re.search(r"FREETIMEATDESTINATION:?(\d+)", full_sq)
         or re.search(r"(\d+)DAYSFREETIME", full_sq)
         or re.search(r"FREETIME:?(\d+)DAYS", full_sq)
         or re.search(r"(\d+)DAYSFREE", full_sq)
         or re.search(r"FREE\s*TIME:?\s*(\d+)\s*DAYS", spaced, re.I))
    if m:
        rec["free_days"] = int(m.group(1))

    if items:
        low = [i for i in items if i.get("score", 1) < 0.6]
        if len(low) > len(items) * 0.35:
            warnings.append("Parts of this photo were hard to read — "
                            "please check the record against the BL.")
    rec["warnings"] = warnings
    meta = {"excluded": sorted(excluded_hard | excluded_soft),
            "seals": sorted(seal_numbers), "bl_from_label": bl_from_label}
    return rec, meta


def _vision_bl_extract(data_url, offline, meta):
    """OPTIONAL booster (v49): settings mein AI key ho to photo ek
    vision model ko bhej kar record ki cross-check. Sirf tab istemal
    hota hai jab jawab saaf JSON ho, bl_no khaali na ho, aur wo
    container/seal/booking pattern NA ho. Koi bhi ghalti ho to
    khamoshi se offline result — ye rasta kabhi scan nahi rokta."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    try:
        key = str(get_settings().get("ai_key") or "").strip()
        if not key.startswith("gsk_"):
            return None
        prompt = (
            "Read this Bill of Lading photo and return ONLY a JSON "
            "object with keys: bl_no, carrier, vessel, voyage, "
            "shipper, consignee, pol, pod, ts_port, on_board, "
            "issue_date, goods, packages, gross_kg, net_kg, cbm, "
            "freight, free_days, containers (array of {no, seal, "
            "type}). RULES: bl_no is the value printed next to the "
            "'Bill Of Lading No' / 'B/L No.' label. NEVER use the "
            "booking number, S/O number, serial number, shipment "
            "reference, a container number (4 letters + 7 digits) or "
            "a seal number as bl_no. If the document is a PROFORMA "
            "or the BL number box is empty, set bl_no to \"\". Use "
            "\"\" for anything not printed. No commentary, JSON only.")
        body = None
        for model in ("meta-llama/llama-4-scout-17b-16e-instruct",
                      "meta-llama/llama-4-maverick-17b-128e-instruct"):
            body = {"model": model, "temperature": 0,
                    "messages": [{"role": "user", "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url",
                         "image_url": {"url": data_url}}]}]}
            req = _u.Request(
                "https://api.groq.com/openai/v1/chat/completions",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}",
                         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; "
                         "Win64; x64) AppleWebKit/537.36 (KHTML, "
                         "like Gecko) Chrome/130.0 Safari/537.36"})
            try:
                with _u.urlopen(req, timeout=45) as r:
                    d = _j.loads(r.read().decode("utf-8", "replace"))
                txt = (d["choices"][0]["message"].get("content")
                       or "").strip()
                txt = re.sub(r"^```(?:json)?|```$", "", txt,
                             flags=re.M).strip()
                v = _j.loads(txt)
                break
            except _ue.HTTPError as e:
                if e.code in (400, 403, 404, 429):
                    continue
                return None
            except Exception:
                continue
        else:
            return None
        if not isinstance(v, dict):
            return None
        blv = _sq(str(v.get("bl_no") or ""))
        if not blv:
            return None
        if re.fullmatch(r"[A-Z]{4}\d{7}", blv) and _iso_ok(blv):
            return None  # container ko BL bana diya — qabool nahi
        if blv in set(meta.get("excluded") or []) \
                or blv in set(meta.get("seals") or []):
            return None
        if not (8 <= len(blv) <= 20):
            return None
        return v
    except Exception:
        return None


# ------------- v51: Groq vision fallback (local engine na ho to) -------------
_VISION_BL_PROMPT = (
    "Read this Bill of Lading photo and return ONLY a JSON "
    "object with keys: bl_no, carrier, vessel, voyage, "
    "shipper, consignee, pol, pod, ts_port, on_board, "
    "issue_date, goods, packages, gross_kg, net_kg, cbm, "
    "freight, free_days, proforma, containers (array of {no, "
    "seal, type}). RULES: bl_no is the value printed next to "
    "the 'Bill Of Lading No' / 'B/L No.' label. NEVER use the "
    "booking number, S/O number, serial number, shipment "
    "reference, a container number (4 letters + 7 digits) or "
    "a seal number as bl_no. If the document is a PROFORMA "
    "or the BL number box is empty, set proforma to true and "
    "bl_no to \"\". Use \"\" for anything not printed. No "
    "commentary, JSON only.")


def _vision_extract_record(image_bytes, mime, ai_key):
    """v51: photo-scan ka doosra rasta — local OCR engine
    tayyar na ho (missing / setup chal raha / setup fail) to
    Groq ke vision model se seedha record nikalo. Record ki
    shape bilkul wahi jo extract_bl_record deta hai, engine
    'vision' ke sath. Sakht validation: bl_no ka pattern
    (^[A-Z0-9]{8,20}$), container ISO 6346 check digit (fail
    wala container drop, check_ok imandari se), PROFORMA par
    bl_no hamesha khaali (booking kabhi BL nahi banta). Koi
    bhi ghalti ho to None — ye function kabhi raise nahi
    karta; handler phir purane saaf error par gir jata hai."""
    import base64 as _b64
    import urllib.request as _u
    import json as _j
    try:
        key = str(ai_key or "").strip()
        if not key or not image_bytes:
            return None
        data_url = ("data:" + (mime or "image/png")
                    + ";base64,"
                    + _b64.b64encode(image_bytes).decode())
        v = None
        for model in ("meta-llama/llama-4-scout-17b-16e-instruct",
                      "llama-3.2-11b-vision-preview"):
            body = {"model": model, "temperature": 0,
                    "messages": [{"role": "user", "content": [
                        {"type": "text",
                         "text": _VISION_BL_PROMPT},
                        {"type": "image_url",
                         "image_url": {"url": data_url}}]}]}
            req = _u.Request(
                "https://api.groq.com/openai/v1/chat/completions",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}",
                         "User-Agent": "Mozilla/5.0 (Windows NT "
                         "10.0; Win64; x64) AppleWebKit/537.36 "
                         "(KHTML, like Gecko) Chrome/130.0 "
                         "Safari/537.36"})
            try:
                with _u.urlopen(req, timeout=30) as r:
                    d = _j.loads(r.read().decode("utf-8",
                                                 "replace"))
                txt = (d["choices"][0]["message"].get("content")
                       or "").strip()
                txt = re.sub(r"^```(?:json)?|```$", "", txt,
                             flags=re.M).strip()
                v = _j.loads(txt)
                break
            except Exception:
                continue
        if not isinstance(v, dict):
            return None
        # ---- validation + record shape ----
        rec = {"bl_no": "", "containers": [], "carrier": "",
               "vessel": "", "voyage": "", "shipper": "",
               "consignee": "", "pol": "", "pod": "",
               "ts_port": "", "on_board": "", "issue_date": "",
               "goods": "", "packages": "", "gross_kg": "",
               "net_kg": "", "cbm": "", "freight": "",
               "free_days": "", "proforma": False}
        blv = _sq(str(v.get("bl_no") or ""))
        proforma = bool(v.get("proforma"))
        if blv:
            if not re.fullmatch(r"[A-Z0-9]{8,20}", blv):
                return None
            # container number ko BL bana diya ho to qabool nahi
            if re.fullmatch(r"[A-Z]{4}\d{7}", blv) \
                    and _iso_ok(blv):
                return None
            rec["bl_no"] = blv
            proforma = False
        elif not proforma:
            return None   # na BL mila na proforma — no-result
        rec["proforma"] = proforma
        for k in ("carrier", "vessel", "voyage", "shipper",
                  "consignee", "pol", "pod", "ts_port",
                  "on_board", "issue_date", "goods", "packages",
                  "freight"):
            val = v.get(k)
            if val not in (None, ""):
                rec[k] = str(val).strip()
        for k in ("gross_kg", "net_kg", "cbm"):
            rec[k] = _num_or_blank(v.get(k))
        fd = _num_or_blank(v.get("free_days"))
        rec["free_days"] = int(fd) if fd != "" else ""
        for c in v.get("containers") or []:
            if not isinstance(c, dict) or not c.get("no"):
                continue
            no = _sq(str(c["no"]))
            if not re.fullmatch(r"[A-Z]{4}\d{7}", no):
                continue
            if not _iso_ok(no):
                continue   # check digit fail — container drop
            rec["containers"].append({
                "no": no,
                "seal": str(c.get("seal") or "").strip().upper(),
                "type": str(c.get("type") or ""),
                "check_ok": True})
        rec["ok"] = True
        rec["engine"] = "vision"
        rec["warnings"] = [
            "Read with the AI vision fallback (the built-in "
            "scan engine is not ready on this device yet) — "
            "please double-check the details against the "
            "document."]
        return rec
    except Exception:
        return None


def _public_settings():
    s = dict(get_settings())
    s["ai_key_set"] = bool(str(s.get("ai_key") or "").strip())
    s.pop("ai_key", None)
    # v56: Traqo key bhi ai_key ki tarah — sirf flag bahar, key nahi.
    s["traqo_key_set"] = bool(str(s.get("traqo_key") or "").strip())
    s.pop("traqo_key", None)
    # v48: the password hash itself never leaves the server — only a flag.
    s["app_pass_set"] = bool(str(s.get("app_pass") or "").strip())
    s.pop("app_pass", None)
    return s


def get_settings():
    s = load_json(SETTINGS_FILE, {})
    return s if isinstance(s, dict) else {}


# ---------------- app lock + sessions (v48) ----------------
# The password is stored ONLY as a salted hash in settings.json
# ("app_pass" = salt_hex$sha256_hex, sha256 of salt+password).
# No app_pass -> the app is UNLOCKED (first-run mode, old behaviour).
# Browser sessions live in sessions.json, keyed by sha256(token);
# the raw token only ever exists in the browser's HttpOnly cookie.

def _app_pass_hash():
    return str(get_settings().get("app_pass") or "").strip()


def _make_pass_hash(pw):
    salt = secrets.token_bytes(16)
    digest = hashlib.sha256(salt + pw.encode("utf-8")).hexdigest()
    return salt.hex() + "$" + digest


def _verify_pass(pw, stored):
    try:
        salt_hex, digest = stored.split("$", 1)
        cand = hashlib.sha256(
            bytes.fromhex(salt_hex) + pw.encode("utf-8")).hexdigest()
        return hmac.compare_digest(cand, digest)
    except Exception:
        return False


def _load_sessions():
    d = load_json(SESSIONS_FILE, {})
    if not isinstance(d, dict):
        d = {}
    if not isinstance(d.get("sessions"), dict):
        d["sessions"] = {}
    if not isinstance(d.get("attempts"), list):
        d["attempts"] = []
    return d


def _save_sessions(d):
    return save_json(SESSIONS_FILE, d)


def device_label(ua):
    """Friendly device label from a User-Agent string."""
    ua = ua or ""
    if "Edg/" in ua:
        browser = "Edge"
    elif "OPR/" in ua or "Opera" in ua:
        browser = "Opera"
    elif "Firefox/" in ua:
        browser = "Firefox"
    elif "CriOS" in ua or "Chrome/" in ua:
        browser = "Chrome"
    elif "Safari/" in ua:
        browser = "Safari"
    else:
        browser = "Browser"
    if "iPhone" in ua:
        osname = "iPhone"
    elif "iPad" in ua:
        osname = "iPad"
    elif "Android" in ua:
        osname = "Android"
    elif "Windows" in ua:
        osname = "Windows"
    elif "Mac OS" in ua or "Macintosh" in ua:
        osname = "Mac"
    elif "Linux" in ua:
        osname = "Linux"
    else:
        osname = ""
    return f"{browser} on {osname}" if osname else browser


def _create_session(ua, ip):
    """Create a session; returns the raw token (for the cookie)."""
    token = secrets.token_urlsafe(32)
    th = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = time.time()
    with _lock:
        d = _load_sessions()
        d["sessions"][th] = {"created": now, "last_seen": now,
                             "ua": ua, "ip": ip}
        if len(d["sessions"]) > 20:  # cap: drop the oldest
            by_age = sorted(d["sessions"].items(),
                            key=lambda kv: kv[1].get("created", 0))
            for k, _v in by_age[:len(by_age) - 20]:
                d["sessions"].pop(k, None)
        _save_sessions(d)
    return token


def _record_attempt(ip, ua, ok):
    with _lock:
        d = _load_sessions()
        d["attempts"].append({"ts": time.time(), "ip": ip,
                              "ua": ua, "ok": bool(ok)})
        d["attempts"] = d["attempts"][-50:]  # keep only the last 50
        _save_sessions(d)


_SESS_SEEN = {}     # token_hash -> last_seen ts (in memory, freshest)
_SESS_WRITTEN = {}  # token_hash -> ts of last sessions.json write


def _touch_session(th, ua, ip):
    """Update a session's last_seen; the disk write is throttled to
    at most once per 60 seconds per session to avoid churn."""
    now = time.time()
    _SESS_SEEN[th] = now
    if now - _SESS_WRITTEN.get(th, 0) <= 60:
        return
    with _lock:
        d = _load_sessions()
        s = d["sessions"].get(th)
        if not s:
            return
        s["last_seen"] = now
        s["ua"] = ua
        s["ip"] = ip
        if _save_sessions(d):
            _SESS_WRITTEN[th] = now


def _sess_cookie(token):
    return (f"ct_sess={token}; HttpOnly; Path=/; "
            f"Max-Age=7776000; SameSite=Lax")


_SESS_COOKIE_CLEAR = "ct_sess=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax"

LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CargoTrack — Locked</title>
<style>
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;display:flex;align-items:center;
    justify-content:center;background:#12121E;color:#ECECF4;
    font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
    padding:20px}
  .card{background:#1E1E30;border:1px solid #2F2F47;border-radius:20px;
    padding:34px 30px;width:100%;max-width:380px;text-align:center;
    box-shadow:0 24px 60px rgba(0,0,0,.5)}
  .card img{width:84px;height:84px;object-fit:contain;border-radius:18px}
  h1{margin:14px 0 2px;font-size:26px;letter-spacing:.3px;
    background:linear-gradient(90deg,#A78BFA,#F472B6);
    -webkit-background-clip:text;background-clip:text;color:transparent}
  .sub{color:#A8A8BE;font-size:14px;margin:0 0 22px}
  input{width:100%;padding:13px 14px;border-radius:12px;font-size:16px;
    border:2px solid #2F2F47;background:#12121E;color:#ECECF4;outline:none}
  input:focus{border-color:#7C3AED}
  button{width:100%;margin-top:14px;padding:13px;border:0;border-radius:12px;
    font-size:16px;font-weight:700;color:#fff;cursor:pointer;
    background:linear-gradient(90deg,#7C3AED,#DB2777)}
  button:active{transform:scale(.99)}
  #err{display:none;color:#F87171;font-size:14px;margin-top:14px}
  .lock{font-size:15px;color:#A8A8BE;margin-top:18px}
</style></head><body>
  <div class="card">
    <img src="/logos/ct-logo.png" alt="CargoTrack"
      onerror="this.style.display='none'">
    <h1>CargoTrack</h1>
    <p class="sub">This app is locked. Enter your password to open it.</p>
    <form id="lf" autocomplete="off">
      <input id="pw" type="password" placeholder="Password"
        autocomplete="current-password" autofocus>
      <button type="submit">Open app</button>
    </form>
    <div id="err"></div>
    <div class="lock">🔐 Only browsers you sign in on can use this app.</div>
  </div>
<script>
  document.getElementById("lf").addEventListener("submit", async e => {
    e.preventDefault();
    const err = document.getElementById("err");
    err.style.display = "none";
    try {
      const r = await fetch("/api/login", {method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({password:
          document.getElementById("pw").value})});
      if (r.ok) { location.href = "/"; return; }
      const j = await r.json().catch(() => ({}));
      err.textContent = j.error === "wrong password"
        ? "Wrong password — please try again."
        : ("Could not sign in: " + (j.error || r.status));
      err.style.display = "block";
    } catch (ex) {
      err.textContent = "Could not reach the server.";
      err.style.display = "block";
    }
  });
</script>
</body></html>"""


# ---------------- tracking jobs (live layer progress) ----------------
JOBS = {}


def _run_job(job_id, items, mode, carrier_manual, client):
    job = JOBS[job_id]
    results = []
    for item in items:
        events = []

        def cb(name, status, detail=""):
            events.append({"name": name, "status": status, "detail": detail})
            job["events"] = list(events)
            job["current"] = item

        try:
            res = ENG.track_all(
                bl=item if mode == "bl" else None,
                ctn=item if mode == "container" else None,
                vessel_name=item if mode == "vessel" else None,
                progress_cb=cb,
                carrier_hint=carrier_manual,
                traqo_key=str(get_settings().get("traqo_key")
                              or "").strip() or None)
        except Exception as e:
            res = {"carrier": None, "prefix": "", "result": {}, "layers": [],
                   "contacts": None}
            events.append({"name": "Error", "status": "fail", "detail": str(e)})
        if carrier_manual:
            res["carrier"] = carrier_manual
        ctx = {"query": item, "mode": mode, "client": client,
               "carrier": res.get("carrier"), "prefix": res.get("prefix"),
               "result": res.get("result", {}), "layers": res.get("layers", []),
               "contacts": res.get("contacts"),
               "found": bool(res.get("result")),
               "time": datetime.now().strftime("%d/%m %H:%M")}
        try:
            _record(ctx)
        except Exception:
            # F-04 fix (v46 audit): a bad history entry must never kill
            # the job thread — the UI polls until job["done"] is set and
            # would otherwise spin forever with the Track button dead.
            pass
        results.append(ctx)
        job["results"] = list(results)
    job["done"] = True


_PLACEHOLDERS = {"", "/", "—", "-", "N/A", "NA", "None", "null"}
_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun",
     "jul", "aug", "sep", "oct", "nov", "dec"])}


def _real(v):
    """True when a value is real data, not an empty placeholder."""
    if v is None:
        return False
    if isinstance(v, str):
        return v.strip() not in _PLACEHOLDERS
    if isinstance(v, (list, dict)):
        return len(v) > 0
    return True


def _pdate(s):
    """Best-effort date parse for the formats our sources produce."""
    if not s:
        return None
    t = str(s).strip().lower()
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            return None
    m = re.search(r"(\d{1,2})[\s\-]([a-z]{3,9})[\s\-,]+(\d{2,4})", t)
    if m and m.group(2)[:3] in _MONTHS:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        try:
            return date(y, _MONTHS[m.group(2)[:3]], int(m.group(1)))
        except Exception:
            return None
    m = re.search(r"([a-z]{3,9})\s+(\d{1,2})", t)
    if m and m.group(1)[:3] in _MONTHS:
        try:
            return date(date.today().year, _MONTHS[m.group(1)[:3]],
                        int(m.group(2)))
        except Exception:
            return None
    return None


def _merge_result(old_r, new_r):
    """Merge a fresh tracking result into the stored one.

    A weaker new result must never erase data we already know:
    every field keeps the new value when it is real, otherwise the
    old value survives. Containers are unioned."""
    old_r = old_r or {}
    new_r = new_r or {}
    merged = {}
    for k in set(old_r) | set(new_r):
        nv, ov = new_r.get(k), old_r.get(k)
        if k == "containers":
            seen, out_c = set(), []
            for c in list(nv or []) + list(ov or []):
                if _real(c) and c not in seen:
                    seen.add(c)
                    out_c.append(c)
            if out_c:
                merged[k] = out_c
            continue
        if _real(nv):
            merged[k] = nv
        elif _real(ov):
            merged[k] = ov
    # A stored ETA later than the discharge date is a vessel-schedule
    # artifact, not the shipment's ETA — drop it for completed cargo.
    # The combined label "KICT/SAPT" is never a valid terminal name:
    # drop it, and repair any stored status that contains it.
    if merged.get("terminal") == "KICT/SAPT":
        merged.pop("terminal", None)
    _st = merged.get("status") or ""
    if "KICT/SAPT" in _st:
        if merged.get("terminal"):
            merged["status"] = _st.replace("KICT/SAPT",
                                             merged["terminal"])
        else:
            merged["status"] = "Arrived at Karachi terminal"
    dis = _pdate(merged.get("discharge_time"))
    eta = _pdate(merged.get("eta"))
    st = (merged.get("status") or "").lower()
    if dis and eta and eta > dis and any(
            w in st for w in ("discharg", "released", "delivered",
                              "gate out", "hold")):
        merged.pop("eta", None)
    return merged


_OLD_LAYER_NAMES = {
    "Layer 0 — Carrier pehchano": "Layer 0 — Carrier identification",
    "Layer 3 — Karachi Terminals (KICT/SAPT)": "Layer 3 — Karachi Terminal",
}
_OLD_TOKENS = ("nahi", "karo", "mila", "rabta", "khulti", "maroof",
               "Neeche", "pehchano", "Namaloom", "ghalat", "sakta")


def _fix_old_detail(d):
    """Translate or clear Roman-Urdu layer details stored by old
    versions, so they never surface in the current app."""
    if "allow nahi karta" in d:
        return ("Automated tracking is not allowed by this carrier "
                "(bot protection).")
    m = re.search(r"KICT/SAPT par (\d+) container", d)
    if m:
        return f"{m.group(1)} container(s) at Karachi terminal"
    if "rabta nahi ho saka" in d:
        return "The source could not be reached on that check."
    if any(t in d for t in _OLD_TOKENS):
        return ""
    return d


def _migrate_entry(h):
    """Bring a stored history entry up to current standards: clean
    result (no combined terminal label, no placeholders), English
    carrier name, English layer names and details."""
    if not isinstance(h, dict):
        return h
    r = h.get("result")
    if isinstance(r, dict) and r:
        h["result"] = _merge_result(r, {})
    if h.get("carrier"):
        h["carrier"] = h["carrier"].replace(" (unverified)", "")
    for lay in h.get("layers") or []:
        if lay.get("name") in _OLD_LAYER_NAMES:
            lay["name"] = _OLD_LAYER_NAMES[lay["name"]]
        if lay.get("detail"):
            lay["detail"] = _fix_old_detail(lay["detail"])
    return h



def _fmt_disch(s):
    """'06-OCT-2026 22:34' / '06-OCT-26 08:48' -> '6 Oct 2026'."""
    m = re.match(r"\s*(\d{1,2})-([A-Za-z]{3})-(\d{2,4})", s or "")
    if not m:
        return s or ""
    y = m.group(3)
    if len(y) == 2:
        y = "20" + y
    return f"{int(m.group(1))} {m.group(2).title()} {y}"


def _eta_cell(r):
    """Report cell: the ETA while a shipment is on the way; once it
    has arrived, the date that matters is the discharge date (QICT
    and the Karachi terminals publish no ETA at all)."""
    if r.get("eta"):
        return _esc(r["eta"])
    if r.get("discharge_time"):
        return "Discharged " + _esc(_fmt_disch(r["discharge_time"]))
    return "—"

def _record(ctx):
    """History mein save (purani entry ki checklist/notes mehfooz).

    Freshness honesty (v41 audit): checked_ts/time are only stamped
    when this check actually returned data — or when there was no
    earlier found record to protect. A refresh whose sources all
    failed must never make old data look freshly checked."""
    got_new = bool(ctx.get("result"))
    with _lock:
        hist = get_history()
        old = next((h for h in hist if h.get("query") == ctx["query"]), None)
        if old and old.get("found") and not got_new:
            ctx["time"] = old.get("time", ctx.get("time", ""))
            ctx["checked_ts"] = old.get("checked_ts")
        else:
            ctx["checked_ts"] = time.time()
        if old:
            ctx["result"] = _merge_result(old.get("result"),
                                           ctx.get("result"))
            if not ctx.get("carrier"):
                ctx["carrier"] = old.get("carrier")
            if ctx.get("carrier"):
                ctx["carrier"] = ctx["carrier"].replace(
                    " (unverified)", "")
            if old.get("found") and ctx["result"]:
                ctx["found"] = True
            ctx["checklist"] = old.get("checklist", {})
            ctx["notes"] = old.get("notes", "")
            ctx["first_seen"] = old.get("first_seen", date.today().isoformat())
            ctx["photo"] = old.get("photo", "")
            for f in ("client", "amount", "received"):
                if not ctx.get(f):
                    ctx[f] = old.get(f, "")
            ctx["returned"] = bool(old.get("returned", False))
            ctx["starred"] = bool(old.get("starred", False))
            old_r = old.get("result") or {}
            new_r = ctx.get("result") or {}
            old_status = old_r.get("status") or ""
            new_status = new_r.get("status") or ""
            old_pos = old_r.get("position") or ""
            new_pos = new_r.get("position") or ""
            # Badlav ki QISAM pehchano (v41) — taake user ke
            # apne alert usool (idea 22) faisla kar sakein ke
            # is badlav par ghanti bajni hai ya khamoshi se
            # sirf record ho jana hai.
            rules = get_settings().get("alert_rules") or {}
            kind = None
            chg = None
            if (not old_r.get("discharge_time")
                    and new_r.get("discharge_time")):
                kind = "discharge"
                chg = {"time": ctx.get("time", ""),
                       "from": "Not discharged",
                       "to": "Discharged " + str(new_r["discharge_time"])}
            elif (new_r.get("holds") or "") != (old_r.get("holds") or "") \
                    and new_r.get("holds"):
                kind = "hold"
                chg = {"time": ctx.get("time", ""),
                       "from": old_r.get("holds") or "No hold",
                       "to": "Hold: " + str(new_r["holds"])}
            elif (not _status_final(old_r)) and _status_final(new_r):
                kind = "delivered"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status or "In progress",
                       "to": new_status or "Delivered"}
            elif old_status and new_status and old_status != new_status:
                kind = "status"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status, "to": new_status}
            elif (old_r.get("eta") and new_r.get("eta")
                    and old_r["eta"] != new_r["eta"]):
                kind = "eta"
                chg = {"time": ctx.get("time", ""),
                       "from": "ETA " + str(old_r["eta"]),
                       "to": "ETA " + str(new_r["eta"])}
            elif old_pos and new_pos and old_pos != new_pos:
                kind = "position"
                chg = {"time": ctx.get("time", ""),
                       "from": f"Position: {old_pos}",
                       "to": f"Position: {new_pos}"}
            changes = old.get("changes") or []
            if chg:
                changes = ([chg] + changes)[:5]
                ctx["change_kind"] = kind
                # Usool band ho to badlav record ho jaye lekin
                # ghanti na baje (purani ghanti bhi na bujhe).
                ctx["changed"] = (True if rules.get(kind, True)
                                  else bool(old.get("changed")))
            else:
                ctx["change_kind"] = old.get("change_kind")
                ctx["changed"] = bool(old.get("changed"))
            ctx["changes"] = changes
            hist = [h for h in hist if h.get("query") != ctx["query"]]
        else:
            ctx["checklist"] = {}
            ctx["notes"] = ""
            ctx["first_seen"] = date.today().isoformat()
            ctx["changes"] = []
            ctx["changed"] = False
            ctx["returned"] = False
            ctx["starred"] = False
        hist.insert(0, ctx)
        save_json(HISTORY_FILE, hist[:1000])  # F-11: was a silent 300-entry cap


# ---------------- reports (Tk app wale hi generators, web version) -------
def _esc(s):
    return (str(s or "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")



_REPORT_BRANDS = [
    ("maersk", "M", "#2B7FB8"), ("msc", "MSC", "#111111"),
    ("mediterranean", "MSC", "#111111"), ("cosco", "CO", "#00529B"),
    ("oocl", "OO", "#007A3D"), ("cma", "CMA", "#1B2A6B"),
    ("evergreen", "EG", "#006B54"), ("hapag", "HL", "#D14D00"),
    ("ocean network", "ONE", "#B00062"), ("yang ming", "YM", "#AE0F27"),
    ("wan hai", "WH", "#003E73"), ("zim", "ZIM", "#3E1D63"),
    ("emkay", "EM", "#083D6B"), ("rtw", "RTW", "#4C1D95"),
    ("em-a", "EMA", "#92400E"), ("ema", "EMA", "#92400E"),
    ("kict", "KICT", "#115E59"), ("sapt", "SAPT", "#0A5356"),
    ("qict", "QICT", "#172554"), ("pict", "PICT", "#334155"),
]
_REPORT_LOGOS = [
    ("maersk", "maersk.svg"), ("mediterranean", "msc.svg"),
    ("msc", "msc.svg"), ("cosco", "cosco.svg"), ("oocl", "oocl.svg"),
    ("cma", "cma.svg"), ("evergreen", "evergreen.svg"),
    ("hapag", "hapag.svg"), ("ocean network", "one.svg"),
    ("yang ming", "yangming.png"), ("wan hai", "wanhai.png"),
    ("zim", "zim.svg"), ("emkay", "emkay.png"), ("rtw", "rtw.png"),
    ("hyundai", "hmm.svg"), ("hmm", "hmm.svg"),
    ("pacific international", "pil.svg"), ("em-a", "ema.webp"),
    ("kict", "kict.png"), ("sapt", "sapt.png"), ("qict", "qict.png"),
    ("dp world", "qict.png"), ("star lines", "starlines.png"),
    ("baltic", "baltic.png"), ("new golden", "newgoldensea.png"),
]
_REPORT_PALETTE = ["#475569", "#0E7490", "#7C3AED", "#B45309",
                   "#15803D", "#1D4ED8", "#BE185D", "#0F766E"]

def full_report_html(hist):
    _co = (get_settings().get("company_name") or "").strip()
    _co_tag = (get_settings().get("company_tagline") or "").strip()

    def badge(name):
        n = (name or "").lower()
        for key, mono, col in _REPORT_BRANDS:
            if key in n:
                return (f'<span style="display:inline-block;min-width:30px;'
                        f'text-align:center;background:{col};color:#fff;'
                        f'font-weight:700;font-size:10.5px;border-radius:7px;'
                        f'padding:4px 6px;margin-right:7px">{mono}</span>')
        words = [w for w in re.split(r"[^A-Za-z]+", name or "") if w]
        mono = ((words[0][0] if words else "C")
                + (words[1][0] if len(words) > 1 else "")).upper()
        col = _REPORT_PALETTE[abs(hash(name or "?")) % len(_REPORT_PALETTE)]
        return (f'<span style="display:inline-block;min-width:30px;'
                f'text-align:center;background:{col};color:#fff;'
                f'font-weight:700;font-size:10.5px;border-radius:7px;'
                f'padding:4px 6px;margin-right:7px">{mono}</span>')

    def logo_html(name):
        n = (name or "").lower()
        for key, f in _REPORT_LOGOS:
            if key in n:
                return (f'<img src="/logos/{f}" alt="" style="width:92px;'
                        f'height:26px;object-fit:contain;'
                        f'vertical-align:middle;margin-right:8px">')
        return badge(name)

    def row(h):
        r = h.get("result") or {}
        ok = h.get("found")
        carrier = (h.get("carrier") or "—").replace(" (unverified)", "")
        vessel = r.get("vessel") or "—"
        if r.get("voyage"):
            vessel += f" ({r['voyage']})"
        ctns = ", ".join(r.get("containers") or [])
        return (f"<tr><td>{_esc(h.get('time',''))}</td>"
                f"<td><b>{_esc(h.get('query',''))}</b></td>"
                f"<td>{logo_html(h.get('carrier'))}{_esc(carrier)}</td>"
                f"<td>{_esc(vessel)}</td>"
                f"<td>{_esc(ctns or '—')}</td>"
                f"<td>{_esc(r.get('eta') or '—')}</td>"
                f"<td>{_esc(_fmt_disch(r.get('discharge_time')) or '—')}</td>"
                f"<td>{_esc(r.get('terminal') or '—')}</td>"
                f"<td>{_esc(r.get('position') or '—')}</td>"
                f"<td>{_esc(r.get('status') or '—')}</td>"
                f"<td>{'✅' if ok else '❌'}</td></tr>")
    found = [h for h in hist if h.get("found")]
    notf = [h for h in hist if not h.get("found")]
    th = ("<tr><th>Time</th><th>BL / Query</th><th>Carrier</th><th>Vessel</th>"
          "<th>Containers</th><th>ETA</th><th>Discharged</th><th>Terminal</th>"
          "<th>Position</th><th>Status</th><th></th></tr>")
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>CargoTrack — Full Tracking Report</title><style>
body{{font-family:'Segoe UI',Arial,sans-serif;margin:32px;color:#1F2937}}
h1{{color:#5B21B6}} h2{{margin-top:28px}} table{{border-collapse:collapse;width:100%}}
th{{background:#EDE9FE;color:#5B21B6;text-align:left;padding:8px}}
td{{border-bottom:1px solid #E5E7EB;padding:8px;vertical-align:middle}} .muted{{color:#6B7280}}
@media print{{body{{margin:10px}}}}</style></head><body>
<h1>◆ {_esc(_co) + " — " if _co else ""}CargoTrack — Full Tracking Report</h1>{f'<p style="color:#6B7280;margin:2px 0 0">{_esc(_co_tag)}</p>' if _co_tag else ""}
<p class="muted">Generated {datetime.now().strftime('%d %b %Y, %H:%M')}</p>
<h2>✅ Found ({len(found)})</h2><table>{th}{''.join(row(h) for h in found)}</table>
<h2>❌ Not found ({len(notf)})</h2><table>{th}{''.join(row(h) for h in notf)}</table>
<p class="muted">Tip: Print → Save as PDF to keep a copy.</p></body></html>"""


# ---------------- auto re-check ----------------
def _status_final(result):
    r = result or {}
    st = (r.get("status") or "").lower()
    return bool(r.get("gate_out")) or "deliver" in st


def _entry_due(h, now_ts, hrs):
    """Is entry ko dobara track karna chahiye ya nahi?"""
    ts = h.get("checked_ts")
    age = (now_ts - float(ts)) if ts else None
    if _status_final(h.get("result")):
        return False
    mult = 0.5 if h.get("starred") else 1.0
    if not h.get("found"):
        # Not-found entries bhi kabhi kabhi dobara dekho (BL baad
        # mein system mein aa sakta hai) — lekin 4 guna dheere.
        return age is None or age >= hrs * 4 * 3600 * mult
    return age is None or age >= hrs * 3600 * mult


def _recheck_loop():
    time.sleep(120)  # pehli jaanch start ke ~2 minute baad
    while True:
        try:
            hrs = float(get_settings().get("recheck_hours", 6) or 6)
        except Exception:
            hrs = 6
        try:
            now_ts = time.time()
            due = [h for h in get_history()
                   if h.get("query") and _entry_due(h, now_ts, hrs)]
            due.sort(key=lambda h: (0 if h.get("starred") else 1,
                                    float(h.get("checked_ts") or 0)))
            for h in due[:4]:
                mode = h.get("mode", "bl")
                try:
                    res = ENG.track_all(
                        bl=h["query"] if mode == "bl" else None,
                        ctn=h["query"] if mode == "container" else None,
                        vessel_name=h["query"] if mode == "vessel" else None,
                        carrier_hint=h.get("carrier") or None,
                        traqo_key=str(get_settings().get("traqo_key")
                                      or "").strip() or None)
                except Exception:
                    continue
                ctx = {"query": h["query"], "mode": mode,
                       "client": h.get("client", ""),
                       "carrier": res.get("carrier"),
                       "prefix": res.get("prefix"),
                       "result": res.get("result", {}),
                       "layers": res.get("layers", []),
                       "contacts": res.get("contacts"),
                       "found": bool(res.get("result")),
                       "time": datetime.now().strftime("%d/%m %H:%M")}
                try:
                    _record(ctx)
                except Exception:
                    continue
        except Exception:
            pass
        time.sleep(1200)  # agli jaanch 20 minute baad


# ---------------- HTTP ----------------
MIME = {".html": "text/html; charset=utf-8", ".png": "image/png",
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml",
        ".webp": "image/webp",
        ".json": "application/json; charset=utf-8"}


# ---------------- v50: latest-version check (Item 14) ----------------
_VER_CACHE = {"t": 0.0, "latest": None}
_VERSION_URL = ("https://raw.githubusercontent.com/"
                "cargotrack-app/cargotrack-app/main/version.txt")


def _latest_version():
    """Newest published CargoTrack version, or None when unknown.

    Cached: 6 hours after a successful read, 10 minutes after a
    failure — fail-silent by design: any network problem simply
    leaves the UI showing the running version on its own.
    """
    now = time.time()
    ttl = 6 * 3600 if _VER_CACHE["latest"] is not None else 600
    if now - _VER_CACHE["t"] < ttl and _VER_CACHE["t"]:
        return _VER_CACHE["latest"]
    latest = None
    try:
        import urllib.request as _u
        req = _u.Request(_VERSION_URL,
                         headers={"User-Agent": "CargoTrack/" + str(APP_VERSION)})
        with _u.urlopen(req, timeout=4) as resp:
            txt = resp.read().decode("utf-8", "replace")
        m = re.search(r"\d+", txt)
        if m:
            latest = int(m.group())
    except Exception:
        latest = None
    _VER_CACHE.update(t=now, latest=latest)
    return latest


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8",
              headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            n = 0  # F-15: a malformed header must not kill the handler
        n = max(0, min(n, 32 * 1024 * 1024))
        raw = self.rfile.read(n) if n else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    # ---- v48 auth helpers ----
    def _cookie_token(self):
        raw = self.headers.get("Cookie") or ""
        for part in raw.split(";"):
            part = part.strip()
            if part.startswith("ct_sess="):
                return part[len("ct_sess="):]
        return ""

    def _client_ip(self):
        try:
            return self.client_address[0]
        except Exception:
            return ""

    def _auth_state(self):
        """None = locked out; "unlocked" = no password set;
        otherwise the caller's session token-hash. Also touches the
        session's last_seen (throttled inside _touch_session)."""
        if not _app_pass_hash():
            return "unlocked"
        tok = self._cookie_token()
        if not tok:
            return None
        th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
        with _lock:
            known = th in _load_sessions()["sessions"]
        if not known:
            return None
        _touch_session(th, self.headers.get("User-Agent") or "",
                       self._client_ip())
        return th

    def _locked_out(self, p):
        """True (and a denial response already sent) when this request
        must not proceed. The denial is a 401 JSON — the client turns
        a 401 on its data calls into a full reload, and the server
        then serves the login page for GET /."""
        self._send(401, {"error": "locked"})
        return True

    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        # v48: the app logo stays public — the login page shows it.
        if p == "/logos/ct-logo.png":
            f = BASE / "logos" / "ct-logo.png"
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME[".png"])
            return self._send(404, {"error": "no logo"})
        auth = self._auth_state()
        if p == "/" or p == "/index.html":
            if auth is None:
                # locked and not signed in -> the login page
                return self._send(200, LOGIN_HTML, MIME[".html"])
            f = BASE / "static" / "index.html"
            return self._send(200, f.read_bytes(), MIME[".html"])
        if auth is None:
            return self._locked_out(p)
        if p == "/api/sessions":
            d = _load_sessions()
            sess = []
            for th, s in sorted(
                    d["sessions"].items(),
                    key=lambda kv: kv[1].get("created", 0), reverse=True):
                sess.append({
                    "id": th[:10],
                    "device": device_label(s.get("ua", "")),
                    "ua": s.get("ua", ""),
                    "ip": s.get("ip", ""),
                    "created": s.get("created"),
                    "last_seen": max(float(s.get("last_seen") or 0),
                                     _SESS_SEEN.get(th, 0)),
                    "current": th == auth})
            atts = [{"ts": a.get("ts"), "ip": a.get("ip", ""),
                     "device": device_label(a.get("ua", "")),
                     "ok": bool(a.get("ok"))}
                    for a in d["attempts"][-15:]][::-1]
            return self._send(200, {
                "locked": bool(_app_pass_hash()),
                "count": len(sess), "sessions": sess, "attempts": atts})
        if p == "/demo.html":
            f = BASE / "static" / "demo.html"
            if f.exists():
                return self._send(200, f.read_bytes(), MIME[".html"])
            return self._send(404, {"error": "no demo"})
        if p.startswith("/logos/"):
            f = (BASE / "logos" / Path(p).name)
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME.get(f.suffix, "image/png"))
            return self._send(404, {"error": "no logo"})
        if p.startswith("/photos/"):
            f = (PHOTOS_DIR / Path(p).name)
            if f.is_file():  # F-16: ".." resolved to the dir itself and crashed read_bytes
                return self._send(200, f.read_bytes(),
                                  MIME.get(f.suffix.lower(), "image/jpeg"))
            return self._send(404, {"error": "no photo"})
        if p == "/api/version":
            return self._send(200, {"app": APP_VERSION,
                                    "latest": _latest_version()})
        if p == "/api/ocr/setup-status":
            return self._send(200, _ocr_setup_status())
        if p == "/api/history":
            return self._send(200, {"history": get_history(),
                                    "settings": _public_settings(),
                                    "carriers": sorted(set(ENG.CARRIERS.values()))})
        if p == "/api/job":
            jid = (parse_qs(u.query).get("id") or [""])[0]
            job = JOBS.get(jid)
            if not job:
                return self._send(404, {"error": "job not found"})
            return self._send(200, {"done": job["done"], "current": job["current"],
                                    "events": job["events"],
                                    "results": job["results"]})
        if p == "/api/report/full":
            return self._send(200, full_report_html(get_history()), MIME[".html"])
        if p == "/api/backup":
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                if HISTORY_FILE.exists():
                    z.write(HISTORY_FILE, HISTORY_FILE.name)
                if SETTINGS_FILE.exists():
                    # F-13 fix (v46 audit): the backup used to ship the
                    # plaintext AI key to anyone on the LAN who asked.
                    # The key is stripped from the backup copy; it can
                    # be re-entered in Settings after a restore.
                    safe = {k: v for k, v in load_json(SETTINGS_FILE, {}).items()
                            if k not in ("ai_key", "app_pass", "traqo_key")}
                    z.writestr(SETTINGS_FILE.name,
                               json.dumps(safe, ensure_ascii=False, indent=1))
                if PHOTOS_DIR.exists():
                    for pf in sorted(PHOTOS_DIR.iterdir()):
                        if pf.is_file():
                            z.write(pf, f"photos/{pf.name}")
            data = buf.getvalue()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition",
                             'attachment; filename="cargotrack_backup.zip"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        p = u.path
        if p == "/api/login":
            # the only API route open while locked — it IS the key.
            b = self._body()
            stored = _app_pass_hash()
            if not stored:
                return self._send(400, {"error": "no password set"})
            ua = self.headers.get("User-Agent") or ""
            ip = self._client_ip()
            if not _verify_pass(str(b.get("password") or ""), stored):
                _record_attempt(ip, ua, False)
                return self._send(401, {"error": "wrong password"})
            _record_attempt(ip, ua, True)
            token = _create_session(ua, ip)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _sess_cookie(token))])
        auth = self._auth_state()
        if auth is None:
            return self._locked_out(p)
        b = self._body()
        if p == "/api/logout":
            tok = self._cookie_token()
            if tok:
                th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
                with _lock:
                    d = _load_sessions()
                    d["sessions"].pop(th, None)
                    _save_sessions(d)
                _SESS_SEEN.pop(th, None)
                _SESS_WRITTEN.pop(th, None)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/password":
            if b.get("remove") is True:
                # v51: app lock khatam karo — password hash hatao
                # aur tamam saved sessions saaf karo. Caller
                # pehle se authenticated hai (ye route lock gate
                # ke peeche hai). Set/change wala rasta neeche
                # bilkul waisa hi hai jaisa pehle tha.
                s = get_settings()
                s.pop("app_pass", None)
                if not save_json(SETTINGS_FILE, s):
                    return self._send(500, {"error": "could not save"})
                with _lock:
                    d = _load_sessions()
                    d["sessions"] = {}
                    _save_sessions(d)
                _SESS_SEEN.clear()
                _SESS_WRITTEN.clear()
                return self._send(200, {"ok": True},
                                  headers=[("Set-Cookie",
                                            _SESS_COOKIE_CLEAR)])
            new = str(b.get("new") or "")
            if len(new) < 6:
                return self._send(400, {
                    "error": "Password must be at least 6 characters"})
            stored = _app_pass_hash()
            if stored and not _verify_pass(str(b.get("current") or ""),
                                           stored):
                return self._send(401, {"error": "wrong password"})
            s = get_settings()
            s["app_pass"] = _make_pass_hash(new)
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            if not stored:
                # First password ever: sign this browser in right away
                # so the owner is not locked out of his own app.
                token = _create_session(
                    self.headers.get("User-Agent") or "", self._client_ip())
                return self._send(200, {"ok": True, "first": True},
                                  headers=[("Set-Cookie",
                                            _sess_cookie(token))])
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick":
            kid = str(b.get("id") or "")
            if not kid:
                return self._send(400, {"error": "no session id"})
            with _lock:
                d = _load_sessions()
                target = next((k for k in d["sessions"]
                               if k.startswith(kid)), None)
                if target is None:
                    return self._send(404, {"error": "session not found"})
                if target == auth:
                    return self._send(400, {
                        "error": "That is this browser — use Log out"})
                d["sessions"].pop(target, None)
                _save_sessions(d)
            _SESS_SEEN.pop(target, None)
            _SESS_WRITTEN.pop(target, None)
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick_all":
            with _lock:
                d = _load_sessions()
                d["sessions"] = {}
                _save_sessions(d)
            _SESS_SEEN.clear()
            _SESS_WRITTEN.clear()
            return self._send(200, {"ok": True, "reload": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/assistant":
            q = (b.get("q") or "").strip()
            if not q:
                return self._send(400, {"error": "empty question"})
            try:
                return self._send(200, assistant_answer(
                    q, b.get("history"), b.get("attach")))
            except Exception as e:
                return self._send(200, {"answer":
                    "Something went wrong while checking: " + str(e),
                    "actions": []})
        if p == "/api/ping":
            return self._send(200, {"v": APP_VERSION})
        if p == "/api/doctor":
            q = str(b.get("q") or "")
            if not q.strip():
                return self._send(400, {"error": "empty"})
            return self._send(200, doctor_number(q))
        if p == "/api/transcribe":
            import base64
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=False)
            except Exception:
                return self._send(400, {"error": "bad audio"})
            if len(raw) > 12 * 1024 * 1024:
                return self._send(400, {"error": "recording too long"})
            if len(raw) < 800:
                return self._send(200, {"ok": False, "error":
                    "Recording too short — speak the number clearly."})
            ok, val = _transcribe_audio(raw)
            return self._send(200, {"ok": True, "text": val} if ok
                              else {"ok": False, "error": val})
        if p == "/api/track":
            items = [ENG.norm(str(x)) for x in (b.get("items") or []) if str(x).strip()]
            if not items:
                return self._send(400, {"error": "empty"})
            if len(items) > 40:
                return self._send(400, {"error": "too many numbers — 40 at a time, please"})
            if b.get("mode", "bl") not in ("bl", "container", "vessel"):
                return self._send(400, {"error": "bad mode"})
            job_id = f"job{int(time.time()*1000)}{threading.get_ident() % 997}"
            JOBS[job_id] = {"done": False, "current": "", "events": [], "results": []}
            # F-14 fix (v46 audit): finished jobs were kept forever —
            # prune so only the newest 50 done jobs stay in memory.
            done_ids = [k for k, v in JOBS.items() if v.get("done")]
            for old in done_ids[:-50]:
                JOBS.pop(old, None)
            threading.Thread(target=_run_job,
                             args=(job_id, items, b.get("mode", "bl"),
                                   b.get("carrier") or None,
                                   (b.get("client") or "").strip()),
                             daemon=True).start()
            return self._send(200, {"job": job_id})
        if p == "/api/history/update":
            q = b.get("query")
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                if "checklist" in b:
                    hit["checklist"] = b["checklist"]
                if "notes" in b:
                    hit["notes"] = b["notes"]
                for f in ("client", "amount", "received"):
                    if f in b:
                        hit[f] = b[f]
                if "returned" in b:
                    hit["returned"] = bool(b["returned"])
                if "starred" in b:
                    hit["starred"] = bool(b["starred"])
                if b.get("seen"):
                    hit["changed"] = False
                if not save_json(HISTORY_FILE, hist):
                    return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/history/delete":
            q = b.get("query")
            with _lock:
                hist = get_history()
                gone = next((h for h in hist if h.get("query") == q), None)
                if gone is None:
                    return self._send(404, {"error": "entry not found"})
                rest = [h for h in hist if h.get("query") != q]
                if not save_json(HISTORY_FILE, rest):
                    return self._send(500, {"error": "could not save"})
                ph = gone.get("photo")
                if ph and not any(h.get("photo") == ph for h in rest):
                    try:
                        (PHOTOS_DIR / Path(ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True})
        if p == "/api/settings":
            b = b or {}
            # v48: the password hash is managed ONLY via /api/password —
            # a settings save must never overwrite or inject it.
            b.pop("app_pass", None)
            try:
                if "recheck_hours" in b:
                    rh = float(b["recheck_hours"])
                    if rh not in (3, 6, 12, 24):
                        raise ValueError("recheck_hours")
                    b["recheck_hours"] = rh
                if "free_days" in b:
                    fd = float(b["free_days"])
                    if not (0 <= fd <= 60):
                        raise ValueError("free_days")
                    b["free_days"] = fd
                if "demurrage_rate" in b:
                    dr = float(b["demurrage_rate"])
                    if dr < 0:
                        raise ValueError("demurrage_rate")
                    b["demurrage_rate"] = dr
                if "return_days" in b:
                    rd = float(b["return_days"])
                    if not (1 <= rd <= 60):
                        raise ValueError("return_days")
                    b["return_days"] = rd
            except (TypeError, ValueError) as e:
                return self._send(400, {"error": f"invalid setting: {e}"})
            for k in ("company_name", "company_tagline"):
                if k in b:
                    b[k] = str(b[k]).strip()[:80]
            if "ai_key" in b:
                _k = str(b["ai_key"] or "").strip()
                if _k:
                    b["ai_key"] = _k[:220]
                else:
                    b.pop("ai_key")
            if "traqo_key" in b:
                _k = str(b["traqo_key"] or "").strip()
                if _k:
                    b["traqo_key"] = _k[:220]
                else:
                    b.pop("traqo_key")
            s = get_settings()
            s.update(b)
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/photo":
            import base64
            q = ENG.norm(str(b.get("query") or ""))
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            if len(raw) > 8 * 1024 * 1024:
                return self._send(400, {"error": "photo too large (8 MB max)"})
            # The payload must really be an image — trust the file
            # signature, never the caller's word (v41 audit fix).
            fmt = None
            if raw[:3] == b"\xff\xd8\xff":
                fmt = ".jpg"
            elif raw[:8] == b"\x89PNG\r\n\x1a\n":
                fmt = ".png"
            elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                fmt = ".webp"
            if not fmt:
                return self._send(400, {"error": "that file is not an image"})
            name = f"{q}{fmt}"
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                old_ph = hit.get("photo")
                (PHOTOS_DIR / name).write_bytes(raw)
                hit["photo"] = name
                if not save_json(HISTORY_FILE, hist):
                    return self._send(500, {"error": "could not save"})
                if old_ph and old_ph != name:
                    try:
                        (PHOTOS_DIR / Path(old_ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True, "photo": name})
        if p == "/api/ocr":
            # v49 photo scan: app ke andar band OCR engine
            # (RapidOCR, ocr/venv) + seekha-huwa BL extractor
            # (bl-formats-learned.md). Tesseract bilkul nahi.
            import base64
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            tmp = DATA_DIR / (f"ocr_tmp_{int(time.time()*1000)}_"
                              f"{threading.get_ident()}.png")
            try:
                tmp.write_bytes(raw)
                d, err = _run_ocr_items(tmp)
            finally:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass
            if err:
                # v51: local engine tayyar nahi (missing / setup
                # chal raha / setup fail) aur settings mein Groq
                # key ho to vision fallback se record banao —
                # warna wahi saaf error jo pehle tha.
                vrec = None
                if not _ocr_python():
                    try:
                        _key = str(get_settings().get("ai_key")
                                   or "").strip()
                    except Exception:
                        _key = ""
                    if _key:
                        if raw[:8] == b"\x89PNG\r\n\x1a\n":
                            _mime = "image/png"
                        elif raw[:3] == b"\xff\xd8\xff":
                            _mime = "image/jpeg"
                        elif raw[:4] == b"RIFF" \
                                and raw[8:12] == b"WEBP":
                            _mime = "image/webp"
                        else:
                            _mime = "image/png"
                        vrec = _vision_extract_record(
                            raw, _mime, _key)
                if vrec:
                    return self._send(200, vrec)
                return self._send(200, {"ok": False, "error": err})
            rec, meta = extract_bl_record(d["items"], d["w"], d["h"])
            engine = "rapidocr-onnxruntime"
            # OPTIONAL vision booster: sirf cross-check/enrichment;
            # offline result hamesha buniyad hai aur koi vision
            # ghalti scan ko kabhi nahi rokti.
            try:
                vb = _vision_bl_extract(
                    "data:image/png;base64,"
                    + base64.b64encode(raw).decode(), rec, meta)
            except Exception:
                vb = None
            if vb:
                warns = list(rec.get("warnings") or [])
                if rec["bl_no"] \
                        and _sq(str(vb.get("bl_no"))) != rec["bl_no"]:
                    warns.append(
                        "The AI vision check read a different BL "
                        "number (" + str(vb.get("bl_no")) + ") — "
                        "please verify against the document.")
                merged = dict(rec)
                for k in ("bl_no", "carrier", "vessel", "voyage",
                          "shipper", "consignee", "pol", "pod",
                          "ts_port", "on_board", "issue_date",
                          "goods", "packages", "freight"):
                    val = vb.get(k)
                    if val not in (None, ""):
                        merged[k] = val
                for k in ("gross_kg", "net_kg", "cbm", "free_days"):
                    val = vb.get(k)
                    if val not in (None, ""):
                        merged[k] = _num_or_blank(val) or val
                vc = []
                for c in vb.get("containers") or []:
                    if isinstance(c, dict) and c.get("no"):
                        no = _sq(str(c["no"]))
                        vc.append({"no": no,
                                   "seal": _sq(str(c.get("seal")
                                                    or "")),
                                   "type": str(c.get("type") or ""),
                                   "check_ok": _iso_ok(no)})
                if vc:
                    have = {c["no"] for c in merged["containers"]}
                    merged["containers"] = merged["containers"] + \
                        [c for c in vc if c["no"] not in have]
                if merged.get("bl_no"):
                    merged["proforma"] = False
                merged["warnings"] = warns
                rec = merged
                engine = "groq-vision+rapidocr"
            rec["ok"] = True
            rec["engine"] = engine
            return self._send(200, rec)
        return self._send(404, {"error": "not found"})



def _iso_ok(s):
    """ISO 6346 check digit ki jaanch."""
    VAL = {"A": 10, "B": 12, "C": 13, "D": 14, "E": 15, "F": 16,
           "G": 17, "H": 18, "I": 19, "J": 20, "K": 21, "L": 23,
           "M": 24, "N": 25, "O": 26, "P": 27, "Q": 28, "R": 29,
           "S": 30, "T": 31, "U": 32, "V": 34, "W": 35, "X": 36,
           "Y": 37, "Z": 38}
    try:
        tot = 0
        for i, ch in enumerate(s[:10]):
            v = int(ch) if ch.isdigit() else VAL[ch]
            tot += v * (2 ** i)
        return (tot % 11) % 10 == int(s[10])
    except Exception:
        return False


def _lev(a, b):
    if abs(len(a) - len(b)) > 3:
        return 99
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1,
                           prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def doctor_number(raw):
    """Number Doctor (idea 20): search se PEHLE number ki
    jaanch — ye BL hai ya container, kis line ka lagta hai,
    digit theek hai ya nahi, aur list ke kisi number se
    milta julta to nahi."""
    import re as _re
    n = ENG.norm(str(raw or ""))
    out = {"input": raw, "normalized": n, "type": "Not recognized",
           "carrier": None, "valid": None, "notes": [],
           "suggestion": None, "expanded": None}
    if not n:
        out["notes"].append("Nothing was entered.")
        return out
    if _re.fullmatch(r"\d{5}", n) and n[0] == "5":
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True, expanded="EMKAYMBAKHI" + n)
        out["notes"].append("5 digits starting with 5 — by the "
                            "standing rule this is an Emkay Lines "
                            "BL; TRACK adds EMKAYMBAKHI by itself.")
        return out
    if n.startswith("EMKAY") or n.startswith("MBAK"):
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True)
        out["notes"].append("This is an Emkay Lines BL.")
        return out
    if _re.fullmatch(r"[A-Z]{4}\d{7}", n):
        ok = _iso_ok(n)
        out.update(type="Container", valid=ok,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if ok:
            out["notes"].append("The container number's shape and its "
                                "final check digit are both correct.")
        else:
            out["notes"].append("The final digit (check digit) does not "
                                "match the calculation — there is "
                                "likely a typing mistake in the number.")
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} usually belongs to "
                                f"{out['carrier']}.")
        return out
    if _re.fullmatch(r"[A-Z]{4}[A-Z0-9]{5,}", n):
        out.update(type="BL", valid=True,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} — this looks like a "
                                f"{out['carrier']} BL.")
        else:
            out["notes"].append("BL-shaped number, but the prefix does "
                                "not match a well-known line — the "
                                "search will still try every route.")
        return out
    if _re.fullmatch(r"\d{9,12}", n):
        out.update(type="BL (digits only)",
                   carrier="COSCO Shipping (likely)", valid=True)
        out["notes"].append("Digits-only BLs are usually COSCO — "
                            "the app will search by the digits.")
        return out
    if _re.fullmatch(r"[A-Z ]{3,}", n) and " " in n.strip():
        out.update(type="Vessel name", valid=True)
        out["notes"].append("This looks like a vessel name — "
                            "search it in Vessel mode.")
        return out
    out["notes"].append("The shape is unclear — it does not look "
                        "like a BL, a container or a vessel name.")
    best = None
    for h in get_history():
        q = (h.get("query") or "").upper()
        if q and abs(len(q) - len(n)) <= 2:
            d = _lev(n, q)
            if best is None or d < best[0]:
                best = (d, q)
    if best and 0 < best[0] <= 2:
        out["suggestion"] = best[1]
        out["notes"].append(f"This closely matches {best[1]} in your "
                            "list — could it be the same one?")
    return out


def _parse_doc_fields(text):
    """BL ki photo ke text se poori tafseel (idea 26): jahaz,
    voyage, wazan, tadaad, samaan — jo mile, imaandari se."""
    import re as _re
    t = text or ""
    f = {}
    m = _re.search(r"VESSEL[:\s]*([A-Za-z][A-Za-z ]{2,28})", t)
    if m:
        f["vessel"] = m.group(1).strip().upper()
    m = _re.search(r"(?:VOYAGE|VOY\.?|V\.)[:\s]*([A-Za-z0-9]{2,10})", t)
    if m:
        f["voyage"] = m.group(1).upper()
    m = _re.search(r"([\d.,]+)\s*KGS?\b", t, _re.I)
    if m:
        f["weight"] = m.group(1) + " KGS"
    m = _re.search(r"(\d+)\s*(PACKAGES|PKGS|CARTONS|BAGS|PCS|UNITS)",
                   t, _re.I)
    if m:
        f["packages"] = m.group(1) + " " + m.group(2).upper()
    for label in ("DESCRIPTION OF GOODS", "DESCRIPTION",
                  "PARTICULARS", "COMMODITY"):
        m = _re.search(label + r"[:\s]*([^\n]{4,90})", t, _re.I)
        if m:
            f["commodity"] = m.group(1).strip(" :-").upper()
            break
    return f


def _ast_date(v):
    """App ki mukhtalif date shaklo ko date mein badlo."""
    if not v:
        return None
    t = str(v).strip()
    for f in ("%d %b %Y", "%d-%b-%Y", "%d %b %y", "%Y-%m-%d",
              "%d/%m/%Y", "%d-%m-%Y", "%d %B %Y"):
        try:
            return datetime.strptime(t.title()
                                     if f in ("%d %b %Y", "%d %b %y")
                                     else t, f).date()
        except Exception:
            continue
    m = re.match(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{4})", t)
    if m:
        try:
            return datetime.strptime(
                f"{m.group(1)} {m.group(2)[:3]} {m.group(3)}",
                "%d %b %Y").date()
        except Exception:
            return None
    return None


def _ast_completed(h):
    r = h.get("result") or {}
    return bool(r.get("gate_out")) or "deliver" in (
        r.get("status") or "").lower() or (
        (r.get("position") or "").upper() == "OUT")


def _computed_facts(found):
    """v57: Assistant ke liye app ke GINAY HUAY facts — din aur
    gin-ti model ke andaze par nahi chhorte. Aamad (arrivals),
    hold, late aur bina-ETA fehristein TAMAM records se banti
    hain, taake bot aadhi list ko poori na keh sake (v56 ki
    ghalti: context mein sirf pehle 25 records jate thay)."""
    from datetime import timedelta, timezone
    today = datetime.now(timezone(timedelta(hours=5))).date()
    arr, late, noeta, holds = [], [], [], []
    for h in found:
        r = h.get("result") or {}
        st = (r.get("status") or "").lower()
        if "hold" in st:
            holds.append(h)
        if _ast_completed(h):
            continue
        d = _ast_date(r.get("eta"))
        if d and d >= today:
            arr.append((d, h))
        elif d:
            late.append((d, h))
        elif "discharg" not in st and "deliver" not in st \
                and "arriv" not in st and "berthed" not in st \
                and "terminal" not in st:
            noeta.append(h)
    arr.sort(key=lambda x: x[0])
    L = ["",
         "COMPUTED FACTS - counted by the app itself from ALL "
         f"{len(found)} found records (today: "
         f"{today.strftime('%d %b %Y')}, Karachi time). For ANY "
         "question about arrivals, holds or totals, answer ONLY "
         "from this section: list EVERY matching shipment and "
         "state the total number. Never do your own date maths "
         "and never present a partial list as complete."]
    if arr:
        L.append(f"Upcoming arrivals ({len(arr)} total, "
                 "soonest first):")
        for d, h in arr:
            r = h.get("result") or {}
            n = (d - today).days
            when = ("today" if n == 0 else
                    "tomorrow" if n == 1 else f"in {n} days")
            L.append(f"- {h.get('query')} - ETA {r.get('eta')} "
                     f"({when}) - {r.get('vessel') or 'vessel n/a'}"
                     f" - {r.get('terminal') or ''} - "
                     f"{r.get('status') or ''}")
        for w in (7, 14, 20, 30):
            sub = [str(h.get("query")) for d, h in arr
                   if (d - today).days <= w]
            L.append(f"Arriving within {w} days: {len(sub)}"
                     + (": " + ", ".join(sub) if sub else ""))
    else:
        L.append("Upcoming arrivals: none with a future ETA.")
    if late:
        L.append("ETA date already passed, still in transit "
                 "(no new date yet): "
                 + ", ".join(str(h.get("query")) for _, h in late))
    if noeta:
        L.append("In transit with NO ETA recorded yet (never "
                 "invent a date for these): "
                 + ", ".join(str(h.get("query")) for h in noeta))
    if holds:
        L.append(f"ON HOLD right now ({len(holds)}): "
                 + ", ".join(str(h.get("query")) for h in holds))
    return L


def _assistant_context():
    hist = get_history()
    found = [h for h in hist if h.get("found")]
    nf = [h for h in hist if not h.get("found")]
    lines = [f"Shipments in the app: {len(hist)} tracked, "
             f"{len(found)} found, {len(nf)} not found.",
             f"COMPLETE LIST of found shipments (all "
             f"{len(found)} - nothing is cut off):"]
    for h in found:
        r = h.get("result") or {}
        row = (f"- {h.get('query')} ({h.get('carrier') or 'carrier unknown'}): "
               f"{r.get('status') or 'status unknown'}")
        if r.get("vessel"):
            row += f", vessel {r['vessel']}"
        if r.get("eta"):
            row += f", ETA {r['eta']}"
        if r.get("terminal"):
            row += f", terminal {r['terminal']}"
        if r.get("containers"):
            row += f", containers {', '.join(r['containers'])}"
        lines.append(row)
    if nf:
        lines.append("Not found so far: " + ", ".join(
            str(h.get("query")) for h in nf))
    lines.extend(_computed_facts(found))
    st = get_settings()
    lines.append(f"Free days before demurrage: {st.get('free_days')}; "
                 f"auto re-check every {st.get('recheck_hours')} hours.")
    lines.append("Photo scanning (OCR) on this computer: "
                 + ("ready (engine built into the app)"
                    if _ocr_python() else
                    "not set up on this device yet - it installs "
                    "itself automatically the first time you scan "
                    "a photo (one-time, a few minutes)"))
    return "\n".join(lines)

def _ocr_image_bytes(raw):
    """Photo ke bytes se text — v49: app ka apna band OCR engine
    (RapidOCR, subprocess). (True, text) ya (False, wajah)."""
    tmp = DATA_DIR / (f"ocr_tmp_{int(time.time()*1000)}_"
                      f"{threading.get_ident()}.png")
    try:
        tmp.write_bytes(raw)
        d, err = _run_ocr_items(tmp)
        if err:
            return False, err
        items = sorted(d["items"],
                       key=lambda i: (_it_cy(i), _it_cx(i)))
        lines = _ocr_lines(items, d["h"])
        return True, "\n".join(ln["text"] for ln in lines)
    except Exception as e:
        return False, str(e)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def _pdf_text(raw):
    """v46: PDF se text — koi library nahi, stdlib zlib se FlateDecode
    streams khol kar Tj/TJ text operators jama karo. Scanned-image
    PDF par khaali milega (caller imandari se wahi kehta hai)."""
    import re as _re
    import zlib as _zlib
    out = []
    for m in _re.finditer(rb"stream\r?\n(.*?)endstream", raw, _re.S):
        data = m.group(1)
        try:
            data = _zlib.decompress(data)
        except Exception:
            pass
        for t in _re.findall(rb"\((?:\\.|[^\\)])*\)\s*Tj", data):
            out.append(t[1:t.rindex(b")")])
        for arr in _re.findall(rb"\[(.*?)\]\s*TJ", data, _re.S):
            parts = _re.findall(rb"\((?:\\.|[^\\)])*\)", arr)
            if parts:
                out.append(b"".join(p[1:-1] for p in parts))
    txt = b" ".join(out).decode("latin-1", "replace")
    txt = txt.replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\")
    return " ".join(txt.split())


def _transcribe_audio(raw):
    """Recorded aawaz ko Groq Whisper se text banao (v41).
    Browser ki apni speech service aksar atak jati thi — ye
    rasta hamesha app ki apni key se chalta hai."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    key = str(get_settings().get("ai_key") or "").strip()
    if not key.startswith("gsk_"):
        return False, ("Voice typing needs the free AI key — add "
                       "it in Settings first.")
    for model in ("whisper-large-v3-turbo", "whisper-large-v3"):
        boundary = "----ct" + str(int(time.time() * 1000))
        body = b""
        for name, val in (("model", model),
                          ("response_format", "json"),
                          ("language", "en"),
                          ("prompt", "Shipping numbers: bill of "
                           "lading and container numbers, spoken "
                           "digit by digit.")):
            body += (f"--{boundary}\r\nContent-Disposition: "
                     f"form-data; name=\"{name}\"\r\n\r\n"
                     f"{val}\r\n").encode()
        body += (f"--{boundary}\r\nContent-Disposition: form-data; "
                 f"name=\"file\"; filename=\"voice.webm\"\r\n"
                 f"Content-Type: audio/webm\r\n\r\n").encode()
        body += raw + f"\r\n--{boundary}--\r\n".encode()
        req = _u.Request(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            data=body,
            headers={"Authorization": f"Bearer {key}",
                     "Content-Type": "multipart/form-data; "
                     f"boundary={boundary}",
                     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; "
                     "Win64; x64) AppleWebKit/537.36 (KHTML, "
                     "like Gecko) Chrome/130.0 Safari/537.36"})
        try:
            with _u.urlopen(req, timeout=60) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            txt = (d.get("text") or "").strip()
            if txt:
                return True, txt
            return False, ("Nothing was heard in that recording — "
                           "try again, a little closer to the mic.")
        except _ue.HTTPError as e:
            if e.code in (400, 404, 415) and model.endswith("turbo"):
                continue
            if e.code == 401:
                return False, ("The AI key was refused by Groq — "
                               "check the key in Settings.")
            return False, (f"Voice service error ({e.code}) — "
                           "please try again.")
        except Exception as e:
            return False, "Voice service unreachable: " + str(e)[:80]
    return False, "Voice service did not answer — please try again."



def _groq_answer(q, hist, key, extra=""):
    """Groq (muft tier, Llama models) se asal guftagu. Key
    'gsk_' se shuru hoti hai. Ghalti par None — local jawab
    sambhal lega, jhooti tasalli kabhi nahi."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    sys_txt = (
        "You are the assistant inside CargoTrack, a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. Answer EXACTLY the question he asked - never substitute a different answer. When he asks for all / every / tamaam / sab, enumerate the COMPLETE matching list from the data below and state how many there are; presenting a partial list as complete is the worst possible answer. The COMPUTED FACTS section was counted by the app from ALL records - trust it over your own counting and date maths. If he asks for a photo, image, card or report but has NOT named a shipment in this conversation, ask in ONE short line which BL he means - never pick a shipment for him, and never volunteer information he did not ask for. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app CREATES it automatically and it appears in the chat under your reply - so confirm it in one short line (for example: it is ready below, have a look) instead of describing steps or asking him to press anything. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically.\n\nLIVE APP DATA:\n"
        + _assistant_context() + extra)
    msgs = [{"role": "system", "content": sys_txt}]
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:800]
        if t:
            msgs.append({"role": "user" if h.get("role") == "user"
                         else "assistant", "content": t})
    msgs.append({"role": "user", "content": q})
    # Groq ka catalog badalta rehta hai — 21 Oct 2026 ko is
    # account par Llama models maujood hi nahi thay, sirf
    # gpt-oss / qwen family thi. Is liye pehle wohi, phir
    # purane naam (jin accounts par hon un ke liye).
    for model in ("openai/gpt-oss-120b", "qwen/qwen3.8-27b",
                  "openai/gpt-oss-20b", "llama-3.3-70b-versatile",
                  "llama-3.1-8b-instant"):
        try:
            body = {"model": model, "messages": msgs,
                    "temperature": 0.2, "max_tokens": 1100}
            req = _u.Request(
                "https://api.groq.com/openai/v1/chat/completions",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}",
                         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; "
                         "Win64; x64) AppleWebKit/537.36 (KHTML, "
                         "like Gecko) Chrome/130.0 Safari/537.36"})
            with _u.urlopen(req, timeout=35) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            txt = (d["choices"][0]["message"].get("content")
                   or "").strip()
            if txt:
                return txt
        except _ue.HTTPError as e:
            if e.code in (404, 400, 403, 429):
                continue
            return None
        except Exception:
            continue  # F-12: one model's network hiccup must not skip the rest
    return None


def _gemini_answer(q, hist, key, extra=""):
    """Google Gemini (free tier) se asal jawab. Koi ghalti ho to
    None — jhooti tasalli kabhi nahi."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    contents = []
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:800]
        if t:
            contents.append({"role": "user" if h.get("role") == "user"
                             else "model",
                             "parts": [{"text": t}]})
    contents.append({"role": "user", "parts": [{"text": q}]})
    sys_txt = (
        "You are the assistant inside CargoTrack, a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. Answer EXACTLY the question he asked - never substitute a different answer. When he asks for all / every / tamaam / sab, enumerate the COMPLETE matching list from the data below and state how many there are; presenting a partial list as complete is the worst possible answer. The COMPUTED FACTS section was counted by the app from ALL records - trust it over your own counting and date maths. If he asks for a photo, image, card or report but has NOT named a shipment in this conversation, ask in ONE short line which BL he means - never pick a shipment for him, and never volunteer information he did not ask for. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app CREATES it automatically and it appears in the chat under your reply - so confirm it in one short line (for example: it is ready below, have a look) instead of describing steps or asking him to press anything. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically.\n\nLIVE APP DATA:\n"
        + _assistant_context() + extra)
    body = {"systemInstruction": {"parts": [{"text": sys_txt}]},
            "contents": contents,
            "generationConfig": {"temperature": 0.2,
                                 "maxOutputTokens": 1100}}
    for model in ("gemini-2.5-flash", "gemini-2.0-flash"):
        try:
            req = _u.Request(
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{model}:generateContent?key={key}",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json"})
            with _u.urlopen(req, timeout=35) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            parts = d["candidates"][0]["content"]["parts"]
            txt = "".join(x.get("text", "") for x in parts).strip()
            if txt:
                return txt
        except _ue.HTTPError as e:
            if e.code == 404:
                continue
            return None
        except Exception:
            continue  # F-12: try the next model before giving up
    return None


def _find_mentioned_entry(text):
    t = ENG.norm(text or "")
    if not t:
        return None
    for h in get_history():
        if h.get("query") and h["query"].upper() in t:
            return h
        for c in ((h.get("result") or {}).get("containers") or []):
            if c and c.upper() in t:
                return h
    return None


_MEDIA_WORDS = ("image", "photo", "tasveer", "picture", "pic", "jpg",
                "jpeg", "png", "card", "pdf", "report", "file", "download")


def _media_ask(q):
    """v47: media (image/card/PDF/report) SIRF tab bane jab user
    ne is sawal mein saaf tor par manga ho. Sirf BL ka status
    poochne par koi card/report nahi banti — sirf text jawab."""
    ql = (q or "").lower()
    return any(re.search(r"\b" + w + r"\b", ql) for w in _MEDIA_WORDS)


def _media_intent_actions(q, local_q, hist=None):
    """Jis shipment ki baat ho rahi ho — chahe zikr is sawal
    mein ho ya Pichli baat-cheet mein — us ke liye mukammal
    options: Image, Report, Copy, WhatsApp. LEKIN v47 se ye
    actions sirf tab aate hain jab user ne media saaf tor par
    manga ho (_media_ask) — warna jawab sirf text hota hai."""
    media = _media_ask(q)
    entry = _find_mentioned_entry(local_q)
    if not entry and media:
        # pichli guftagu ulta tartib mein dekho — sab se
        # aakhri zikr wala shipment hi mauzu hai (sirf media
        # mange par; aam guftagu mein purani baat nahi uthani)
        for turn in reversed(hist or []):
            if (turn or {}).get("role") == "user":
                entry = _find_mentioned_entry(turn.get("text"))
                if entry:
                    break
    if entry and not media:
        # Shipment pehchana gaya lekin media nahi manga —
        # v47: sirf compact text jawab, koi action nahi.
        return []
    if not entry:
        if media:
            rec = []  # v57: BL mange baghair kisi shipment ka card NAHI banta
            # (purana code pehli 3 shipments ke Image/Report
            #  button khud bana deta tha - wohi ghalti jo user ne pakri)
            acts_r = []
            for h in rec:
                acts_r.append({"label": "\U0001F5BC Image — "
                               + h["query"], "act": "image",
                               "arg": h["query"]})
                acts_r.append({"label": "\U0001F4C4 Report — "
                               + h["query"], "act": "report",
                               "arg": h["query"]})
            if acts_r:
                return acts_r
        m = re.search(r"\b[A-Z0-9][A-Z0-9\-]{5,}\b",
                      (local_q or "").upper())
        if m and any(c.isdigit() for c in m.group(0)):
            return [{"label": "\U0001F50D Track — " + m.group(0),
                     "act": "track", "arg": m.group(0),
                     "mode": "bl"}]
        return []
    qy = entry["query"]
    # v47 fix: jo media manga hai, sirf wohi bane — sirf image
    # maangne par report tile bhi ban jati thi (QA finding D3).
    ql = (q or "").lower()

    def _has(words):
        return any(re.search(r"\b" + w + r"\b", ql) for w in words)

    want_img = _has(("image", "photo", "tasveer", "picture",
                     "pic", "jpg", "jpeg", "png", "card"))
    want_rep = _has(("pdf", "report", "file"))
    if _has(("download",)) and not want_img and not want_rep:
        want_img = want_rep = True
    if not want_img and not want_rep:
        want_img = want_rep = True
    acts = []
    if want_img:
        acts.append({"label": "\U0001F5BC Image — " + qy,
                     "act": "image", "arg": qy})
    if want_rep:
        acts.append({"label": "\U0001F4C4 Report — " + qy,
                     "act": "report", "arg": qy})
    acts.append({"label": "\U0001F4CB Copy — " + qy, "act": "copy",
                 "arg": qy})
    acts.append({"label": "\U0001F4AC WhatsApp — " + qy,
                 "act": "wa", "arg": qy})
    return acts


def assistant_answer(q, hist=None, attach=None):
    extra = ""
    local_q = q
    if attach:
        if attach.get("kind") == "image" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            if raw:
                ok, val = _ocr_image_bytes(raw)
                if ok:
                    nums = re_find_numbers(val)
                    extra = ("\n\nATTACHED PHOTO — text read "
                             "from it:\n" + val[:1500])
                    if nums:
                        extra += ("\nNumbers found in the photo: "
                                  + ", ".join(nums))
                        local_q = q + " " + " ".join(nums)
                else:
                    extra = ("\n\nThe user attached a photo, but "
                             "this computer could not read it: "
                             + val)
        elif attach.get("kind") == "pdf" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            ptxt = _pdf_text(raw) if raw else ""
            if ptxt:
                nums = re_find_numbers(ptxt)
                extra = ("\n\nATTACHED PDF ("
                         + str(attach.get("name") or "file")[:60]
                         + ") — text read from it:\n" + ptxt[:4000])
                if nums:
                    extra += ("\nNumbers found in the PDF: "
                              + ", ".join(nums))
                    local_q = q + " " + " ".join(nums)
            else:
                extra = ("\n\nThe user attached a PDF, but no text "
                         "could be read from it on this computer (it "
                         "may be a scanned-image PDF). Say so honestly "
                         "in one line and suggest sending a photo of "
                         "the page instead.")
        elif attach.get("kind") == "file":
            extra = ("\n\nATTACHED FILE ("
                     + str(attach.get("name") or "file")[:60]
                     + ") — its text:\n"
                     + str(attach.get("text") or "")[:4000])
    acts = _media_intent_actions(q, local_q, hist)
    key = str(get_settings().get("ai_key") or "").strip()
    if key:
        try:
            txt = (_groq_answer(q, hist, key, extra)
                   if key.startswith("gsk_")
                   else _gemini_answer(q, hist, key, extra))
        except Exception:
            txt = None
        if txt:
            return {"answer": txt, "actions": acts, "mode": "ai"}
        out = _assistant_local(local_q)
        out["mode"] = "local"
        out["ai_error"] = True
        out["actions"] = (out.get("actions") or []) + acts
        return out
    out = _assistant_local(local_q)
    out["mode"] = "local"
    out["actions"] = (out.get("actions") or []) + acts
    return out


def _assistant_local(q):
    from datetime import timedelta, timezone
    """App ke andar ka madadgar: jawab hamesha app ke APNE data
    aur system ki asal halat se banta hai — andaza nahi. Jo is ke
    bas se bahar ho, wahan saaf kehta hai ke Shezi se poochein."""
    ql = q.lower()
    hist = get_history()
    st = get_settings()
    today = datetime.now(timezone(timedelta(hours=5))).date()
    acts = []
    lines = []

    def track_act(query, mode, label=None):
        acts.append({"label": label or f"Track {query}",
                     "act": "track", "arg": query, "mode": mode})

    # 1) sawal mein koi number ho to us ki poori report
    # number = kam az kam 8 harf/rakam AUR us mein digit lazmi
    # (warna "shipments" jese aam lafz bhi number ban jate thay)
    token = None
    for cand in re.findall(r"[A-Za-z0-9]{8,20}", q):
        if any(ch.isdigit() for ch in cand):
            token = cand.upper()
            break
    if token and not any(k in ql for k in
                         ("how", "what", "why", "kaise", "kya")):
        h = next((x for x in hist if x["query"].upper() == token),
                 None)
        if not h:
            h = next((x for x in hist
                      if token in ((x.get("result") or {})
                                   .get("containers") or [])), None)
        if h:
            r = h.get("result") or {}
            lines.append(f"{h['query']} — "
                         f"{'FOUND' if h['found'] else 'NOT FOUND'}"
                         f" ({h.get('carrier') or 'carrier unknown'})")
            if r.get("status"):
                lines.append(f"Status: {r['status']}")
            if r.get("vessel"):
                lines.append("Vessel: " + r["vessel"] +
                             (f" ({r['voyage']})" if r.get("voyage")
                              else ""))
            if r.get("eta"):
                lines.append(f"ETA: {r['eta']}")
            if r.get("terminal"):
                lines.append(f"Terminal: {r['terminal']}")
            if r.get("position"):
                lines.append(f"Position: {r['position']}")
            if r.get("holds"):
                lines.append(f"Holds: {r['holds']}")
            if (r.get("containers") or []):
                lines.append("Containers: "
                             + ", ".join(r["containers"]))
            lines.append(f"Last checked: {h.get('time') or '—'}")
            track_act(h["query"], h.get("mode") or "bl",
                      "↻ Check again now")
            return {"answer": "\n".join(lines), "actions": acts}
        lines.append(f"{token} is not in your tracked shipments yet.")
        track_act(token, "container"
                  if re.fullmatch(r"[A-Z]{4}\d{7}", token) else "bl",
                  f"Track {token} now")
        return {"answer": "\n".join(lines), "actions": acts}

    # 13) istilahat / "kya hota hai" — shipping ki har aam istilah
    GLOSS = {
      "demurrage": "Demurrage: the charge for keeping a container at the terminal BEYOND the free days after discharge. Counted per day, per container. Your free days are set in Settings (currently {fd}).",
      "detention": "Detention: the charge for keeping the container OUTSIDE the terminal (at your godown) beyond the allowed days after gate-out.",
      "bill of lading": "Bill of Lading (BL): the shipment's main document — the contract and receipt for the cargo. Its number tracks the whole shipment: vessel, route, containers, status.",
      " bl ": "BL (Bill of Lading): the shipment's main document and tracking number — one BL can carry several containers.",
      "eta": "ETA (Estimated Time of Arrival): the date the vessel is expected to reach the destination port. It is an estimate — it can move as the voyage progresses.",
      "etd": "ETD (Estimated Time of Departure): the date the vessel is expected to leave the loading port.",
      "gate pass": "Gate Pass: the terminal's permission for a truck to collect the container. 'GatePass Not Issued' means the release steps (delivery order, payments, holds) are not complete yet.",
      "delivery order": "Delivery Order (DO): the shipping line's order telling the terminal to release the cargo to you. It has an expiry date — after that it must be renewed.",
      "vir": "VIR (Vessel Inward Report): the terminal's arrival record for a vessel visit. The VIR number also tells the terminal honestly — PKKHIKICT means KICT, PKKHISAPT means SAPT, PKBQMQICT means QICT.",
      "hold": "Hold: the terminal, customs or the line has stopped the release — billing hold, customs hold or line hold. Cargo cannot move until the hold is cleared.",
      "yard": "Yard: the container's storage area inside the terminal. 'Position: YARD' means the container is physically inside, waiting for release steps.",
      "discharge": "Discharge: unloading the container from the vessel at the port. Your free days start counting from the discharge date.",
      "transhipment": "Transhipment (transshipment): the cargo changes vessel at an in-between port before reaching Karachi.",
      "transshipment": "Transhipment: the cargo changes vessel at an in-between port before reaching Karachi.",
      "free days": "Free days: the days after discharge during which the terminal charges no demurrage. Set yours in Settings — currently {fd} days.",
      "nvocc": "NVOCC: a carrier that books space on other lines' vessels instead of owning ships (like Emkay Line). Their house BLs are tracked through the terminal and the master line.",
      "teu": "TEU: Twenty-foot Equivalent Unit — the standard measure of container capacity. A 40ft container is 2 TEU.",
      "container": "Container number: 4 letters + 7 digits (like CSNU6961392). The last digit is a check digit — this app verifies it with the ISO 6346 formula.",
    }
    for term, definition in GLOSS.items():
        if (term in ql and any(w in ql for w in
                              ("kya hota", "kya hai", "what is",
                               "meaning", "matlab", "samjha",
                               "explain"))
                and not any(w in ql for w in
                            ("which", "list", "kons", "show me",
                             "kitn", "on hold", "batao", "konsi",
                             "konse", "kitne", "kitni", "kab "))):
            lines.append(definition.replace("{fd}",
                                            str(st.get("free_days", 7))))
            return {"answer": "\n".join(lines), "actions": acts}


    found = [h for h in hist if h["found"]]
    notfound = [h for h in hist if not h["found"]]

    # 1c) v57: media manga lekin koi shipment nahi pehchana
    # gaya - andaz se card NAHI banta, pehle poochho kis BL ki
    if _media_ask(q) and not _find_mentioned_entry(q):
        lines.append("Photo / image / report ke liye shipment ka "
                     "BL number likh dein - kis BL ki chahiye? "
                     "Misal: '142G513366 ki photo'.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 2) holds
    if any(k in ql for k in ("hold", "ruk", "stuck")):
        hs = [h for h in found
              if "hold" in ((h["result"].get("status") or "").lower())
              or (h["result"].get("holds"))]
        if hs:
            lines.append(f"{len(hs)} shipment(s) on hold:")
            for h in hs[:10]:
                r = h["result"]
                lines.append(f"• {h['query']} — {r.get('status')}"
                             + (f" ({r['terminal']})"
                                if r.get("terminal") else ""))
        else:
            lines.append("No shipment is on hold right now. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 3) arriving soon - v57: sawal ka din-window (20 days /
    # 2 week / hafta) samajh kar, gin-ti ke sath poori list
    if any(k in ql for k in ("arriv", "eta", "kab aay", "coming",
                             "expected", "aane wal", "aayenge",
                             "aayega", "a raha", "aa raha", "tamaam",
                             "aane", "dinon", "agle din")):
        arr = []
        for h in found:
            d = _ast_date((h["result"] or {}).get("eta"))
            if d and d >= today and not _ast_completed(h):
                arr.append((d, h))
        arr.sort(key=lambda x: x[0])
        win = None
        m = re.search(r"(\d+)\s*(day|days|din|roz|week|hafte|"
                      r"hafta|month|mahin|maah)", ql)
        if m:
            u = m.group(2)
            win = int(m.group(1)) * (7 if u.startswith(("week",
                     "haft")) else 30 if u.startswith(("month",
                     "mahin", "maah")) else 1)
        elif "week" in ql or "haft" in ql:
            win = 7
        sel = [(d, h) for d, h in arr
               if win is None or (d - today).days <= win]
        if sel:
            lines.append("Arriving"
                         + (f" in the next {win} days" if win
                            else " (soonest first)")
                         + f" - {len(sel)} shipment(s):")
            for d, h in sel[:30]:
                r = h["result"]
                lines.append(f"\u2022 {h['query']} - ETA "
                             f"{r.get('eta')} \u2022 "
                             f"{r.get('vessel') or ''} \u2022 "
                             f"{r.get('terminal') or ''}")
            if len(sel) > 30:
                lines.append(f"... and {len(sel) - 30} more.")
        else:
            lines.append("No upcoming arrivals with an ETA in "
                         "your list"
                         + (f" in the next {win} days." if win
                            else "."))
        return {"answer": "\n".join(lines), "actions": acts}

    # 4) delivered
    if any(k in ql for k in ("deliver", "pohanch", "completed",
                             "done")):
        ds = [h for h in found if _ast_completed(h)]
        lines.append(f"{len(ds)} shipment(s) completed / delivered:")
        for h in ds[:10]:
            lines.append(f"• {h['query']} — "
                         f"{h['result'].get('status')}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 5) demurrage risk
    if any(k in ql for k in ("demurrage", "risk", "late charge",
                             "free day")):
        fd = st.get("free_days", 7)
        risk = []
        for h in found:
            if _ast_completed(h):
                continue
            d = _ast_date((h["result"] or {}).get("discharge_time"))
            if d and (today - d).days > fd:
                risk.append(((today - d).days - fd, h))
        risk.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if risk:
            lines.append("Demurrage risk (free days over):")
            for over, h in risk[:10]:
                lines.append(f"• {h['query']} — {over} day(s) over "
                             f"the {fd} free days")
        else:
            lines.append("No demurrage risk right now — nothing is "
                         "past its free days. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 6) not found help
    if any(k in ql for k in ("not found", "nahi mil", "missing",
                             "no record")):
        lines.append(f"You have {len(notfound)} not-found number(s):")
        for h in notfound[:10]:
            lines.append(f"• {h['query']}")
        lines.append("Common reasons: one letter typed wrong (the "
                     "app now suggests the close match from your "
                     "history), the carrier has not published the "
                     "record yet, or the system did not respond — "
                     "a 'not found' here never proves your number "
                     "is wrong. Retry after a while.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 15) sab se purani pending shipment
    if any(k in ql for k in ("oldest", "purani", "sab se pehle",
                             "longest waiting")):
        pend = []
        for h in found:
            if _ast_completed(h):
                continue
            dd = _ast_date((h["result"] or {}).get("discharge_time"))
            if dd:
                pend.append(((today - dd).days, h))
        pend.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if pend:
            lines.append("Longest-waiting shipments (discharged, "
                         "not yet delivered):")
            for days, h in pend[:5]:
                lines.append(f"• {h['query']} — {days} day(s) since "
                             f"discharge • {h['result'].get('status')}")
        else:
            lines.append("No discharged-and-waiting shipments.")
        return {"answer": "\n".join(lines), "actions": acts}


    # 7) payments
    if any(k in ql for k in ("payment", "paisa", "pending",
                             "receive", "client")):
        from collections import defaultdict
        agg = defaultdict(lambda: [0, 0])
        for h in hist:
            c = (h.get("client") or "").strip()
            if not c:
                continue
            try:
                agg[c][0] += float(h.get("amount") or 0)
                agg[c][1] += float(h.get("received") or 0)
            except Exception:
                pass
        pend = [(c, a - r) for c, (a, r) in agg.items() if a - r > 0]
        if pend:
            lines.append("Pending payments:")
            for c, p in pend[:10]:
                lines.append(f"• {c}: PKR {p:,.0f} pending")
        else:
            lines.append("No pending payments in your records. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 8) OCR / photo
    if any(k in ql for k in ("ocr", "photo", "scan", "camera",
                             "tasveer")):
        if _ocr_python():
            lines.append("Photo scanning (OCR) is READY — the "
                         "engine is built into the app itself, "
                         "nothing needs to be installed.")
            lines.append("Use 'Scan photo' on the search box, or "
                         "attach a photo to any result.")
        else:
            lines.append("Photo scanning is not set up on this "
                         "device yet. Nothing to install by hand: "
                         "scan any BL photo once and the engine "
                         "sets itself up automatically (one-time, "
                         "a few minutes, internet needed); after "
                         "that every scan works directly.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 9) system health — "system pe nazar"
    if any(k in ql for k in ("system", "health", "halat",
                             "report", "kais")):
        stale = [h for h in found if not _ast_completed(h)
                 and h.get("checked_ts")
                 and time.time() - h["checked_ts"] > 3 * 3600]
        lines.append("System health:")
        lines.append(f"• Tracked shipments: {len(hist)} "
                     f"({len(found)} found, {len(notfound)} not found)")
        lines.append(f"• On hold: "
                     f"{len([h for h in found if 'hold' in ((h['result'].get('status') or '').lower())])}")
        lines.append(f"• Data older than 3 hours (press TRACK to "
                     f"refresh): {len(stale)}")
        lines.append(f"• Auto re-check: every "
                     f"{st.get('recheck_hours', 6)} hours")
        lines.append(f"• Photo scanning (OCR): "
                     f"{'ready ✓' if _ocr_python() else 'not set up yet — automatic on first photo scan'}")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 10) backup
    if "backup" in ql:
        lines.append("Your data (history, settings, photos) lives "
                     "outside the app folder, so updates never "
                     "erase it. A backup ZIP can be downloaded any "
                     "time:")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 11) delete / clear help
    if any(k in ql for k in ("delete", "clear", "hata", "remove")):
        lines.append("Every row in the Logs lists now has a 🗑 "
                     "Delete button, and the Not Found card has a "
                     "'Clear all' button that removes all not-found "
                     "entries at once (it asks first). Found "
                     "shipments can also be deleted from their "
                     "result card.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 12) greeting / help
    if (re.search(r"\b(hi|hello|salam|aoa|help|madad)\b", ql)
            or "what can" in ql):
        lines.append("I am the built-in assistant. I watch your "
                     "shipments and this app, and answer from your "
                     "own data. Try:")
        lines.append("• 'Which shipments are on hold?'")
        lines.append("• 'What is arriving soon?'")
        lines.append("• 'System health'")
        lines.append("• Type any BL / container number for its "
                     "full report")
        lines.append("• 'Why is my number not found?'")
        return {"answer": "\n".join(lines), "actions": acts}

    # 14) aaj ka brief
    if any(k in ql for k in ("brief", "aaj ka", "today", "summary")):
        arr_today = [h for h in found
                     if _ast_date((h["result"] or {}).get("eta")) == today]
        holds = [h for h in found
                 if "hold" in ((h["result"].get("status") or "").lower())]
        lines.append(f"Today's brief — {len(hist)} tracked, "
                     f"{len(found)} found, {len(notfound)} not found.")
        lines.append(f"• Arriving today: {len(arr_today)}"
                     + (": " + ", ".join(h["query"] for h in arr_today[:5])
                        if arr_today else ""))
        lines.append(f"• On hold: {len(holds)}"
                     + (": " + ", ".join(h["query"] for h in holds[:5])
                        if holds else ""))
        lines.append(f"• Completed / delivered: "
                     f"{len([h for h in found if _ast_completed(h)])}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 16) carrier ke hisab se ginti
    if any(k in ql for k in ("per carrier", "carrier wise",
                             "kis carrier", "by carrier")):
        from collections import Counter
        cc = Counter(h.get("carrier") or "Unknown" for h in hist)
        lines.append("Shipments by carrier:")
        for name, cnt in cc.most_common(10):
            lines.append(f"• {name}: {cnt}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 17) chhoti baatein
    if any(k in ql for k in ("thank", "shukriya", "great", "acha")):
        lines.append("You are welcome! Ask me anything else — "
                     "holds, arrivals, a report for any number, "
                     "or system health.")
        return {"answer": "\n".join(lines), "actions": acts}
    if any(k in ql for k in ("tum kon", "who are you", "tumhara naam",
                             "your name")):
        lines.append("I am the CargoTrack assistant — I live inside "
                     "this app, watch your shipments and answer from "
                     "your own data. Shezi (in your chat) is the one "
                     "who built me and can do everything beyond this "
                     "app.")
        return {"answer": "\n".join(lines), "actions": acts}

    # fallback — imandari se
    lines.append("That question needs the full AI, and it is not "
                 "answering right now (an internet hiccup or the "
                 "free limit) — my built-in answers only cover "
                 "this app and your shipments, so please ask "
                 "again in a little while.")
    lines.append("What I CAN do right now: holds, arrivals, "
                 "demurrage risk, payments, not-found help, OCR "
                 "status and a full system health report.")
    lines.append("Or tap below — your question will be copied, "
                 "paste it in your chat with Shezi and he will "
                 "answer it there.")
    acts.append({"label": "📋 Copy this question for Shezi",
                 "act": "copyq", "arg": q})
    return {"answer": "\n".join(lines), "actions": acts}


# OCR digit-confusion repair: Tesseract aksar 0 ko O, 1 ko I, 5 ko S
# parh deta hai — container ke digit hisse mein ye badal kar check
# digit dobara jaancha jata hai.
_OCR_DIG_FIX = str.maketrans({"O": "0", "Q": "0", "I": "1", "L": "1",
                              "S": "5", "B": "8", "Z": "2", "G": "6"})


def _iso_repair(tok):
    if len(tok) != 11 or not tok[:4].isalpha():
        return None
    fixed = tok[4:].translate(_OCR_DIG_FIX)
    if not fixed.isdigit():
        return None
    cand = tok[:4] + fixed
    return cand if _iso_ok(cand) else None


def re_extract_doc_numbers(text):
    """v46 Phase C — document se number nikaalne ka naya usool.

    Yousuf ka sikhaya huwa document order: pehle CONTAINER number,
    phir size (20'/40'), phir SEAL number — aksar baghair heading ke.
    Is liye:
    - Container sirf wahi jo ISO check-digit pass kare (ya OCR ki
      digit-ghalti theek karke pass ho jaye).
    - SEAL wali line ka number, aur container ke baad wali line par
      6-8 digit ka khaali number, kabhi BL nahi banta.
    - BL woh alphanumeric number hai jis ki pehchan ho (carrier
      prefix) ya jo ghar ka/house BL lagta ho; 9-10 khaali digits
      Maersk/COSCO ke BL ho sakte hain.
    - OCR aksar number ke beech space/dash daal deta hai — token
      unhein jor kar banta hai.
    """
    import re
    bls, cons, seals, others = [], [], [], []
    seen = set()

    def push(lst, v):
        if v and v not in seen:
            seen.add(v)
            lst.append(v)

    def classify(tok):
        """Ek saaf token ki (score, qism, value). Score: container 3,
        pehchana huwa BL 2, aam BL/other 1, fazool 0. Lambai 17 se
        zyada wali mili-juli satr kabhi number nahi hoti."""
        if len(tok) > 17 or not re.fullmatch(r"[A-Z0-9]+", tok):
            return 0, None, tok
        if re.fullmatch(r"[A-Z]{4}\d{7}", tok):
            if _iso_ok(tok):
                return 3, "container", tok
            rep = _iso_repair(tok)
            if rep:
                return 3, "container", rep
            return 1, "other", tok
        if tok.isdigit():
            if len(tok) in (9, 10):
                return 2, "bl", tok         # Maersk 9-digit / COSCO digits
            if len(tok) == 11:
                return 1, "other", tok      # phone-like — aakhri ummeed
            return 0, None, tok
        if len(tok) >= 9 and re.search(r"[A-Z]", tok) \
                and re.search(r"\d", tok):
            try:
                _pfx, cname = ENG.identify_carrier(tok)
            except Exception:
                cname = None
            return (2, "bl", tok) if cname else (1, "bl", tok)
        return 0, None, tok

    for line in (text or "").upper().splitlines():
        seal_line = "SEAL" in line
        groups = [g.strip(".,;:()") for g in line.split()]
        groups = [g for g in groups if g]
        if seal_line:
            # Seal wali line par jor nahi lagana — "SEAL NO PK123456"
            # ko ek bana kar ghalat value banti thi. Har hisse ko
            # alag seal samjho (label lafz chor kar).
            for g in groups:
                solo = ENG.norm(g)
                if len(solo) >= 5 and re.search(r"\d", solo) \
                        and solo not in ("SEAL", "SEALNO"):
                    push(seals, solo)
            continue
        line_has_container = False
        i = 0
        while i < len(groups):
            hit = None
            # OCR aksar ek hi number ko space se tor deta hai — 1, 2
            # aur 3 hisse jor kar jaancho aur sab se achi pehchan
            # (score) wala window pakro; barabar par lamba window
            # (poora number) jeet-ta hai.
            best = (0, 0, None, None)       # score, w, kind, val
            # Size/type code (40HC, 20GP...) se shuru hone wala hissa
            # kisi number ka aaghaz nahi hota — use jor ka hisa na banao.
            size_first = re.fullmatch(r"(20|40|45)(GP|HC|HQ|RF|DC|DV|OT|FR)?",
                                      ENG.norm(groups[i]))
            for w in (1, 2, 3):
                if size_first:
                    break
                if i + w > len(groups):
                    continue
                joined = ENG.norm("".join(groups[i:i + w]))
                if len(joined) < 6:
                    continue
                sc, kind, val = classify(joined)
                if w >= 2 and sc < 2:
                    continue  # jor kar sirf pakki pehchan chalegi — "WEIGHT 24500" jaisi aam satr BL nahi banti
                if sc > best[0] or (sc == best[0] and sc > 0 and w > best[1]):
                    best = (sc, w, kind, val)
            if best[0] > 0:
                hit = (best[1], best[2], best[3])
            if hit:
                w, kind, val = hit
                if seal_line:
                    push(seals, val)
                elif kind == "container":
                    push(cons, val)
                    line_has_container = True
                elif kind == "bl":
                    push(bls, val)
                else:
                    push(others, val)
                i += w
                continue
            # kuch pehchana nahi gaya: 6-8 digit ka khaali number
            # container wali line par seal hota hai, warna rehne do.
            solo = ENG.norm(groups[i])
            if solo.isdigit() and 6 <= len(solo) <= 8 and line_has_container:
                push(seals, solo)
            elif seal_line and len(solo) >= 5:
                push(seals, solo)
            i += 1
    numbers = bls + cons + others
    return {"numbers": numbers[:12], "bls": bls,
            "containers": cons, "seals": seals}


def re_find_numbers(text):
    return re_extract_doc_numbers(text)["numbers"]


def main():
    threading.Thread(target=_recheck_loop, daemon=True).start()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    print(f"CargoTrack v51 is running: http://127.0.0.1:{PORT}")
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        print(f"On your phone (same WiFi): http://{s.getsockname()[0]}:{PORT}")
        s.close()
    except Exception:
        pass
    print("To stop CargoTrack, close this window.")
    try:
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
