#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CargoTrack v48 — Web UI server (stdlib only).
Tracking engine: bl_track.py. Data lives outside the app folder:
  ~/CargoTrack_Data/history.json + settings.json
Run:  python server.py   (your browser opens automatically)
"""
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shutil
import sys
import threading
import time
import zipfile
from datetime import datetime, date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bl_track as ENG

DATA_DIR = Path.home() / "CargoTrack_Data"
DATA_DIR.mkdir(exist_ok=True)
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
PHOTOS_DIR = DATA_DIR / "photos"
PHOTOS_DIR.mkdir(exist_ok=True)
PORT = 8765

_lock = threading.Lock()


def load_json(p, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(p, obj):
    # F-05 fix (v46 audit): write to a temp file, then atomically
    # replace — a crash/power-cut mid-write used to corrupt the file,
    # and load_json then silently returned empty (whole history lost).
    try:
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        os.replace(tmp, p)
        return True
    except Exception:
        return False


APP_DIR = Path(__file__).resolve().parent


def _apply_seed_once():
    """v44 FINAL one-time seed: replace history with the verified 78-BL
    record shipped beside server.py. The old history is first copied to a
    dated backup in the data dir; a marker stops any re-application."""
    seed = APP_DIR / "seed_history.json"
    marker = DATA_DIR / "seed_v44final.done"
    try:
        if seed.exists() and not marker.exists():
            data = load_json(seed, None)
            if isinstance(data, list) and data:
                if HISTORY_FILE.exists():
                    bak = DATA_DIR / "history_backup_2026-10-22.json"
                    if not bak.exists():
                        bak.write_bytes(HISTORY_FILE.read_bytes())
                if save_json(HISTORY_FILE, data):
                    marker.write_text("done", encoding="utf-8")
                    seed.unlink()
    except Exception:
        pass


_apply_seed_once()


def get_history():
    h = load_json(HISTORY_FILE, [])
    if not isinstance(h, list):
        return []
    return [_migrate_entry(x) for x in h]


def _tesseract_path():
    """Tesseract ka rasta: pehle PATH, phir aam install jaghein.
    Windows installer aksar PATH mein nahi jorta, is liye sirf
    PATH dekhna 'install nahi hai' ka jhoota jawab deta tha."""
    w = shutil.which("tesseract")
    if w:
        return w
    cands = []
    if os.name == "nt":
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pfx = os.environ.get("ProgramFiles(x86)",
                               r"C:\Program Files (x86)")
        lad = os.environ.get("LOCALAPPDATA", "")
        cands = [os.path.join(pf, "Tesseract-OCR", "tesseract.exe"),
                 os.path.join(pfx, "Tesseract-OCR", "tesseract.exe"),
                 os.path.join(lad, "Programs", "Tesseract-OCR",
                              "tesseract.exe"),
                 os.path.join(lad, "Tesseract-OCR", "tesseract.exe")]
    else:
        cands = ["/usr/bin/tesseract", "/usr/local/bin/tesseract",
                 "/opt/homebrew/bin/tesseract"]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return None


def _public_settings():
    s = dict(get_settings())
    s["ai_key_set"] = bool(str(s.get("ai_key") or "").strip())
    s.pop("ai_key", None)
    # v48: the password hash itself never leaves the server — only a flag.
    s["app_pass_set"] = bool(str(s.get("app_pass") or "").strip())
    s.pop("app_pass", None)
    return s


def get_settings():
    s = load_json(SETTINGS_FILE, {})
    return s if isinstance(s, dict) else {}


# ---------------- app lock + sessions (v48) ----------------
# The password is stored ONLY as a salted hash in settings.json
# ("app_pass" = salt_hex$sha256_hex, sha256 of salt+password).
# No app_pass -> the app is UNLOCKED (first-run mode, old behaviour).
# Browser sessions live in sessions.json, keyed by sha256(token);
# the raw token only ever exists in the browser's HttpOnly cookie.

def _app_pass_hash():
    return str(get_settings().get("app_pass") or "").strip()


def _make_pass_hash(pw):
    salt = secrets.token_bytes(16)
    digest = hashlib.sha256(salt + pw.encode("utf-8")).hexdigest()
    return salt.hex() + "$" + digest


def _verify_pass(pw, stored):
    try:
        salt_hex, digest = stored.split("$", 1)
        cand = hashlib.sha256(
            bytes.fromhex(salt_hex) + pw.encode("utf-8")).hexdigest()
        return hmac.compare_digest(cand, digest)
    except Exception:
        return False


def _load_sessions():
    d = load_json(SESSIONS_FILE, {})
    if not isinstance(d, dict):
        d = {}
    if not isinstance(d.get("sessions"), dict):
        d["sessions"] = {}
    if not isinstance(d.get("attempts"), list):
        d["attempts"] = []
    return d


def _save_sessions(d):
    return save_json(SESSIONS_FILE, d)


def device_label(ua):
    """Friendly device label from a User-Agent string."""
    ua = ua or ""
    if "Edg/" in ua:
        browser = "Edge"
    elif "OPR/" in ua or "Opera" in ua:
        browser = "Opera"
    elif "Firefox/" in ua:
        browser = "Firefox"
    elif "CriOS" in ua or "Chrome/" in ua:
        browser = "Chrome"
    elif "Safari/" in ua:
        browser = "Safari"
    else:
        browser = "Browser"
    if "iPhone" in ua:
        osname = "iPhone"
    elif "iPad" in ua:
        osname = "iPad"
    elif "Android" in ua:
        osname = "Android"
    elif "Windows" in ua:
        osname = "Windows"
    elif "Mac OS" in ua or "Macintosh" in ua:
        osname = "Mac"
    elif "Linux" in ua:
        osname = "Linux"
    else:
        osname = ""
    return f"{browser} on {osname}" if osname else browser


def _create_session(ua, ip):
    """Create a session; returns the raw token (for the cookie)."""
    token = secrets.token_urlsafe(32)
    th = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = time.time()
    with _lock:
        d = _load_sessions()
        d["sessions"][th] = {"created": now, "last_seen": now,
                             "ua": ua, "ip": ip}
        if len(d["sessions"]) > 20:  # cap: drop the oldest
            by_age = sorted(d["sessions"].items(),
                            key=lambda kv: kv[1].get("created", 0))
            for k, _v in by_age[:len(by_age) - 20]:
                d["sessions"].pop(k, None)
        _save_sessions(d)
    return token


def _record_attempt(ip, ua, ok):
    with _lock:
        d = _load_sessions()
        d["attempts"].append({"ts": time.time(), "ip": ip,
                              "ua": ua, "ok": bool(ok)})
        d["attempts"] = d["attempts"][-50:]  # keep only the last 50
        _save_sessions(d)


_SESS_SEEN = {}     # token_hash -> last_seen ts (in memory, freshest)
_SESS_WRITTEN = {}  # token_hash -> ts of last sessions.json write


def _touch_session(th, ua, ip):
    """Update a session's last_seen; the disk write is throttled to
    at most once per 60 seconds per session to avoid churn."""
    now = time.time()
    _SESS_SEEN[th] = now
    if now - _SESS_WRITTEN.get(th, 0) <= 60:
        return
    with _lock:
        d = _load_sessions()
        s = d["sessions"].get(th)
        if not s:
            return
        s["last_seen"] = now
        s["ua"] = ua
        s["ip"] = ip
        if _save_sessions(d):
            _SESS_WRITTEN[th] = now


def _sess_cookie(token):
    return (f"ct_sess={token}; HttpOnly; Path=/; "
            f"Max-Age=7776000; SameSite=Lax")


_SESS_COOKIE_CLEAR = "ct_sess=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax"

LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CargoTrack — Locked</title>
<style>
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;display:flex;align-items:center;
    justify-content:center;background:#12121E;color:#ECECF4;
    font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
    padding:20px}
  .card{background:#1E1E30;border:1px solid #2F2F47;border-radius:20px;
    padding:34px 30px;width:100%;max-width:380px;text-align:center;
    box-shadow:0 24px 60px rgba(0,0,0,.5)}
  .card img{width:84px;height:84px;object-fit:contain;border-radius:18px}
  h1{margin:14px 0 2px;font-size:26px;letter-spacing:.3px;
    background:linear-gradient(90deg,#A78BFA,#F472B6);
    -webkit-background-clip:text;background-clip:text;color:transparent}
  .sub{color:#A8A8BE;font-size:14px;margin:0 0 22px}
  input{width:100%;padding:13px 14px;border-radius:12px;font-size:16px;
    border:2px solid #2F2F47;background:#12121E;color:#ECECF4;outline:none}
  input:focus{border-color:#7C3AED}
  button{width:100%;margin-top:14px;padding:13px;border:0;border-radius:12px;
    font-size:16px;font-weight:700;color:#fff;cursor:pointer;
    background:linear-gradient(90deg,#7C3AED,#DB2777)}
  button:active{transform:scale(.99)}
  #err{display:none;color:#F87171;font-size:14px;margin-top:14px}
  .lock{font-size:15px;color:#A8A8BE;margin-top:18px}
</style></head><body>
  <div class="card">
    <img src="/logos/ct-logo.png" alt="CargoTrack"
      onerror="this.style.display='none'">
    <h1>CargoTrack</h1>
    <p class="sub">This app is locked. Enter your password to open it.</p>
    <form id="lf" autocomplete="off">
      <input id="pw" type="password" placeholder="Password"
        autocomplete="current-password" autofocus>
      <button type="submit">Open app</button>
    </form>
    <div id="err"></div>
    <div class="lock">🔐 Only browsers you sign in on can use this app.</div>
  </div>
<script>
  document.getElementById("lf").addEventListener("submit", async e => {
    e.preventDefault();
    const err = document.getElementById("err");
    err.style.display = "none";
    try {
      const r = await fetch("/api/login", {method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({password:
          document.getElementById("pw").value})});
      if (r.ok) { location.href = "/"; return; }
      const j = await r.json().catch(() => ({}));
      err.textContent = j.error === "wrong password"
        ? "Wrong password — please try again."
        : ("Could not sign in: " + (j.error || r.status));
      err.style.display = "block";
    } catch (ex) {
      err.textContent = "Could not reach the server.";
      err.style.display = "block";
    }
  });
</script>
</body></html>"""


# ---------------- tracking jobs (live layer progress) ----------------
JOBS = {}


def _run_job(job_id, items, mode, carrier_manual, client):
    job = JOBS[job_id]
    results = []
    for item in items:
        events = []

        def cb(name, status, detail=""):
            events.append({"name": name, "status": status, "detail": detail})
            job["events"] = list(events)
            job["current"] = item

        try:
            res = ENG.track_all(
                bl=item if mode == "bl" else None,
                ctn=item if mode == "container" else None,
                vessel_name=item if mode == "vessel" else None,
                progress_cb=cb,
                carrier_hint=carrier_manual)
        except Exception as e:
            res = {"carrier": None, "prefix": "", "result": {}, "layers": [],
                   "contacts": None}
            events.append({"name": "Error", "status": "fail", "detail": str(e)})
        if carrier_manual:
            res["carrier"] = carrier_manual
        ctx = {"query": item, "mode": mode, "client": client,
               "carrier": res.get("carrier"), "prefix": res.get("prefix"),
               "result": res.get("result", {}), "layers": res.get("layers", []),
               "contacts": res.get("contacts"),
               "found": bool(res.get("result")),
               "time": datetime.now().strftime("%d/%m %H:%M")}
        try:
            _record(ctx)
        except Exception:
            # F-04 fix (v46 audit): a bad history entry must never kill
            # the job thread — the UI polls until job["done"] is set and
            # would otherwise spin forever with the Track button dead.
            pass
        results.append(ctx)
        job["results"] = list(results)
    job["done"] = True


_PLACEHOLDERS = {"", "/", "—", "-", "N/A", "NA", "None", "null"}
_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun",
     "jul", "aug", "sep", "oct", "nov", "dec"])}


def _real(v):
    """True when a value is real data, not an empty placeholder."""
    if v is None:
        return False
    if isinstance(v, str):
        return v.strip() not in _PLACEHOLDERS
    if isinstance(v, (list, dict)):
        return len(v) > 0
    return True


def _pdate(s):
    """Best-effort date parse for the formats our sources produce."""
    if not s:
        return None
    t = str(s).strip().lower()
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            return None
    m = re.search(r"(\d{1,2})[\s\-]([a-z]{3,9})[\s\-,]+(\d{2,4})", t)
    if m and m.group(2)[:3] in _MONTHS:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        try:
            return date(y, _MONTHS[m.group(2)[:3]], int(m.group(1)))
        except Exception:
            return None
    m = re.search(r"([a-z]{3,9})\s+(\d{1,2})", t)
    if m and m.group(1)[:3] in _MONTHS:
        try:
            return date(date.today().year, _MONTHS[m.group(1)[:3]],
                        int(m.group(2)))
        except Exception:
            return None
    return None


def _merge_result(old_r, new_r):
    """Merge a fresh tracking result into the stored one.

    A weaker new result must never erase data we already know:
    every field keeps the new value when it is real, otherwise the
    old value survives. Containers are unioned."""
    old_r = old_r or {}
    new_r = new_r or {}
    merged = {}
    for k in set(old_r) | set(new_r):
        nv, ov = new_r.get(k), old_r.get(k)
        if k == "containers":
            seen, out_c = set(), []
            for c in list(nv or []) + list(ov or []):
                if _real(c) and c not in seen:
                    seen.add(c)
                    out_c.append(c)
            if out_c:
                merged[k] = out_c
            continue
        if _real(nv):
            merged[k] = nv
        elif _real(ov):
            merged[k] = ov
    # A stored ETA later than the discharge date is a vessel-schedule
    # artifact, not the shipment's ETA — drop it for completed cargo.
    # The combined label "KICT/SAPT" is never a valid terminal name:
    # drop it, and repair any stored status that contains it.
    if merged.get("terminal") == "KICT/SAPT":
        merged.pop("terminal", None)
    _st = merged.get("status") or ""
    if "KICT/SAPT" in _st:
        if merged.get("terminal"):
            merged["status"] = _st.replace("KICT/SAPT",
                                             merged["terminal"])
        else:
            merged["status"] = "Arrived at Karachi terminal"
    dis = _pdate(merged.get("discharge_time"))
    eta = _pdate(merged.get("eta"))
    st = (merged.get("status") or "").lower()
    if dis and eta and eta > dis and any(
            w in st for w in ("discharg", "released", "delivered",
                              "gate out", "hold")):
        merged.pop("eta", None)
    return merged


_OLD_LAYER_NAMES = {
    "Layer 0 — Carrier pehchano": "Layer 0 — Carrier identification",
    "Layer 3 — Karachi Terminals (KICT/SAPT)": "Layer 3 — Karachi Terminal",
}
_OLD_TOKENS = ("nahi", "karo", "mila", "rabta", "khulti", "maroof",
               "Neeche", "pehchano", "Namaloom", "ghalat", "sakta")


def _fix_old_detail(d):
    """Translate or clear Roman-Urdu layer details stored by old
    versions, so they never surface in the current app."""
    if "allow nahi karta" in d:
        return ("Automated tracking is not allowed by this carrier "
                "(bot protection).")
    m = re.search(r"KICT/SAPT par (\d+) container", d)
    if m:
        return f"{m.group(1)} container(s) at Karachi terminal"
    if "rabta nahi ho saka" in d:
        return "The source could not be reached on that check."
    if any(t in d for t in _OLD_TOKENS):
        return ""
    return d


def _migrate_entry(h):
    """Bring a stored history entry up to current standards: clean
    result (no combined terminal label, no placeholders), English
    carrier name, English layer names and details."""
    if not isinstance(h, dict):
        return h
    r = h.get("result")
    if isinstance(r, dict) and r:
        h["result"] = _merge_result(r, {})
    if h.get("carrier"):
        h["carrier"] = h["carrier"].replace(" (unverified)", "")
    for lay in h.get("layers") or []:
        if lay.get("name") in _OLD_LAYER_NAMES:
            lay["name"] = _OLD_LAYER_NAMES[lay["name"]]
        if lay.get("detail"):
            lay["detail"] = _fix_old_detail(lay["detail"])
    return h



def _fmt_disch(s):
    """'06-OCT-2026 22:34' / '06-OCT-26 08:48' -> '6 Oct 2026'."""
    m = re.match(r"\s*(\d{1,2})-([A-Za-z]{3})-(\d{2,4})", s or "")
    if not m:
        return s or ""
    y = m.group(3)
    if len(y) == 2:
        y = "20" + y
    return f"{int(m.group(1))} {m.group(2).title()} {y}"


def _eta_cell(r):
    """Report cell: the ETA while a shipment is on the way; once it
    has arrived, the date that matters is the discharge date (QICT
    and the Karachi terminals publish no ETA at all)."""
    if r.get("eta"):
        return _esc(r["eta"])
    if r.get("discharge_time"):
        return "Discharged " + _esc(_fmt_disch(r["discharge_time"]))
    return "—"

def _record(ctx):
    """History mein save (purani entry ki checklist/notes mehfooz).

    Freshness honesty (v41 audit): checked_ts/time are only stamped
    when this check actually returned data — or when there was no
    earlier found record to protect. A refresh whose sources all
    failed must never make old data look freshly checked."""
    got_new = bool(ctx.get("result"))
    with _lock:
        hist = get_history()
        old = next((h for h in hist if h.get("query") == ctx["query"]), None)
        if old and old.get("found") and not got_new:
            ctx["time"] = old.get("time", ctx.get("time", ""))
            ctx["checked_ts"] = old.get("checked_ts")
        else:
            ctx["checked_ts"] = time.time()
        if old:
            ctx["result"] = _merge_result(old.get("result"),
                                           ctx.get("result"))
            if not ctx.get("carrier"):
                ctx["carrier"] = old.get("carrier")
            if ctx.get("carrier"):
                ctx["carrier"] = ctx["carrier"].replace(
                    " (unverified)", "")
            if old.get("found") and ctx["result"]:
                ctx["found"] = True
            ctx["checklist"] = old.get("checklist", {})
            ctx["notes"] = old.get("notes", "")
            ctx["first_seen"] = old.get("first_seen", date.today().isoformat())
            ctx["photo"] = old.get("photo", "")
            for f in ("client", "amount", "received"):
                if not ctx.get(f):
                    ctx[f] = old.get(f, "")
            ctx["returned"] = bool(old.get("returned", False))
            ctx["starred"] = bool(old.get("starred", False))
            old_r = old.get("result") or {}
            new_r = ctx.get("result") or {}
            old_status = old_r.get("status") or ""
            new_status = new_r.get("status") or ""
            old_pos = old_r.get("position") or ""
            new_pos = new_r.get("position") or ""
            # Badlav ki QISAM pehchano (v41) — taake user ke
            # apne alert usool (idea 22) faisla kar sakein ke
            # is badlav par ghanti bajni hai ya khamoshi se
            # sirf record ho jana hai.
            rules = get_settings().get("alert_rules") or {}
            kind = None
            chg = None
            if (not old_r.get("discharge_time")
                    and new_r.get("discharge_time")):
                kind = "discharge"
                chg = {"time": ctx.get("time", ""),
                       "from": "Not discharged",
                       "to": "Discharged " + str(new_r["discharge_time"])}
            elif (new_r.get("holds") or "") != (old_r.get("holds") or "") \
                    and new_r.get("holds"):
                kind = "hold"
                chg = {"time": ctx.get("time", ""),
                       "from": old_r.get("holds") or "No hold",
                       "to": "Hold: " + str(new_r["holds"])}
            elif (not _status_final(old_r)) and _status_final(new_r):
                kind = "delivered"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status or "In progress",
                       "to": new_status or "Delivered"}
            elif old_status and new_status and old_status != new_status:
                kind = "status"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status, "to": new_status}
            elif (old_r.get("eta") and new_r.get("eta")
                    and old_r["eta"] != new_r["eta"]):
                kind = "eta"
                chg = {"time": ctx.get("time", ""),
                       "from": "ETA " + str(old_r["eta"]),
                       "to": "ETA " + str(new_r["eta"])}
            elif old_pos and new_pos and old_pos != new_pos:
                kind = "position"
                chg = {"time": ctx.get("time", ""),
                       "from": f"Position: {old_pos}",
                       "to": f"Position: {new_pos}"}
            changes = old.get("changes") or []
            if chg:
                changes = ([chg] + changes)[:5]
                ctx["change_kind"] = kind
                # Usool band ho to badlav record ho jaye lekin
                # ghanti na baje (purani ghanti bhi na bujhe).
                ctx["changed"] = (True if rules.get(kind, True)
                                  else bool(old.get("changed")))
            else:
                ctx["change_kind"] = old.get("change_kind")
                ctx["changed"] = bool(old.get("changed"))
            ctx["changes"] = changes
            hist = [h for h in hist if h.get("query") != ctx["query"]]
        else:
            ctx["checklist"] = {}
            ctx["notes"] = ""
            ctx["first_seen"] = date.today().isoformat()
            ctx["changes"] = []
            ctx["changed"] = False
            ctx["returned"] = False
            ctx["starred"] = False
        hist.insert(0, ctx)
        save_json(HISTORY_FILE, hist[:1000])  # F-11: was a silent 300-entry cap


# ---------------- reports (Tk app wale hi generators, web version) -------
def _esc(s):
    return (str(s or "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")



_REPORT_BRANDS = [
    ("maersk", "M", "#2B7FB8"), ("msc", "MSC", "#111111"),
    ("mediterranean", "MSC", "#111111"), ("cosco", "CO", "#00529B"),
    ("oocl", "OO", "#007A3D"), ("cma", "CMA", "#1B2A6B"),
    ("evergreen", "EG", "#006B54"), ("hapag", "HL", "#D14D00"),
    ("ocean network", "ONE", "#B00062"), ("yang ming", "YM", "#AE0F27"),
    ("wan hai", "WH", "#003E73"), ("zim", "ZIM", "#3E1D63"),
    ("emkay", "EM", "#083D6B"), ("rtw", "RTW", "#4C1D95"),
    ("em-a", "EMA", "#92400E"), ("ema", "EMA", "#92400E"),
    ("kict", "KICT", "#115E59"), ("sapt", "SAPT", "#0A5356"),
    ("qict", "QICT", "#172554"), ("pict", "PICT", "#334155"),
]
_REPORT_LOGOS = [
    ("maersk", "maersk.svg"), ("mediterranean", "msc.svg"),
    ("msc", "msc.svg"), ("cosco", "cosco.svg"), ("oocl", "oocl.svg"),
    ("cma", "cma.svg"), ("evergreen", "evergreen.svg"),
    ("hapag", "hapag.svg"), ("ocean network", "one.svg"),
    ("yang ming", "yangming.png"), ("wan hai", "wanhai.png"),
    ("zim", "zim.svg"), ("emkay", "emkay.png"), ("rtw", "rtw.png"),
    ("hyundai", "hmm.svg"), ("hmm", "hmm.svg"),
    ("pacific international", "pil.svg"), ("em-a", "ema.webp"),
    ("kict", "kict.png"), ("sapt", "sapt.png"), ("qict", "qict.png"),
    ("dp world", "qict.png"), ("star lines", "starlines.png"),
    ("baltic", "baltic.png"), ("new golden", "newgoldensea.png"),
]
_REPORT_PALETTE = ["#475569", "#0E7490", "#7C3AED", "#B45309",
                   "#15803D", "#1D4ED8", "#BE185D", "#0F766E"]

def full_report_html(hist):
    _co = (get_settings().get("company_name") or "").strip()
    _co_tag = (get_settings().get("company_tagline") or "").strip()

    def badge(name):
        n = (name or "").lower()
        for key, mono, col in _REPORT_BRANDS:
            if key in n:
                return (f'<span style="display:inline-block;min-width:30px;'
                        f'text-align:center;background:{col};color:#fff;'
                        f'font-weight:700;font-size:10.5px;border-radius:7px;'
                        f'padding:4px 6px;margin-right:7px">{mono}</span>')
        words = [w for w in re.split(r"[^A-Za-z]+", name or "") if w]
        mono = ((words[0][0] if words else "C")
                + (words[1][0] if len(words) > 1 else "")).upper()
        col = _REPORT_PALETTE[abs(hash(name or "?")) % len(_REPORT_PALETTE)]
        return (f'<span style="display:inline-block;min-width:30px;'
                f'text-align:center;background:{col};color:#fff;'
                f'font-weight:700;font-size:10.5px;border-radius:7px;'
                f'padding:4px 6px;margin-right:7px">{mono}</span>')

    def logo_html(name):
        n = (name or "").lower()
        for key, f in _REPORT_LOGOS:
            if key in n:
                return (f'<img src="/logos/{f}" alt="" style="width:92px;'
                        f'height:26px;object-fit:contain;'
                        f'vertical-align:middle;margin-right:8px">')
        return badge(name)

    def row(h):
        r = h.get("result") or {}
        ok = h.get("found")
        carrier = (h.get("carrier") or "—").replace(" (unverified)", "")
        vessel = r.get("vessel") or "—"
        if r.get("voyage"):
            vessel += f" ({r['voyage']})"
        ctns = ", ".join(r.get("containers") or [])
        return (f"<tr><td>{_esc(h.get('time',''))}</td>"
                f"<td><b>{_esc(h.get('query',''))}</b></td>"
                f"<td>{logo_html(h.get('carrier'))}{_esc(carrier)}</td>"
                f"<td>{_esc(vessel)}</td>"
                f"<td>{_esc(ctns or '—')}</td>"
                f"<td>{_esc(r.get('eta') or '—')}</td>"
                f"<td>{_esc(_fmt_disch(r.get('discharge_time')) or '—')}</td>"
                f"<td>{_esc(r.get('terminal') or '—')}</td>"
                f"<td>{_esc(r.get('position') or '—')}</td>"
                f"<td>{_esc(r.get('status') or '—')}</td>"
                f"<td>{'✅' if ok else '❌'}</td></tr>")
    found = [h for h in hist if h.get("found")]
    notf = [h for h in hist if not h.get("found")]
    th = ("<tr><th>Time</th><th>BL / Query</th><th>Carrier</th><th>Vessel</th>"
          "<th>Containers</th><th>ETA</th><th>Discharged</th><th>Terminal</th>"
          "<th>Position</th><th>Status</th><th></th></tr>")
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>CargoTrack — Full Tracking Report</title><style>
body{{font-family:'Segoe UI',Arial,sans-serif;margin:32px;color:#1F2937}}
h1{{color:#5B21B6}} h2{{margin-top:28px}} table{{border-collapse:collapse;width:100%}}
th{{background:#EDE9FE;color:#5B21B6;text-align:left;padding:8px}}
td{{border-bottom:1px solid #E5E7EB;padding:8px;vertical-align:middle}} .muted{{color:#6B7280}}
@media print{{body{{margin:10px}}}}</style></head><body>
<h1>◆ {_esc(_co) + " — " if _co else ""}CargoTrack — Full Tracking Report</h1>{f'<p style="color:#6B7280;margin:2px 0 0">{_esc(_co_tag)}</p>' if _co_tag else ""}
<p class="muted">Generated {datetime.now().strftime('%d %b %Y, %H:%M')}</p>
<h2>✅ Found ({len(found)})</h2><table>{th}{''.join(row(h) for h in found)}</table>
<h2>❌ Not found ({len(notf)})</h2><table>{th}{''.join(row(h) for h in notf)}</table>
<p class="muted">Tip: Print → Save as PDF to keep a copy.</p></body></html>"""


# ---------------- auto re-check ----------------
def _status_final(result):
    r = result or {}
    st = (r.get("status") or "").lower()
    return bool(r.get("gate_out")) or "deliver" in st


def _entry_due(h, now_ts, hrs):
    """Is entry ko dobara track karna chahiye ya nahi?"""
    ts = h.get("checked_ts")
    age = (now_ts - float(ts)) if ts else None
    if _status_final(h.get("result")):
        return False
    mult = 0.5 if h.get("starred") else 1.0
    if not h.get("found"):
        # Not-found entries bhi kabhi kabhi dobara dekho (BL baad
        # mein system mein aa sakta hai) — lekin 4 guna dheere.
        return age is None or age >= hrs * 4 * 3600 * mult
    return age is None or age >= hrs * 3600 * mult


def _recheck_loop():
    time.sleep(120)  # pehli jaanch start ke ~2 minute baad
    while True:
        try:
            hrs = float(get_settings().get("recheck_hours", 6) or 6)
        except Exception:
            hrs = 6
        try:
            now_ts = time.time()
            due = [h for h in get_history()
                   if h.get("query") and _entry_due(h, now_ts, hrs)]
            due.sort(key=lambda h: (0 if h.get("starred") else 1,
                                    float(h.get("checked_ts") or 0)))
            for h in due[:4]:
                mode = h.get("mode", "bl")
                try:
                    res = ENG.track_all(
                        bl=h["query"] if mode == "bl" else None,
                        ctn=h["query"] if mode == "container" else None,
                        vessel_name=h["query"] if mode == "vessel" else None,
                        carrier_hint=h.get("carrier") or None)
                except Exception:
                    continue
                ctx = {"query": h["query"], "mode": mode,
                       "client": h.get("client", ""),
                       "carrier": res.get("carrier"),
                       "prefix": res.get("prefix"),
                       "result": res.get("result", {}),
                       "layers": res.get("layers", []),
                       "contacts": res.get("contacts"),
                       "found": bool(res.get("result")),
                       "time": datetime.now().strftime("%d/%m %H:%M")}
                try:
                    _record(ctx)
                except Exception:
                    continue
        except Exception:
            pass
        time.sleep(1200)  # agli jaanch 20 minute baad


# ---------------- HTTP ----------------
MIME = {".html": "text/html; charset=utf-8", ".png": "image/png",
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml",
        ".webp": "image/webp",
        ".json": "application/json; charset=utf-8"}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8",
              headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            n = 0  # F-15: a malformed header must not kill the handler
        n = max(0, min(n, 32 * 1024 * 1024))
        raw = self.rfile.read(n) if n else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    # ---- v48 auth helpers ----
    def _cookie_token(self):
        raw = self.headers.get("Cookie") or ""
        for part in raw.split(";"):
            part = part.strip()
            if part.startswith("ct_sess="):
                return part[len("ct_sess="):]
        return ""

    def _client_ip(self):
        try:
            return self.client_address[0]
        except Exception:
            return ""

    def _auth_state(self):
        """None = locked out; "unlocked" = no password set;
        otherwise the caller's session token-hash. Also touches the
        session's last_seen (throttled inside _touch_session)."""
        if not _app_pass_hash():
            return "unlocked"
        tok = self._cookie_token()
        if not tok:
            return None
        th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
        with _lock:
            known = th in _load_sessions()["sessions"]
        if not known:
            return None
        _touch_session(th, self.headers.get("User-Agent") or "",
                       self._client_ip())
        return th

    def _locked_out(self, p):
        """True (and a denial response already sent) when this request
        must not proceed. The denial is a 401 JSON — the client turns
        a 401 on its data calls into a full reload, and the server
        then serves the login page for GET /."""
        self._send(401, {"error": "locked"})
        return True

    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        # v48: the app logo stays public — the login page shows it.
        if p == "/logos/ct-logo.png":
            f = BASE / "logos" / "ct-logo.png"
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME[".png"])
            return self._send(404, {"error": "no logo"})
        auth = self._auth_state()
        if p == "/" or p == "/index.html":
            if auth is None:
                # locked and not signed in -> the login page
                return self._send(200, LOGIN_HTML, MIME[".html"])
            f = BASE / "static" / "index.html"
            return self._send(200, f.read_bytes(), MIME[".html"])
        if auth is None:
            return self._locked_out(p)
        if p == "/api/sessions":
            d = _load_sessions()
            sess = []
            for th, s in sorted(
                    d["sessions"].items(),
                    key=lambda kv: kv[1].get("created", 0), reverse=True):
                sess.append({
                    "id": th[:10],
                    "device": device_label(s.get("ua", "")),
                    "ua": s.get("ua", ""),
                    "ip": s.get("ip", ""),
                    "created": s.get("created"),
                    "last_seen": max(float(s.get("last_seen") or 0),
                                     _SESS_SEEN.get(th, 0)),
                    "current": th == auth})
            atts = [{"ts": a.get("ts"), "ip": a.get("ip", ""),
                     "device": device_label(a.get("ua", "")),
                     "ok": bool(a.get("ok"))}
                    for a in d["attempts"][-15:]][::-1]
            return self._send(200, {
                "locked": bool(_app_pass_hash()),
                "count": len(sess), "sessions": sess, "attempts": atts})
        if p == "/demo.html":
            f = BASE / "static" / "demo.html"
            if f.exists():
                return self._send(200, f.read_bytes(), MIME[".html"])
            return self._send(404, {"error": "no demo"})
        if p.startswith("/logos/"):
            f = (BASE / "logos" / Path(p).name)
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME.get(f.suffix, "image/png"))
            return self._send(404, {"error": "no logo"})
        if p.startswith("/photos/"):
            f = (PHOTOS_DIR / Path(p).name)
            if f.is_file():  # F-16: ".." resolved to the dir itself and crashed read_bytes
                return self._send(200, f.read_bytes(),
                                  MIME.get(f.suffix.lower(), "image/jpeg"))
            return self._send(404, {"error": "no photo"})
        if p == "/api/history":
            return self._send(200, {"history": get_history(),
                                    "settings": _public_settings(),
                                    "carriers": sorted(set(ENG.CARRIERS.values()))})
        if p == "/api/job":
            jid = (parse_qs(u.query).get("id") or [""])[0]
            job = JOBS.get(jid)
            if not job:
                return self._send(404, {"error": "job not found"})
            return self._send(200, {"done": job["done"], "current": job["current"],
                                    "events": job["events"],
                                    "results": job["results"]})
        if p == "/api/report/full":
            return self._send(200, full_report_html(get_history()), MIME[".html"])
        if p == "/api/backup":
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                if HISTORY_FILE.exists():
                    z.write(HISTORY_FILE, HISTORY_FILE.name)
                if SETTINGS_FILE.exists():
                    # F-13 fix (v46 audit): the backup used to ship the
                    # plaintext AI key to anyone on the LAN who asked.
                    # The key is stripped from the backup copy; it can
                    # be re-entered in Settings after a restore.
                    safe = {k: v for k, v in load_json(SETTINGS_FILE, {}).items()
                            if k not in ("ai_key", "app_pass")}
                    z.writestr(SETTINGS_FILE.name,
                               json.dumps(safe, ensure_ascii=False, indent=1))
                if PHOTOS_DIR.exists():
                    for pf in sorted(PHOTOS_DIR.iterdir()):
                        if pf.is_file():
                            z.write(pf, f"photos/{pf.name}")
            data = buf.getvalue()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition",
                             'attachment; filename="cargotrack_backup.zip"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        p = u.path
        if p == "/api/login":
            # the only API route open while locked — it IS the key.
            b = self._body()
            stored = _app_pass_hash()
            if not stored:
                return self._send(400, {"error": "no password set"})
            ua = self.headers.get("User-Agent") or ""
            ip = self._client_ip()
            if not _verify_pass(str(b.get("password") or ""), stored):
                _record_attempt(ip, ua, False)
                return self._send(401, {"error": "wrong password"})
            _record_attempt(ip, ua, True)
            token = _create_session(ua, ip)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _sess_cookie(token))])
        auth = self._auth_state()
        if auth is None:
            return self._locked_out(p)
        b = self._body()
        if p == "/api/logout":
            tok = self._cookie_token()
            if tok:
                th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
                with _lock:
                    d = _load_sessions()
                    d["sessions"].pop(th, None)
                    _save_sessions(d)
                _SESS_SEEN.pop(th, None)
                _SESS_WRITTEN.pop(th, None)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/password":
            new = str(b.get("new") or "")
            if len(new) < 6:
                return self._send(400, {
                    "error": "Password must be at least 6 characters"})
            stored = _app_pass_hash()
            if stored and not _verify_pass(str(b.get("current") or ""),
                                           stored):
                return self._send(401, {"error": "wrong password"})
            s = get_settings()
            s["app_pass"] = _make_pass_hash(new)
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            if not stored:
                # First password ever: sign this browser in right away
                # so the owner is not locked out of his own app.
                token = _create_session(
                    self.headers.get("User-Agent") or "", self._client_ip())
                return self._send(200, {"ok": True, "first": True},
                                  headers=[("Set-Cookie",
                                            _sess_cookie(token))])
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick":
            kid = str(b.get("id") or "")
            if not kid:
                return self._send(400, {"error": "no session id"})
            with _lock:
                d = _load_sessions()
                target = next((k for k in d["sessions"]
                               if k.startswith(kid)), None)
                if target is None:
                    return self._send(404, {"error": "session not found"})
                if target == auth:
                    return self._send(400, {
                        "error": "That is this browser — use Log out"})
                d["sessions"].pop(target, None)
                _save_sessions(d)
            _SESS_SEEN.pop(target, None)
            _SESS_WRITTEN.pop(target, None)
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick_all":
            with _lock:
                d = _load_sessions()
                d["sessions"] = {}
                _save_sessions(d)
            _SESS_SEEN.clear()
            _SESS_WRITTEN.clear()
            return self._send(200, {"ok": True, "reload": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/assistant":
            q = (b.get("q") or "").strip()
            if not q:
                return self._send(400, {"error": "empty question"})
            try:
                return self._send(200, assistant_answer(
                    q, b.get("history"), b.get("attach")))
            except Exception as e:
                return self._send(200, {"answer":
                    "Something went wrong while checking: " + str(e),
                    "actions": []})
        if p == "/api/ping":
            return self._send(200, {"v": 48})
        if p == "/api/doctor":
            q = str(b.get("q") or "")
            if not q.strip():
                return self._send(400, {"error": "empty"})
            return self._send(200, doctor_number(q))
        if p == "/api/transcribe":
            import base64
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=False)
            except Exception:
                return self._send(400, {"error": "bad audio"})
            if len(raw) > 12 * 1024 * 1024:
                return self._send(400, {"error": "recording too long"})
            if len(raw) < 800:
                return self._send(200, {"ok": False, "error":
                    "Recording too short — speak the number clearly."})
            ok, val = _transcribe_audio(raw)
            return self._send(200, {"ok": True, "text": val} if ok
                              else {"ok": False, "error": val})
        if p == "/api/track":
            items = [ENG.norm(str(x)) for x in (b.get("items") or []) if str(x).strip()]
            if not items:
                return self._send(400, {"error": "empty"})
            if len(items) > 40:
                return self._send(400, {"error": "too many numbers — 40 at a time, please"})
            if b.get("mode", "bl") not in ("bl", "container", "vessel"):
                return self._send(400, {"error": "bad mode"})
            job_id = f"job{int(time.time()*1000)}{threading.get_ident() % 997}"
            JOBS[job_id] = {"done": False, "current": "", "events": [], "results": []}
            # F-14 fix (v46 audit): finished jobs were kept forever —
            # prune so only the newest 50 done jobs stay in memory.
            done_ids = [k for k, v in JOBS.items() if v.get("done")]
            for old in done_ids[:-50]:
                JOBS.pop(old, None)
            threading.Thread(target=_run_job,
                             args=(job_id, items, b.get("mode", "bl"),
                                   b.get("carrier") or None,
                                   (b.get("client") or "").strip()),
                             daemon=True).start()
            return self._send(200, {"job": job_id})
        if p == "/api/history/update":
            q = b.get("query")
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                if "checklist" in b:
                    hit["checklist"] = b["checklist"]
                if "notes" in b:
                    hit["notes"] = b["notes"]
                for f in ("client", "amount", "received"):
                    if f in b:
                        hit[f] = b[f]
                if "returned" in b:
                    hit["returned"] = bool(b["returned"])
                if "starred" in b:
                    hit["starred"] = bool(b["starred"])
                if b.get("seen"):
                    hit["changed"] = False
                if not save_json(HISTORY_FILE, hist):
                    return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/history/delete":
            q = b.get("query")
            with _lock:
                hist = get_history()
                gone = next((h for h in hist if h.get("query") == q), None)
                if gone is None:
                    return self._send(404, {"error": "entry not found"})
                rest = [h for h in hist if h.get("query") != q]
                if not save_json(HISTORY_FILE, rest):
                    return self._send(500, {"error": "could not save"})
                ph = gone.get("photo")
                if ph and not any(h.get("photo") == ph for h in rest):
                    try:
                        (PHOTOS_DIR / Path(ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True})
        if p == "/api/settings":
            b = b or {}
            # v48: the password hash is managed ONLY via /api/password —
            # a settings save must never overwrite or inject it.
            b.pop("app_pass", None)
            try:
                if "recheck_hours" in b:
                    rh = float(b["recheck_hours"])
                    if rh not in (3, 6, 12, 24):
                        raise ValueError("recheck_hours")
                    b["recheck_hours"] = rh
                if "free_days" in b:
                    fd = float(b["free_days"])
                    if not (0 <= fd <= 60):
                        raise ValueError("free_days")
                    b["free_days"] = fd
                if "demurrage_rate" in b:
                    dr = float(b["demurrage_rate"])
                    if dr < 0:
                        raise ValueError("demurrage_rate")
                    b["demurrage_rate"] = dr
                if "return_days" in b:
                    rd = float(b["return_days"])
                    if not (1 <= rd <= 60):
                        raise ValueError("return_days")
                    b["return_days"] = rd
            except (TypeError, ValueError) as e:
                return self._send(400, {"error": f"invalid setting: {e}"})
            for k in ("company_name", "company_tagline"):
                if k in b:
                    b[k] = str(b[k]).strip()[:80]
            if "ai_key" in b:
                _k = str(b["ai_key"] or "").strip()
                if _k:
                    b["ai_key"] = _k[:220]
                else:
                    b.pop("ai_key")
            s = get_settings()
            s.update(b)
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/photo":
            import base64
            q = ENG.norm(str(b.get("query") or ""))
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            if len(raw) > 8 * 1024 * 1024:
                return self._send(400, {"error": "photo too large (8 MB max)"})
            # The payload must really be an image — trust the file
            # signature, never the caller's word (v41 audit fix).
            fmt = None
            if raw[:3] == b"\xff\xd8\xff":
                fmt = ".jpg"
            elif raw[:8] == b"\x89PNG\r\n\x1a\n":
                fmt = ".png"
            elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                fmt = ".webp"
            if not fmt:
                return self._send(400, {"error": "that file is not an image"})
            name = f"{q}{fmt}"
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                old_ph = hit.get("photo")
                (PHOTOS_DIR / name).write_bytes(raw)
                hit["photo"] = name
                if not save_json(HISTORY_FILE, hist):
                    return self._send(500, {"error": "could not save"})
                if old_ph and old_ph != name:
                    try:
                        (PHOTOS_DIR / Path(old_ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True, "photo": name})
        if p == "/api/ocr":
            import base64
            import subprocess
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            tmp = DATA_DIR / f"ocr_tmp_{int(time.time()*1000)}_{threading.get_ident()}.png"
            # Pre-process for OCR accuracy: greyscale, 2x upscale,
            # hard threshold — printed BL text reads far better.
            try:
                from PIL import Image
                _im = Image.open(io.BytesIO(raw)).convert("L")
                _im = _im.resize((_im.width * 2, _im.height * 2))
                _im = _im.point(lambda v: 0 if v < 160 else 255)
                _im.save(str(tmp))
            except Exception:
                tmp.write_bytes(raw)
            tess = _tesseract_path()
            if not tess:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass
                return self._send(200, {"ok": False,
                    "error": ("Tesseract OCR was not found on this "
                              "computer (checked the PATH and the "
                              "usual install folders). Install it "
                              "to use photo scanning.")})
            try:
                out = subprocess.run([tess, str(tmp), "stdout"],
                                     capture_output=True, timeout=60)
                if out.returncode != 0:
                    return self._send(200, {"ok": False,
                        "error": "OCR could not read that photo — please try a clearer, closer photo."})
                text = out.stdout.decode("utf-8", "replace")
            except FileNotFoundError:
                return self._send(200, {"ok": False,
                    "error": "Tesseract OCR is not installed on this laptop. Install it to use photo scanning."})
            except Exception as e:
                return self._send(200, {"ok": False, "error": str(e)})
            finally:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass
            ext = re_extract_doc_numbers(text)
            if not ext["numbers"]:
                # v46 Phase C, doosra chance: the hard threshold can
                # erase light print entirely ("photo me kuch nahi
                # mila"). Retry once on plain greyscale, no threshold.
                try:
                    from PIL import Image
                    _im2 = Image.open(io.BytesIO(raw)).convert("L")
                    _im2 = _im2.resize((_im2.width * 2, _im2.height * 2))
                    _im2.save(str(tmp))
                    out2 = subprocess.run([tess, str(tmp), "stdout"],
                                          capture_output=True, timeout=60)
                    if out2.returncode == 0:
                        text2 = out2.stdout.decode("utf-8", "replace")
                        ext2 = re_extract_doc_numbers(text2)
                        if ext2["numbers"]:
                            text, ext = text2, ext2
                except Exception:
                    pass
                finally:
                    try:
                        tmp.unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True, "numbers": ext["numbers"],
                "bls": ext["bls"], "seals": ext["seals"],
                "text": text[:500],
                "containers": ext["containers"],
                "fields": _parse_doc_fields(text)})
        return self._send(404, {"error": "not found"})



def _iso_ok(s):
    """ISO 6346 check digit ki jaanch."""
    VAL = {"A": 10, "B": 12, "C": 13, "D": 14, "E": 15, "F": 16,
           "G": 17, "H": 18, "I": 19, "J": 20, "K": 21, "L": 23,
           "M": 24, "N": 25, "O": 26, "P": 27, "Q": 28, "R": 29,
           "S": 30, "T": 31, "U": 32, "V": 34, "W": 35, "X": 36,
           "Y": 37, "Z": 38}
    try:
        tot = 0
        for i, ch in enumerate(s[:10]):
            v = int(ch) if ch.isdigit() else VAL[ch]
            tot += v * (2 ** i)
        return (tot % 11) % 10 == int(s[10])
    except Exception:
        return False


def _lev(a, b):
    if abs(len(a) - len(b)) > 3:
        return 99
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1,
                           prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def doctor_number(raw):
    """Number Doctor (idea 20): search se PEHLE number ki
    jaanch — ye BL hai ya container, kis line ka lagta hai,
    digit theek hai ya nahi, aur list ke kisi number se
    milta julta to nahi."""
    import re as _re
    n = ENG.norm(str(raw or ""))
    out = {"input": raw, "normalized": n, "type": "Not recognized",
           "carrier": None, "valid": None, "notes": [],
           "suggestion": None, "expanded": None}
    if not n:
        out["notes"].append("Nothing was entered.")
        return out
    if _re.fullmatch(r"\d{5}", n) and n[0] == "5":
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True, expanded="EMKAYMBAKHI" + n)
        out["notes"].append("5 digits starting with 5 — by the "
                            "standing rule this is an Emkay Lines "
                            "BL; TRACK adds EMKAYMBAKHI by itself.")
        return out
    if n.startswith("EMKAY") or n.startswith("MBAK"):
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True)
        out["notes"].append("This is an Emkay Lines BL.")
        return out
    if _re.fullmatch(r"[A-Z]{4}\d{7}", n):
        ok = _iso_ok(n)
        out.update(type="Container", valid=ok,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if ok:
            out["notes"].append("The container number's shape and its "
                                "final check digit are both correct.")
        else:
            out["notes"].append("The final digit (check digit) does not "
                                "match the calculation — there is "
                                "likely a typing mistake in the number.")
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} usually belongs to "
                                f"{out['carrier']}.")
        return out
    if _re.fullmatch(r"[A-Z]{4}[A-Z0-9]{5,}", n):
        out.update(type="BL", valid=True,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} — this looks like a "
                                f"{out['carrier']} BL.")
        else:
            out["notes"].append("BL-shaped number, but the prefix does "
                                "not match a well-known line — the "
                                "search will still try every route.")
        return out
    if _re.fullmatch(r"\d{9,12}", n):
        out.update(type="BL (digits only)",
                   carrier="COSCO Shipping (likely)", valid=True)
        out["notes"].append("Digits-only BLs are usually COSCO — "
                            "the app will search by the digits.")
        return out
    if _re.fullmatch(r"[A-Z ]{3,}", n) and " " in n.strip():
        out.update(type="Vessel name", valid=True)
        out["notes"].append("This looks like a vessel name — "
                            "search it in Vessel mode.")
        return out
    out["notes"].append("The shape is unclear — it does not look "
                        "like a BL, a container or a vessel name.")
    best = None
    for h in get_history():
        q = (h.get("query") or "").upper()
        if q and abs(len(q) - len(n)) <= 2:
            d = _lev(n, q)
            if best is None or d < best[0]:
                best = (d, q)
    if best and 0 < best[0] <= 2:
        out["suggestion"] = best[1]
        out["notes"].append(f"This closely matches {best[1]} in your "
                            "list — could it be the same one?")
    return out


def _parse_doc_fields(text):
    """BL ki photo ke text se poori tafseel (idea 26): jahaz,
    voyage, wazan, tadaad, samaan — jo mile, imaandari se."""
    import re as _re
    t = text or ""
    f = {}
    m = _re.search(r"VESSEL[:\s]*([A-Za-z][A-Za-z ]{2,28})", t)
    if m:
        f["vessel"] = m.group(1).strip().upper()
    m = _re.search(r"(?:VOYAGE|VOY\.?|V\.)[:\s]*([A-Za-z0-9]{2,10})", t)
    if m:
        f["voyage"] = m.group(1).upper()
    m = _re.search(r"([\d.,]+)\s*KGS?\b", t, _re.I)
    if m:
        f["weight"] = m.group(1) + " KGS"
    m = _re.search(r"(\d+)\s*(PACKAGES|PKGS|CARTONS|BAGS|PCS|UNITS)",
                   t, _re.I)
    if m:
        f["packages"] = m.group(1) + " " + m.group(2).upper()
    for label in ("DESCRIPTION OF GOODS", "DESCRIPTION",
                  "PARTICULARS", "COMMODITY"):
        m = _re.search(label + r"[:\s]*([^\n]{4,90})", t, _re.I)
        if m:
            f["commodity"] = m.group(1).strip(" :-").upper()
            break
    return f


def _ast_date(v):
    """App ki mukhtalif date shaklo ko date mein badlo."""
    if not v:
        return None
    t = str(v).strip()
    for f in ("%d %b %Y", "%d-%b-%Y", "%d %b %y", "%Y-%m-%d",
              "%d/%m/%Y", "%d-%m-%Y", "%d %B %Y"):
        try:
            return datetime.strptime(t.title()
                                     if f in ("%d %b %Y", "%d %b %y")
                                     else t, f).date()
        except Exception:
            continue
    m = re.match(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{4})", t)
    if m:
        try:
            return datetime.strptime(
                f"{m.group(1)} {m.group(2)[:3]} {m.group(3)}",
                "%d %b %Y").date()
        except Exception:
            return None
    return None


def _ast_completed(h):
    r = h.get("result") or {}
    return bool(r.get("gate_out")) or "deliver" in (
        r.get("status") or "").lower() or (
        (r.get("position") or "").upper() == "OUT")


def _assistant_context():
    hist = get_history()
    found = [h for h in hist if h.get("found")]
    nf = [h for h in hist if not h.get("found")]
    lines = [f"Shipments in the app: {len(hist)} tracked, "
             f"{len(found)} found, {len(nf)} not found."]
    for h in found[:25]:
        r = h.get("result") or {}
        row = (f"- {h.get('query')} ({h.get('carrier') or 'carrier unknown'}): "
               f"{r.get('status') or 'status unknown'}")
        if r.get("vessel"):
            row += f", vessel {r['vessel']}"
        if r.get("eta"):
            row += f", ETA {r['eta']}"
        if r.get("terminal"):
            row += f", terminal {r['terminal']}"
        if r.get("containers"):
            row += f", containers {', '.join(r['containers'])}"
        lines.append(row)
    if nf:
        lines.append("Not found so far: " + ", ".join(
            str(h.get("query")) for h in nf[:12]))
    st = get_settings()
    lines.append(f"Free days before demurrage: {st.get('free_days')}; "
                 f"auto re-check every {st.get('recheck_hours')} hours.")
    lines.append("Photo scanning (OCR) on this computer: "
                 + ("ready" if _tesseract_path() else "NOT installed"))
    return "\n".join(lines)

_RAPID_SCRIPT = (
    "import sys\n"
    "from rapidocr_onnxruntime import RapidOCR\n"
    "res, _ = RapidOCR()(sys.argv[1])\n"
    "items = []\n"
    "for box, txt, score in (res or []):\n"
    "    items.append((min(p[1] for p in box),"
    " min(p[0] for p in box), txt))\n"
    "items.sort()\n"
    "print('\\n'.join(t for _, _, t in items))")


def _ocr_image_bytes(raw):
    """Photo ke bytes se text. Pehle Tesseract (laptop par
    installed), phir — jahan wo na ho — local RapidOCR venv.
    (True, text) ya (False, wajah)."""
    import subprocess
    tmp = DATA_DIR / (f"ocr_tmp_{int(time.time()*1000)}_"
                      f"{threading.get_ident()}.png")
    try:
        try:
            from PIL import Image
            _im = Image.open(io.BytesIO(raw)).convert("L")
            _im = _im.resize((_im.width * 2, _im.height * 2))
            _im = _im.point(lambda v: 0 if v < 160 else 255)
            _im.save(str(tmp))
        except Exception:
            tmp.write_bytes(raw)
        tess = _tesseract_path()
        if tess:
            out = subprocess.run([tess, str(tmp), "stdout"],
                                 capture_output=True, timeout=60)
            if out.returncode == 0:
                return True, out.stdout.decode("utf-8", "replace")
            return False, ("OCR could not read that photo — please "
                          "try a clearer, closer photo.")
        venv_py = (Path.home() / "workspace" / "ocrvenv"
                   / "bin" / "python")
        if venv_py.exists():
            out = subprocess.run(
                [str(venv_py), "-c", _RAPID_SCRIPT, str(tmp)],
                capture_output=True, timeout=120)
            txt = out.stdout.decode("utf-8", "replace").strip()
            if out.returncode == 0 and txt:
                return True, txt
            return False, ("OCR could not read that photo — please "
                           "try a clearer, closer photo.")
        return False, ("Tesseract OCR was not found on this computer "
                       "(checked the PATH and the usual install "
                       "folders). Install it to use photo scanning.")
    except Exception as e:
        return False, str(e)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def _pdf_text(raw):
    """v46: PDF se text — koi library nahi, stdlib zlib se FlateDecode
    streams khol kar Tj/TJ text operators jama karo. Scanned-image
    PDF par khaali milega (caller imandari se wahi kehta hai)."""
    import re as _re
    import zlib as _zlib
    out = []
    for m in _re.finditer(rb"stream\r?\n(.*?)endstream", raw, _re.S):
        data = m.group(1)
        try:
            data = _zlib.decompress(data)
        except Exception:
            pass
        for t in _re.findall(rb"\((?:\\.|[^\\)])*\)\s*Tj", data):
            out.append(t[1:t.rindex(b")")])
        for arr in _re.findall(rb"\[(.*?)\]\s*TJ", data, _re.S):
            parts = _re.findall(rb"\((?:\\.|[^\\)])*\)", arr)
            if parts:
                out.append(b"".join(p[1:-1] for p in parts))
    txt = b" ".join(out).decode("latin-1", "replace")
    txt = txt.replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\")
    return " ".join(txt.split())


def _transcribe_audio(raw):
    """Recorded aawaz ko Groq Whisper se text banao (v41).
    Browser ki apni speech service aksar atak jati thi — ye
    rasta hamesha app ki apni key se chalta hai."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    key = str(get_settings().get("ai_key") or "").strip()
    if not key.startswith("gsk_"):
        return False, ("Voice typing needs the free AI key — add "
                       "it in Settings first.")
    for model in ("whisper-large-v3-turbo", "whisper-large-v3"):
        boundary = "----ct" + str(int(time.time() * 1000))
        body = b""
        for name, val in (("model", model),
                          ("response_format", "json"),
                          ("language", "en"),
                          ("prompt", "Shipping numbers: bill of "
                           "lading and container numbers, spoken "
                           "digit by digit.")):
            body += (f"--{boundary}\r\nContent-Disposition: "
                     f"form-data; name=\"{name}\"\r\n\r\n"
                     f"{val}\r\n").encode()
        body += (f"--{boundary}\r\nContent-Disposition: form-data; "
                 f"name=\"file\"; filename=\"voice.webm\"\r\n"
                 f"Content-Type: audio/webm\r\n\r\n").encode()
        body += raw + f"\r\n--{boundary}--\r\n".encode()
        req = _u.Request(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            data=body,
            headers={"Authorization": f"Bearer {key}",
                     "Content-Type": "multipart/form-data; "
                     f"boundary={boundary}",
                     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; "
                     "Win64; x64) AppleWebKit/537.36 (KHTML, "
                     "like Gecko) Chrome/130.0 Safari/537.36"})
        try:
            with _u.urlopen(req, timeout=60) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            txt = (d.get("text") or "").strip()
            if txt:
                return True, txt
            return False, ("Nothing was heard in that recording — "
                           "try again, a little closer to the mic.")
        except _ue.HTTPError as e:
            if e.code in (400, 404, 415) and model.endswith("turbo"):
                continue
            if e.code == 401:
                return False, ("The AI key was refused by Groq — "
                               "check the key in Settings.")
            return False, (f"Voice service error ({e.code}) — "
                           "please try again.")
        except Exception as e:
            return False, "Voice service unreachable: " + str(e)[:80]
    return False, "Voice service did not answer — please try again."



def _groq_answer(q, hist, key, extra=""):
    """Groq (muft tier, Llama models) se asal guftagu. Key
    'gsk_' se shuru hoti hai. Ghalti par None — local jawab
    sambhal lega, jhooti tasalli kabhi nahi."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    sys_txt = (
        "You are the assistant inside CargoTrack, a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app CREATES it automatically and it appears in the chat under your reply - so confirm it in one short line (for example: it is ready below, have a look) instead of describing steps or asking him to press anything. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically.\n\nLIVE APP DATA:\n"
        + _assistant_context() + extra)
    msgs = [{"role": "system", "content": sys_txt}]
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:800]
        if t:
            msgs.append({"role": "user" if h.get("role") == "user"
                         else "assistant", "content": t})
    msgs.append({"role": "user", "content": q})
    # Groq ka catalog badalta rehta hai — 21 Oct 2026 ko is
    # account par Llama models maujood hi nahi thay, sirf
    # gpt-oss / qwen family thi. Is liye pehle wohi, phir
    # purane naam (jin accounts par hon un ke liye).
    for model in ("openai/gpt-oss-120b", "qwen/qwen3.8-27b",
                  "openai/gpt-oss-20b", "llama-3.3-70b-versatile",
                  "llama-3.1-8b-instant"):
        try:
            body = {"model": model, "messages": msgs,
                    "temperature": 0.4, "max_tokens": 700}
            req = _u.Request(
                "https://api.groq.com/openai/v1/chat/completions",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}",
                         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; "
                         "Win64; x64) AppleWebKit/537.36 (KHTML, "
                         "like Gecko) Chrome/130.0 Safari/537.36"})
            with _u.urlopen(req, timeout=35) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            txt = (d["choices"][0]["message"].get("content")
                   or "").strip()
            if txt:
                return txt
        except _ue.HTTPError as e:
            if e.code in (404, 400, 403, 429):
                continue
            return None
        except Exception:
            continue  # F-12: one model's network hiccup must not skip the rest
    return None


def _gemini_answer(q, hist, key, extra=""):
    """Google Gemini (free tier) se asal jawab. Koi ghalti ho to
    None — jhooti tasalli kabhi nahi."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    contents = []
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:800]
        if t:
            contents.append({"role": "user" if h.get("role") == "user"
                             else "model",
                             "parts": [{"text": t}]})
    contents.append({"role": "user", "parts": [{"text": q}]})
    sys_txt = (
        "You are the assistant inside CargoTrack, a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app CREATES it automatically and it appears in the chat under your reply - so confirm it in one short line (for example: it is ready below, have a look) instead of describing steps or asking him to press anything. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically.\n\nLIVE APP DATA:\n"
        + _assistant_context() + extra)
    body = {"systemInstruction": {"parts": [{"text": sys_txt}]},
            "contents": contents,
            "generationConfig": {"temperature": 0.4,
                                 "maxOutputTokens": 700}}
    for model in ("gemini-2.5-flash", "gemini-2.0-flash"):
        try:
            req = _u.Request(
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{model}:generateContent?key={key}",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json"})
            with _u.urlopen(req, timeout=35) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            parts = d["candidates"][0]["content"]["parts"]
            txt = "".join(x.get("text", "") for x in parts).strip()
            if txt:
                return txt
        except _ue.HTTPError as e:
            if e.code == 404:
                continue
            return None
        except Exception:
            continue  # F-12: try the next model before giving up
    return None


def _find_mentioned_entry(text):
    t = ENG.norm(text or "")
    if not t:
        return None
    for h in get_history():
        if h.get("query") and h["query"].upper() in t:
            return h
        for c in ((h.get("result") or {}).get("containers") or []):
            if c and c.upper() in t:
                return h
    return None


_MEDIA_WORDS = ("image", "photo", "tasveer", "picture", "pic", "jpg",
                "jpeg", "png", "card", "pdf", "report", "file", "download")


def _media_ask(q):
    """v47: media (image/card/PDF/report) SIRF tab bane jab user
    ne is sawal mein saaf tor par manga ho. Sirf BL ka status
    poochne par koi card/report nahi banti — sirf text jawab."""
    ql = (q or "").lower()
    return any(re.search(r"\b" + w + r"\b", ql) for w in _MEDIA_WORDS)


def _media_intent_actions(q, local_q, hist=None):
    """Jis shipment ki baat ho rahi ho — chahe zikr is sawal
    mein ho ya Pichli baat-cheet mein — us ke liye mukammal
    options: Image, Report, Copy, WhatsApp. LEKIN v47 se ye
    actions sirf tab aate hain jab user ne media saaf tor par
    manga ho (_media_ask) — warna jawab sirf text hota hai."""
    media = _media_ask(q)
    entry = _find_mentioned_entry(local_q)
    if not entry and media:
        # pichli guftagu ulta tartib mein dekho — sab se
        # aakhri zikr wala shipment hi mauzu hai (sirf media
        # mange par; aam guftagu mein purani baat nahi uthani)
        for turn in reversed(hist or []):
            if (turn or {}).get("role") == "user":
                entry = _find_mentioned_entry(turn.get("text"))
                if entry:
                    break
    if entry and not media:
        # Shipment pehchana gaya lekin media nahi manga —
        # v47: sirf compact text jawab, koi action nahi.
        return []
    if not entry:
        if media:
            rec = [h for h in get_history() if h.get("found")][:3]
            acts_r = []
            for h in rec:
                acts_r.append({"label": "\U0001F5BC Image — "
                               + h["query"], "act": "image",
                               "arg": h["query"]})
                acts_r.append({"label": "\U0001F4C4 Report — "
                               + h["query"], "act": "report",
                               "arg": h["query"]})
            if acts_r:
                return acts_r
        m = re.search(r"\b[A-Z0-9][A-Z0-9\-]{5,}\b",
                      (local_q or "").upper())
        if m and any(c.isdigit() for c in m.group(0)):
            return [{"label": "\U0001F50D Track — " + m.group(0),
                     "act": "track", "arg": m.group(0),
                     "mode": "bl"}]
        return []
    qy = entry["query"]
    # v47 fix: jo media manga hai, sirf wohi bane — sirf image
    # maangne par report tile bhi ban jati thi (QA finding D3).
    ql = (q or "").lower()

    def _has(words):
        return any(re.search(r"\b" + w + r"\b", ql) for w in words)

    want_img = _has(("image", "photo", "tasveer", "picture",
                     "pic", "jpg", "jpeg", "png", "card"))
    want_rep = _has(("pdf", "report", "file"))
    if _has(("download",)) and not want_img and not want_rep:
        want_img = want_rep = True
    if not want_img and not want_rep:
        want_img = want_rep = True
    acts = []
    if want_img:
        acts.append({"label": "\U0001F5BC Image — " + qy,
                     "act": "image", "arg": qy})
    if want_rep:
        acts.append({"label": "\U0001F4C4 Report — " + qy,
                     "act": "report", "arg": qy})
    acts.append({"label": "\U0001F4CB Copy — " + qy, "act": "copy",
                 "arg": qy})
    acts.append({"label": "\U0001F4AC WhatsApp — " + qy,
                 "act": "wa", "arg": qy})
    return acts


def assistant_answer(q, hist=None, attach=None):
    extra = ""
    local_q = q
    if attach:
        if attach.get("kind") == "image" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            if raw:
                ok, val = _ocr_image_bytes(raw)
                if ok:
                    nums = re_find_numbers(val)
                    extra = ("\n\nATTACHED PHOTO — text read "
                             "from it:\n" + val[:1500])
                    if nums:
                        extra += ("\nNumbers found in the photo: "
                                  + ", ".join(nums))
                        local_q = q + " " + " ".join(nums)
                else:
                    extra = ("\n\nThe user attached a photo, but "
                             "this computer could not read it: "
                             + val)
        elif attach.get("kind") == "pdf" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            ptxt = _pdf_text(raw) if raw else ""
            if ptxt:
                nums = re_find_numbers(ptxt)
                extra = ("\n\nATTACHED PDF ("
                         + str(attach.get("name") or "file")[:60]
                         + ") — text read from it:\n" + ptxt[:4000])
                if nums:
                    extra += ("\nNumbers found in the PDF: "
                              + ", ".join(nums))
                    local_q = q + " " + " ".join(nums)
            else:
                extra = ("\n\nThe user attached a PDF, but no text "
                         "could be read from it on this computer (it "
                         "may be a scanned-image PDF). Say so honestly "
                         "in one line and suggest sending a photo of "
                         "the page instead.")
        elif attach.get("kind") == "file":
            extra = ("\n\nATTACHED FILE ("
                     + str(attach.get("name") or "file")[:60]
                     + ") — its text:\n"
                     + str(attach.get("text") or "")[:4000])
    acts = _media_intent_actions(q, local_q, hist)
    key = str(get_settings().get("ai_key") or "").strip()
    if key:
        try:
            txt = (_groq_answer(q, hist, key, extra)
                   if key.startswith("gsk_")
                   else _gemini_answer(q, hist, key, extra))
        except Exception:
            txt = None
        if txt:
            return {"answer": txt, "actions": acts, "mode": "ai"}
        out = _assistant_local(local_q)
        out["mode"] = "local"
        out["ai_error"] = True
        out["actions"] = (out.get("actions") or []) + acts
        return out
    out = _assistant_local(local_q)
    out["mode"] = "local"
    out["actions"] = (out.get("actions") or []) + acts
    return out


def _assistant_local(q):
    """App ke andar ka madadgar: jawab hamesha app ke APNE data
    aur system ki asal halat se banta hai — andaza nahi. Jo is ke
    bas se bahar ho, wahan saaf kehta hai ke Shezi se poochein."""
    ql = q.lower()
    hist = get_history()
    st = get_settings()
    today = datetime.now().date()
    acts = []
    lines = []

    def track_act(query, mode, label=None):
        acts.append({"label": label or f"Track {query}",
                     "act": "track", "arg": query, "mode": mode})

    # 1) sawal mein koi number ho to us ki poori report
    # number = kam az kam 8 harf/rakam AUR us mein digit lazmi
    # (warna "shipments" jese aam lafz bhi number ban jate thay)
    token = None
    for cand in re.findall(r"[A-Za-z0-9]{8,20}", q):
        if any(ch.isdigit() for ch in cand):
            token = cand.upper()
            break
    if token and not any(k in ql for k in
                         ("how", "what", "why", "kaise", "kya")):
        h = next((x for x in hist if x["query"].upper() == token),
                 None)
        if not h:
            h = next((x for x in hist
                      if token in ((x.get("result") or {})
                                   .get("containers") or [])), None)
        if h:
            r = h.get("result") or {}
            lines.append(f"{h['query']} — "
                         f"{'FOUND' if h['found'] else 'NOT FOUND'}"
                         f" ({h.get('carrier') or 'carrier unknown'})")
            if r.get("status"):
                lines.append(f"Status: {r['status']}")
            if r.get("vessel"):
                lines.append("Vessel: " + r["vessel"] +
                             (f" ({r['voyage']})" if r.get("voyage")
                              else ""))
            if r.get("eta"):
                lines.append(f"ETA: {r['eta']}")
            if r.get("terminal"):
                lines.append(f"Terminal: {r['terminal']}")
            if r.get("position"):
                lines.append(f"Position: {r['position']}")
            if r.get("holds"):
                lines.append(f"Holds: {r['holds']}")
            if (r.get("containers") or []):
                lines.append("Containers: "
                             + ", ".join(r["containers"]))
            lines.append(f"Last checked: {h.get('time') or '—'}")
            track_act(h["query"], h.get("mode") or "bl",
                      "↻ Check again now")
            return {"answer": "\n".join(lines), "actions": acts}
        lines.append(f"{token} is not in your tracked shipments yet.")
        track_act(token, "container"
                  if re.fullmatch(r"[A-Z]{4}\d{7}", token) else "bl",
                  f"Track {token} now")
        return {"answer": "\n".join(lines), "actions": acts}

    # 13) istilahat / "kya hota hai" — shipping ki har aam istilah
    GLOSS = {
      "demurrage": "Demurrage: the charge for keeping a container at the terminal BEYOND the free days after discharge. Counted per day, per container. Your free days are set in Settings (currently {fd}).",
      "detention": "Detention: the charge for keeping the container OUTSIDE the terminal (at your godown) beyond the allowed days after gate-out.",
      "bill of lading": "Bill of Lading (BL): the shipment's main document — the contract and receipt for the cargo. Its number tracks the whole shipment: vessel, route, containers, status.",
      " bl ": "BL (Bill of Lading): the shipment's main document and tracking number — one BL can carry several containers.",
      "eta": "ETA (Estimated Time of Arrival): the date the vessel is expected to reach the destination port. It is an estimate — it can move as the voyage progresses.",
      "etd": "ETD (Estimated Time of Departure): the date the vessel is expected to leave the loading port.",
      "gate pass": "Gate Pass: the terminal's permission for a truck to collect the container. 'GatePass Not Issued' means the release steps (delivery order, payments, holds) are not complete yet.",
      "delivery order": "Delivery Order (DO): the shipping line's order telling the terminal to release the cargo to you. It has an expiry date — after that it must be renewed.",
      "vir": "VIR (Vessel Inward Report): the terminal's arrival record for a vessel visit. The VIR number also tells the terminal honestly — PKKHIKICT means KICT, PKKHISAPT means SAPT, PKBQMQICT means QICT.",
      "hold": "Hold: the terminal, customs or the line has stopped the release — billing hold, customs hold or line hold. Cargo cannot move until the hold is cleared.",
      "yard": "Yard: the container's storage area inside the terminal. 'Position: YARD' means the container is physically inside, waiting for release steps.",
      "discharge": "Discharge: unloading the container from the vessel at the port. Your free days start counting from the discharge date.",
      "transhipment": "Transhipment (transshipment): the cargo changes vessel at an in-between port before reaching Karachi.",
      "transshipment": "Transhipment: the cargo changes vessel at an in-between port before reaching Karachi.",
      "free days": "Free days: the days after discharge during which the terminal charges no demurrage. Set yours in Settings — currently {fd} days.",
      "nvocc": "NVOCC: a carrier that books space on other lines' vessels instead of owning ships (like Emkay Line). Their house BLs are tracked through the terminal and the master line.",
      "teu": "TEU: Twenty-foot Equivalent Unit — the standard measure of container capacity. A 40ft container is 2 TEU.",
      "container": "Container number: 4 letters + 7 digits (like CSNU6961392). The last digit is a check digit — this app verifies it with the ISO 6346 formula.",
    }
    for term, definition in GLOSS.items():
        if (term in ql and any(w in ql for w in
                              ("kya hota", "kya hai", "what is",
                               "meaning", "matlab", "samjha",
                               "explain"))
                and not any(w in ql for w in
                            ("which", "list", "kons", "show me",
                             "kitn"))):
            lines.append(definition.replace("{fd}",
                                            str(st.get("free_days", 7))))
            return {"answer": "\n".join(lines), "actions": acts}


    found = [h for h in hist if h["found"]]
    notfound = [h for h in hist if not h["found"]]

    # 2) holds
    if any(k in ql for k in ("hold", "ruk", "stuck")):
        hs = [h for h in found
              if "hold" in ((h["result"].get("status") or "").lower())
              or (h["result"].get("holds"))]
        if hs:
            lines.append(f"{len(hs)} shipment(s) on hold:")
            for h in hs[:10]:
                r = h["result"]
                lines.append(f"• {h['query']} — {r.get('status')}"
                             + (f" ({r['terminal']})"
                                if r.get("terminal") else ""))
        else:
            lines.append("No shipment is on hold right now. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 3) arriving soon
    if any(k in ql for k in ("arriv", "eta", "kab aay", "coming",
                             "expected")):
        arr = []
        for h in found:
            d = _ast_date((h["result"] or {}).get("eta"))
            if d and d >= today and not _ast_completed(h):
                arr.append((d, h))
        arr.sort(key=lambda x: x[0])
        if arr:
            lines.append("Arriving (next first):")
            for d, h in arr[:10]:
                r = h["result"]
                lines.append(f"• {h['query']} — ETA "
                             f"{r.get('eta')} • {r.get('vessel') or ''}"
                             f" • {r.get('terminal') or ''}")
        else:
            lines.append("No upcoming arrivals with an ETA in your "
                         "list.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 4) delivered
    if any(k in ql for k in ("deliver", "pohanch", "completed",
                             "done")):
        ds = [h for h in found if _ast_completed(h)]
        lines.append(f"{len(ds)} shipment(s) completed / delivered:")
        for h in ds[:10]:
            lines.append(f"• {h['query']} — "
                         f"{h['result'].get('status')}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 5) demurrage risk
    if any(k in ql for k in ("demurrage", "risk", "late charge",
                             "free day")):
        fd = st.get("free_days", 7)
        risk = []
        for h in found:
            if _ast_completed(h):
                continue
            d = _ast_date((h["result"] or {}).get("discharge_time"))
            if d and (today - d).days > fd:
                risk.append(((today - d).days - fd, h))
        risk.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if risk:
            lines.append("Demurrage risk (free days over):")
            for over, h in risk[:10]:
                lines.append(f"• {h['query']} — {over} day(s) over "
                             f"the {fd} free days")
        else:
            lines.append("No demurrage risk right now — nothing is "
                         "past its free days. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 6) not found help
    if any(k in ql for k in ("not found", "nahi mil", "missing",
                             "no record")):
        lines.append(f"You have {len(notfound)} not-found number(s):")
        for h in notfound[:10]:
            lines.append(f"• {h['query']}")
        lines.append("Common reasons: one letter typed wrong (the "
                     "app now suggests the close match from your "
                     "history), the carrier has not published the "
                     "record yet, or the system did not respond — "
                     "a 'not found' here never proves your number "
                     "is wrong. Retry after a while.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 15) sab se purani pending shipment
    if any(k in ql for k in ("oldest", "purani", "sab se pehle",
                             "longest waiting")):
        pend = []
        for h in found:
            if _ast_completed(h):
                continue
            dd = _ast_date((h["result"] or {}).get("discharge_time"))
            if dd:
                pend.append(((today - dd).days, h))
        pend.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if pend:
            lines.append("Longest-waiting shipments (discharged, "
                         "not yet delivered):")
            for days, h in pend[:5]:
                lines.append(f"• {h['query']} — {days} day(s) since "
                             f"discharge • {h['result'].get('status')}")
        else:
            lines.append("No discharged-and-waiting shipments.")
        return {"answer": "\n".join(lines), "actions": acts}


    # 7) payments
    if any(k in ql for k in ("payment", "paisa", "pending",
                             "receive", "client")):
        from collections import defaultdict
        agg = defaultdict(lambda: [0, 0])
        for h in hist:
            c = (h.get("client") or "").strip()
            if not c:
                continue
            try:
                agg[c][0] += float(h.get("amount") or 0)
                agg[c][1] += float(h.get("received") or 0)
            except Exception:
                pass
        pend = [(c, a - r) for c, (a, r) in agg.items() if a - r > 0]
        if pend:
            lines.append("Pending payments:")
            for c, p in pend[:10]:
                lines.append(f"• {c}: PKR {p:,.0f} pending")
        else:
            lines.append("No pending payments in your records. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 8) OCR / photo
    if any(k in ql for k in ("ocr", "photo", "scan", "camera",
                             "tasveer")):
        tess = _tesseract_path()
        if tess:
            lines.append("Photo scanning (OCR) is READY on this "
                         "computer — Tesseract was found at:")
            lines.append(tess)
            lines.append("Use 'Scan photo' on the search box, or "
                         "attach a photo to any result.")
        else:
            lines.append("Photo scanning is NOT ready: Tesseract "
                         "was not found in the PATH or the usual "
                         "install folders (Program Files\\"
                         "Tesseract-OCR). If you installed it "
                         "somewhere custom, reinstalling into the "
                         "default folder fixes it.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 9) system health — "system pe nazar"
    if any(k in ql for k in ("system", "health", "halat",
                             "report", "kais")):
        stale = [h for h in found if not _ast_completed(h)
                 and h.get("checked_ts")
                 and time.time() - h["checked_ts"] > 3 * 3600]
        lines.append("System health:")
        lines.append(f"• Tracked shipments: {len(hist)} "
                     f"({len(found)} found, {len(notfound)} not found)")
        lines.append(f"• On hold: "
                     f"{len([h for h in found if 'hold' in ((h['result'].get('status') or '').lower())])}")
        lines.append(f"• Data older than 3 hours (press TRACK to "
                     f"refresh): {len(stale)}")
        lines.append(f"• Auto re-check: every "
                     f"{st.get('recheck_hours', 6)} hours")
        lines.append(f"• Photo scanning (OCR): "
                     f"{'ready ✓' if _tesseract_path() else 'NOT ready — ask me about OCR'}")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 10) backup
    if "backup" in ql:
        lines.append("Your data (history, settings, photos) lives "
                     "outside the app folder, so updates never "
                     "erase it. A backup ZIP can be downloaded any "
                     "time:")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 11) delete / clear help
    if any(k in ql for k in ("delete", "clear", "hata", "remove")):
        lines.append("Every row in the Logs lists now has a 🗑 "
                     "Delete button, and the Not Found card has a "
                     "'Clear all' button that removes all not-found "
                     "entries at once (it asks first). Found "
                     "shipments can also be deleted from their "
                     "result card.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 12) greeting / help
    if (re.search(r"\b(hi|hello|salam|aoa|help|madad)\b", ql)
            or "what can" in ql):
        lines.append("I am the built-in assistant. I watch your "
                     "shipments and this app, and answer from your "
                     "own data. Try:")
        lines.append("• 'Which shipments are on hold?'")
        lines.append("• 'What is arriving soon?'")
        lines.append("• 'System health'")
        lines.append("• Type any BL / container number for its "
                     "full report")
        lines.append("• 'Why is my number not found?'")
        return {"answer": "\n".join(lines), "actions": acts}

    # 14) aaj ka brief
    if any(k in ql for k in ("brief", "aaj ka", "today", "summary")):
        arr_today = [h for h in found
                     if _ast_date((h["result"] or {}).get("eta")) == today]
        holds = [h for h in found
                 if "hold" in ((h["result"].get("status") or "").lower())]
        lines.append(f"Today's brief — {len(hist)} tracked, "
                     f"{len(found)} found, {len(notfound)} not found.")
        lines.append(f"• Arriving today: {len(arr_today)}"
                     + (": " + ", ".join(h["query"] for h in arr_today[:5])
                        if arr_today else ""))
        lines.append(f"• On hold: {len(holds)}"
                     + (": " + ", ".join(h["query"] for h in holds[:5])
                        if holds else ""))
        lines.append(f"• Completed / delivered: "
                     f"{len([h for h in found if _ast_completed(h)])}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 16) carrier ke hisab se ginti
    if any(k in ql for k in ("per carrier", "carrier wise",
                             "kis carrier", "by carrier")):
        from collections import Counter
        cc = Counter(h.get("carrier") or "Unknown" for h in hist)
        lines.append("Shipments by carrier:")
        for name, cnt in cc.most_common(10):
            lines.append(f"• {name}: {cnt}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 17) chhoti baatein
    if any(k in ql for k in ("thank", "shukriya", "great", "acha")):
        lines.append("You are welcome! Ask me anything else — "
                     "holds, arrivals, a report for any number, "
                     "or system health.")
        return {"answer": "\n".join(lines), "actions": acts}
    if any(k in ql for k in ("tum kon", "who are you", "tumhara naam",
                             "your name")):
        lines.append("I am the CargoTrack assistant — I live inside "
                     "this app, watch your shipments and answer from "
                     "your own data. Shezi (in your chat) is the one "
                     "who built me and can do everything beyond this "
                     "app.")
        return {"answer": "\n".join(lines), "actions": acts}

    # fallback — imandari se
    lines.append("That question needs the full AI, and it is not "
                 "answering right now (an internet hiccup or the "
                 "free limit) — my built-in answers only cover "
                 "this app and your shipments, so please ask "
                 "again in a little while.")
    lines.append("What I CAN do right now: holds, arrivals, "
                 "demurrage risk, payments, not-found help, OCR "
                 "status and a full system health report.")
    lines.append("Or tap below — your question will be copied, "
                 "paste it in your chat with Shezi and he will "
                 "answer it there.")
    acts.append({"label": "📋 Copy this question for Shezi",
                 "act": "copyq", "arg": q})
    return {"answer": "\n".join(lines), "actions": acts}


# OCR digit-confusion repair: Tesseract aksar 0 ko O, 1 ko I, 5 ko S
# parh deta hai — container ke digit hisse mein ye badal kar check
# digit dobara jaancha jata hai.
_OCR_DIG_FIX = str.maketrans({"O": "0", "Q": "0", "I": "1", "L": "1",
                              "S": "5", "B": "8", "Z": "2", "G": "6"})


def _iso_repair(tok):
    if len(tok) != 11 or not tok[:4].isalpha():
        return None
    fixed = tok[4:].translate(_OCR_DIG_FIX)
    if not fixed.isdigit():
        return None
    cand = tok[:4] + fixed
    return cand if _iso_ok(cand) else None


def re_extract_doc_numbers(text):
    """v46 Phase C — document se number nikaalne ka naya usool.

    Yousuf ka sikhaya huwa document order: pehle CONTAINER number,
    phir size (20'/40'), phir SEAL number — aksar baghair heading ke.
    Is liye:
    - Container sirf wahi jo ISO check-digit pass kare (ya OCR ki
      digit-ghalti theek karke pass ho jaye).
    - SEAL wali line ka number, aur container ke baad wali line par
      6-8 digit ka khaali number, kabhi BL nahi banta.
    - BL woh alphanumeric number hai jis ki pehchan ho (carrier
      prefix) ya jo ghar ka/house BL lagta ho; 9-10 khaali digits
      Maersk/COSCO ke BL ho sakte hain.
    - OCR aksar number ke beech space/dash daal deta hai — token
      unhein jor kar banta hai.
    """
    import re
    bls, cons, seals, others = [], [], [], []
    seen = set()

    def push(lst, v):
        if v and v not in seen:
            seen.add(v)
            lst.append(v)

    def classify(tok):
        """Ek saaf token ki (score, qism, value). Score: container 3,
        pehchana huwa BL 2, aam BL/other 1, fazool 0. Lambai 17 se
        zyada wali mili-juli satr kabhi number nahi hoti."""
        if len(tok) > 17 or not re.fullmatch(r"[A-Z0-9]+", tok):
            return 0, None, tok
        if re.fullmatch(r"[A-Z]{4}\d{7}", tok):
            if _iso_ok(tok):
                return 3, "container", tok
            rep = _iso_repair(tok)
            if rep:
                return 3, "container", rep
            return 1, "other", tok
        if tok.isdigit():
            if len(tok) in (9, 10):
                return 2, "bl", tok         # Maersk 9-digit / COSCO digits
            if len(tok) == 11:
                return 1, "other", tok      # phone-like — aakhri ummeed
            return 0, None, tok
        if len(tok) >= 9 and re.search(r"[A-Z]", tok) \
                and re.search(r"\d", tok):
            try:
                _pfx, cname = ENG.identify_carrier(tok)
            except Exception:
                cname = None
            return (2, "bl", tok) if cname else (1, "bl", tok)
        return 0, None, tok

    for line in (text or "").upper().splitlines():
        seal_line = "SEAL" in line
        groups = [g.strip(".,;:()") for g in line.split()]
        groups = [g for g in groups if g]
        if seal_line:
            # Seal wali line par jor nahi lagana — "SEAL NO PK123456"
            # ko ek bana kar ghalat value banti thi. Har hisse ko
            # alag seal samjho (label lafz chor kar).
            for g in groups:
                solo = ENG.norm(g)
                if len(solo) >= 5 and re.search(r"\d", solo) \
                        and solo not in ("SEAL", "SEALNO"):
                    push(seals, solo)
            continue
        line_has_container = False
        i = 0
        while i < len(groups):
            hit = None
            # OCR aksar ek hi number ko space se tor deta hai — 1, 2
            # aur 3 hisse jor kar jaancho aur sab se achi pehchan
            # (score) wala window pakro; barabar par lamba window
            # (poora number) jeet-ta hai.
            best = (0, 0, None, None)       # score, w, kind, val
            # Size/type code (40HC, 20GP...) se shuru hone wala hissa
            # kisi number ka aaghaz nahi hota — use jor ka hisa na banao.
            size_first = re.fullmatch(r"(20|40|45)(GP|HC|HQ|RF|DC|DV|OT|FR)?",
                                      ENG.norm(groups[i]))
            for w in (1, 2, 3):
                if size_first:
                    break
                if i + w > len(groups):
                    continue
                joined = ENG.norm("".join(groups[i:i + w]))
                if len(joined) < 6:
                    continue
                sc, kind, val = classify(joined)
                if w >= 2 and sc < 2:
                    continue  # jor kar sirf pakki pehchan chalegi — "WEIGHT 24500" jaisi aam satr BL nahi banti
                if sc > best[0] or (sc == best[0] and sc > 0 and w > best[1]):
                    best = (sc, w, kind, val)
            if best[0] > 0:
                hit = (best[1], best[2], best[3])
            if hit:
                w, kind, val = hit
                if seal_line:
                    push(seals, val)
                elif kind == "container":
                    push(cons, val)
                    line_has_container = True
                elif kind == "bl":
                    push(bls, val)
                else:
                    push(others, val)
                i += w
                continue
            # kuch pehchana nahi gaya: 6-8 digit ka khaali number
            # container wali line par seal hota hai, warna rehne do.
            solo = ENG.norm(groups[i])
            if solo.isdigit() and 6 <= len(solo) <= 8 and line_has_container:
                push(seals, solo)
            elif seal_line and len(solo) >= 5:
                push(seals, solo)
            i += 1
    numbers = bls + cons + others
    return {"numbers": numbers[:12], "bls": bls,
            "containers": cons, "seals": seals}


def re_find_numbers(text):
    return re_extract_doc_numbers(text)["numbers"]


def main():
    threading.Thread(target=_recheck_loop, daemon=True).start()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    print(f"CargoTrack v48 is running: http://127.0.0.1:{PORT}")
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        print(f"On your phone (same WiFi): http://{s.getsockname()[0]}:{PORT}")
        s.close()
    except Exception:
        pass
    print("To stop CargoTrack, close this window.")
    try:
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
