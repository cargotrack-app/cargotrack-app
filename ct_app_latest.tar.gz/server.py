#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CargoTrack v51 — Web UI server (stdlib only).
Tracking engine: bl_track.py. Data lives outside the app folder:
  ~/CargoTrack_Data/history.json + settings.json
Run:  python server.py   (your browser opens automatically)
"""
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shutil
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as _FutTimeout
import zipfile
from datetime import datetime, date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import urllib.request
import urllib.error

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bl_track as ENG

DATA_DIR = Path.home() / "CargoTrack_Data"
DATA_DIR.mkdir(exist_ok=True)
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
PHOTOS_DIR = DATA_DIR / "photos"
PHOTOS_DIR.mkdir(exist_ok=True)
PORT = 8765
APP_VERSION = 98
APP_BUILT = "30 Oct 2026, 12:04 AM PKT"

_lock = threading.Lock()


def load_json(p, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(p, obj):
    # F-05 fix (v46 audit): write to a temp file, then atomically
    # replace — a crash/power-cut mid-write used to corrupt the file,
    # and load_json then silently returned empty (whole history lost).
    try:
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        os.replace(tmp, p)
        return True
    except Exception:
        return False


APP_DIR = Path(__file__).resolve().parent


def _apply_seed_once():
    """v44 FINAL one-time seed: replace history with the verified 78-BL
    record shipped beside server.py. The old history is first copied to a
    dated backup in the data dir; a marker stops any re-application."""
    seed = APP_DIR / "seed_history.json"
    marker = DATA_DIR / "seed_v44final.done"
    try:
        if seed.exists() and not marker.exists():
            data = load_json(seed, None)
            if isinstance(data, list) and data:
                if HISTORY_FILE.exists():
                    bak = DATA_DIR / "history_backup_2026-10-22.json"
                    if not bak.exists():
                        bak.write_bytes(HISTORY_FILE.read_bytes())
                if save_json(HISTORY_FILE, data):
                    marker.write_text("done", encoding="utf-8")
                    seed.unlink()
    except Exception:
        pass


_apply_seed_once()


def _remove_lock_once():
    """v51 one-time lock removal (Yousuf ka hukm): update package
    ke sath aayi ct_remove_lock.flag server.py ke sath mojood ho
    aur data dir mein marker na ho, to settings se SIRF app_pass
    key hatao — Groq key aur baqi har setting mehfooz rehti hai.
    Marker dobara chalne se rokta hai aur flag file bhi delete
    ho jati hai. Kabhi raise nahi karta."""
    flag = APP_DIR / "ct_remove_lock.flag"
    marker = DATA_DIR / "ct_lock_removed_v51.done"
    try:
        if flag.exists() and not marker.exists():
            s = load_json(SETTINGS_FILE, {})
            if isinstance(s, dict) and "app_pass" in s:
                s.pop("app_pass", None)
                save_json(SETTINGS_FILE, s)
            marker.write_text("done", encoding="utf-8")
            flag.unlink()
    except Exception:
        pass


_remove_lock_once()


def _enrich_history_once():
    """v54/v55 one-time record ENRICH (24 Oct 2026): enrich data
    files mein diye gaye verified fields maujooda entries mein
    sirf wahan bhare jate hain jahan wo khaali hain — koi bhari
    hui field overwrite nahi hoti, siwa un ke jo item ki
    'force' list mein hain (masalan purana placeholder status).
    Entry maujood na ho to nayi bana di jati hai. Har file ka
    apna marker dobara chalne se rokta hai; data file apply ke
    baad delete. Kabhi raise nahi karta.
    v96 (29 Oct 2026): ct_enrich_history_v96.json — data audit
    ki saboot-shuda corrections; item-level 'returned': true
    entry ke empty-return flag ko bhi set kar sakta hai."""
    for _fname, _mname in (
            ("ct_enrich_history.json", "ct_enrich_v54.done"),
            ("ct_enrich_history_v55.json", "ct_enrich_v55.done"),
            ("ct_enrich_history_v66.json", "ct_enrich_v66.done"),
            ("ct_enrich_history_v87.json", "ct_enrich_v87.done"),
            ("ct_enrich_history_v96.json", "ct_enrich_v96.done")):
        data_file = APP_DIR / _fname
        marker = DATA_DIR / _mname
        try:
            if data_file.exists() and not marker.exists():
                raw = load_json(data_file, {})
                items = raw.get("enrich") if isinstance(raw, dict) else raw
                if isinstance(items, list) and items:
                    hist = load_json(HISTORY_FILE, [])
                    if not isinstance(hist, list):
                        hist = []
                    by_q = {(e.get("query") or ""): e for e in hist
                            if isinstance(e, dict)}
                    changed = False
                    for it in items:
                        q = (it.get("query") or "").strip()
                        if not q:
                            continue
                        fill = it.get("result") or {}
                        force = set(it.get("force") or [])
                        e = by_q.get(q)
                        if e is None:
                            now = time.time()
                            stamp = time.strftime(
                                "%d %b %Y, %I:%M %p",
                                time.localtime(now))
                            e = {"query": q, "mode": "bl", "client": "",
                                 "carrier": it.get("carrier", ""),
                                 "prefix": "", "contacts": None,
                                 "amount": "", "received": "",
                                 "returned": "", "notes": "",
                                 "photo": "", "starred": False,
                                 "checklist": {}, "changes": [],
                                 "change_kind": "", "changed": False,
                                 "found": bool(it.get("found")),
                                 "result": dict(fill),
                                 "layers": [{
                                     "name": "Shezi — record update "
                                             "(24 Oct 2026)",
                                     "status": "done",
                                     "detail": "Verified details added "
                                               "by Shezi; recheck in "
                                               "the app for live "
                                               "status."}],
                                 "checked_ts": int(now), "time": stamp,
                                 "first_seen": stamp}
                            if it.get("returned"):
                                e["returned"] = True
                            hist.append(e)
                            by_q[q] = e
                            changed = True
                            continue
                        r = e.get("result")
                        if not isinstance(r, dict):
                            r = {}
                            e["result"] = r
                        for k, v in fill.items():
                            if k in force or r.get(k) in (None, "", []):
                                if r.get(k) != v:
                                    r[k] = v
                                    changed = True
                        if it.get("found") and not e.get("found"):
                            e["found"] = True
                            changed = True
                        # v96: item-level 'returned' — lifecycle
                        # entry ka h['returned'] flag parhta hai;
                        # terminal saboot par empty-return isi se
                        # darj hota hai (data audit round 2).
                        if it.get("returned") and not e.get("returned"):
                            e["returned"] = True
                            changed = True
                        if it.get("carrier") and not e.get("carrier"):
                            e["carrier"] = it["carrier"]
                            changed = True
                    if changed:
                        save_json(HISTORY_FILE, hist)
                marker.write_text("done", encoding="utf-8")
                data_file.unlink()
        except Exception:
            pass


def _merge_extra_history_once():
    """v51 one-time record merge (Yousuf ka hukm, 24 Oct 2026):
    update package ke sath aayi ct_extra_history.json mein jo BL
    records hain, un mein se jo history mein pehle se NAHI hain
    sirf wohi jama karo — maujooda koi entry kabhi overwrite
    nahi hoti. Marker dobara chalne se rokta hai, data file
    apply hone ke baad delete ho jati hai. Kabhi raise nahi
    karta."""
    data_file = APP_DIR / "ct_extra_history.json"
    marker = DATA_DIR / "ct_extra_history_v51.done"
    try:
        if data_file.exists() and not marker.exists():
            raw = load_json(data_file, [])
            entries = raw.get("history") if isinstance(raw, dict) else raw
            if isinstance(entries, list) and entries:
                hist = load_json(HISTORY_FILE, [])
                if not isinstance(hist, list):
                    hist = []
                have = {(e.get("query") or "") for e in hist
                        if isinstance(e, dict)}
                added = [e for e in entries
                         if isinstance(e, dict)
                         and (e.get("query") or "")
                         and (e.get("query") or "") not in have]
                if added:
                    save_json(HISTORY_FILE, hist + added)
            marker.write_text("done", encoding="utf-8")
            data_file.unlink()
    except Exception:
        pass


_merge_extra_history_once()
_enrich_history_once()


def _refresh_history_once():
    """v63 one-time record REFRESH (25 Oct 2026): Yousuf ka
    hukm — tamam records dobara track karke bheje gaye fresh
    records. Shipped entry ka checked_ts stored wale se naya
    ho to SIRF tracking wala hissa (found/result/layers/time/
    checked_ts) badla jata hai; user ke apne fields (starred,
    checklist, notes, client, amount, received, returned,
    photo, first_seen) kabhi nahi chhoote. Status badla ho to
    changes mein darj hota hai. Marker dobara chalne se rokta
    hai; data file apply ke baad delete. Kabhi raise nahi."""
    data_file = APP_DIR / "ct_refresh_history_v63.json"
    marker = DATA_DIR / "ct_refresh_v63.done"
    try:
        if data_file.exists() and not marker.exists():
            raw = load_json(data_file, {})
            items = raw.get("refresh") if isinstance(raw, dict) else raw
            if isinstance(items, list) and items:
                hist = load_json(HISTORY_FILE, [])
                if not isinstance(hist, list):
                    hist = []
                by_q = {(e.get("query") or ""): e for e in hist
                        if isinstance(e, dict)}
                changed = False
                for it in items:
                    q = (it.get("query") or "").strip()
                    if not q:
                        continue
                    e = by_q.get(q)
                    if e is None:
                        continue  # refresh sirf maujooda records ke liye
                    if int(it.get("checked_ts") or 0) <= int(
                            e.get("checked_ts") or 0):
                        continue
                    old_status = (e.get("result") or {}).get(
                        "status") or ""
                    e["found"] = bool(it.get("found"))
                    e["result"] = it.get("result") or {}
                    e["layers"] = it.get("layers") or []
                    e["time"] = it.get("time") or e.get("time")
                    e["checked_ts"] = int(it.get("checked_ts") or 0)
                    new_status = (e["result"] or {}).get("status") or ""
                    if new_status != old_status:
                        ch = e.get("changes")
                        if not isinstance(ch, list):
                            ch = []
                            e["changes"] = ch
                        ch.append({"from": old_status,
                                   "to": new_status,
                                   "time": e["time"]})
                        e["changed"] = True
                        e["change_kind"] = "status"
                    changed = True
                if changed:
                    save_json(HISTORY_FILE, hist)
            marker.write_text("done", encoding="utf-8")
            data_file.unlink()
    except Exception:
        pass


_refresh_history_once()


def get_history():
    h = load_json(HISTORY_FILE, [])
    if not isinstance(h, list):
        return []
    return [_migrate_entry(x) for x in h]


# ---------------- v49: bundled OCR engine + BL record extractor ------------
# Photo scan ab app ke ANDAR band engine (RapidOCR/onnxruntime)
# se chalta hai — Tesseract ki koi zaroorat nahi. Har scan ek
# chhote subprocess mein hota hai taake model ki memory scan ke
# baad khali ho jaye.
# v50: engine do jagah mil sakta hai — (a) app ke sath aya
# ocr/venv, ya (b) ocr/pylibs, jo pehli scan par ONE-TIME
# AUTO-SETUP khud bana deta hai (ocr/setup_state.json +
# ocr/setup.log dekho). Is liye bilkul nayi machine (fresh
# server / fresh laptop) par bhi user ko kuch install nahi
# karna parta: pehli photo par setup chand minute mein khud
# ho jata hai, agli scans seedha chalti hain.
# Extractor ke usool Yousuf ki 43 BL photos se seekhe gaye hain
# (~/workspace/bl-formats-learned.md): BL number hamesha LABEL ke
# paas se; booking/S-O/serial kabhi BL nahi; container ISO check
# digit se; seal kabhi BL nahi; PROFORMA par BL hota hi nahi.
OCR_DIR = BASE / "ocr"
OCR_PYLIBS = OCR_DIR / "pylibs"
OCR_BOOTSTRAP_DIR = OCR_DIR / "_bootstrap"
OCR_SETUP_STATE = OCR_DIR / "setup_state.json"
OCR_SETUP_LOG = OCR_DIR / "setup.log"
# v86 (system fix): scan engine ab MUSTAQIL shared jagah par —
# DATA_DIR ke sath "ocr_engine". Pehle engine har version ke
# folder ke andar banta tha; har naya version = engine gayab =
# 450MB setup dobara, aur setup adhura rahe to scan khamoshi
# se sirf-AI-vision par gir jata tha (I/1 ghalti ki jar). Ab
# ek dafa bana engine har version istemal karega.
OCR_SHARED = DATA_DIR / "ocr_engine"
OCR_SHARED_PYLIBS = OCR_SHARED / "pylibs"
OCR_SHARED_STATE = OCR_SHARED / "setup_state.json"
OCR_SHARED_LOG = OCR_SHARED / "setup.log"
OCR_SETUP_MSG = ("Photo-scan engine is being set up on this device "
                 "(one-time setup, a few minutes). Please try again "
                 "shortly.")
OCR_FAILED_MSG = ("Photo-scan engine setup could not be completed "
                  "on this device. Please check the internet "
                  "connection and try again later.")
_ocr_cache = {"py": None, "env": None, "ts": 0.0}
_ocr_setup = {"proc": None}
_ocr_setup_lock = threading.Lock()


def _ocr_probe(py, env_extra=None):
    """Ek interpreter par rapidocr import ki quick jaanch.
    env_extra (masalan PYTHONPATH=ocr/pylibs) subprocess ko milta
    hai. File na ho / import fail ho to False."""
    import subprocess
    if not py or not os.path.isfile(py):
        return False
    env = None
    if env_extra:
        env = dict(os.environ)
        for k, v in env_extra.items():
            if k == "PYTHONPATH" and env.get("PYTHONPATH"):
                env[k] = v + os.pathsep + env["PYTHONPATH"]
            else:
                env[k] = v
    try:
        r = subprocess.run([py, "-c", "import rapidocr_onnxruntime"],
                           capture_output=True, timeout=60, env=env)
        return r.returncode == 0
    except Exception:
        return False


def _ocr_resolve(force=False):
    """Engine resolution: (python_path, env_extra) ya (None, None).
    Order: (0) CT_OCR_PYTHON override, (1) app ka ocr/venv —
    bilkul waisa hi jaisa v49 mein tha, (2) ocr/pylibs app ke
    apne Python (sys.executable) + PYTHONPATH ke sath,
    (3) yehi Python agar us mein rapidocr pehle se mojood ho,
    (4) developer machine ka ocrvenv.
    Kaamyab resolution hamesha cached; na-kaam sirf 20 second
    cached taake har request par mehngi probe na chale aur
    auto-setup ke baad engine foran mil jaye."""
    now = time.time()
    if _ocr_cache["py"]:
        return _ocr_cache["py"], _ocr_cache["env"]
    if not force and now - _ocr_cache["ts"] < 20:
        return None, None
    cands = []
    env_py = os.environ.get("CT_OCR_PYTHON")
    if env_py:
        cands.append((env_py, None))
    cands.append((str(OCR_DIR / "venv" / (
        "Scripts/python.exe" if os.name == "nt" else "bin/python")),
        None))
    if OCR_SHARED_PYLIBS.is_dir():
        cands.append((sys.executable,
                      {"PYTHONPATH": str(OCR_SHARED_PYLIBS)}))
    if OCR_PYLIBS.is_dir():
        cands.append((sys.executable,
                      {"PYTHONPATH": str(OCR_PYLIBS)}))
    cands.append((sys.executable, None))
    cands.append((str(Path.home() / "workspace" / "ocrvenv"
                      / "bin" / "python"), None))
    py = envx = None
    seen = set()
    for c, e in cands:
        key = (c, (e or {}).get("PYTHONPATH", ""))
        if key in seen:
            continue
        seen.add(key)
        if _ocr_probe(c, e):
            py, envx = c, e
            break
    _ocr_cache.update(py=py, env=envx, ts=now)
    return py, envx


def _ocr_python():
    """OCR engine ka Python (path) ya None. Baqi callers ise
    sirf ready / not-ready jaanch ke liye istemal karte hain;
    asal scan _run_ocr_items se hota hai jo env bhi sambhalta
    hai (pylibs wale raste par PYTHONPATH chahiye hota hai)."""
    return _ocr_resolve()[0]


# ------------- v51: one-time OCR auto-setup (detached worker) -------------
# Nayi machine par na ocr/venv hota hai na aksar python3-venv /
# ensurepip (Debian/Ubuntu unhein neuter kar dete hain) — is
# liye setup venv par NAHI, sirf stdlib par chalta hai:
#   1. PyPI JSON API se pip ka latest stable wheel download
#      karke ocr/_bootstrap/ mein unzip karo (wheel khud ek
#      zip hai; unzip ki hui pip `python -m pip` se chalti hai).
#   2. Usi pip se ocr/requirements.txt ko ocr/pylibs mein
#      --target install karo (system Python ko haath nahi
#      lagta, --break-system-packages PEP 668 wale servers ke
#      liye hai jahan --target bhi kabhi rok diya jata hai).
#   3. cv2 import probe: GUI-wali opencv-python aa gayi ho aur
#      headless server par import fail ho (libGL nahi hoti)
#      to cv2 ke package dirs saaf karke SIRF headless dobara
#      install karo, phir dobara probe karo.
#   4. Asal probe: app ke Python se pylibs import karke dekho.
# v51 tabdeeli: asal kaam ab ocr/setup_worker.py karta hai —
# server use DETACHED process (start_new_session=True) mein
# chalata hai taake app/service ka restart setup ko beech
# mein na mar sake. Halat ocr/setup_state.json mein, tafseel
# ocr/setup.log mein (aakhri lines state ke 'log_tail' mein
# bhi mehfooz hoti hain taake failure ki wajah app ke error
# mein nazar aaye). Fail ho jaye to 120 second baad agli scan
# par NAYI koshish ho sakti hai — purani "ek server-run mein
# sirf ek koshish" wali rok khatam; retry loop phir bhi nahi,
# har koshish user ki scan se hi shuru hoti hai.


def _ocr_state_path():
    return OCR_SHARED_STATE if OCR_SHARED_STATE.exists() \
        else OCR_SETUP_STATE


def _ocr_log_path():
    return OCR_SHARED_LOG if OCR_SHARED_LOG.exists() \
        else OCR_SETUP_LOG


def _ocr_setup_state():
    st = load_json(_ocr_state_path(), None)
    return st if isinstance(st, dict) else {"state": "idle"}


def _ocr_setup_log(msg):
    try:
        OCR_SHARED.mkdir(parents=True, exist_ok=True)
        with open(OCR_SHARED_LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S  ")
                    + str(msg) + "\n")
    except Exception:
        pass


def _ocr_set_setup_state(**kw):
    st = _ocr_setup_state()
    st.update(kw)
    try:
        OCR_SHARED.mkdir(parents=True, exist_ok=True)
        OCR_SHARED_STATE.write_text(json.dumps(st, indent=1),
                                    encoding="utf-8")
    except Exception:
        pass


def _ocr_setup_pid_alive(st):
    """state file mein darj worker pid zinda hai ya nahi.
    Server restart ke baad bhi yehi jaanch kaam karti hai —
    Popen handle to restart mein kho jata hai, pid rehta hai."""
    try:
        pid = int(st.get("pid") or 0)
    except Exception:
        pid = 0
    if pid <= 0:
        return False
    if os.name == "nt":
        # Windows par os.kill(pid, 0) doosre process ko signal
        # bhej sakta hai — wahan sirf apne spawn kiye huwe
        # handle par bharosa karo.
        p = _ocr_setup.get("proc")
        return p is not None and p.poll() is None
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _ocr_log_tail(n=15):
    """ocr/setup.log ki aakhri n saaf lines (timestamp hata
    kar) — failure ki wajah dhoondhne ke liye."""
    try:
        lines = _ocr_log_path().read_text(
            encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    out = []
    for ln in lines[-max(n * 3, n):]:
        ln = ln.strip()
        m = re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\s+",
                     ln)
        if m:
            ln = ln[m.end():].strip()
        if ln:
            out.append(ln)
    return out[-n:]


def _ocr_failed_msg():
    """Setup fail hone par saaf error + asal wajah ki ek line
    (state ke log_tail se, warna setup.log se, warna state ke
    error se) — taake user ka screenshot hi diagnosis ke liye
    kaafi ho. Wajah ~200 chars par trim hoti hai."""
    reason = ""
    st = _ocr_setup_state()
    tail = st.get("log_tail")
    if isinstance(tail, list) and tail:
        reason = str(tail[-1]).strip()
    if not reason:
        t2 = _ocr_log_tail(15)
        if t2:
            reason = t2[-1]
    if not reason:
        reason = str(st.get("error") or "").strip()
    reason = re.sub(r"\s+", " ", reason).strip()
    if len(reason) > 200:
        reason = reason[:197].rstrip() + "..."
    if reason:
        return OCR_FAILED_MSG + f" (Reason: {reason})"
    return OCR_FAILED_MSG


_ocr_pylibs_size = {"mb": 0.0, "ts": 0.0}


def _ocr_pylibs_mb():
    """ocr/pylibs ka size MB mein (5s cache — hazaaron files
    ki walk har poll par mehngi parti hai)."""
    now = time.time()
    if _ocr_pylibs_size["mb"] and \
            now - _ocr_pylibs_size["ts"] < 5:
        return _ocr_pylibs_size["mb"]
    total = 0
    try:
        for _base in (OCR_SHARED_PYLIBS, OCR_PYLIBS):
            for root, _dirs, files in os.walk(_base):
                for fn in files:
                    try:
                        total += os.path.getsize(
                            os.path.join(root, fn))
                    except OSError:
                        pass
    except Exception:
        pass
    _ocr_pylibs_size.update(mb=round(total / 1048576.0, 1),
                            ts=now)
    return _ocr_pylibs_size["mb"]


def _ocr_setup_activity(tail):
    """setup.log ki aakhri lines se insaani jumla: abhi kya
    ho raha hai (konsa package download/install ho raha
    hai) — taake user ko andhere mein intezar na pare."""
    for ln in reversed(tail or []):
        s = str(ln).strip()
        m = re.search(r"Downloading\s+(\S+?)-(\d[\d.]*)-", s)
        if m:
            sz = re.search(r"\(([\d.]+\s*[MG]B)\)", s)
            return ("Downloading " +
                    m.group(1).replace("_", "-") +
                    (" (" + sz.group(1) + ")" if sz else ""))
        m = re.search(r"Collecting\s+(\S+)", s)
        if m:
            return "Collecting " + m.group(1)
        if "Installing collected packages" in s:
            return "Installing the downloaded packages"
        if "Successfully installed" in s:
            return "Install complete — final check running"
        if "setup READY" in s:
            return "Setup complete"
    if tail:
        return str(tail[-1]).strip()[:120]
    return "Starting"


def _ocr_setup_status():
    """Photo-scan setup ki LIVE halat (v52): state, kitna
    waqt huwa, abhi kya ho raha hai, kitne MB aa gaye,
    kitni koshishein huin, fail ho to wajah. Yousuf ki
    hidayat par — setup ka saboot app ke andar nazar aaye,
    user ko ocr folder ki files na kholni paren."""
    st = _ocr_setup_state()
    ready = False
    try:
        ready = bool(_ocr_python())
    except Exception:
        ready = False
    state = str(st.get("state") or "idle")
    if ready:
        state = "ready"
    tail = _ocr_log_tail(15)
    elapsed = None
    if state == "running":
        try:
            t0 = datetime.fromisoformat(
                str(st.get("started") or "")).timestamp()
            elapsed = max(0, int(time.time() - t0))
        except Exception:
            elapsed = None
    reason = ""
    if state == "failed":
        t = st.get("log_tail")
        if isinstance(t, list) and t:
            reason = str(t[-1]).strip()
        if not reason and tail:
            reason = str(tail[-1]).strip()
        if not reason:
            reason = str(st.get("error") or "").strip()
        reason = re.sub(r"\s+", " ", reason)[:200]
    return {
        "state": state,
        "engine_ready": ready,
        "started": st.get("started") or "",
        "finished": st.get("finished") or "",
        "elapsed_s": elapsed,
        "attempts": int(st.get("attempts") or 0),
        "activity": (_ocr_setup_activity(tail)
                     if state in ("running", "failed")
                     else ("Setup complete"
                           if state == "ready" else "")),
        "pylibs_mb": _ocr_pylibs_mb(),
        "log_tail": [str(x)[:160] for x in tail[-3:]],
        "reason": reason,
    }


def _ocr_trigger_setup():
    """Detached setup worker chalao agar zaroorat ho.
    Return 'running' (chal raha hai / abhi shuru huwa) ya
    'failed' (haal hi mein fail huwa — 120 second ke andar
    dobara koshish nahi; us ke baad agli scan par nayi
    koshish khud ho jayegi)."""
    import subprocess
    with _ocr_setup_lock:
        st = _ocr_setup_state()
        state = st.get("state")
        if state == "running":
            if _ocr_setup_pid_alive(st):
                return "running"
            state = "failed"   # worker beech mein mar gaya
        if state == "failed":
            fin = 0.0
            try:
                fin = datetime.fromisoformat(
                    str(st.get("finished") or "")).timestamp()
            except Exception:
                fin = 0.0
            if fin and time.time() - fin <= 120:
                return "failed"
        try:
            OCR_DIR.mkdir(parents=True, exist_ok=True)
            OCR_SHARED.mkdir(parents=True, exist_ok=True)
            lf = open(OCR_SHARED_LOG, "a", encoding="utf-8")
            _env = dict(os.environ)
            _env["CT_OCR_DIR"] = str(OCR_SHARED)
            proc = subprocess.Popen(
                [sys.executable,
                 str(OCR_DIR / "setup_worker.py")],
                cwd=str(BASE), stdout=lf, env=_env,
                stderr=subprocess.STDOUT,
                start_new_session=True)
            _ocr_setup["proc"] = proc
            _ocr_set_setup_state(
                state="running",
                started=datetime.now().isoformat(
                    timespec="seconds"),
                pid=proc.pid, error="",
                attempts=int(st.get("attempts") or 0) + 1)
            return "running"
        except Exception:
            return "failed"


def _run_ocr_items(img_path):
    """OCR subprocess: (result_dict, None) ya (None, wajah).
    result = {"items":[{box,text,score}], "w":W, "h":H}
    Engine kahin na mile (na ocr/venv, na ocr/pylibs) to one-time
    auto-setup background mein shuru ho jata hai aur client ko
    'setting up' wala saaf jawab milta hai — koi traceback ya
    install ki hidayat user ko nahi dikhti."""
    import subprocess
    py, envx = _ocr_resolve()
    if not py:
        if _ocr_trigger_setup() == "running":
            return None, OCR_SETUP_MSG
        return None, _ocr_failed_msg()
    env = None
    if envx:
        env = dict(os.environ)
        for k, v in envx.items():
            if k == "PYTHONPATH" and env.get("PYTHONPATH"):
                env[k] = v + os.pathsep + env["PYTHONPATH"]
            else:
                env[k] = v
    try:
        out = subprocess.run(
            [py, str(OCR_DIR / "ocr_runner.py"), str(img_path)],
            capture_output=True, timeout=120, env=env)
    except subprocess.TimeoutExpired:
        return None, ("Photo scanning took too long — please try a "
                      "clearer, closer photo.")
    except Exception as e:
        return None, str(e)
    txt = out.stdout.decode("utf-8", "replace").strip()
    d = None
    for line in reversed(txt.splitlines()):
        try:
            d = json.loads(line)
            break
        except Exception:
            continue
    if not d or d.get("error") or "items" not in d:
        return None, ("OCR could not read that photo — please try a "
                      "clearer, closer photo.")
    return d, None


def _sq(s):
    """Squash: sirf A-Z0-9 — OCR ke space/punctuation jhanjhat se azad."""
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def _it_cx(it):
    b = it["box"]
    return (b[0][0] + b[2][0]) / 2.0


def _it_cy(it):
    b = it["box"]
    return (b[0][1] + b[2][1]) / 2.0


def _ocr_lines(items, page_h):
    """OCR items ko reading lines mein joro (y qareeb = ek line)."""
    its = sorted(items, key=lambda i: (_it_cy(i), _it_cx(i)))
    heights = sorted((i["box"][2][1] - i["box"][0][1]) for i in its)
    med = heights[len(heights) // 2] if heights else 20
    tol = max(9.0, med * 0.72)
    lines = []
    for it in its:
        cy = _it_cy(it)
        if lines and abs(cy - lines[-1]["cy"]) <= tol:
            lines[-1]["items"].append(it)
            n = len(lines[-1]["items"])
            lines[-1]["cy"] = (lines[-1]["cy"] * (n - 1) + cy) / n
        else:
            lines.append({"cy": cy, "items": [it]})
    for ln in lines:
        ln["items"].sort(key=_it_cx)
        ln["text"] = " ".join(i["text"] for i in ln["items"])
        ln["squash"] = _sq(ln["text"])
    return lines


# Carrier BL formats — bl-formats-learned.md se. Kuch jagah digit
# ginti document ke asal number se milti rakhi hai (Monter ke 8-10,
# KMTC ke 7-8, RCL ke 8-9) warna asal BL hi miss ho jata.
_BL_PATTERNS = [
    (r"EMKAYMBAKHI\d{5}", "Emkay Line"),
    (r"\d{3}G\d{6,7}", "Wan Hai Lines"),
    (r"C[O0]AU\d{10}", "COSCO Shipping"),
    (r"[O0]{2}LU\d{10}", "OOCL"),
    (r"MEDU[TS]\d{7}", "MSC"),
    (r"YMJAS\d{9}", "Yang Ming"),
    (r"KMTC[A-Z]{3}\d{7,8}", "KMTC Line"),
    (r"PELMSA[A-Z]{6}\d{6}", "Prolog Express Line (PEL)"),
    (r"MBAQITS\d{10}", "RTW Shipping & Logistics"),
    (r"STS[A-Z]{3,}\d{5}", "Star Lines"),
    (r"BAL[A-Z]{3,}\d{7}", "Baltic Lines"),
    (r"FRL[A-Z]{3,}\d{6}", "Feeder Logistics DMCC"),
    (r"EMA[A-Z]{3,}\d{6}", "EM-A Shipping"),
    (r"SGS\d{4}SINKHI\d?", "SeaGem Shipping"),
    (r"SSL[A-Z]{3,}\d{4,}", "Samudera Shipping Line"),
    (r"MCL[A-Z]{3}\d{8,10}", "Monter Container Line"),
    (r"HAICB\d{8,9}", "RCL (Regional Container Lines)"),
]

_LETTERHEAD_CARRIERS = [
    ("MAXTOP", "MAXTOP Logistics"),
    ("MONTER", "Monter Container Line"),
    ("MEDITERRANEANSHIPPING", "MSC"),
    ("NEWGOLDENSEA", "COSCO Shipping"),
    ("ORIENTOVERSEAS", "OOCL"),
    ("KOREAMARINE", "KMTC Line"),
    ("PROLOGEXPRESS", "Prolog Express Line (PEL)"),
    ("SEAGEM", "SeaGem Shipping"),
    ("SAMUDERA", "Samudera Shipping Line"),
    ("FEEDERLOGISTICS", "Feeder Logistics DMCC"),
    ("REGIONALCONTAINER", "RCL (Regional Container Lines)"),
    ("YANGMING", "Yang Ming"),
    ("WANHAI", "Wan Hai Lines"),
    ("BALTICLINES", "Baltic Lines"),
    ("STARLINES", "Star Lines"),
    ("EMKAY", "Emkay Line"),
    ("MAERSK", "Maersk"),
]


def _bl_pattern_fix(m, pat):
    """OCR ki 0/O ghalti prefix mein theek karo (0OLU -> OOLU)."""
    if pat in (r"C[O0]AU\d{10}", r"[O0]{2}LU\d{10}"):
        head = m[:4].replace("0", "O")
        return head + m[4:]
    return m


_MONTHS = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
           "JUL": 7, "AUG": 8, "SEP": 9, "SEPT": 9, "OCT": 10,
           "NOV": 11, "DEC": 12,
           "JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4,
           "JUNE": 6, "JULY": 7, "AUGUST": 8, "SEPTEMBER": 9,
           "OCTOBER": 10, "NOVEMBER": 11, "DECEMBER": 12}
_MONTH_ABBR = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
               "Aug", "Sep", "Oct", "Nov", "Dec"]


def _norm_date(s):
    """Date wali string ko '18 Sep 2026' banao; na bane to raw."""
    t = (s or "").strip().upper().replace(",", " ")
    m = re.search(r"(\d{1,2})[-/. ](\d{1,2})[-/. ](\d{2,4})", t)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return f"{d:02d} {_MONTH_ABBR[mo]} {y}"
    m = re.search(r"(\d{1,2})[-/. ]([A-Z]{3,9})[-/. ](\d{2,4})", t)
    if m:
        mon = _MONTHS.get(m.group(2)) or _MONTHS.get(m.group(2)[:3])
        if mon:
            d, y = int(m.group(1)), int(m.group(3))
            if y < 100:
                y += 2000
            return f"{d:02d} {_MONTH_ABBR[mon]} {y}"
    m = re.search(r"([A-Z]{3,9})\.?\s+(\d{1,2})\s+(\d{4})", t)
    if m and m.group(1) in _MONTHS:
        return (f"{int(m.group(2)):02d} "
                f"{_MONTH_ABBR[_MONTHS[m.group(1)]]} {m.group(3)}")
    m = re.search(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", t)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12:
            return f"{d:02d} {_MONTH_ABBR[mo]} {y}"
    return (s or "").strip()


_DATE_RE = (r"\d{1,2}[-/. ](?:\d{1,2}|[A-Z]{3,9})[-/. ]\d{2,4}"
            r"|[A-Z]{3,9}\.?\s+\d{1,2},?\s+\d{4}"
            r"|\d{4}[-/.]\d{1,2}[-/.]\d{1,2}")


def _num_or_blank(s):
    """'54,108.000' -> 54108 (int); na bane to ''."""
    if s is None:
        return ""
    t = str(s).replace(",", "").replace(" ", "").strip()
    try:
        f = float(t)
    except Exception:
        return ""
    return int(f) if f == int(f) else f


_LABEL_KEYS = [
    ("bl", ("BILLOFLADINGNO", "BLNO")),
    ("booking", ("BOOKINGNO", "BOOKINGREF")),
    ("sono", ("SONO",)),
    ("serial", ("SERIALNO",)),
    ("reference", ("SHIPMENTREFERENCE", "CARRIERSREFERENCE",
                   "CARRIERREFERENCE", "EXPORTREFERENCE",
                   "SHIPPERSREF", "SHIPPERREFERENCE")),
    ("shipper", ("SHIPPER",)),
    ("consignee", ("CONSIGNEE", "CONSIGNED")),
    ("notify", ("NOTIFY",)),
    ("vessel", ("VESSEL",)),
    ("voyage", ("VOYAGE", "VOYNO")),
    ("pol", ("PORTOFLOADING",)),
    ("pod", ("PORTOFDISCHARGE", "PORTOFLANDING")),
    ("receipt", ("PLACEOFRECEIPT", "PLACEOFACCEPTANCE")),
    ("delivery", ("PLACEOFDELIVERY", "PLACEOFFINALDELIVERY")),
    ("tranship", ("TRANSHIPMENT", "TRANSSHIPMENT")),
    ("issue", ("DATEOFISSUE", "PLACEANDDATEOFISSUE")),
    ("containers", ("CONTAINER",)),
    ("goods", ("DESCRIPTION", "PARTICULARS")),
    ("gross", ("GROSSWEIGHT", "GROSSWT")),
    ("net", ("NETWEIGHT", "NETTWEIGHT", "NETWT")),
    ("measure", ("MEASUREMENT",)),
    ("freight", ("FREIGHT",)),
    ("marks", ("MARKSAND", "MARKS")),
    ("seal", ("SEAL",)),
]


def _item_label_kind(it):
    """Ek OCR item kis label ka hai (ya None)."""
    sq = _sq(it["text"])
    if not sq:
        return None
    if "CONSIGNEE" in sq:
        return "consignee"  # lamba negotiable wala label bhi yahi hai
    for kind, keys in _LABEL_KEYS:
        for k in keys:
            if k in sq:
                if kind == "shipper" and (
                        "LOAD" in sq or "STOW" in sq
                        or len(sq) > 26):
                    continue  # SHIPPER'S LOAD... party nahi hai
                if kind == "bl" and "FOROCEAN" in sq:
                    continue  # document ka title, number box nahi
                return kind
    return None


def _line_label_kinds(ln):
    return {k for k in (_item_label_kind(i) for i in ln["items"]) if k}


def extract_bl_record(items, page_w, page_h):
    """OCR items se mukammal BL record.
    (record, meta) — meta mein extractor ki androoni maloomat
    (excluded values waghera) jo API jawab mein nahi jati."""
    W = float(page_w or 1000)
    H = float(page_h or 1400)
    lines = _ocr_lines(items, H)
    full_sq = "".join(_sq(i["text"]) for i in
                      sorted(items, key=lambda i: (_it_cy(i), _it_cx(i))))
    warnings = []
    rec = {"bl_no": "", "containers": [], "carrier": "", "vessel": "",
           "voyage": "", "shipper": "", "consignee": "", "pol": "",
           "pod": "", "ts_port": "", "on_board": "", "issue_date": "",
           "goods": "", "packages": "", "gross_kg": "", "net_kg": "",
           "cbm": "", "freight": "", "free_days": "", "proforma": False}

    # ---- 1) labels aur un ke paas wale values (claiming) ----
    labels = []       # (kind, cx, cy)
    for ln in lines:
        for it in ln["items"]:
            k = _item_label_kind(it)
            if k in ("bl", "booking", "sono", "serial", "reference"):
                labels.append((k, _it_cx(it), _it_cy(it), it))
    # glued label+value ek hi item mein (masalan "B/LNoYMJAS430202944",
    # "S/O No: KCT60910727") — pehle yahi se pakro
    inline_bl, inline_excl = "", set()
    for it in items:
        t = it["text"]
        m = re.search(r"(?i)B\s*/\s*L\s*\.?\s*NO\.?\s*:?\s*"
                      r"([A-Z0-9][A-Z0-9\-]{5,19})$", t.strip())
        if m and not inline_bl:
            inline_bl = _sq(m.group(1))
        m = re.search(r"(?i)S\s*/\s*O\s*\.?\s*NO\.?\s*:?\s*"
                      r"([A-Z0-9][A-Z0-9\-]{3,19})", t)
        if m:
            inline_excl.add(_sq(m.group(1)))
    cands = []        # (squash, cx, cy)
    for it in items:
        sq = _sq(it["text"])
        if 6 <= len(sq) <= 20 and re.search(r"\d", sq) \
                and not _item_label_kind(it):
            cands.append((sq, _it_cx(it), _it_cy(it)))
    # Jis label ki value usi item mein ghuli ho (masalan
    # "S/O No: KCT60910727") wo label geometric claiming mein
    # hissa nahi leta — warna wo paas wala asal BL bhi hadap
    # karke use exclusion mein daal deta hai (Wan Hai par huwa).
    def _label_has_inline(k, it):
        sq = _sq(it["text"])
        for kk in ("BILLOFLADINGNO", "BLNO", "BOOKINGNO",
                   "BOOKINGREF", "SONO", "SERIALNO",
                   "SHIPMENTREFERENCE", "CARRIERSREFERENCE",
                   "CARRIERREFERENCE", "EXPORTREFERENCE",
                   "SHIPPERSREF", "SHIPPERREFERENCE"):
            sq = sq.replace(kk, "", 1) if sq.startswith(kk) else sq
        return len(sq) >= 4 and bool(re.search(r"\d", sq))

    # Claiming: har candidate apne QAREEB TAREEN label ko jata
    # hai; BL label sirf tab jeet-ta hai jab wo taqreeban utna hi
    # qareeb ho (warna PROFORMA par booking number BL label hadap
    # leta hai, aur Wan Hai par S/O asal BL ko exclusion mein
    # daal deta hai).
    raw_pairs = []
    for li, (k, lx, ly, _it) in enumerate(labels):
        if k != "bl" and _label_has_inline(k, _it):
            continue
        for ci, (sq, cx, cy) in enumerate(cands):
            dx = abs(cx - lx) / W
            dy = abs(cy - ly) / H
            if dx < 0.36 and dy < 0.065:
                raw_pairs.append((dx + dy, li, ci))
    best_for_c = {}
    for d, li, ci in raw_pairs:
        if ci not in best_for_c or d < best_for_c[ci]:
            best_for_c[ci] = d
    pairs = []
    for d, li, ci in raw_pairs:
        k = labels[li][0]
        prio = 0 if (k == "bl" and d <= best_for_c[ci] + 0.02) else 1
        pairs.append((prio, d, li, ci))
    pairs.sort()
    claimed_c, claimed_l = {}, {}
    for _p, _d, li, ci in pairs:
        if li in claimed_l or ci in claimed_c:
            continue
        claimed_l[li] = ci
        claimed_c[ci] = li
    excluded_soft, excluded_hard = set(inline_excl), set(inline_excl)
    label_bl_value = ""
    bl_label_seen = booking_seen = False
    for li, (k, _x, _y, _it) in enumerate(labels):
        if k == "bl":
            bl_label_seen = True
            if li in claimed_l:
                label_bl_value = cands[claimed_l[li]][0]
        elif k == "booking":
            booking_seen = True
            if li in claimed_l:
                excluded_soft.add(cands[claimed_l[li]][0])
        elif li in claimed_l:
            excluded_hard.add(cands[claimed_l[li]][0])
    if inline_bl:
        label_bl_value = inline_bl

    # ---- 2) containers (ISO + check digit) aur seals ----
    stream = []       # (token_raw, line_idx)
    for li, ln in enumerate(lines):
        for it in ln["items"]:
            for tok in re.split(r"[\s/,;()]+", it["text"]):
                tok = tok.strip(".:")
                if tok:
                    stream.append((tok, li, it))
    cont_hits = []    # (stream_idx, number, check_ok, item)
    seen_cont = set()
    for si, (tok, li, it) in enumerate(stream):
        if re.search(r"\d{1,2}-\d{1,2}-\d{2,4}", tok) \
                or "DATED" in _sq(it["text"]):
            continue  # date wala token container nahi ho sakta
        if "-" in tok:
            continue  # hyphen wala number seal hota hai (ML-KE…),
            # container kabhi hyphen ke sath nahi chhupta
        sq = _sq(tok)
        for m in re.finditer(r"[A-Z]{4}\d{7}", sq):
            num = m.group(0)
            if num[:4] == "CODE":
                continue  # "HS CODE 0909..." ghul kar bana hua jhoota
                # container — asal prefix CODE kabhi nahi hota
            ok = _iso_ok(num)
            if not ok:
                rep = _iso_repair(num)
                if rep:
                    num, ok = rep, True
            if num in seen_cont:
                continue
            if not ok:
                ctx = (it["text"] + " " + lines[li]["text"]).upper()
                if not ("CONTAINER" in ctx or "SEAL" in ctx
                        or re.search(r"(20|40|45)\s?'?\s?"
                                     r"(GP|HC|HQ|SD|DC|DV|RF|G1)", ctx)):
                    continue  # check digit fail + context bhi nahi — fazool
            seen_cont.add(num)
            cont_hits.append((si, num, ok, it))
    cont_pos = {si for si, _n, _o, _i in cont_hits}

    def _size_of(it, li):
        ctx = it["text"] + " " + lines[li]["text"]
        m = re.search(r"(20|40|45)\s?'?\s?(GP|HC|HQ|SD|DC|DV|RF|G1|G2)",
                      ctx.upper())
        return (m.group(1) + m.group(2)) if m else ""

    cont_numbers = {n for _s, n, _o, _i in cont_hits}
    # Seals: har container ki apni line ya agli 2 lines mein pehla
    # seal-numa token. Raw token mein '.' ya ',' ho to wo weight ka
    # tukra hai, seal nahi. Date wala token bhi seal nahi.
    line_tokens = []
    for ln in lines:
        toks = []
        for it in ln["items"]:
            for tok in re.split(r"[\s/,;()]+", it["text"]):
                tok = tok.strip(".:")
                if tok:
                    toks.append(tok)
        line_tokens.append(toks)

    def _seal_shape(tok):
        if "." in tok or "," in tok:
            return ""
        raw = tok.upper()
        sq = _sq(tok)
        if sq.startswith("DATED"):
            return ""
        if re.fullmatch(r"ML-[A-Z]{2}\d{5,}", raw):
            return raw  # ML-KE0272798 — hyphen ke sath asal shakal
        if re.fullmatch(r"[A-Z]{2,6}\d{4,8}", sq):
            return sq
        m = re.search(r"(?:20|40|45)(?:GP|HC|HQ|SD|DC|DV|RF|G1|G2)"
                      r"\d{0,2}([A-Z]{4}\d{5,8})$", sq)
        if m:
            return m.group(1)  # size ke sath ghula seal:
            # "40SD96WHAD001536" -> WHAD001536
        return ""

    def _seal_ok(sq, raw=""):
        if not sq or sq == label_bl_value \
                or sq in excluded_hard or sq in excluded_soft \
                or sq in cont_numbers:
            return False
        if "-" in raw:
            return True  # hyphen wala number seal hi hota hai,
            # container kabhi hyphen ke sath nahi chhupta
        return not re.fullmatch(r"[A-Z]{4}\d{7}", sq) \
            and not any(re.fullmatch(p, sq)
                        for p, _c in _BL_PATTERNS)

    containers = []
    used_seals = set()
    for si, num, ok, it in cont_hits:
        li = next(l for l, ln in enumerate(lines)
                  if it in ln["items"])
        seal = ""
        for j in range(li, min(li + 3, len(lines))):
            for tok in line_tokens[j]:
                s = _seal_shape(tok)
                if s and _seal_ok(s, tok) and s not in used_seals:
                    seal = s
                    break
            if seal:
                break
        if seal:
            used_seals.add(seal)
        containers.append({"no": num, "seal": seal,
                           "type": _size_of(it, li), "check_ok": ok})
        if not ok:
            warnings.append(f"Container {num}: check digit could not "
                            "be verified — please confirm the number.")
    seal_hits = []
    for j, toks in enumerate(line_tokens):
        if "SEAL" in lines[j]["squash"]:
            for tok in toks:
                s = _seal_shape(tok) or (
                    _sq(tok) if re.fullmatch(r"\d{5,8}", _sq(tok))
                    and "." not in tok and "," not in tok else "")
                if s and _seal_ok(s, tok) and s not in used_seals:
                    seal_hits.append((j, s))
    for _j, s in seal_hits:
        warnings.append(f"Seal {s} was read but could not be "
                        "paired with a container.")
    rec["containers"] = containers
    seal_numbers = {s for _j, s in seal_hits} \
        | {c["seal"] for c in containers if c["seal"]}

    # ---- 3) BL number: label wala pehle, phir carrier formats ----
    def _bl_sane(v):
        return bool(v) and v not in cont_numbers \
            and v not in seal_numbers and v not in excluded_hard \
            and 8 <= len(v) <= 20

    bl, bl_from_label = "", False
    if label_bl_value:
        v = label_bl_value
        for pat, _c in _BL_PATTERNS:
            m = re.fullmatch(pat, v)
            if m:
                v = _bl_pattern_fix(m.group(0), pat)
                break
        if _bl_sane(v):
            bl, bl_from_label = v, True
    # Carrier-format ki pakki hit label wale ghair-format value
    # (masalan barcode) par hamesha jeetti hai
    pattern_bl = ""
    for pat, _c in _BL_PATTERNS:
        hits = []
        for it in items:
            for m in re.finditer(pat, _sq(it["text"])):
                hits.append(_bl_pattern_fix(m.group(0), pat))
        if not hits:
            hits = [_bl_pattern_fix(m.group(0), pat)
                    for m in re.finditer(pat, full_sq)]
        for v in hits:
            if _bl_sane(v) and v not in excluded_soft:
                pattern_bl = v
                break
        if pattern_bl:
            break
    if pattern_bl and pattern_bl != bl:
        if not bl or not any(re.fullmatch(p, bl)
                             for p, _c in _BL_PATTERNS):
            bl, bl_from_label = pattern_bl, False
    if not bl and booking_seen and bl_label_seen:
        # Maersk usool: booking aur B/L number EK hi hota hai.
        for v in excluded_soft:
            if "MAERSK" in full_sq and re.fullmatch(r"\d{9}", v):
                bl = v
                warnings.append("BL and booking number are the same "
                                "on this document (Maersk style).")
                break
    rec["bl_no"] = bl

    # ---- 4) PROFORMA ----
    if not bl and ("PROFORMA" in full_sq
                   or (bl_label_seen and booking_seen)):
        rec["proforma"] = True
    if not bl and not rec["proforma"]:
        warnings.append("BL number could not be read from this photo.")

    # ---- 5) carrier ----
    carrier = ""
    for pat, cname in _BL_PATTERNS:
        if bl and re.fullmatch(pat, bl):
            carrier = cname
            break
    if not carrier:
        for key, cname in _LETTERHEAD_CARRIERS:
            if key in full_sq:
                carrier = cname
                break
    if not carrier and bl:
        try:
            _pfx, cname = ENG.identify_carrier(bl)
            carrier = cname or ""
        except Exception:
            carrier = ""
    rec["carrier"] = carrier

    # ---- 6) labeled fields ----
    def label_item_of(ln, kinds):
        for it in ln["items"]:
            if _item_label_kind(it) in kinds:
                return it
        return None

    def after_label(kinds, max_lines=1, joiner=" "):
        for li, ln in enumerate(lines):
            lab = label_item_of(ln, kinds)
            if lab is None:
                continue
            band = (_it_cx(lab) - 0.30 * W, _it_cx(lab) + 0.30 * W)
            multi = len(_line_label_kinds(ln)) >= 2
            vals = []
            # pehle label ke NEECHE wale values (merged line mein
            # label ke neeche chipka item bhi shamil) — label ki
            # line par DAayein taraf aksar reference number hota
            # hai, asal value nahi
            below0 = [i for i in ln["items"]
                      if _it_cy(i) > _it_cy(lab) + 4
                      and band[0] <= _it_cx(i) <= band[1]
                      and _item_label_kind(i) is None]
            if below0:
                vals.append(" ".join(i["text"] for i in below0))
            for j in range(li + 1, min(li + 1 + max_lines + 2,
                                       len(lines))):
                if len(vals) >= max_lines:
                    break
                lk = _line_label_kinds(lines[j])
                if lk and not lk.issubset(kinds):
                    break  # doosra label aa gaya; apna hi label
                    # (masalan "SAME AS CONSIGNEE") value hai
                cand = [i for i in lines[j]["items"]
                        if band[0] <= _it_cx(i) <= band[1]]
                if not cand and not multi:
                    cand = lines[j]["items"]
                if not cand:
                    break
                vals.append(" ".join(i["text"] for i in cand))
            if vals:
                return joiner.join(vals).strip()
            right = [i for i in ln["items"]
                     if _it_cx(i) > _it_cx(lab) + 4
                     and abs(_it_cy(i) - _it_cy(lab)) <= 6
                     and _item_label_kind(i) is None]
            if right:
                return " ".join(i["text"] for i in right).strip()
            return ""
        return ""

    def column_value(kind):
        """Header row (kai labels ek line) — neeche wali line ke
        items qareeb tareen label ko milte hain."""
        for li, ln in enumerate(lines):
            kinds_here = _line_label_kinds(ln)
            if kind not in kinds_here or len(kinds_here) < 2:
                continue
            labs = [( _item_label_kind(i), _it_cx(i))
                    for i in ln["items"] if _item_label_kind(i)]
            for j in range(li + 1, len(lines)):
                if not lines[j]["items"]:
                    continue
                got = []
                for i in lines[j]["items"]:
                    near = min(labs, key=lambda t: abs(t[1] - _it_cx(i)))
                    if near[0] == kind:
                        got.append(i["text"])
                if got:
                    return " ".join(got).strip()
                break
        return ""

    # vessel / voyage
    vessel_raw = column_value("vessel") or after_label({"vessel"})
    voy = after_label({"voyage"})
    if vessel_raw:
        v = vessel_raw.strip(" .,-")
        m = re.split(r"\s*/\s*", v, maxsplit=1)
        if len(m) == 2 and m[1]:
            v, voy = m[0].strip(), (voy or m[1].strip())
        else:
            m2 = re.match(r"^(.*?)[\s]+(\d{3,4}[A-Z]|[A-Z]\d{3,4}|"
                          r"\d{3}[A-Z]{2}|[A-Z]{2}\d{4}[A-Z])$", v)
            if m2:
                v, voy = m2.group(1).strip(), (voy or m2.group(2))
        rec["vessel"] = v.upper()
    if voy:
        rec["voyage"] = voy.strip().upper()
    if not rec["vessel"]:
        m = re.search(r"SHIPPEDONBOARDBY([A-Z]{4,30}?)"
                      r"(CS\d{4}[A-Z]|\d{3,4}[A-Z]\b|\d{3,4}[A-Z])",
                      full_sq)
        if m:
            rec["vessel"] = m.group(1)
            rec["voyage"] = rec["voyage"] or m.group(2)

    # parties (pehli 2-3 lines, agle label tak)
    for kinds, key in (({"shipper"}, "shipper"),
                       ({"consignee"}, "consignee")):
        val = after_label(kinds, max_lines=3, joiner=", ")
        val = re.sub(r"\s+", " ", val).strip(" ,")
        if val and "SAME AS" not in val.upper()[:9]:
            rec[key] = val

    rec["pol"] = (column_value("pol") or after_label({"pol"})
                  or after_label({"receipt"}))
    rec["pod"] = column_value("pod") or after_label({"pod"})
    rec["ts_port"] = (column_value("tranship")
                      or after_label({"tranship"}))
    for k in ("pol", "pod", "ts_port"):
        rec[k] = re.sub(r"\s+", " ", rec[k]).strip(" ,").upper()

    # dates
    def _date_near(pred, span=3):
        for li, ln in enumerate(lines):
            if pred(ln):
                for j in range(li, min(li + span, len(lines))):
                    m = re.search(_DATE_RE, lines[j]["text"], re.I)
                    if m:
                        return _norm_date(m.group(0))
                return ""
        return ""

    rec["on_board"] = _date_near(
        lambda ln: "ONBOARD" in ln["squash"]
        or "LADENONBOARD" in ln["squash"]
        or "SHIPPEDONBOARD" in ln["squash"])
    rec["issue_date"] = _date_near(
        lambda ln: "DATEOFISSUE" in ln["squash"]
        or "PLACEANDDATEOFISSUE" in ln["squash"])

    # ---- 7) goods / packages / weights / freight / free time ----
    spaced = " ".join(ln["text"] for ln in lines)
    best_pkg = None
    for m in re.finditer(r"(\d[\d,]*)\s*(BAGS?|PACKAGES?|CARTONS?|"
                          r"BOXES|PKGS|PCS)\b", spaced, re.I):
        n = int(m.group(1).replace(",", ""))
        if best_pkg is None or n > best_pkg[0]:
            best_pkg = (n, m.group(1) + " " + m.group(2).upper())
    if best_pkg:
        rec["packages"] = best_pkg[1]
    m = re.search(r"(\d[\d,]*)\s*(?:BAGS?|PACKAGES?|CARTONS?|BOXES)"
                  r"\s+OF\s+([A-Z][A-Z .&/'-]{2,40})", spaced)
    if not m:
        m2 = re.search(r"(\d+)(BAGS|PACKAGES|CARTONS|BOXES)OF"
                       r"([A-Z]{3,30})", full_sq)
        if m2:
            m = None
            rec["goods"] = m2.group(3)
            if not rec["packages"]:
                rec["packages"] = m2.group(1) + " " + m2.group(2)
    if m:
        rec["goods"] = re.sub(r"\s+", " ",
                              m.group(2)).strip(" .,-").upper()
    if not rec["goods"]:
        m = re.search(r"(?:SAID TO CONTAIN|STC)\s*[:\-]?\s*"
                      r"([A-Z][A-Z ]{3,30})", spaced)
        if m and "CONTAINER" not in m.group(1):
            rec["goods"] = m.group(1).strip().upper()

    def _weight(kinds_keys, pats):
        # Pehle saaf TOTAL/label patterns; phir label ke paas ke
        # candidates mein SAB SE BARA number (total hamesha
        # per-container weight se bara hota hai). Sirf woh number
        # jo KGS ke sath ho ya decimal wala ho — container/seal
        # ke digits weight nahi ban sakte.
        for p in pats:
            m = re.search(p, spaced, re.I)
            if m:
                return _num_or_blank(m.group(1))
        best = None
        for li, ln in enumerate(lines):
            if _line_label_kinds(ln) & kinds_keys:
                for j in range(li, min(li + 9, len(lines))):
                    for m in re.finditer(
                            r"([\d,]+\.\d+|\d[\d,]*)\s*\(?(KGS?)?\)?",
                            lines[j]["text"]):
                        has_unit = bool(m.group(2)) or "KGS" in \
                            lines[j]["text"][m.end():m.end() + 5].upper()
                        if "." in m.group(1) or has_unit:
                            v = _num_or_blank(m.group(1))
                            if isinstance(v, (int, float)) and (
                                    best is None or v > best):
                                best = v
                if best is not None:
                    return best
        return ""

    rec["gross_kg"] = _weight({"gross"}, [
        r"TOTAL\s*GROSS\s*(?:WT|WEIGHT)?[:\s.]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"GROSS\s*WEIGHT[:\s]*([\d,]+\.?\d*)"])
    rec["net_kg"] = _weight({"net"}, [
        r"TOTAL\s*NET\s*(?:WT|WEIGHT)?[:\s.]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"NET\s*WEIGHT[:\s]*([\d,]+(?:\s[\d,]+)?\.?\d*)",
        r"NETT\s*WEIGHT[:\s]*([\d,]+\.?\d*)"])
    # v54 CBM fix: pehle GEOMETRY se — form par CBM ki value
    # aksar 'CBM' label ke seedha UPAR hoti hai aur OCR unhe
    # alag items deta hai; text-join par adjacency toot jati
    # hai aur line-merge se 'EXPIRYDATE:07/2029 CBM' jaisi
    # line ban kar saal (2029) CBM uth jata tha (Wan Hai BL
    # par asal 65.0000 ki jagah 2029 aaya). Label ke column
    # mein us ke upar sab se qareebi number hi asal value hai.
    _cbm_done = False
    for it in items:
        if str(it.get("text", "")).strip().upper() not in ("CBM", "M3"):
            continue
        lx0, ly0 = it["box"][0][0], it["box"][0][1]
        lx1 = it["box"][2][0]
        best_v, best_gap = None, None
        for jt in items:
            if jt is it:
                continue
            t = str(jt.get("text", "")).strip().replace(",", "")
            if not re.fullmatch(r"\d+\.\d+|\d+", t):
                continue
            jx0, jy1 = jt["box"][0][0], jt["box"][2][1]
            jx1 = jt["box"][2][0]
            if jx1 < lx0 - 0.06 * W or jx0 > lx1 + 0.06 * W:
                continue  # doosra column
            gap = ly0 - jy1
            if gap < -0.02 * H or gap > 0.08 * H:
                continue  # label ke upar hi hona chahiye
            v = _num_or_blank(t)
            if isinstance(v, (int, float)) and 0 < v < 10000:
                if best_gap is None or abs(gap) < best_gap:
                    best_v, best_gap = v, abs(gap)
        if best_v is not None:
            rec["cbm"] = best_v
            _cbm_done = True
            break
    if not _cbm_done:
        m = re.search(r"(?<![\d/,.\-])([\d,]+\.\d+)\s*(CBM|M3)\b",
                      spaced) \
            or re.search(r"(?<![\d/,.\-])([\d,]+\.?\d*)\s*(CBM|M3)\b",
                         spaced)
        if m:
            v = _num_or_blank(m.group(1))
            # HS code ghul jaye to karoron wala jhoota CBM ata
            # hai; khaalis saal (2029 waghera) bhi CBM nahi —
            # asal CBM hamesha chhota hota hai
            if isinstance(v, (int, float)) and v < 10000 \
                    and not (float(v).is_integer()
                             and 1900 <= v <= 2099):
                rec["cbm"] = v
    if "FREIGHTPREPAID" in full_sq or re.search(
            r"FREIGHT\s+PREPAID", spaced, re.I):
        rec["freight"] = "Prepaid"
    elif "FREIGHTCOLLECT" in full_sq:
        rec["freight"] = "Collect"
    m = (re.search(r"(\d+)\s*DAYS?\s*(?:FREE\s*)?(?:FREETIME|FREE\s*TIME|"
                   r"DETENTION|DEMURRAGE)", spaced, re.I)
         or re.search(r"FREETIMEATDESTINATION:?(\d+)", full_sq)
         or re.search(r"(\d+)DAYSFREETIME", full_sq)
         or re.search(r"FREETIME:?(\d+)DAYS", full_sq)
         or re.search(r"(\d+)DAYSFREE", full_sq)
         or re.search(r"FREE\s*TIME:?\s*(\d+)\s*DAYS", spaced, re.I))
    if m:
        rec["free_days"] = int(m.group(1))

    if items:
        low = [i for i in items if i.get("score", 1) < 0.6]
        if len(low) > len(items) * 0.35:
            warnings.append("Parts of this photo were hard to read — "
                            "please check the record against the BL.")
    rec["warnings"] = warnings
    meta = {"excluded": sorted(excluded_hard | excluded_soft),
            "seals": sorted(seal_numbers), "bl_from_label": bl_from_label}
    return rec, meta


def _vision_bl_extract(data_url, offline, meta):
    """OPTIONAL booster (v49): settings mein AI key ho to photo ek
    vision model ko bhej kar record ki cross-check. Sirf tab istemal
    hota hai jab jawab saaf JSON ho, bl_no khaali na ho, aur wo
    container/seal/booking pattern NA ho. Koi bhi ghalti ho to
    khamoshi se offline result — ye rasta kabhi scan nahi rokta."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    try:
        key = _ai_key_single()
        if not key and not _groq_key():
            return None
        prompt = (
            "Read this Bill of Lading photo and return ONLY a JSON "
            "object with keys: bl_no, carrier, vessel, voyage, "
            "shipper, consignee, pol, pod, ts_port, on_board, "
            "issue_date, goods, packages, gross_kg, net_kg, cbm, "
            "freight, free_days, containers (array of {no, seal, "
            "type}). RULES: bl_no is the value printed next to the "
            "'Bill Of Lading No' / 'B/L No.' label. NEVER use the "
            "booking number, S/O number, serial number, shipment "
            "reference, a container number (4 letters + 7 digits) or "
            "a seal number as bl_no. If the document is a PROFORMA "
            "or the BL number box is empty, set bl_no to \"\". Use "
            "\"\" for anything not printed. No commentary, JSON only.")
        _vmime = "image/png"
        _vb64 = data_url or ""
        if _vb64.startswith("data:"):
            _vmime = _vb64[5:].split(";", 1)[0].strip().lower() or _vmime
        if "," in _vb64:
            _vb64 = _vb64.split(",", 1)[1]
        txt = _vision_text_any(prompt, _vmime, _vb64)
        v = None
        if txt:
            txt = re.sub(r"^```(?:json)?|```$", "", txt,
                         flags=re.M).strip()
            try:
                v = _j.loads(txt)
            except Exception:
                v = None
        if not isinstance(v, dict):
            return None
        blv = _sq(str(v.get("bl_no") or ""))
        if not blv:
            return None
        if re.fullmatch(r"[A-Z]{4}\d{7}", blv) and _iso_ok(blv):
            return None  # container ko BL bana diya — qabool nahi
        if blv in set(meta.get("excluded") or []) \
                or blv in set(meta.get("seals") or []):
            return None
        if not (8 <= len(blv) <= 20):
            return None
        return v
    except Exception:
        return None


# ------------- v86: SCAN KA AKHRI DARWAZA -------------
def _matches_any_pat(s):
    try:
        return any(re.fullmatch(p, s) for p, _c in _BL_PATTERNS)
    except Exception:
        return False


def _confusable_alt(no):
    """Parhe gaye BL number ka confusable variant (1->I, 0->O,
    5->S, 8->B) — sirf tab jab variant kisi maroof BL pattern
    par poora utre aur asal number na utre. Sahi numbers par
    jhoota variant kabhi nahi banta."""
    try:
        _bn = str(no or "")
        _flip = {"1": "I", "0": "O", "5": "S", "8": "B"}
        for _i, _ch in enumerate(_bn):
            if _ch in _flip and _i > 2:
                _cand = (_bn[:_i] + _flip[_ch]
                         + _bn[_i + 1:])
                if (_matches_any_pat(_cand)
                        and not _matches_any_pat(_bn)):
                    return _cand
        return ""
    except Exception:
        return ""


def _scan_rescue(no, alt=""):
    """History-rescue: parha number khud history mein FOUND
    na ho aur kisi maroof pattern par bhi na utre, lekin us
    ka qareebi roop (confusable badal, ya ek harf ka farq)
    history mein FOUND ho aur pattern par utre — to wahi
    asal number hai. Pattern ki shart sequential numbers
    (Maersk/Emkay) ko ghalat rescue se bachati hai: sahi
    parha number ya to pattern par utarta hai ya us ka
    padosi bhi nahi utarta."""
    try:
        if not no or _matches_any_pat(no):
            return ""
        hist = load_json(HISTORY_FILE, [])
        found = set()
        for h in hist if isinstance(hist, list) else []:
            if isinstance(h, dict) and h.get("found"):
                q = _sq(str(h.get("query") or ""))
                if q:
                    found.add(q)
        if not found or no in found:
            return ""
        cands = []
        if alt:
            cands.append(alt)
        _fl = {"1": "I", "I": "1", "0": "O", "O": "0",
               "5": "S", "S": "5", "8": "B", "B": "8"}
        for _i, _ch in enumerate(str(no)):
            if _ch in _fl and _i > 2:
                cands.append(str(no)[:_i] + _fl[_ch]
                             + str(no)[_i + 1:])
        for c in cands:
            if c in found and _matches_any_pat(c):
                return c
        for f in found:
            if _matches_any_pat(f) and _lev(str(no), f) == 1:
                return f
        return ""
    except Exception:
        return ""


def _finalize_scan(rec, vision_no=""):
    """SCAN KA AKHRI DARWAZA (v86 system fix): /api/ocr ka
    HAR jawab — local engine ho ya sirf-AI-vision fallback —
    yahin se guzar kar bahar jata hai. (Pehle variant wali
    hifazat sirf local raste par thi; vision fallback use
    bypass kar deta tha — wohi kharabi jis se FRLS ki I/1
    ghalti do dafa hui.) Har number par: variant (bl_alt),
    phir history-rescue — qareebi FOUND record ho to wahi
    asal number (bl_no) banta hai, parha number bl_alt mein
    jata hai taake wo bhi check ho, aur baat warning mein
    saaf likhi jati hai."""
    try:
        if not isinstance(rec, dict):
            return rec
        no = str(rec.get("bl_no") or "")
        if not no:
            return rec
        warns = list(rec.get("warnings") or [])
        alt = ""
        if vision_no and str(vision_no) != no:
            alt = str(vision_no)
        if not alt:
            alt = _confusable_alt(no)
        rescue = _scan_rescue(no, alt)
        if rescue and rescue != no:
            rec["bl_rescue_from"] = no
            rec["bl_no"] = rescue
            rec["bl_alt"] = no
            warns.append(
                "The photo read " + no + " — but a shipment "
                "with the very similar number " + rescue +
                " is already in your history as FOUND, so "
                "that number is being tracked as the BL "
                "(the read number is also checked).")
        elif alt:
            rec["bl_alt"] = alt
        rec["warnings"] = warns
        return rec
    except Exception:
        return rec


# ------------- v51: AI vision fallback (local engine na ho to) -------------
_VISION_BL_PROMPT = (
    "Read this Bill of Lading photo and return ONLY a JSON "
    "object with keys: bl_no, carrier, vessel, voyage, "
    "shipper, consignee, pol, pod, ts_port, on_board, "
    "issue_date, goods, packages, gross_kg, net_kg, cbm, "
    "freight, free_days, proforma, containers (array of {no, "
    "seal, type}). RULES: bl_no is the value printed next to "
    "the 'Bill Of Lading No' / 'B/L No.' label. NEVER use the "
    "booking number, S/O number, serial number, shipment "
    "reference, a container number (4 letters + 7 digits) or "
    "a seal number as bl_no. If the document is a PROFORMA "
    "or the BL number box is empty, set proforma to true and "
    "bl_no to \"\". Use \"\" for anything not printed. No "
    "commentary, JSON only.")


def _vision_extract_record(image_bytes, mime, ai_key):
    """v51: photo-scan ka doosra rasta — local OCR engine
    tayyar na ho (missing / setup chal raha / setup fail) to
    Gemini ke vision model se seedha record nikalo. Record ki
    shape bilkul wahi jo extract_bl_record deta hai, engine
    'vision' ke sath. Sakht validation: bl_no ka pattern
    (^[A-Z0-9]{8,20}$), container ISO 6346 check digit (fail
    wala container drop, check_ok imandari se), PROFORMA par
    bl_no hamesha khaali (booking kabhi BL nahi banta). Koi
    bhi ghalti ho to None — ye function kabhi raise nahi
    karta; handler phir purane saaf error par gir jata hai."""
    import base64 as _b64
    import urllib.request as _u
    import json as _j
    try:
        key = _ai_key_single() or str(ai_key or "").strip()
        if key.startswith("gsk_"):
            key = ""
        if (not key and not _groq_key()) or not image_bytes:
            return None
        txt = _vision_text_any(_VISION_BL_PROMPT,
                               mime or "image/png",
                               _b64.b64encode(image_bytes).decode())
        v = None
        if txt:
            txt = re.sub(r"^```(?:json)?|```$", "", txt,
                         flags=re.M).strip()
            try:
                v = _j.loads(txt)
            except Exception:
                v = None

        if not isinstance(v, dict):
            return None
        # ---- validation + record shape ----
        rec = {"bl_no": "", "containers": [], "carrier": "",
               "vessel": "", "voyage": "", "shipper": "",
               "consignee": "", "pol": "", "pod": "",
               "ts_port": "", "on_board": "", "issue_date": "",
               "goods": "", "packages": "", "gross_kg": "",
               "net_kg": "", "cbm": "", "freight": "",
               "free_days": "", "proforma": False}
        blv = _sq(str(v.get("bl_no") or ""))
        proforma = bool(v.get("proforma"))
        if blv:
            if not re.fullmatch(r"[A-Z0-9]{8,20}", blv):
                return None
            # container number ko BL bana diya ho to qabool nahi
            if re.fullmatch(r"[A-Z]{4}\d{7}", blv) \
                    and _iso_ok(blv):
                return None
            rec["bl_no"] = blv
            proforma = False
        elif not proforma:
            return None   # na BL mila na proforma — no-result
        rec["proforma"] = proforma
        for k in ("carrier", "vessel", "voyage", "shipper",
                  "consignee", "pol", "pod", "ts_port",
                  "on_board", "issue_date", "goods", "packages",
                  "freight"):
            val = v.get(k)
            if val not in (None, ""):
                rec[k] = str(val).strip()
        for k in ("gross_kg", "net_kg", "cbm"):
            rec[k] = _num_or_blank(v.get(k))
        fd = _num_or_blank(v.get("free_days"))
        rec["free_days"] = int(fd) if fd != "" else ""
        for c in v.get("containers") or []:
            if not isinstance(c, dict) or not c.get("no"):
                continue
            no = _sq(str(c["no"]))
            if not re.fullmatch(r"[A-Z]{4}\d{7}", no):
                continue
            if not _iso_ok(no):
                continue   # check digit fail — container drop
            rec["containers"].append({
                "no": no,
                "seal": str(c.get("seal") or "").strip().upper(),
                "type": str(c.get("type") or ""),
                "check_ok": True})
        rec["ok"] = True
        rec["engine"] = "vision"
        rec["warnings"] = [
            "Read with the AI vision fallback (the built-in "
            "scan engine is not ready on this device yet) — "
            "please double-check the details against the "
            "document."]
        return rec
    except Exception:
        return None


def _public_settings():
    s = dict(get_settings())
    s["ai_key_set"] = bool(str(s.get("ai_key") or "").strip())
    s.pop("ai_key", None)
    # v67: Gemini key bhi sirf flag ki surat mein bahar.
    s["gemini_key_set"] = bool(str(s.get("gemini_key") or "").strip())
    s.pop("gemini_key", None)
    s["groq_key_set"] = bool(str(s.get("groq_key") or "").strip())
    s.pop("groq_key", None)
    # v56: Traqo key bhi ai_key ki tarah — sirf flag bahar, key nahi.
    s["traqo_key_set"] = bool(str(s.get("traqo_key") or "").strip())
    s.pop("traqo_key", None)
    # v59: mail setup (Shezi ko chat bhejna) - app password sirf flag.
    s["mail_pass_set"] = bool(str(s.get("mail_pass") or "").strip())
    s.pop("mail_pass", None)
    if not s.get("mail_user"):
        s["mail_user"] = "officeuseonlydell@gmail.com"
    # v48: the password hash itself never leaves the server — only a flag.
    s["app_pass_set"] = bool(str(s.get("app_pass") or "").strip())
    s.pop("app_pass", None)
    # v96 Profile: naam settings store mein rehta hai; photo DATA_DIR ki
    # ek file hai — settings jawab mein sirf flag jata hai, photo ka data
    # kabhi nahi (photo /profile/photo route se milti hai).
    s["profile_name"] = str(s.get("profile_name") or "").strip()
    s["profile_photo_set"] = _profile_photo_path() is not None
    # v98 Stage B (Sync): token/hash kabhi bahar nahi — sirf
    # halat (role, address, aakhri sync, joined copies).
    s.pop("sync_token_hash", None)
    s.pop("sync_client_token", None)
    s.pop("sync_instance_id", None)
    s.pop("profile_sync_ts", None)
    try:
        s.update(_sync_public())
    except Exception:
        pass
    return s


PROFILE_PHOTO_EXTS = (".jpg", ".png", ".webp")


def _profile_photo_path():
    for ext in PROFILE_PHOTO_EXTS:
        f = DATA_DIR / ("profile_photo" + ext)
        if f.exists():
            return f
    return None


def get_settings():
    s = load_json(SETTINGS_FILE, {})
    return s if isinstance(s, dict) else {}


# ---------------- data sync (v98, Stage B) ----------------
# Usool (Yousuf ka hukum, 29 Oct 2026): jo copy bhi use ho — laptop
# ZIP, mustaqil server link, ya aarzi link — data hamesha UPDATED
# aur SAME ho, kahin koi farq nahi. Design: ek copy markazi HUB
# hoti hai (hamesha-jagta server); baqi copies khud us se jurti
# hain. Pehli joining par protective union merge — kuch zaya
# nahi, delete huwa record dobara zinda nahi hota. API keys /
# secrets sync payload mein KABHI nahi jate; shipment data aur
# profile (naam + photo) jata hai.
#
# Merge ka dil: record-level, key = query (BL). Har record par
# sync_ts (Lamport-style: hamesha system mein dekhe gaye sab se
# bare ts se aage) + stage rank (milestone tartib se). Zyada
# stage jeet-ta hai; barabar stage par naya sync_ts; jeetne wala
# POORA liya jata hai, magar jo field jeetne wale ke pas khaali
# hai aur haarne wale ke pas bhara hai, wo bhar diya jata hai
# (enrich-fill wala hi usool). Tombstone (delete ka nishan)
# purane record ko hamesha harata hai; naya record tombstone ko.
#
# State file ke tamam helper _lock ke baghair hain — har caller
# ko _lock thaame rakhna hai (HTTP calls lock ke BAHAR hote hain).

SYNC_STATE_FILE = DATA_DIR / "sync_state.json"
_SYNC_TOMB_CAP = 500
_SYNC_TOMB_KEEP = 180 * 24 * 3600
_SYNC_HASH_SKIP = ("sync_ts", "milestones")


def _sync_state():
    st = load_json(SYNC_STATE_FILE, {})
    if not isinstance(st, dict):
        st = {}
    if not isinstance(st.get("tombstones"), list):
        st["tombstones"] = []
    if not isinstance(st.get("last_sent"), dict):
        st["last_sent"] = {}
    if not isinstance(st.get("peers"), dict):
        st["peers"] = {}
    st.setdefault("max_ts", 0)
    st.setdefault("last_pull_ts", 0)
    return st


def _sync_state_save(st):
    return save_json(SYNC_STATE_FILE, st)


def _sync_role():
    return str(get_settings().get("sync_role") or "").strip()


def _sync_token_ok(token):
    want = str(get_settings().get("sync_token_hash") or "").strip()
    if not want or not token:
        return False
    got = hashlib.sha256(str(token).encode("utf-8")).hexdigest()
    return hmac.compare_digest(got, want)


def _sync_next_ts(st=None):
    """Lamport ghari: is copy par naya stamp hamesha us sab se
    bare ts se aage hoga jo is ne kabhi dekha hai — ghari peeche
    hone par bhi koi tabdeeli 'purani' nahi ban sakti."""
    try:
        mx = float((st or _sync_state()).get("max_ts") or 0)
    except Exception:
        mx = 0
    return max(time.time(), mx + 0.01)


def _sync_clone(x):
    return json.loads(json.dumps(x, ensure_ascii=False, default=str))


def _sync_rec_hash(rec):
    core = {k: v for k, v in (rec or {}).items()
            if k not in _SYNC_HASH_SKIP}
    blob = json.dumps(core, sort_keys=True, ensure_ascii=False,
                      default=str)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _sync_empty(v):
    return v is None or v == "" or v == [] or v == {}


_SYNC_FILL_BOOL = ("found", "returned", "starred")


def _sync_stage_rank(rec):
    """Milestone tartib se stage ka number (bara = aage):
    0 kuch nahi · 1 mila · 2 rawana · 3 laga (berth) ·
    4 aadha unload · 5 unload · 6 gate out · 7 delivered ·
    8 khaali wapas (returned)."""
    r = (rec or {}).get("result") or {}
    rank = 1 if (rec or {}).get("found") else 0
    try:
        states = {m.get("key"): m.get("state")
                  for m in _milestones(rec or {})}
    except Exception:
        states = {}
    if states.get("departed") == "done":
        rank = max(rank, 2)
    if states.get("berthed") == "done":
        rank = max(rank, 3)
    if states.get("discharged") == "partial":
        rank = max(rank, 4)
    if states.get("discharged") == "done":
        rank = max(rank, 5)
    if states.get("gateout") == "done":
        rank = max(rank, 6)
    if _status_final(r):
        rank = max(rank, 7)
    if (rec or {}).get("returned"):
        rank = max(rank, 8)
    return rank


def _sync_fill(winner, loser):
    """Jeetne wala poora; sirf us ke KHAALI field haarne wale
    ke bhare huwe se bhare jate hain (ek satah andar 'result'
    ke liye bhi wohi usool)."""
    w = _sync_clone(winner)
    for k, lv in (loser or {}).items():
        if k in _SYNC_HASH_SKIP:
            continue
        wv = w.get(k)
        if k in _SYNC_FILL_BOOL:
            if not wv and lv:
                w[k] = lv
            continue
        if _sync_empty(wv) and not _sync_empty(lv):
            w[k] = lv
        elif k == "result" and isinstance(wv, dict) \
                and isinstance(lv, dict):
            for rk, rlv in lv.items():
                if _sync_empty(wv.get(rk)) and not _sync_empty(rlv):
                    wv[rk] = rlv
    return w


def _sync_pick(local, remote):
    """Do copies mein se merge shuda record. Stage pehle,
    phir sync_ts; pura barabar ho to zyada bhara huwa record."""
    if local is None:
        return _sync_clone(remote)
    if remote is None:
        return _sync_clone(local)
    lr, rr = _sync_stage_rank(local), _sync_stage_rank(remote)
    lt = float(local.get("sync_ts") or 0)
    rt = float(remote.get("sync_ts") or 0)
    if rr > lr or (rr == lr and rt > lt):
        win, lose = remote, local
    elif lr > rr or (lr == rr and lt > rt):
        win, lose = local, remote
    elif _sync_rec_hash(remote) == _sync_rec_hash(local):
        win, lose = local, remote
    elif len(str(remote)) > len(str(local)):
        win, lose = remote, local
    else:
        win, lose = local, remote
    merged = _sync_fill(win, lose)
    merged["sync_ts"] = max(lt, rt)
    return merged


def _sync_prune_tombs(tombs, now=None):
    now = now or time.time()
    keep = [t for t in tombs
            if now - float(t.get("ts") or 0) <= _SYNC_TOMB_KEEP]
    keep.sort(key=lambda t: float(t.get("ts") or 0), reverse=True)
    return keep[:_SYNC_TOMB_CAP]


def _sync_add_tombstone(st, query, ts=None):
    """Caller _lock thaame. Delete ka nishan state mein."""
    if not query:
        return
    ts = ts if ts is not None else _sync_next_ts(st)
    tombs = {t.get("query"): t for t in st["tombstones"]}
    old = tombs.get(query)
    if old is None or float(old.get("ts") or 0) < ts:
        tombs[query] = {"query": query, "ts": ts}
    st["tombstones"] = _sync_prune_tombs(list(tombs.values()))
    st["max_ts"] = max(float(st.get("max_ts") or 0), ts)


def _sync_apply(hist, records_in, tombs_in):
    """Aayi hui records + tombstones ko is copy ke hist (list,
    in-place) par merge usool se lagao. Caller _lock thaame aur
    baad mein history save kare. Return: (badle huwe records ki
    gin-ti, {query: hash} jo likhe gaye, [mitaye gaye query])."""
    st = _sync_state()
    tombs = {t.get("query"): dict(t) for t in st["tombstones"]}
    for t in (tombs_in or []):
        q = t.get("query")
        if not q:
            continue
        ts = float(t.get("ts") or 0)
        if q not in tombs or float(tombs[q].get("ts") or 0) < ts:
            tombs[q] = {"query": q, "ts": ts}
        st["max_ts"] = max(float(st.get("max_ts") or 0), ts)
    by_q = {}
    for h in hist:
        if h.get("query"):
            by_q[h["query"]] = h
    written, gone = {}, []
    changed = 0
    for rec in (records_in or []):
        q = (rec or {}).get("query")
        if not q:
            continue
        rts = float(rec.get("sync_ts") or 0)
        st["max_ts"] = max(float(st.get("max_ts") or 0), rts)
        tb = tombs.get(q)
        if tb is not None and float(tb.get("ts") or 0) >= rts \
                and rts > 0:
            continue  # tombstone is record se naya — record mara rahe
        merged = _sync_pick(by_q.get(q), rec)
        if tb is not None \
                and float(merged.get("sync_ts") or 0) > float(tb.get("ts") or 0):
            del tombs[q]  # naya record tombstone ko hara gaya
        old = by_q.get(q)
        if old is not None and _sync_rec_hash(old) == _sync_rec_hash(merged):
            hist[hist.index(old)] = merged  # sirf sync_ts refresh
            by_q[q] = merged
            continue
        old_status = ((old or {}).get("result") or {}).get("status") or ""
        new_status = (merged.get("result") or {}).get("status") or ""
        if old is not None and old_status != new_status and new_status:
            chg = {"time": datetime.now().strftime("%d/%m %H:%M"),
                   "from": old_status or "In progress",
                   "to": new_status, "via": "sync"}
            merged["changes"] = ([chg] + list(
                merged.get("changes") or []))[:6]
            merged["changed"] = True
        if old is None:
            hist.insert(0, merged)
        else:
            hist[hist.index(old)] = merged
        by_q[q] = merged
        written[q] = _sync_rec_hash(merged)
        changed += 1
    for q, tb in list(tombs.items()):
        cur = by_q.get(q)
        if cur is not None \
                and float(tb.get("ts") or 0) >= float(cur.get("sync_ts") or 0):
            hist.remove(cur)
            del by_q[q]
            gone.append(q)
            changed += 1
    st["tombstones"] = _sync_prune_tombs(list(tombs.values()))
    _sync_state_save(st)
    return changed, written, gone


def _sync_snapshot(since=0.0):
    """Hub jawab: records + tombstones (since se naye) + profile.
    Caller _lock thaame. Pehle stamp core — hub ke apne taaza
    badlav (jo background chakkar se pehle ke hon) bhi is
    jawab mein lazmi shamil hon."""
    _sync_stamp_core(mark_clean=True)
    hist = get_history()
    recs = [h for h in hist
            if float(h.get("sync_ts") or 0) > since]
    st = _sync_state()
    tombs = [t for t in st["tombstones"]
             if float(t.get("ts") or 0) > since]
    mx = float(st.get("max_ts") or 0)
    for h in hist:
        mx = max(mx, float(h.get("sync_ts") or 0))
    return {"records": recs, "tombstones": tombs,
            "profile": _sync_profile_payload(), "max_ts": mx}


def _sync_profile_payload():
    import base64
    s = get_settings()
    photo = None
    f = _profile_photo_path()
    if f is not None:
        try:
            raw = f.read_bytes()
            if len(raw) <= 2 * 1024 * 1024:
                photo = {"ext": f.suffix,
                         "b64": base64.b64encode(raw).decode("ascii")}
        except Exception:
            photo = None
    return {"name": str(s.get("profile_name") or "").strip(),
            "photo": photo,
            "ts": float(s.get("profile_sync_ts") or 0)}


def _sync_apply_profile(p):
    """Caller _lock thaame. Sirf NAYA profile lagta hai
    (profile_sync_ts ki ghari wohi Lamport hai)."""
    import base64
    if not isinstance(p, dict):
        return False
    ts = float(p.get("ts") or 0)
    s = get_settings()
    if ts <= float(s.get("profile_sync_ts") or 0):
        return False
    s["profile_name"] = str(p.get("name") or "").strip()[:80]
    s["profile_sync_ts"] = ts
    if not save_json(SETTINGS_FILE, s):
        return False
    ph = p.get("photo")
    if isinstance(ph, dict) and ph.get("ext") in PROFILE_PHOTO_EXTS:
        try:
            raw = base64.b64decode(ph.get("b64") or "", validate=True)
            if 0 < len(raw) <= 2 * 1024 * 1024:
                for ext in PROFILE_PHOTO_EXTS:
                    if ext != ph["ext"]:
                        (DATA_DIR / ("profile_photo" + ext)).unlink(
                            missing_ok=True)
                (DATA_DIR / ("profile_photo" + ph["ext"])).write_bytes(raw)
        except Exception:
            pass
    elif ph is None:
        for ext in PROFILE_PHOTO_EXTS:
            try:
                (DATA_DIR / ("profile_photo" + ext)).unlink(missing_ok=True)
            except Exception:
                pass
    return True


def _sync_stamp_core(mark_clean=False):
    """_sync_stamp_pass ka andar wala hissa — caller _lock
    thaame hue hai. Return wohi."""
    hist = get_history()
    st = _sync_state()
    last_sent = dict(st.get("last_sent") or {})
    now = time.time()
    dirty, present, hist_dirty = [], set(), False
    for rec in hist:
        q = rec.get("query")
        if not q:
            continue
        present.add(q)
        if not rec.get("sync_ts"):
            base = rec.get("checked_ts") or rec.get("attempt_ts") or now
            rec["sync_ts"] = float(base)
            st["max_ts"] = max(float(st.get("max_ts") or 0),
                               float(base))
            hist_dirty = True
        h = _sync_rec_hash(rec)
        if last_sent.get(q) != h:
            if q in last_sent:
                rec["sync_ts"] = _sync_next_ts(st)
                st["max_ts"] = max(float(st.get("max_ts") or 0),
                                   float(rec["sync_ts"]))
                hist_dirty = True
            dirty.append(_sync_clone(rec))
            if mark_clean:
                last_sent[q] = _sync_rec_hash(rec)
        elif mark_clean:
            last_sent[q] = h
    for q in list(last_sent):
        if q not in present:
            _sync_add_tombstone(st, q)
            del last_sent[q]
    st["last_sent"] = last_sent
    _sync_state_save(st)
    if hist_dirty:
        save_json(HISTORY_FILE, hist[:1000])
    return dirty, list(st["tombstones"])


def _sync_stamp_pass(mark_clean=False):
    """Is copy ke apne badlav pakro: jo record pichli baseline
    ke baad badla, use naya sync_ts do; jo ghayab huwa, us ka
    tombstone banao. mark_clean=True (hub) par baseline foran
    maujooda halat par taza ho jati hai — hub ko kahin bhejna
    nahi hota, pull seedha history se jata hai. Joined copy par
    baseline kamyab push ke baad _sync_mark_sent se taza hoti
    hai. Caller _lock NA thaame — ye khud lock leta hai.
    Return: (gande records [clone], tamam tombstones)."""
    with _lock:
        return _sync_stamp_core(mark_clean)


def _sync_mark_sent(queries):
    """Joined: kamyab push ke baad in records ki baseline hash
    maujooda halat par rakho (dobara push na ho)."""
    with _lock:
        hist = get_history()
        st = _sync_state()
        by_q = {h.get("query"): h for h in hist}
        for q in queries:
            rec = by_q.get(q)
            if rec is not None:
                st["last_sent"][q] = _sync_rec_hash(rec)
        _sync_state_save(st)


def _sync_http(url, token, payload=None, timeout=25):
    """Hub se baat. (status, json) ya (None, None) jab rabta hi
    na ho (offline) — caller farq samjhe: 401 matlab token
    ghalat, None matlab net nahi."""
    headers = {"X-Sync-Token": str(token or ""),
               "Content-Type": "application/json",
               "X-Sync-Client": _sync_instance_id(),
               "X-Sync-Label": _sync_instance_label()}
    data = None
    if payload is not None:
        payload = dict(payload)
        payload.setdefault("client_id", _sync_instance_id())
        payload.setdefault("label", _sync_instance_label())
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, headers=headers,
        method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {}
    except Exception:
        return None, None


def _sync_instance_id():
    s = get_settings()
    iid = str(s.get("sync_instance_id") or "").strip()
    if not iid:
        iid = secrets.token_hex(6)
        s["sync_instance_id"] = iid
        save_json(SETTINGS_FILE, s)
    return iid


def _sync_instance_label():
    try:
        import socket
        return socket.gethostname() or "CargoTrack copy"
    except Exception:
        return "CargoTrack copy"


def _sync_note_peer(client_id, label):
    """Hub: kis copy ne kab rabta kiya. Caller _lock thaame."""
    if not client_id:
        return
    st = _sync_state()
    st["peers"][str(client_id)[:40]] = {
        "label": str(label or "CargoTrack copy")[:60],
        "last_seen": time.time()}
    _sync_state_save(st)


_SYNC_KICK = threading.Event()


def _sync_set_status(msg, ok=False):
    st = _sync_state()
    st["last_sync_msg"] = str(msg or "")[:200]
    if ok:
        st["last_sync_ok_ts"] = time.time()
    _sync_state_save(st)


def _sync_cycle():
    """Joined copy ka ek chakkar: gande records + tombstones
    bhejo, hub ke jeetne wale wapas lagao, phir nayi tabdeeliyan
    kheench lo. Kabhi raise nahi karta — offline par khamoshi
    se agli koshish ka intezar."""
    s = get_settings()
    if _sync_role() != "joined":
        return
    hub = str(s.get("sync_hub_url") or "").strip().rstrip("/")
    token = str(s.get("sync_client_token") or "").strip()
    if not hub or not token:
        return
    dirty, tombs = _sync_stamp_pass()
    code, resp = _sync_http(hub + "/api/sync/push", token, {
        "records": dirty, "tombstones": tombs,
        "profile": _sync_profile_payload()})
    if code is None:
        with _lock:
            _sync_set_status("offline — will sync when the hub "
                             "is reachable")
        return
    if code == 401:
        with _lock:
            _sync_set_status("sync token rejected by the hub — "
                             "check the token in Settings")
        return
    if code != 200 or not isinstance(resp, dict):
        with _lock:
            _sync_set_status(f"hub answered {code} — will retry")
        return
    _sync_mark_sent([r.get("query") for r in dirty if r.get("query")])
    with _lock:
        hist = get_history()
        _sync_apply_profile(resp.get("profile"))
        ch, written, gone = _sync_apply(
            hist, resp.get("records") or [],
            resp.get("tombstones") or [])
        if ch:
            save_json(HISTORY_FILE, hist[:1000])
        st = _sync_state()
        for q, h in written.items():
            st["last_sent"][q] = h
        for q in gone:
            st["last_sent"].pop(q, None)
        st["profile_sent_hash"] = hashlib.sha256(json.dumps(
            _sync_profile_payload(), sort_keys=True,
            default=str).encode("utf-8")).hexdigest()
        _sync_state_save(st)
    # ab hub ki nayi tabdeeliyan kheench lo
    with _lock:
        since = float(_sync_state().get("last_pull_ts") or 0)
    code, resp = _sync_http(f"{hub}/api/sync/pull?since={since}",
                            token)
    if code == 200 and isinstance(resp, dict):
        with _lock:
            hist = get_history()
            _sync_apply_profile(resp.get("profile"))
            ch, written, gone = _sync_apply(
                hist, resp.get("records") or [],
                resp.get("tombstones") or [])
            if ch:
                save_json(HISTORY_FILE, hist[:1000])
            st = _sync_state()
            for qq, h in written.items():
                st["last_sent"][qq] = h
            for qq in gone:
                st["last_sent"].pop(qq, None)
            st["last_pull_ts"] = max(
                float(st.get("last_pull_ts") or 0),
                float(resp.get("max_ts") or 0))
            st["last_sync_msg"] = "synced"
            st["last_sync_ok_ts"] = time.time()
            _sync_state_save(st)
    else:
        with _lock:
            _sync_set_status("synced (push); pull will retry", ok=True)


def _sync_join_now():
    """Pehli joining: hub ka POORA snapshot union-merge karo,
    phir apna sab kuch push karo. (ok, message) return."""
    s = get_settings()
    hub = str(s.get("sync_hub_url") or "").strip().rstrip("/")
    token = str(s.get("sync_client_token") or "").strip()
    if not hub or not token:
        return False, "hub address or token missing"
    code, resp = _sync_http(hub + "/api/sync/join", token, {})
    if code is None:
        return False, "hub unreachable — check the address and network"
    if code == 401:
        return False, "sync token rejected by the hub"
    if code != 200 or not isinstance(resp, dict):
        return False, f"hub answered {code}"
    with _lock:
        hist = get_history()
        _sync_apply_profile(resp.get("profile"))
        ch, written, gone = _sync_apply(
            hist, resp.get("records") or [],
            resp.get("tombstones") or [])
        if ch:
            save_json(HISTORY_FILE, hist[:1000])
        st = _sync_state()
        for q, h in written.items():
            st["last_sent"][q] = h
        for q in gone:
            st["last_sent"].pop(q, None)
        st["last_pull_ts"] = max(float(st.get("last_pull_ts") or 0),
                                 float(resp.get("max_ts") or 0))
        _sync_state_save(st)
    _sync_cycle()
    return True, "joined — data merged both ways, nothing lost"


def _sync_loop():
    """Pas-e-parda chakkar: shuru mein foran, phir har 2 minute
    pull; local badlav ~10s debounce ke baad push. Hub copy par
    sirf stamp pass (taake us ke apne badlav pull mein jayen)."""
    time.sleep(5)
    last_full = 0.0
    dirty_since = 0.0
    while True:
        try:
            role = _sync_role()
            if role == "hub":
                _sync_stamp_pass(mark_clean=True)
            elif role == "joined":
                now = time.time()
                dirty, _ = _sync_stamp_pass()
                if dirty and not dirty_since:
                    dirty_since = now
                if (dirty and now - dirty_since >= 10) \
                        or now - last_full >= 120 \
                        or _SYNC_KICK.is_set():
                    _SYNC_KICK.clear()
                    _sync_cycle()
                    last_full = time.time()
                    dirty_since = 0.0
        except Exception:
            pass
        time.sleep(15)


def _sync_public():
    s = get_settings()
    st = _sync_state()
    peers = [{"label": v.get("label") or "CargoTrack copy",
              "last_seen": v.get("last_seen")}
             for v in (st.get("peers") or {}).values()]
    peers.sort(key=lambda x: x.get("last_seen") or 0, reverse=True)
    return {
        "sync_role": _sync_role(),
        "sync_hub_url": str(s.get("sync_hub_url") or ""),
        "sync_hub_token_set": bool(s.get("sync_token_hash")),
        "sync_client_token_set": bool(s.get("sync_client_token")),
        "sync_last_ok": st.get("last_sync_ok_ts"),
        "sync_last_msg": st.get("last_sync_msg") or "",
        "sync_peers": peers,
        "sync_records": len(get_history()),
        "sync_tombstones": len(st.get("tombstones") or [])}


# ---------------- app lock + sessions (v48) ----------------
# The password is stored ONLY as a salted hash in settings.json
# ("app_pass" = salt_hex$sha256_hex, sha256 of salt+password).
# No app_pass -> the app is UNLOCKED (first-run mode, old behaviour).
# Browser sessions live in sessions.json, keyed by sha256(token);
# the raw token only ever exists in the browser's HttpOnly cookie.

def _app_pass_hash():
    return str(get_settings().get("app_pass") or "").strip()


def _make_pass_hash(pw):
    salt = secrets.token_bytes(16)
    digest = hashlib.sha256(salt + pw.encode("utf-8")).hexdigest()
    return salt.hex() + "$" + digest


def _verify_pass(pw, stored):
    try:
        salt_hex, digest = stored.split("$", 1)
        cand = hashlib.sha256(
            bytes.fromhex(salt_hex) + pw.encode("utf-8")).hexdigest()
        return hmac.compare_digest(cand, digest)
    except Exception:
        return False


def _load_sessions():
    d = load_json(SESSIONS_FILE, {})
    if not isinstance(d, dict):
        d = {}
    if not isinstance(d.get("sessions"), dict):
        d["sessions"] = {}
    if not isinstance(d.get("attempts"), list):
        d["attempts"] = []
    return d


def _save_sessions(d):
    return save_json(SESSIONS_FILE, d)


def device_label(ua):
    """Friendly device label from a User-Agent string."""
    ua = ua or ""
    if "Edg/" in ua:
        browser = "Edge"
    elif "OPR/" in ua or "Opera" in ua:
        browser = "Opera"
    elif "Firefox/" in ua:
        browser = "Firefox"
    elif "CriOS" in ua or "Chrome/" in ua:
        browser = "Chrome"
    elif "Safari/" in ua:
        browser = "Safari"
    else:
        browser = "Browser"
    if "iPhone" in ua:
        osname = "iPhone"
    elif "iPad" in ua:
        osname = "iPad"
    elif "Android" in ua:
        osname = "Android"
    elif "Windows" in ua:
        osname = "Windows"
    elif "Mac OS" in ua or "Macintosh" in ua:
        osname = "Mac"
    elif "Linux" in ua:
        osname = "Linux"
    else:
        osname = ""
    return f"{browser} on {osname}" if osname else browser


def _create_session(ua, ip):
    """Create a session; returns the raw token (for the cookie)."""
    token = secrets.token_urlsafe(32)
    th = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = time.time()
    with _lock:
        d = _load_sessions()
        d["sessions"][th] = {"created": now, "last_seen": now,
                             "ua": ua, "ip": ip}
        if len(d["sessions"]) > 20:  # cap: drop the oldest
            by_age = sorted(d["sessions"].items(),
                            key=lambda kv: kv[1].get("created", 0))
            for k, _v in by_age[:len(by_age) - 20]:
                d["sessions"].pop(k, None)
        _save_sessions(d)
    return token


def _record_attempt(ip, ua, ok):
    with _lock:
        d = _load_sessions()
        d["attempts"].append({"ts": time.time(), "ip": ip,
                              "ua": ua, "ok": bool(ok)})
        d["attempts"] = d["attempts"][-50:]  # keep only the last 50
        _save_sessions(d)


_SESS_SEEN = {}     # token_hash -> last_seen ts (in memory, freshest)
_SESS_WRITTEN = {}  # token_hash -> ts of last sessions.json write


def _touch_session(th, ua, ip):
    """Update a session's last_seen; the disk write is throttled to
    at most once per 60 seconds per session to avoid churn."""
    now = time.time()
    _SESS_SEEN[th] = now
    if now - _SESS_WRITTEN.get(th, 0) <= 60:
        return
    with _lock:
        d = _load_sessions()
        s = d["sessions"].get(th)
        if not s:
            return
        s["last_seen"] = now
        s["ua"] = ua
        s["ip"] = ip
        if _save_sessions(d):
            _SESS_WRITTEN[th] = now


def _sess_cookie(token):
    return (f"ct_sess={token}; HttpOnly; Path=/; "
            f"Max-Age=7776000; SameSite=Lax")


_SESS_COOKIE_CLEAR = "ct_sess=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax"

LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CargoTrack — Locked</title>
<style>
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;display:flex;align-items:center;
    justify-content:center;background:#12121E;color:#ECECF4;
    font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
    padding:20px}
  .card{background:#1E1E30;border:1px solid #2F2F47;border-radius:20px;
    padding:34px 30px;width:100%;max-width:380px;text-align:center;
    box-shadow:0 24px 60px rgba(0,0,0,.5)}
  .card img{width:84px;height:84px;object-fit:contain;border-radius:18px;
    background:rgba(255,255,255,.94)}
  h1{margin:14px 0 2px;font-size:26px;letter-spacing:.3px;
    background:linear-gradient(90deg,#A78BFA,#F472B6);
    -webkit-background-clip:text;background-clip:text;color:transparent}
  .sub{color:#A8A8BE;font-size:14px;margin:0 0 22px}
  input{width:100%;padding:13px 14px;border-radius:12px;font-size:16px;
    border:2px solid #2F2F47;background:#12121E;color:#ECECF4;outline:none}
  input:focus{border-color:#7C3AED}
  button{width:100%;margin-top:14px;padding:13px;border:0;border-radius:12px;
    font-size:16px;font-weight:700;color:#fff;cursor:pointer;
    background:linear-gradient(90deg,#7C3AED,#DB2777)}
  button:active{transform:scale(.99)}
  #err{display:none;color:#F87171;font-size:14px;margin-top:14px}
  .lock{font-size:15px;color:#A8A8BE;margin-top:18px}
</style></head><body>
  <div class="card">
    <img src="/logos/ct-logo.png" alt="CargoTrack"
      onerror="this.style.display='none'">
    <h1>CargoTrack</h1>
    <p class="sub">This app is locked. Enter your password to open it.</p>
    <form id="lf" autocomplete="off">
      <input id="pw" type="password" placeholder="Password"
        autocomplete="current-password" autofocus>
      <button type="submit">Open app</button>
    </form>
    <div id="err"></div>
    <div class="lock">🔐 Only browsers you sign in on can use this app.</div>
  </div>
<script>
  document.getElementById("lf").addEventListener("submit", async e => {
    e.preventDefault();
    const err = document.getElementById("err");
    err.style.display = "none";
    try {
      const r = await fetch("/api/login", {method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({password:
          document.getElementById("pw").value})});
      if (r.ok) { location.href = "/"; return; }
      const j = await r.json().catch(() => ({}));
      err.textContent = j.error === "wrong password"
        ? "Wrong password — please try again."
        : ("Could not sign in: " + (j.error || r.status));
      err.style.display = "block";
    } catch (ex) {
      err.textContent = "Could not reach the server.";
      err.style.display = "block";
    }
  });
</script>
</body></html>"""


# ---------------- tracking jobs (live layer progress) ----------------
JOBS = {}


def _run_job(job_id, items, mode, carrier_manual, client):
    job = JOBS[job_id]
    results = []
    for item in items:
        events = []

        def cb(name, status, detail=""):
            events.append({"name": name, "status": status, "detail": detail})
            job["events"] = list(events)
            job["current"] = item

        try:
            res = _track_all_timed(
                240,
                bl=item if mode == "bl" else None,
                ctn=item if mode == "container" else None,
                vessel_name=item if mode == "vessel" else None,
                progress_cb=cb,
                carrier_hint=carrier_manual,
                traqo_key=str(get_settings().get("traqo_key")
                              or "").strip() or None)
        except _FutTimeout:
            res = {"carrier": None, "prefix": "", "result": {}, "layers": [],
                   "contacts": None}
            events.append({"name": "Timed out", "status": "fail",
                           "detail": "Sources took too long — the "
                                     "previous record is kept."})
        except Exception as e:
            res = {"carrier": None, "prefix": "", "result": {}, "layers": [],
                   "contacts": None}
            events.append({"name": "Error", "status": "fail", "detail": str(e)})
        if carrier_manual:
            res["carrier"] = carrier_manual
        ctx = {"query": item, "mode": mode, "client": client,
               "carrier": res.get("carrier"), "prefix": res.get("prefix"),
               "result": res.get("result", {}), "layers": res.get("layers", []),
               "contacts": res.get("contacts"),
               "found": bool(res.get("result")),
               "time": datetime.now().strftime("%d/%m %H:%M")}
        try:
            _record(ctx)
        except Exception:
            # F-04 fix (v46 audit): a bad history entry must never kill
            # the job thread — the UI polls until job["done"] is set and
            # would otherwise spin forever with the Track button dead.
            pass
        results.append(ctx)
        job["results"] = list(results)
    job["done"] = True


_PLACEHOLDERS = {"", "/", "—", "-", "N/A", "NA", "None", "null"}
_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun",
     "jul", "aug", "sep", "oct", "nov", "dec"])}


def _real(v):
    """True when a value is real data, not an empty placeholder."""
    if v is None:
        return False
    if isinstance(v, str):
        return v.strip() not in _PLACEHOLDERS
    if isinstance(v, (list, dict)):
        return len(v) > 0
    return True


def _pdate(s):
    """Best-effort date parse for the formats our sources produce."""
    if not s:
        return None
    t = str(s).strip().lower()
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            return None
    m = re.search(r"(\d{1,2})[\s\-]([a-z]{3,9})[\s\-,]+(\d{2,4})", t)
    if m and m.group(2)[:3] in _MONTHS:
        y = int(m.group(3))
        if y < 100:
            y += 2000
        try:
            return date(y, _MONTHS[m.group(2)[:3]], int(m.group(1)))
        except Exception:
            return None
    m = re.search(r"([a-z]{3,9})\s+(\d{1,2})", t)
    if m and m.group(1)[:3] in _MONTHS:
        try:
            return date(date.today().year, _MONTHS[m.group(1)[:3]],
                        int(m.group(2)))
        except Exception:
            return None
    return None


def _canon_voyage(r):
    """Voyage ki canonical shakal — huroof pehle, number baad mein
    (W631, na ke 631W). v91 ka usool pehle sirf _record ke ek raste
    par tha; ab merge ke HAR raste par hai, taake stored record
    hamesha ek hi format mein rahe (data audit: 49 records par
    digit-first voyage para tha)."""
    try:
        v = str(r.get("voyage") or "").strip()
        m = re.fullmatch(r"(\d{1,4})([A-Za-z])", v)
        if m:
            canon = m.group(2).upper() + m.group(1)
            if canon != v:
                r["voyage"] = canon
                for f in ("position", "status"):
                    fv = str(r.get(f) or "")
                    if ("(" + v + ")") in fv:
                        r[f] = fv.replace("(" + v + ")",
                                          "(" + canon + ")")
    except Exception:
        pass


def _own_cycle_correction(old_r, new_r):
    """Sirf EK surat mein ek final status peeche ja sakta hai:
    naya data record ke APNE cycle ka terminal saboot ho — VIR
    bhi wohi, discharge ka din bhi wohi — aur dabba asal mein
    yard ke andar khara dikhaye, jab ke purane final dawe ke paas
    gate_out ki tareekh ka nishan hi na ho (MBAQITS8502261016:
    'Delivered' likha tha, dabba QICT ke yard mein hi tha).
    Is ke baghair stage guard jhooti final ko hamesha ke liye
    band kar deta. 269665315 is se mehfooz hai: wahan naye data
    ka position OUT tha, yard nahi."""
    _ov = str(old_r.get("vir") or "").strip().upper()
    _nv = str(new_r.get("vir") or "").strip().upper()
    if not (_ov and _nv and _ov == _nv):
        return False
    if _real(old_r.get("gate_out")):
        return False
    _od = _pdate(old_r.get("discharge_time"))
    _nd = _pdate(new_r.get("discharge_time"))
    if not (_od and _nd and _od == _nd):
        return False
    if ENG.status_text_stage(new_r.get("status")) < 3:
        return False
    # v98 (S2, EMKAYMBAKHI59055): yard ka saboot POSITION
    # field mein hona chahiye — sirf status TEXT mein
    # 'yard' kafi nahi. QICT ki Ctr-Inq leg sirf discharge
    # dikhati hai (wo halat gate-out ke baad bhi hamesha
    # rehti hai); us se bana 'Discharged…' text ya ghara
    # huwa position final record ko peeche nahi kar sakta.
    # Asal yard sighting hamesha position mein aati hai
    # (terminal grid / Ctr-Inq ki asal position) — 1016 wala
    # asal case ('In Yard' position) is se mehfooz hai.
    _npos = (new_r.get("position") or "").lower()
    return "yard" in _npos


def _merge_result(old_r, new_r):
    """Merge a fresh tracking result into the stored one.

    A weaker new result must never erase data we already know:
    every field keeps the new value when it is real, otherwise the
    old value survives. Containers are unioned.

    v96 data-audit guards (merge = woh choke point jis se manual
    track, re-track aur auto re-check SAB guzarte hain):
    (i) VIR dono taraf ho aur alag ho to naya data is record ke
        cycle ka hai hi nahi — purana record bilkul mehfooz
        (SSLSUKHICAD0733: dabbe ke AGLE export cycle ne mukammal
        import cycle ko daba diya tha).
    (ii) Purana record mukammal (stage >= 4) ho, naye data ka
        vessel alag ho aur naya data khud delivered na ho to ye
        doosra safar / doosri BL ka data hai — pehchan mehfooz
        (PAL/PKKHI/003995 par S430202793 ki sailing values aa
        gayi thin).
    (iii) Stage downgrade kabhi nahi: naye status ka stage purane
        se kam ho to status/position/gate_out purane ke rehte
        hain — siwaye _own_cycle_correction wali ek sabooti
        surat ke (269665315, S490321128 waghera yahin rukte
        hain)."""
    old_r = old_r or {}
    new_r = new_r or {}
    old_stage = ENG.status_stage(old_r)
    new_stage = ENG.status_stage(new_r)
    _ov = str(old_r.get("vir") or "").strip().upper()
    _nv = str(new_r.get("vir") or "").strip().upper()
    foreign = bool(_ov and _nv and _ov != _nv)
    if not foreign and old_stage >= 4:
        _ovv = re.sub(r"[^A-Z0-9]", "",
                      str(old_r.get("vessel") or "").upper())
        _nvv = re.sub(r"[^A-Z0-9]", "",
                      str(new_r.get("vessel") or "").upper())
        if _ovv and _nvv and _ovv != _nvv and new_stage < 5:
            foreign = True
    if foreign:
        merged = dict(old_r)
        _canon_voyage(merged)
        return merged
    merged = {}
    for k in set(old_r) | set(new_r):
        nv, ov = new_r.get(k), old_r.get(k)
        if k == "containers":
            seen, out_c = set(), []
            for c in list(nv or []) + list(ov or []):
                if _real(c) and c not in seen:
                    seen.add(c)
                    out_c.append(c)
            if out_c:
                merged[k] = out_c
            continue
        if _real(nv):
            merged[k] = nv
        elif _real(ov):
            merged[k] = ov
    # (iii) Stage downgrade protection: naya status purane stage
    # se peeche ho to stage wale fields purane ke rehte hain —
    # kamzor/partial nayi synthesis mukammal record ko kabhi
    # peeche nahi kar sakti.
    if ENG.status_text_stage(new_r.get("status")) \
            < ENG.status_text_stage(old_r.get("status")) \
            and not _own_cycle_correction(old_r, new_r):
        for _f in ("status", "position", "gate_out"):
            if _real(old_r.get(_f)):
                merged[_f] = old_r[_f]
        if old_stage >= 4 and _real(old_r.get("discharge_time")):
            merged["discharge_time"] = old_r["discharge_time"]
    # A stored ETA later than the discharge date is a vessel-schedule
    # artifact, not the shipment's ETA — drop it for completed cargo.
    # The combined label "KICT/SAPT" is never a valid terminal name:
    # drop it, and repair any stored status that contains it.
    if merged.get("terminal") == "KICT/SAPT":
        merged.pop("terminal", None)
    _st = merged.get("status") or ""
    if "KICT/SAPT" in _st:
        if merged.get("terminal"):
            merged["status"] = _st.replace("KICT/SAPT",
                                             merged["terminal"])
        else:
            merged["status"] = "Arrived at Karachi terminal"
    # v96 data-audit round 2 — merge par pakki hifazat:
    # (A) Terminal ki pehchan VIR se hai: merged VIR jis terminal
    #     ka naam de, terminal wohi rahega — kisi layer ke andaze
    #     par QICT ka record SAPT nahi ban sakta (Pattern B:
    #     EMKAYMBAKHI59009/58063/58118/58181/58182 — stored aur
    #     fresh VIR bilkul wahi QICT wala tha, terminal phir bhi
    #     flip huwa). Status text ke andar ka ghalat 'at X' bhi
    #     VIR wale naam se sudharta hai.
    _vt = ENG.vir_terminal(merged.get("vir"))
    if _vt:
        if merged.get("terminal") in ("KICT", "SAPT", "QICT",
                                      "KGTL") \
                and merged["terminal"] != _vt:
            merged["terminal"] = _vt
        elif not _real(merged.get("terminal")):
            merged["terminal"] = _vt
        _stm = merged.get("status") or ""
        _bad = re.search(r"\bat (KICT|SAPT|QICT|KGTL)\b", _stm)
        if _bad and _bad.group(1) != _vt:
            merged["status"] = _stm[:_bad.start(1)] + _vt \
                + _stm[_bad.end(1):]
    # (B1) Tasdeeq-shuda departed tareekh kabhi nahi mit-ti: wo
    #     sirf status text ke andar hoti hai (COSCO: 'departed
    #     Shekou 09 Oct 2026'); naya text use daba de to tareekh
    #     purane text se nikal kar apne 'departed' field mein
    #     mehfooz rehti hai (COAU6468022200/6468022890/6468005230).
    if not _real(merged.get("departed")):
        for _src in (old_r, new_r):
            _dd = ENG.departed_date(_src.get("status"))
            if _dd:
                merged["departed"] = _dd
                break
    # (B2) Provenance label ki hifazat: haath se tasdeeq-shuda
    #     source ('verified by Shezi' wala) aam fresh label se
    #     kabhi replace nahi hota (FRLSUBKHI276826: re-track ne
    #     Shezi ki tasdeeq wala nishan mita diya tha).
    _osrc = str(old_r.get("source") or "")
    if "verified by" in _osrc.lower() \
            and merged.get("source") != _osrc:
        merged["source"] = _osrc
    # (B3) 'Partially discharged' mukammal gate-out ke saboot ke
    #     aage nahi tik sakta: kamzor fresh check par guard (iii)
    #     purani text wapas le aata tha, is liye label hamesha ke
    #     liye chipak gaya tha (COAU6469602070/COAU6464740334 —
    #     dono ka gate_out field mukammal tha). Engine ke
    #     _reconcile_status wala usool ab merge par bhi hai.
    _stm = (merged.get("status") or "").lower()
    if "partially" in _stm and "discharg" in _stm \
            and "hold" not in _stm \
            and ENG.status_stage(merged) >= 4:
        merged["status"] = "Released — Delivered" \
            if ENG.status_stage(merged) >= 5 else "Gate out"
    dis = _pdate(merged.get("discharge_time"))
    eta = _pdate(merged.get("eta"))
    st = (merged.get("status") or "").lower()
    if dis and eta and eta > dis and any(
            w in st for w in ("discharg", "released", "delivered",
                              "gate out", "hold")):
        merged.pop("eta", None)
    # v96 proof-run SF-1: taza source sirf number de ("151") to
    # purana harf-wala canonical voyage ("W151") na dabe —
    # canonicalization digit-first ko to sudharti hai (631W ->
    # W631) lekin harf gira hua number wapas nahi la sakti, aur
    # merge ka aam usool (naya real value jeet-ta hai) use
    # khamoshi se daba deta tha (142G513024: W151 -> 151,
    # 142G512913: W085 -> 085). Digits ek hon to purani
    # canonical shakal hi asal voyage hai; digits badle hon
    # to naya number hi chalega.
    _ovv = str(old_r.get("voyage") or "").strip()
    _mvv = str(merged.get("voyage") or "").strip()
    if _ovv and _mvv and re.fullmatch(r"\d+", _mvv):
        _om = re.fullmatch(r"(\d{1,4})([A-Za-z])", _ovv)
        _ocan = (_om.group(2).upper() + _om.group(1)) if _om \
            else _ovv
        _lm = re.fullmatch(r"([A-Za-z])(\d{1,4})", _ocan)
        if _lm and _lm.group(2) == _mvv:
            merged["voyage"] = _ocan
    _canon_voyage(merged)
    return merged


_OLD_LAYER_NAMES = {
    "Layer 0 — Carrier pehchano": "Layer 0 — Carrier identification",
    "Layer 3 — Karachi Terminals (KICT/SAPT)": "Layer 3 — Karachi Terminal",
}
_OLD_TOKENS = ("nahi", "karo", "mila", "rabta", "khulti", "maroof",
               "Neeche", "pehchano", "Namaloom", "ghalat", "sakta")


def _fix_old_detail(d):
    """Translate or clear Roman-Urdu layer details stored by old
    versions, so they never surface in the current app."""
    if "allow nahi karta" in d:
        return ("Automated tracking is not allowed by this carrier "
                "(bot protection).")
    m = re.search(r"KICT/SAPT par (\d+) container", d)
    if m:
        return f"{m.group(1)} container(s) at Karachi terminal"
    if "rabta nahi ho saka" in d:
        return "The source could not be reached on that check."
    if any(t in d for t in _OLD_TOKENS):
        return ""
    return d


def _migrate_entry(h):
    """Bring a stored history entry up to current standards: clean
    result (no combined terminal label, no placeholders), English
    carrier name, English layer names and details."""
    if not isinstance(h, dict):
        return h
    r = h.get("result")
    if isinstance(r, dict) and r:
        h["result"] = _merge_result(r, {})
    if h.get("carrier"):
        h["carrier"] = h["carrier"].replace(" (unverified)", "")
    for lay in h.get("layers") or []:
        if lay.get("name") in _OLD_LAYER_NAMES:
            lay["name"] = _OLD_LAYER_NAMES[lay["name"]]
        if lay.get("detail"):
            lay["detail"] = _fix_old_detail(lay["detail"])
    return h



def _fmt_disch(s):
    """'06-OCT-2026 22:34' / '06-OCT-26 08:48' -> '6 Oct 2026'."""
    m = re.match(r"\s*(\d{1,2})-([A-Za-z]{3})-(\d{2,4})", s or "")
    if not m:
        return s or ""
    y = m.group(3)
    if len(y) == 2:
        y = "20" + y
    return f"{int(m.group(1))} {m.group(2).title()} {y}"


def _eta_cell(r):
    """Report cell: the ETA while a shipment is on the way; once it
    has arrived, the date that matters is the discharge date (QICT
    and the Karachi terminals publish no ETA at all)."""
    if r.get("eta"):
        return _esc(r["eta"])
    if r.get("discharge_time"):
        return "Discharged " + _esc(_fmt_disch(r["discharge_time"]))
    return "—"

def _live_data_layers(layers):
    """Wo layers jin ka 'done' hona asal LIVE data ka saboot hai.
    Sirf carrier pehchan (Layer 0 — offline prefix match) aur
    manual-check rehnumai layers data nahi dete; un ke 'done'
    hone se record 'live verified' nahi banta (data audit FIX 2:
    142G513024/142G512913 par ek bhi data layer kamyab nahi huwa
    tha, phir bhi purana record 'found' ban kar pesh huwa)."""
    out = []
    for l in layers or []:
        if (l or {}).get("status") != "done":
            continue
        if re.search(r"identification|manual check",
                     (l or {}).get("name") or "", re.I):
            continue
        out.append(l)
    return out


def _record(ctx):
    """History mein save (purani entry ki checklist/notes mehfooz).

    Freshness honesty (v41 audit): checked_ts/time are only stamped
    when this check actually returned data — or when there was no
    earlier found record to protect. A refresh whose sources all
    failed must never make old data look freshly checked.

    Waqt ke teen matlab (v96, data audit FIX 2/3):
    attempt_ts/attempt_time = aakhri KOSHISH (kab asal mein dekha);
    checked_ts/time = aakhri TASDEEQ (kab live data ne record ko
    confirm/badla); live_ok/live_ts = is check mein asal data
    layer kamyab huwa ya nahi. User ko 'Last checked' hamesha
    koshish wala waqt dikhta hai; tasdeeq wala waqt alag rehta hai
    taake purana record taza check ka na lage."""
    got_new = bool(ctx.get("result"))
    live_ok = bool(got_new
                   and (not ctx.get("layers")
                        or _live_data_layers(ctx.get("layers"))))
    ctx["live_ok"] = live_ok
    if live_ok:
        ctx["live_ts"] = time.time()
    # v90: har check ka waqt alag mehfooz — card par "Last checked"
    # (ye wali koshish) aur "record confirmed" (asal tasdeeq) ka
    # farq wazeh dikhega; purana record nayi check ka nahi lagega.
    ctx["attempt_ts"] = time.time()
    ctx["attempt_time"] = datetime.now().strftime("%d/%m %H:%M")
    with _lock:
        hist = get_history()
        old = next((h for h in hist if h.get("query") == ctx["query"]), None)
        if old and not live_ok and old.get("live_ts"):
            ctx["live_ts"] = old["live_ts"]
        if old and old.get("found") and not got_new:
            ctx["time"] = old.get("time", ctx.get("time", ""))
            ctx["checked_ts"] = old.get("checked_ts")
            # v96 FIX 2: ye peshkash SAVED record hai, taza find
            # nahi — alag nishan, aur record ki layers bhi usi
            # aakhri asal track ki rehti hain jis ne ye data diya
            # tha (nakam check ki khaali fehrist un ki jagah nahi
            # legi; 'checks from its last track' ka yahi matlab).
            ctx["saved_only"] = True
            if old.get("layers"):
                ctx["layers"] = old["layers"]
        else:
            ctx["checked_ts"] = time.time()
            ctx["saved_only"] = False
        if old:
            ctx["result"] = _merge_result(old.get("result"),
                                           ctx.get("result"))
            if not ctx.get("carrier"):
                ctx["carrier"] = old.get("carrier")
            if ctx.get("carrier"):
                ctx["carrier"] = ctx["carrier"].replace(
                    " (unverified)", "")
            if old.get("found") and ctx["result"]:
                ctx["found"] = True
            ctx["checklist"] = old.get("checklist", {})
            ctx["notes"] = old.get("notes", "")
            ctx["first_seen"] = old.get("first_seen", date.today().isoformat())
            ctx["photo"] = old.get("photo", "")
            for f in ("client", "amount", "received"):
                if not ctx.get(f):
                    ctx[f] = old.get(f, "")
            ctx["returned"] = bool(old.get("returned", False))
            ctx["starred"] = bool(old.get("starred", False))
            old_r = old.get("result") or {}
            new_r = ctx.get("result") or {}
            old_status = old_r.get("status") or ""
            new_status = new_r.get("status") or ""
            old_pos = old_r.get("position") or ""
            new_pos = new_r.get("position") or ""
            # Badlav ki QISAM pehchano (v41) — taake user ke
            # apne alert usool (idea 22) faisla kar sakein ke
            # is badlav par ghanti bajni hai ya khamoshi se
            # sirf record ho jana hai.
            rules = get_settings().get("alert_rules") or {}
            kind = None
            chg = None
            if (not old_r.get("discharge_time")
                    and new_r.get("discharge_time")):
                kind = "discharge"
                chg = {"time": ctx.get("time", ""),
                       "from": "Not discharged",
                       "to": "Discharged " + str(new_r["discharge_time"])}
            elif (new_r.get("holds") or "") != (old_r.get("holds") or "") \
                    and new_r.get("holds"):
                kind = "hold"
                chg = {"time": ctx.get("time", ""),
                       "from": old_r.get("holds") or "No hold",
                       "to": "Hold: " + str(new_r["holds"])}
            elif (not _status_final(old_r)) and _status_final(new_r):
                kind = "delivered"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status or "In progress",
                       "to": new_status or "Delivered"}
            elif old_status and new_status and old_status != new_status:
                kind = "status"
                chg = {"time": ctx.get("time", ""),
                       "from": old_status, "to": new_status}
            elif (old_r.get("eta") and new_r.get("eta")
                    and old_r["eta"] != new_r["eta"]):
                kind = "eta"
                chg = {"time": ctx.get("time", ""),
                       "from": "ETA " + str(old_r["eta"]),
                       "to": "ETA " + str(new_r["eta"])}
            elif old_pos and new_pos and old_pos != new_pos:
                kind = "position"
                chg = {"time": ctx.get("time", ""),
                       "from": f"Position: {old_pos}",
                       "to": f"Position: {new_pos}"}
            _ov = (old_r.get("vessel") or "").strip()
            _nv = (new_r.get("vessel") or "").strip()
            vchg = None
            if _ov and _nv and _ov.upper() != _nv.upper():
                vchg = {"time": ctx.get("time", ""),
                        "from": "Vessel: " + _ov,
                        "to": "Vessel: " + _nv
                        + " — the previous ETA no longer applies; "
                        "a new ETA will be confirmed"}
            changes = old.get("changes") or []
            if chg:
                changes = ([chg] + changes)[:5]
                ctx["change_kind"] = kind
                # Usool band ho to badlav record ho jaye lekin
                # ghanti na baje (purani ghanti bhi na bujhe).
                ctx["changed"] = (True if rules.get(kind, True)
                                  else bool(old.get("changed")))
            else:
                ctx["change_kind"] = old.get("change_kind")
                ctx["changed"] = bool(old.get("changed"))
            ctx["changes"] = changes
            if vchg:
                ctx["changes"] = ([vchg] + (ctx.get("changes")
                                             or []))[:6]
                ctx["changed"] = True
                ctx["change_kind"] = "vessel"
            hist = [h for h in hist if h.get("query") != ctx["query"]]
        else:
            ctx["checklist"] = {}
            ctx["notes"] = ""
            ctx["first_seen"] = date.today().isoformat()
            ctx["changes"] = []
            ctx["changed"] = False
            ctx["returned"] = False
            ctx["starred"] = False
        try:
            ctx["milestones"] = _milestones(ctx)
        except Exception:
            ctx["milestones"] = []
        hist.insert(0, ctx)
        # v91 (#3): voyage ki shakal har record mein EK jaisi —
        # "102W" aur "W102" do formats mein bikhra huwa tha
        # (position strip kuch aur, status change kuch aur kehta tha).
        try:
            _r91 = ctx.get("result") or {}
            _v91 = str(_r91.get("voyage") or "").strip()
            _m91 = re.fullmatch(r"(\d{1,4})([A-Za-z])", _v91)
            if _m91:
                _canon91 = _m91.group(2).upper() + _m91.group(1)
                if _canon91 != _v91:
                    _r91["voyage"] = _canon91
                    for _f91 in ("position", "status"):
                        _fv91 = str(_r91.get(_f91) or "")
                        if ("(" + _v91 + ")") in _fv91:
                            _r91[_f91] = _fv91.replace(
                                "(" + _v91 + ")", "(" + _canon91 + ")")
        except Exception:
            pass
        save_json(HISTORY_FILE, hist[:1000])  # F-11: was a silent 300-entry cap


# ---------------- reports (Tk app wale hi generators, web version) -------
def _esc(s):
    return (str(s or "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")



_REPORT_BRANDS = [
    ("maersk", "M", "#2B7FB8"), ("msc", "MSC", "#111111"),
    ("mediterranean", "MSC", "#111111"), ("cosco", "CO", "#00529B"),
    ("oocl", "OO", "#007A3D"), ("cma", "CMA", "#1B2A6B"),
    ("evergreen", "EG", "#006B54"), ("hapag", "HL", "#D14D00"),
    ("ocean network", "ONE", "#B00062"), ("yang ming", "YM", "#AE0F27"),
    ("wan hai", "WH", "#003E73"), ("zim", "ZIM", "#3E1D63"),
    ("emkay", "EM", "#083D6B"), ("rtw", "RTW", "#4C1D95"),
    ("em-a", "EMA", "#92400E"), ("ema", "EMA", "#92400E"),
    ("kict", "KICT", "#115E59"), ("sapt", "SAPT", "#0A5356"),
    ("qict", "QICT", "#172554"), ("pict", "PICT", "#334155"),
]
_REPORT_LOGOS = [
    ("maersk", "maersk.svg"), ("mediterranean", "msc.svg"),
    ("msc", "msc.svg"), ("cosco", "cosco.svg"), ("oocl", "oocl.svg"),
    ("cma", "cma.svg"), ("evergreen", "evergreen.svg"),
    ("hapag", "hapag.svg"), ("ocean network", "one.svg"),
    ("yang ming", "yangming.png"), ("wan hai", "wanhai.png"),
    ("zim", "zim.svg"), ("emkay", "emkay.png"), ("rtw", "rtw.png"),
    ("hyundai", "hmm.svg"), ("hmm", "hmm.svg"),
    ("pacific international", "pil.svg"), ("em-a", "ema.webp"),
    ("kict", "kict.png"), ("sapt", "sapt.png"), ("qict", "qict.png"),
    ("dp world", "qict.png"), ("star lines", "starlines.png"),
    ("baltic", "baltic.png"), ("new golden", "newgoldensea.png"),
]
_REPORT_PALETTE = ["#475569", "#0E7490", "#7C3AED", "#B45309",
                   "#15803D", "#1D4ED8", "#BE185D", "#0F766E"]

def full_report_html(hist):
    _co = (get_settings().get("company_name") or "").strip()
    _co_tag = (get_settings().get("company_tagline") or "").strip()

    def badge(name):
        n = (name or "").lower()
        for key, mono, col in _REPORT_BRANDS:
            if key in n:
                return (f'<span style="display:inline-block;min-width:30px;'
                        f'text-align:center;background:{col};color:#fff;'
                        f'font-weight:700;font-size:10.5px;border-radius:7px;'
                        f'padding:4px 6px;margin-right:7px">{mono}</span>')
        words = [w for w in re.split(r"[^A-Za-z]+", name or "") if w]
        mono = ((words[0][0] if words else "C")
                + (words[1][0] if len(words) > 1 else "")).upper()
        col = _REPORT_PALETTE[abs(hash(name or "?")) % len(_REPORT_PALETTE)]
        return (f'<span style="display:inline-block;min-width:30px;'
                f'text-align:center;background:{col};color:#fff;'
                f'font-weight:700;font-size:10.5px;border-radius:7px;'
                f'padding:4px 6px;margin-right:7px">{mono}</span>')

    def logo_html(name):
        n = (name or "").lower()
        for key, f in _REPORT_LOGOS:
            if key in n:
                return (f'<img src="/logos/{f}" alt="" style="width:92px;'
                        f'height:26px;object-fit:contain;'
                        f'vertical-align:middle;margin-right:8px">')
        return badge(name)

    def row(h):
        r = h.get("result") or {}
        ok = h.get("found")
        carrier = (h.get("carrier") or "—").replace(" (unverified)", "")
        vessel = r.get("vessel") or "—"
        if r.get("voyage"):
            vessel += f" ({r['voyage']})"
        ctns = ", ".join(r.get("containers") or [])
        return (f"<tr><td>{_esc(h.get('time',''))}</td>"
                f"<td><b>{_esc(h.get('query',''))}</b></td>"
                f"<td>{logo_html(h.get('carrier'))}{_esc(carrier)}</td>"
                f"<td>{_esc(vessel)}</td>"
                f"<td>{_esc(ctns or '—')}</td>"
                f"<td>{_esc(r.get('eta') or '—')}</td>"
                f"<td>{_esc(_fmt_disch(r.get('discharge_time')) or '—')}</td>"
                f"<td>{_esc(r.get('terminal') or '—')}</td>"
                f"<td>{_esc(r.get('position') or '—')}</td>"
                f"<td>{_esc(r.get('status') or '—')}</td>"
                f"<td>{'✅' if ok else '❌'}</td></tr>")
    found = [h for h in hist if h.get("found")]
    notf = [h for h in hist if not h.get("found")]
    th = ("<tr><th>Time</th><th>BL / Query</th><th>Carrier</th><th>Vessel</th>"
          "<th>Containers</th><th>ETA</th><th>Discharged</th><th>Terminal</th>"
          "<th>Position</th><th>Status</th><th></th></tr>")
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>CargoTrack — Full Tracking Report</title><style>
body{{font-family:'Segoe UI',Arial,sans-serif;margin:32px;color:#1F2937}}
h1{{color:#5B21B6}} h2{{margin-top:28px}} table{{border-collapse:collapse;width:100%}}
th{{background:#EDE9FE;color:#5B21B6;text-align:left;padding:8px}}
td{{border-bottom:1px solid #E5E7EB;padding:8px;vertical-align:middle}} .muted{{color:#6B7280}}
@media print{{body{{margin:10px}}}}</style></head><body>
<h1>◆ {_esc(_co) + " — " if _co else ""}CargoTrack — Full Tracking Report</h1>{f'<p style="color:#6B7280;margin:2px 0 0">{_esc(_co_tag)}</p>' if _co_tag else ""}
<p class="muted">Generated {datetime.now().strftime('%d %b %Y, %H:%M')}</p>
<h2>✅ Found ({len(found)})</h2><table>{th}{''.join(row(h) for h in found)}</table>
<h2>❌ Not found ({len(notf)})</h2><table>{th}{''.join(row(h) for h in notf)}</table>
<p class="muted">Tip: Print → Save as PDF to keep a copy.</p></body></html>"""


# ---------------- auto re-check ----------------
def _status_final(result):
    r = result or {}
    st = (r.get("status") or "").lower()
    # v63: sirf 'delivered' final hai — 'deliver' se 'delivery
    # order' jese status bhi final ban jate thay aur un ki
    # dobara jaanch kabhi hoti hi nahi thi.
    return bool(r.get("gate_out")) or "delivered" in st


def _entry_due(h, now_ts, hrs):
    """Is entry ko dobara track karna chahiye ya nahi?
    Waqt ki bunyad aakhri KOSHISH (attempt) hai, aakhri tasdeeq
    nahi (v96 FIX 3): jis record ko abhi dekha gaya — chahe
    sources ne kuch naya na diya ho — wo foran dobara due nahi
    banta; pehle checked_ts par ye records har cycle mein
    baar baar try hote rehte thay."""
    ts = h.get("attempt_ts") or h.get("checked_ts")
    age = (now_ts - float(ts)) if ts else None
    if _status_final(h.get("result")):
        return False
    mult = 0.5 if h.get("starred") else 1.0
    if not h.get("found"):
        # Not-found entries bhi kabhi kabhi dobara dekho (BL baad
        # mein system mein aa sakta hai) — lekin 4 guna dheere.
        return age is None or age >= hrs * 4 * 3600 * mult
    return age is None or age >= hrs * 3600 * mult


_TRACK_EX = ThreadPoolExecutor(max_workers=6,
                                thread_name_prefix="ct-track")


def _track_all_timed(timeout=240, **kw):
    """track_all ko sakht waqt-hadd ke sath chalao. Latka hua
    source caller ko nahi rok sakta; hadd par _FutTimeout
    uthta hai aur caller purana record mehfooz rakhta hai."""
    fut = _TRACK_EX.submit(ENG.track_all, **kw)
    return fut.result(timeout=timeout)


_RECHECK_STATS = {"last_run": 0, "last_cycle": "",
                  "checked": 0, "updated": 0, "cycles": 0,
                  "timeouts": 0}


def _recheck_public():
    try:
        hrs = float(get_settings().get("recheck_hours", 6) or 6)
    except Exception:
        hrs = 6
    return dict(_RECHECK_STATS, hours=hrs)


def _recheck_loop():
    time.sleep(120)  # pehli jaanch start ke ~2 minute baad
    while True:
        try:
            hrs = float(get_settings().get("recheck_hours", 6) or 6)
        except Exception:
            hrs = 6
        try:
            # v96 Data Doctor: har cycle mein ek mukammal
            # local sweep (koi network nahi) — ghalat data
            # pakro, pakka durust karo, baqi Shezi ko report.
            try:
                _doctor_run("auto")
            except Exception:
                pass
            now_ts = time.time()
            due = [h for h in get_history()
                   if h.get("query") and _entry_due(h, now_ts, hrs)]
            def _prio(h):
                r = h.get("result") or {}
                # v63 tartib: pehle wo jo port par utre hue hain
                # aur gate-out baqi hai (asal window), phir baqi
                # found, aakhir mein not-found.
                atport = bool(r.get("discharge_time")) \
                    and not _status_final(r)
                return (0 if atport else (1 if h.get("found") else 2),
                        0 if h.get("starred") else 1,
                        float(h.get("attempt_ts")
                              or h.get("checked_ts") or 0))
            due.sort(key=_prio)
            _RECHECK_STATS["cycles"] += 1
            _RECHECK_STATS["last_run"] = int(now_ts)
            _RECHECK_STATS["last_cycle"] = time.strftime(
                "%d %b %Y, %I:%M %p", time.localtime(now_ts))
            for h in due[:8]:
                mode = h.get("mode", "bl")
                _old = h.get("result") or {}
                _oldkey = ((_old.get("status") or ""),
                           (_old.get("gate_out") or ""))
                try:
                    res = _track_all_timed(
                        240,
                        bl=h["query"] if mode == "bl" else None,
                        ctn=h["query"] if mode == "container" else None,
                        vessel_name=h["query"] if mode == "vessel" else None,
                        carrier_hint=h.get("carrier") or None,
                        traqo_key=str(get_settings().get("traqo_key")
                                      or "").strip() or None)
                except _FutTimeout:
                    # v63: latka hua source — is entry ko chhor
                    # do, purana record mehfooz; loop aage barhe
                    # ga (pehle yahin hamesha atak jata tha).
                    _RECHECK_STATS["timeouts"] += 1
                    continue
                except Exception:
                    continue
                _RECHECK_STATS["checked"] += 1
                ctx = {"query": h["query"], "mode": mode,
                       "client": h.get("client", ""),
                       "carrier": res.get("carrier"),
                       "prefix": res.get("prefix"),
                       "result": res.get("result", {}),
                       "layers": res.get("layers", []),
                       "contacts": res.get("contacts"),
                       "found": bool(res.get("result")),
                       "time": datetime.now().strftime("%d/%m %H:%M")}
                try:
                    _record(ctx)
                except Exception:
                    continue
                try:
                    _new = next((x for x in get_history()
                                 if x.get("query") == h["query"]), {})
                    _nr = _new.get("result") or {}
                    if ((_nr.get("status") or ""),
                            (_nr.get("gate_out") or "")) != _oldkey:
                        _RECHECK_STATS["updated"] += 1
                except Exception:
                    pass
        except Exception:
            pass
        time.sleep(1200)  # agli jaanch 20 minute baad


# ---------------- v96: Data Doctor ----------------
# User ka hukm (29 Oct 2026): Application ke andar ek aisa
# nizam ho jo ghalat/jhoota data FORAN pehchane, jo saboot se
# pakka durust ho use sahi kare, aur baqi Shezi ko report kare
# taake wo mustaqil hal kare. Teen farz:
#   1. PEHCHAAN — data audit (29 Oct) ke sabit-shuda usool ab
#      code ki surat mein har stored record par chalte hain.
#   2. SAHI KARNA — sirf saboot-se-pakki classes (terminal VIR
#      se, voyage canonical, status apne stamped saboot tak,
#      'Partially' mukammal gate-out par, discharge ke baad ki
#      ETA, departed field, returned nishan). Har correction
#      LOG hoti hai — khamoshi se kabhi koi tabdeeli nahi.
#      Na-yaqeeni classes (jhooti Delivered ka shak, shared
#      container, cross-cycle ke nishan) KABHI khud nahi
#      badalti — wo findings banti hain.
#   3. REPORT — findings + correction log DATA_DIR/
#      doctor_report.json mein rehte hain; nayi findings Shezi
#      ki queue mein jati hain (dedupe: stable ID — wahi finding
#      dobara alert nahi hoti, values badlein to ID badal kar
#      naya alert banta hai) aur mauqa milte hi maujooda
#      Send-to-Shezi (email) raste se bheji jati hain; email
#      set na ho to queue mein khari rehti hain — jhoota
#      'sent' kabhi nahi kaha jata.
# Sweep bilkul local hai: koi network call nahi.
DOCTOR_FILE = DATA_DIR / "doctor_report.json"
_DOCTOR_CORR_CAP = 300
_DOCTOR_QUEUE_CAP = 200
_DOCTOR_ALERTED_CAP = 2000


def _dd_now():
    return time.strftime("%d %b %Y, %I:%M %p")


def _dd_fid(query, rule, sig):
    """Finding ka stable ID: record + rule + jin values par
    finding mabni hai un ka signature. Values wahi rahein to
    ID wahi — dobara alert nahi; values badlein to naya ID."""
    raw = f"{query}|{rule}|{sig}"
    return "dd_" + hashlib.md5(raw.encode("utf-8")).hexdigest()[:12]


def _doctor_check_entry(h, shared, now_ts):
    """Ek stored entry par Data Doctor ke tamam usool.
    Entry ko JAAGAH par durust karta hai (sirf saboot-se-pakki
    corrections) aur (corrections, findings) wapas karta hai.
    shared = {container: [queries]} — doosri entries ke sath
    share hone wale containers ka naqsha."""
    corr, finds = [], []
    q = h.get("query") or ""
    r = h.get("result")
    if not h.get("found") or not isinstance(r, dict) or not r:
        return corr, finds
    st = str(r.get("status") or "")
    stl = st.lower()
    tstage = ENG.status_text_stage(st)

    def F(rule, sev, detail, sig):
        finds.append({"id": _dd_fid(q, rule, sig), "query": q,
                      "rule": rule, "severity": sev,
                      "detail": detail, "time": _dd_now()})

    def C(field, before, after, rule):
        corr.append({"query": q, "field": field, "before": before,
                     "after": after, "rule": rule, "time": _dd_now()})

    dis_d = _pdate(r.get("discharge_time"))
    go_d = _pdate(r.get("gate_out"))

    # --- cross-cycle ke nishan PEHLE dekho: aise record ka
    # status khud uthana khatarnak hai (doosre safar ka data
    # chipak sakta hai) — ye sirf finding bane ga.
    smell = False
    if r.get("gate_out"):
        eta_d0 = _pdate(r.get("eta"))
        dep_d0 = _pdate(r.get("departed"))
        pos0 = (r.get("position") or "").lower()
        if "loaded on vessel" in pos0 or "in transit" in stl \
                or "at sea" in stl \
                or (eta_d0 and go_d and eta_d0 > go_d) \
                or (dep_d0 and go_d and dep_d0 > go_d):
            smell = True
            F("cross-cycle-smell", "high",
              "Gate-out stamped hai lekin record ke kuch fields "
              "doosre safar ke lagte hain (status/position/ETA "
              "is cycle se nahi milte) — Shezi parakhe.",
              f"go={r.get('gate_out')}|st={st}"
              f"|eta={r.get('eta') or ''}")

    # --- SAHI 1: terminal hamesha VIR se (merge FIX A usool)
    vt = ENG.vir_terminal(r.get("vir"))
    if vt:
        term = (r.get("terminal") or "").strip()
        if term in ("KICT", "SAPT", "QICT", "KGTL") and term != vt:
            r["terminal"] = vt
            C("terminal", term, vt, "terminal-vir")
            m = re.search(r"\bat (KICT|SAPT|QICT|KGTL)\b", st)
            if m and m.group(1) != vt:
                new_st = st[:m.start(1)] + vt + st[m.end(1):]
                r["status"] = new_st
                C("status", st, new_st, "terminal-vir")
                st, stl = new_st, new_st.lower()
                tstage = ENG.status_text_stage(st)
        elif not term:
            r["terminal"] = vt
            C("terminal", "", vt, "terminal-vir")

    # --- SAHI 2: voyage canonical (631W -> W631)
    _bv = r.get("voyage")
    _canon_voyage(r)
    if _bv and r.get("voyage") != _bv:
        C("voyage", _bv, r.get("voyage"), "voyage-canon")

    # --- SAHI 3: departed tareekh apne field mein mehfooz
    if not _real(r.get("departed")):
        _dd = ENG.departed_date(st)
        if _dd:
            r["departed"] = _dd
            C("departed", "", _dd, "departed-field")

    # --- SAHI 4: status apne hi stamped saboot tak uthao
    # (engine ke _reconcile_status wala usool; hold ko haath
    # nahi lagta, aur cross-cycle smell wale record par bhi
    # nahi — wahan uthana matlab ghalat data pakka karna hoga)
    if not smell and "hold" not in stl:
        ev = ENG.status_stage(r)
        if ev > tstage:
            term = (r.get("terminal") or "").strip()
            if ev >= 5:
                new_st = "Released — Delivered"
            elif ev >= 4:
                new_st = "Gate out"
            else:
                new_st = (f"Discharged at {term}" if term
                          else "Discharged")
            if new_st != st:
                r["status"] = new_st
                C("status", st, new_st, "status-evidence")
                st, stl = new_st, new_st.lower()
                tstage = ENG.status_text_stage(st)

    # --- SAHI 5: mukammal record par discharge ke baad wali
    # ETA schedule ka artifact hai, shipment ki ETA nahi
    eta_d = _pdate(r.get("eta"))
    if dis_d and eta_d and eta_d > dis_d and any(
            w in stl for w in ("discharg", "released", "delivered",
                               "gate out", "hold")):
        C("eta", r.get("eta"), "", "eta-after-discharge")
        r.pop("eta", None)

    # --- SAHI 6: status text khud keh raha hai ke container
    # empty wapis aya, to entry ka returned nishan bhi lagao
    # (lifecycle asal mein wahi field parhta hai)
    if not h.get("returned") and ("empty returned" in stl
                                  or "returned empty" in stl):
        h["returned"] = True
        C("returned", "", "True", "returned-flag")

    # Corrections ke baad ki asal halat
    final = bool(r.get("gate_out")) or tstage >= 5

    # --- FINDING: Delivered ka dawa, saboot adhoora
    if tstage >= 5 and not r.get("gate_out") \
            and not h.get("live_ok"):
        _strong = (r.get("position") or "").strip().upper() \
            in ("OUT", "GATE OUT", "GATE-OUT") \
            and (r.get("truck") or "").strip().lower() == "delivered"
        F("false-delivered-suspect",
          "medium" if _strong else "high",
          "Status 'Delivered' kehta hai lekin gate-out ki "
          "tareekh ka nishan record mein nahi aur is dawe ki "
          "live tasdeeq bhi nahi hui — container asal mein "
          "abhi yard mein ho sakta hai. Shezi container-mode "
          "se parakhe.",
          f"st={st}|pos={r.get('position') or ''}"
          f"|dis={r.get('discharge_time') or ''}")

    # --- FINDING: ek container, do BL (hamesha finding —
    # kaun si BL asal hai, ye data khud nahi bata sakta)
    for c in r.get("containers") or []:
        cn = str(c or "").strip().upper()
        others = [o for o in shared.get(cn, []) if o != q]
        if cn and others:
            F("shared-container", "high",
              f"Container {cn} is ke ilawa in BLs par bhi "
              f"hai: {', '.join(others)} — ek dabba do "
              f"shipments ka nahi ho sakta.",
              f"c={cn}|others={','.join(others)}")

    # --- FINDING: holds aur status ki khamoshi/ikhtilaf
    holds = r.get("holds")
    if _real(holds) and "hold" not in stl:
        F("holds-silent", "medium",
          f"Holds darj hain ({holds}) lekin status un ka "
          f"zikr nahi karta.",
          f"holds={holds}|st={st}")
    if "hold" in stl and not _real(holds):
        F("hold-no-detail", "medium",
          "Status hold kehta hai lekin holds ki tafseel "
          "(holds field) khaali hai.",
          f"st={st}")

    # --- FINDING: tareekhon ki tartib na-mumkin
    if dis_d and go_d and go_d < dis_d:
        F("date-order", "medium",
          "Gate-out ki tareekh discharge se pehle ki hai — "
          "ek tareekh ghalat hai.",
          f"dis={r.get('discharge_time')}|go={r.get('gate_out')}")
    dep_d = _pdate(r.get("departed"))
    if dep_d and dis_d and dis_d < dep_d:
        F("date-order", "medium",
          "Discharge ki tareekh rawangi (departed) se pehle "
          "ki hai — ek tareekh ghalat hai.",
          f"dep={r.get('departed')}"
          f"|dis={r.get('discharge_time')}")

    # --- FINDING: discharge ko 14+ din, record final nahi
    if dis_d and not final:
        days = (date.today() - dis_d).days
        if days >= 14:
            F("stuck-nonfinal", "high" if days >= 60 else "medium",
              f"Discharge ko {days} din ho gaye lekin record "
              f"abhi final nahi — gate-out ya to capture choot "
              f"gaya ya container abhi port par hai.",
              f"dis={r.get('discharge_time')}")

    # --- FINDING: discharged record ke bunyadi hisse ghayab
    if dis_d and not (r.get("terminal") or "").strip():
        F("terminal-missing", "medium",
          "Discharge darj hai lekin terminal ka naam khaali "
          "hai (aur VIR bhi nahi ke wahan se bhar jata).",
          f"dis={r.get('discharge_time')}")
    if dis_d and not r.get("containers"):
        F("containers-missing", "medium",
          "Discharge darj hai lekin containers ki list "
          "khaali hai.",
          f"dis={r.get('discharge_time')}")
    if dis_d and not (r.get("vessel") or "").strip():
        F("vessel-missing", "minor",
          "Found record par vessel ka naam ghayab hai.",
          f"dis={r.get('discharge_time')}")

    # --- FINDING: kabhi re-check nahi / bohat purani check
    if not final:
        if not h.get("attempt_ts") and not h.get("live_ts"):
            F("never-rechecked", "minor",
              "Ye record import/seed ke baad kabhi dobara "
              "check nahi huwa.",
              "no-attempt")
        else:
            ats = h.get("attempt_ts") or h.get("checked_ts")
            try:
                if ats and now_ts - float(ats) > 30 * 86400:
                    F("stale-check", "minor",
                      "Non-final record ki aakhri check 30+ "
                      "din purani hai.",
                      f"ts={int(float(ats))}")
            except Exception:
                pass
    return corr, finds


def _doctor_update_report(prev, findings, corrections, records_n,
                          now_ts):
    """Sweep ke nataij ko report mein jorna — DEDUPE yahin
    hota hai: finding ka stable ID pehle alert ho chuka ho to
    wo Shezi-queue mein dobara nahi jati; underlying values
    badlein to ID badal jata hai aur finding nayi ban kar
    queue mein jati hai. Corrections hamesha log hoti hain."""
    prev = prev if isinstance(prev, dict) else {}
    alerted = set(prev.get("alerted_ids") or [])
    queue = list(prev.get("shezi_queue") or [])
    prev_by_id = {f.get("id"): f
                  for f in prev.get("findings") or []}
    for f in findings:
        old = prev_by_id.get(f["id"])
        f["first_seen"] = (old or {}).get("first_seen") \
            or f.get("time") or _dd_now()
        if f["id"] not in alerted:
            alerted.add(f["id"])
            queue.append({"id": f["id"], "query": f["query"],
                          "rule": f["rule"],
                          "severity": f["severity"],
                          "detail": f["detail"],
                          "time": f["time"]})
    log = list(prev.get("corrections") or []) + list(corrections)
    sev_rank = {"high": 0, "medium": 1, "minor": 2}
    findings = sorted(
        findings,
        key=lambda f: (sev_rank.get(f["severity"], 3),
                       f["query"], f["rule"]))
    return {
        "version": 1,
        "last_run": _dd_now(),
        "last_run_ts": now_ts,
        "records": records_n,
        "findings": findings,
        "corrections": log[-_DOCTOR_CORR_CAP:],
        "shezi_queue": queue[-_DOCTOR_QUEUE_CAP:],
        "alerted_ids": sorted(alerted)[-_DOCTOR_ALERTED_CAP:],
        "queued": bool(queue),
        "last_sent": prev.get("last_sent"),
        "last_send_result": prev.get("last_send_result"),
    }


def _doctor_run(source="auto"):
    """Poori sweep: raw stored history par usool chalao,
    corrections wahin persist karo, report update karo.
    source='auto' (re-check loop) par Shezi-queue ki email
    koshish bhi hoti hai; baqi soraton mein nahi (bhejna
    hamesha wazeh action hai)."""
    with _lock:
        hist = load_json(HISTORY_FILE, [])
        if not isinstance(hist, list):
            hist = []
        now_ts = time.time()
        cmap = {}
        for h in hist:
            if isinstance(h, dict):
                rr = h.get("result") or {}
                for c in rr.get("containers") or []:
                    cn = str(c or "").strip().upper()
                    if cn:
                        cmap.setdefault(cn, set()).add(
                            h.get("query") or "")
        shared = {c: sorted(qs) for c, qs in cmap.items()
                  if len(qs) > 1}
        all_corr, all_finds, changed = [], [], False
        seen_q = {}
        for h in hist:
            if not isinstance(h, dict):
                continue
            q = h.get("query") or ""
            seen_q[q] = seen_q.get(q, 0) + 1
            if q and seen_q[q] > 1:
                all_finds.append({
                    "id": _dd_fid(q, "duplicate-entry",
                                  f"n={seen_q[q]}"),
                    "query": q, "rule": "duplicate-entry",
                    "severity": "medium",
                    "detail": "Yahi number history mein ek se "
                              "zyada dafa darj hai.",
                    "time": _dd_now()})
            c1, f1 = _doctor_check_entry(h, shared, now_ts)
            if c1:
                changed = True
            all_corr += c1
            all_finds += f1
        if changed:
            save_json(HISTORY_FILE, hist)
        prev = load_json(DOCTOR_FILE, {})
        rep = _doctor_update_report(prev, all_finds, all_corr,
                                    len(hist), now_ts)
        save_json(DOCTOR_FILE, rep)
    if source == "auto" and rep.get("shezi_queue"):
        try:
            _doctor_send_now()
        except Exception:
            pass
    return rep


def _doctor_report_text(rep):
    """Shezi ke liye report ka saaf text (email body)."""
    finds = rep.get("findings") or []
    queue = rep.get("shezi_queue") or []
    lines = ["CargoTrack Data Doctor ki report — ye findings "
             "Application ne khud pakri hain; jo saboot se pakka "
             "tha wo wahin durust ho gaya (correction log report "
             "mein hai), baqi ka mustaqil hal Shezi kare.",
             f"Records sweep huwe: {rep.get('records', 0)} · "
             f"Findings: {len(finds)} · "
             f"Nayi (is report mein): {len(queue)}",
             ""]
    items = queue or finds
    for it in items:
        lines.append(f"- [{it.get('severity', '')}] "
                     f"{it.get('query', '')} — "
                     f"{it.get('rule', '')}: {it.get('detail', '')}")
    if not items:
        lines.append("(koi finding nahi — data saaf hai)")
    return "\n".join(lines)


def _doctor_send_now():
    """Queue mein khari findings maujooda Send-to-Shezi
    (Gmail) raste se bhejo. Email set na ho to queue waisi
    hi rehti hai aur jawab mein saaf 'not_set' + queued
    aata hai — jhoota 'sent' kabhi nahi."""
    with _lock:
        rep = load_json(DOCTOR_FILE, {})
        queue = list(rep.get("shezi_queue") or [])
    if not queue:
        return {"ok": False, "reason": "nothing_to_send",
                "queued": False}
    res = _send_escalation(
        [{"role": "user", "text": _doctor_report_text(rep)}],
        "Data Doctor — data quality findings")
    with _lock:
        rep = load_json(DOCTOR_FILE, {})
        if res.get("ok"):
            rep["shezi_queue"] = []
            rep["queued"] = False
            rep["last_sent"] = _dd_now()
        else:
            rep["queued"] = True
        rep["last_send_result"] = res
        save_json(DOCTOR_FILE, rep)
    if not res.get("ok"):
        return {"ok": False, "reason": res.get("reason"),
                "queued": True}
    return {"ok": True}


def _doctor_public(rep=None):
    """GET /api/doctor-data ka jawab: report ka khulasa —
    findings (needs-Shezi) aur corrections (auto-corrected)
    alag alag, sath rail Alerts ke liye tayyar items."""
    rep = rep if isinstance(rep, dict) \
        else load_json(DOCTOR_FILE, {})
    finds = rep.get("findings") or []
    corr = rep.get("corrections") or []
    alerts = []
    for f in finds[:60]:
        alerts.append({
            "q": f["query"],
            "cls": "red" if f["severity"] == "high"
                   else ("amber" if f["severity"] == "medium"
                         else ""),
            "txt": "🩺 Data Doctor: " + f["detail"],
            "t": f.get("first_seen") or f.get("time") or ""})
    return {
        "ok": True,
        "last_run": rep.get("last_run"),
        "counts": {
            "records": rep.get("records", 0),
            "findings": len(finds),
            "corrected_total": len(corr),
            "high": sum(1 for f in finds
                        if f["severity"] == "high"),
            "medium": sum(1 for f in finds
                          if f["severity"] == "medium"),
            "minor": sum(1 for f in finds
                         if f["severity"] == "minor"),
        },
        "findings": finds,
        "needs_shezi": finds,
        "corrected": corr[-50:],
        "queued": bool(rep.get("shezi_queue")),
        "queue_count": len(rep.get("shezi_queue") or []),
        "last_sent": rep.get("last_sent"),
        "last_send_result": rep.get("last_send_result"),
        "alerts": alerts,
    }


# ---------------- HTTP ----------------
MIME = {".html": "text/html; charset=utf-8", ".png": "image/png",
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml",
        ".webp": "image/webp",
        ".json": "application/json; charset=utf-8"}


# ---------------- v50: latest-version check (Item 14) ----------------
_VER_CACHE = {"t": 0.0, "latest": None}
_VERSION_URL = ("https://raw.githubusercontent.com/"
                "cargotrack-app/cargotrack-app/main/version.txt")


def _latest_version():
    """Newest published CargoTrack version, or None when unknown.

    Cached: 6 hours after a successful read, 10 minutes after a
    failure — fail-silent by design: any network problem simply
    leaves the UI showing the running version on its own.
    """
    now = time.time()
    ttl = 6 * 3600 if _VER_CACHE["latest"] is not None else 600
    if now - _VER_CACHE["t"] < ttl and _VER_CACHE["t"]:
        return _VER_CACHE["latest"]
    latest = None
    try:
        import urllib.request as _u
        req = _u.Request(_VERSION_URL,
                         headers={"User-Agent": "CargoTrack/" + str(APP_VERSION)})
        with _u.urlopen(req, timeout=4) as resp:
            txt = resp.read().decode("utf-8", "replace")
        m = re.search(r"\d+", txt)
        if m:
            latest = int(m.group())
    except Exception:
        latest = None
    _VER_CACHE.update(t=now, latest=latest)
    return latest


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8",
              headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            n = 0  # F-15: a malformed header must not kill the handler
        n = max(0, min(n, 32 * 1024 * 1024))
        raw = self.rfile.read(n) if n else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    # ---- v48 auth helpers ----
    def _cookie_token(self):
        raw = self.headers.get("Cookie") or ""
        for part in raw.split(";"):
            part = part.strip()
            if part.startswith("ct_sess="):
                return part[len("ct_sess="):]
        return ""

    def _client_ip(self):
        try:
            return self.client_address[0]
        except Exception:
            return ""

    def _auth_state(self):
        """None = locked out; "unlocked" = no password set;
        otherwise the caller's session token-hash. Also touches the
        session's last_seen (throttled inside _touch_session)."""
        if not _app_pass_hash():
            return "unlocked"
        tok = self._cookie_token()
        if not tok:
            return None
        th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
        with _lock:
            known = th in _load_sessions()["sessions"]
        if not known:
            return None
        _touch_session(th, self.headers.get("User-Agent") or "",
                       self._client_ip())
        return th

    def _locked_out(self, p):
        """True (and a denial response already sent) when this request
        must not proceed. The denial is a 401 JSON — the client turns
        a 401 on its data calls into a full reload, and the server
        then serves the login page for GET /."""
        self._send(401, {"error": "locked"})
        return True

    # ---- v98 Stage B: sync routes ----
    # Token hi in ki hifazat hai — browser session/lock se in
    # ka koi lena dena nahi (hub par app password ho tab bhi
    # joined copies token se jurti hain). Token ghalat/ghayab
    # = 401; is copy par hub chalu hi nahi = 403.
    def _sync_gate(self, u=None):
        if _sync_role() != "hub" \
                or not str(get_settings().get("sync_token_hash") or ""):
            self._send(403, {"error": "sync hub is not enabled "
                                      "on this copy"})
            return False
        tok = self.headers.get("X-Sync-Token") or ""
        if not tok and u is not None:
            tok = (parse_qs(u.query).get("token") or [""])[0]
        if not _sync_token_ok(tok):
            self._send(401, {"error": "bad sync token"})
            return False
        return True

    def _sync_pull(self, u):
        if not self._sync_gate(u):
            return
        try:
            since = float((parse_qs(u.query).get("since")
                           or ["0"])[0])
        except (TypeError, ValueError):
            since = 0.0
        with _lock:
            _sync_note_peer(self.headers.get("X-Sync-Client") or "",
                            self.headers.get("X-Sync-Label") or "")
            snap = _sync_snapshot(since)
        return self._send(200, snap)

    def _sync_join(self):
        if not self._sync_gate():
            return
        b = self._body()
        with _lock:
            _sync_note_peer(str(b.get("client_id") or ""),
                            str(b.get("label") or ""))
            snap = _sync_snapshot(0.0)
        return self._send(200, snap)

    def _sync_push(self):
        if not self._sync_gate():
            return
        b = self._body()
        recs_in = b.get("records") or []
        tombs_in = b.get("tombstones") or []
        with _lock:
            _sync_note_peer(str(b.get("client_id") or ""),
                            str(b.get("label") or ""))
            _sync_stamp_core(mark_clean=True)
            _sync_apply_profile(b.get("profile"))
            hist = get_history()
            _sync_apply(hist, recs_in, tombs_in)
            save_json(HISTORY_FILE, hist[:1000])
            # jo bheja gaya tha us mein se jo hub par mukhtalif
            # nikla, wo wapas — bhejne wala bhi foran wohi ho jaye
            by_q = {h.get("query"): h for h in hist}
            st = _sync_state()
            tombs = {t.get("query"): t for t in st["tombstones"]}
            back, back_t = [], []
            for rec in recs_in:
                q = (rec or {}).get("query")
                if not q:
                    continue
                cur = by_q.get(q)
                if cur is None:
                    if q in tombs:
                        back_t.append(tombs[q])
                elif _sync_rec_hash(cur) != _sync_rec_hash(rec):
                    back.append(cur)
            # hub ki baseline = maujooda halat (stamp pass in
            # par naya ts na thop de)
            st["last_sent"] = {h.get("query"): _sync_rec_hash(h)
                               for h in hist if h.get("query")}
            _sync_state_save(st)
            out = {"ok": True, "records": back,
                   "tombstones": back_t,
                   "profile": _sync_profile_payload(),
                   "max_ts": float(st.get("max_ts") or 0)}
        return self._send(200, out)

    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        # v48: the app logo stays public — the login page shows it.
        if p == "/logos/ct-logo.png":
            f = BASE / "logos" / "ct-logo.png"
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME[".png"])
            return self._send(404, {"error": "no logo"})
        if p == "/api/sync/pull":
            return self._sync_pull(u)
        auth = self._auth_state()
        if p == "/" or p == "/index.html":
            if auth is None:
                # locked and not signed in -> the login page
                return self._send(200, LOGIN_HTML, MIME[".html"])
            f = BASE / "static" / "index.html"
            return self._send(200, f.read_bytes(), MIME[".html"])
        if p.startswith("/avatar/"):
            name = p.rsplit("/", 1)[-1]
            if name in ("hatch.jpg", "hatch.mp4", "hatch_working.mp4",
                        "hatch_making_something.mp4",
                        "hatch_milestone_level_up.mp4",
                        "hatch-call-light-idle.mp4"):
                f = BASE / "avatar" / name
                if f.exists():
                    mime = "video/mp4" if name.endswith(".mp4") else "image/jpeg"
                    return self._send(200, f.read_bytes(), mime)
            return self._send(404, {"error": "no avatar"})
        if auth is None:
            return self._locked_out(p)
        if p == "/profile/photo":
            # v96 Profile photo (DATA_DIR file) — sirf signed-in session ko.
            f = _profile_photo_path()
            if f is None:
                return self._send(404, {"error": "no profile photo"})
            mime = {".jpg": "image/jpeg", ".png": "image/png",
                    ".webp": "image/webp"}[f.suffix]
            return self._send(200, f.read_bytes(), mime)
        if p == "/api/sessions":
            d = _load_sessions()
            sess = []
            for th, s in sorted(
                    d["sessions"].items(),
                    key=lambda kv: kv[1].get("created", 0), reverse=True):
                sess.append({
                    "id": th[:10],
                    "device": device_label(s.get("ua", "")),
                    "ua": s.get("ua", ""),
                    "ip": s.get("ip", ""),
                    "created": s.get("created"),
                    "last_seen": max(float(s.get("last_seen") or 0),
                                     _SESS_SEEN.get(th, 0)),
                    "current": th == auth})
            atts = [{"ts": a.get("ts"), "ip": a.get("ip", ""),
                     "device": device_label(a.get("ua", "")),
                     "ok": bool(a.get("ok"))}
                    for a in d["attempts"][-15:]][::-1]
            return self._send(200, {
                "locked": bool(_app_pass_hash()),
                "count": len(sess), "sessions": sess, "attempts": atts})
        if p == "/demo.html":
            f = BASE / "static" / "demo.html"
            if f.exists():
                return self._send(200, f.read_bytes(), MIME[".html"])
            return self._send(404, {"error": "no demo"})
        if p.startswith("/vendor/"):
            # v96: capture libraries vendored locally (no CDN dependency —
            # a blocked CDN used to kill every Pdf/Jpg button at once).
            name = Path(p).name
            if name in ("html2canvas.min.js", "jspdf.umd.min.js"):
                f = BASE / "static" / "vendor" / name
                if f.is_file():
                    return self._send(200, f.read_bytes(), "text/javascript")
            return self._send(404, {"error": "no vendor"})
        if p.startswith("/logos/"):
            f = (BASE / "logos" / Path(p).name)
            if f.is_file():
                return self._send(200, f.read_bytes(), MIME.get(f.suffix, "image/png"))
            return self._send(404, {"error": "no logo"})
        if p.startswith("/photos/"):
            f = (PHOTOS_DIR / Path(p).name)
            if f.is_file():  # F-16: ".." resolved to the dir itself and crashed read_bytes
                return self._send(200, f.read_bytes(),
                                  MIME.get(f.suffix.lower(), "image/jpeg"))
            return self._send(404, {"error": "no photo"})
        if p == "/api/version":
            return self._send(200, {"app": APP_VERSION,
                                    "built": APP_BUILT,
                                    "latest": _latest_version()})
        if p == "/api/sync/status":
            return self._send(200, _sync_public())
        if p == "/api/weather":
            # v98 (S3): top-bar weather ka SERVER contract.
            # (v97 tak koi server endpoint tha hi nahi — widget
            # browser se seedha Open-Meteo mangta tha aur
            # localStorage cache bina jaanch ke render ho jata
            # tha: icon aa jata, temperature text ghayab.)
            # Usool: kamyabi (ok:True) ke sath asal numeric
            # temp LAZMI hai; data na mile to saaf ok:False —
            # success-shaped khaali payload kabhi nahi, taake
            # UI capsule ko imaandari se chhupa sake.
            w = _wx_fetch("Karachi")
            if not w or w.get("temp") is None:
                return self._send(200, {"ok": False,
                                        "error": "weather "
                                                 "unavailable"})
            return self._send(200, {"ok": True,
                                    "city": w.get("name"),
                                    "temp": w.get("temp"),
                                    "code": w.get("code"),
                                    "hum": w.get("hum"),
                                    "wind": w.get("wind")})
        if p == "/api/ocr/setup-status":
            return self._send(200, _ocr_setup_status())
        if p == "/api/doctor-data":
            return self._send(200, _doctor_public())
        if p == "/api/history":
            hist60 = get_history()
            for _h60 in hist60:
                try:
                    _h60["milestones"] = _milestones(_h60)
                except Exception:
                    _h60["milestones"] = []
                try:
                    _h60["lifecycle"] = _lifecycle(_h60)
                except Exception:
                    _h60["lifecycle"] = {"stage": "active",
                                         "empty_certainty": "none",
                                         "gate_out": "",
                                         "gate_out_certainty": "none",
                                         "empty": "pending"}
            return self._send(200, {"history": hist60,
                                    "settings": _public_settings(),
                                    "recheck": _recheck_public(),
                                    "carriers": sorted(set(ENG.CARRIERS.values()))})
        if p == "/api/job":
            jid = (parse_qs(u.query).get("id") or [""])[0]
            job = JOBS.get(jid)
            if not job:
                return self._send(404, {"error": "job not found"})
            return self._send(200, {"done": job["done"], "current": job["current"],
                                    "events": job["events"],
                                    "results": job["results"]})
        if p == "/api/report/full":
            return self._send(200, full_report_html(get_history()), MIME[".html"])
        if p == "/api/backup":
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                if HISTORY_FILE.exists():
                    z.write(HISTORY_FILE, HISTORY_FILE.name)
                if SETTINGS_FILE.exists():
                    # F-13 fix (v46 audit): the backup used to ship the
                    # plaintext AI key to anyone on the LAN who asked.
                    # The key is stripped from the backup copy; it can
                    # be re-entered in Settings after a restore.
                    safe = {k: v for k, v in load_json(SETTINGS_FILE, {}).items()
                            if k not in ("ai_key", "gemini_key", "groq_key", "app_pass", "traqo_key", "mail_pass")}
                    z.writestr(SETTINGS_FILE.name,
                               json.dumps(safe, ensure_ascii=False, indent=1))
                if PHOTOS_DIR.exists():
                    for pf in sorted(PHOTOS_DIR.iterdir()):
                        if pf.is_file():
                            z.write(pf, f"photos/{pf.name}")
            data = buf.getvalue()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition",
                             'attachment; filename="cargotrack_backup.zip"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        p = u.path
        # v98 Stage B: sync routes session lock se pehle — in
        # ki hifazat sync token hai (hub ki tarah hi).
        if p == "/api/sync/join":
            return self._sync_join()
        if p == "/api/sync/push":
            return self._sync_push()
        if p == "/api/login":
            # the only API route open while locked — it IS the key.
            b = self._body()
            stored = _app_pass_hash()
            if not stored:
                return self._send(400, {"error": "no password set"})
            ua = self.headers.get("User-Agent") or ""
            ip = self._client_ip()
            if not _verify_pass(str(b.get("password") or ""), stored):
                _record_attempt(ip, ua, False)
                return self._send(401, {"error": "wrong password"})
            _record_attempt(ip, ua, True)
            token = _create_session(ua, ip)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _sess_cookie(token))])
        auth = self._auth_state()
        if auth is None:
            return self._locked_out(p)
        b = self._body()
        if p == "/api/logout":
            tok = self._cookie_token()
            if tok:
                th = hashlib.sha256(tok.encode("utf-8")).hexdigest()
                with _lock:
                    d = _load_sessions()
                    d["sessions"].pop(th, None)
                    _save_sessions(d)
                _SESS_SEEN.pop(th, None)
                _SESS_WRITTEN.pop(th, None)
            return self._send(200, {"ok": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/password":
            if b.get("remove") is True:
                # v51: app lock khatam karo — password hash hatao
                # aur tamam saved sessions saaf karo. Caller
                # pehle se authenticated hai (ye route lock gate
                # ke peeche hai). Set/change wala rasta neeche
                # bilkul waisa hi hai jaisa pehle tha.
                s = get_settings()
                s.pop("app_pass", None)
                if not save_json(SETTINGS_FILE, s):
                    return self._send(500, {"error": "could not save"})
                with _lock:
                    d = _load_sessions()
                    d["sessions"] = {}
                    _save_sessions(d)
                _SESS_SEEN.clear()
                _SESS_WRITTEN.clear()
                return self._send(200, {"ok": True},
                                  headers=[("Set-Cookie",
                                            _SESS_COOKIE_CLEAR)])
            new = str(b.get("new") or "")
            if len(new) < 6:
                return self._send(400, {
                    "error": "Password must be at least 6 characters"})
            stored = _app_pass_hash()
            if stored and not _verify_pass(str(b.get("current") or ""),
                                           stored):
                return self._send(401, {"error": "wrong password"})
            s = get_settings()
            s["app_pass"] = _make_pass_hash(new)
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            if not stored:
                # First password ever: sign this browser in right away
                # so the owner is not locked out of his own app.
                token = _create_session(
                    self.headers.get("User-Agent") or "", self._client_ip())
                return self._send(200, {"ok": True, "first": True},
                                  headers=[("Set-Cookie",
                                            _sess_cookie(token))])
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick":
            kid = str(b.get("id") or "")
            if not kid:
                return self._send(400, {"error": "no session id"})
            with _lock:
                d = _load_sessions()
                target = next((k for k in d["sessions"]
                               if k.startswith(kid)), None)
                if target is None:
                    return self._send(404, {"error": "session not found"})
                if target == auth:
                    return self._send(400, {
                        "error": "That is this browser — use Log out"})
                d["sessions"].pop(target, None)
                _save_sessions(d)
            _SESS_SEEN.pop(target, None)
            _SESS_WRITTEN.pop(target, None)
            return self._send(200, {"ok": True})
        if p == "/api/sessions/kick_all":
            with _lock:
                d = _load_sessions()
                d["sessions"] = {}
                _save_sessions(d)
            _SESS_SEEN.clear()
            _SESS_WRITTEN.clear()
            return self._send(200, {"ok": True, "reload": True},
                              headers=[("Set-Cookie", _SESS_COOKIE_CLEAR)])
        if p == "/api/assistant":
            q = (b.get("q") or "").strip()
            if not q:
                return self._send(400, {"error": "empty question"})
            try:
                return self._send(200, assistant_answer(
                    q, b.get("history"), b.get("attach")))
            except Exception as e:
                return self._send(200, {"answer":
                    "Something went wrong while checking: " + str(e),
                    "actions": []})
        if p == "/api/escalate":
            return self._send(200, _send_escalation(
                b.get("turns"), str(b.get("title") or "")))
        if p == "/api/ping":
            return self._send(200, {"v": APP_VERSION})
        if p == "/api/doctor":
            q = str(b.get("q") or "")
            if not q.strip():
                return self._send(400, {"error": "empty"})
            return self._send(200, doctor_number(q))
        if p == "/api/doctor-data":
            # v96 Data Doctor: baghair action ke = abhi sweep
            # chalao; action='send' = queue Shezi ko bhejo
            # (email set na ho to queued hi rehta hai).
            if (b.get("action") or "") == "send":
                res = _doctor_send_now()
                return self._send(200, dict(
                    _doctor_public(), send=res))
            rep = _doctor_run("manual")
            return self._send(200, _doctor_public(rep))
        if p == "/api/transcribe":
            import base64
            data = b.get("data") or ""
            _mime = ""
            if data.startswith("data:"):
                _mime = data[5:].split(";", 1)[0].strip().lower()
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=False)
            except Exception:
                return self._send(400, {"error": "bad audio"})
            if len(raw) > 12 * 1024 * 1024:
                return self._send(400, {"error": "recording too long"})
            if len(raw) < 800:
                return self._send(200, {"ok": False, "error":
                    "Recording too short — speak the number clearly."})
            ok, val = _transcribe_audio(raw, _mime)
            return self._send(200, {"ok": True, "text": val} if ok
                              else {"ok": False, "error": val})
        if p == "/api/track":
            items = [ENG.norm(str(x)) for x in (b.get("items") or []) if str(x).strip()]
            if not items:
                return self._send(400, {"error": "empty"})
            if len(items) > 40:
                return self._send(400, {"error": "too many numbers — 40 at a time, please"})
            if b.get("mode", "bl") not in ("bl", "container", "vessel"):
                return self._send(400, {"error": "bad mode"})
            job_id = f"job{int(time.time()*1000)}{threading.get_ident() % 997}"
            JOBS[job_id] = {"done": False, "current": "", "events": [], "results": []}
            # F-14 fix (v46 audit): finished jobs were kept forever —
            # prune so only the newest 50 done jobs stay in memory.
            done_ids = [k for k, v in JOBS.items() if v.get("done")]
            for old in done_ids[:-50]:
                JOBS.pop(old, None)
            threading.Thread(target=_run_job,
                             args=(job_id, items, b.get("mode", "bl"),
                                   b.get("carrier") or None,
                                   (b.get("client") or "").strip()),
                             daemon=True).start()
            return self._send(200, {"job": job_id})
        if p == "/api/history/update":
            q = b.get("query")
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                if "checklist" in b:
                    hit["checklist"] = b["checklist"]
                if "notes" in b:
                    hit["notes"] = b["notes"]
                for f in ("client", "amount", "received"):
                    if f in b:
                        hit[f] = b[f]
                if "returned" in b:
                    hit["returned"] = bool(b["returned"])
                if "starred" in b:
                    hit["starred"] = bool(b["starred"])
                if b.get("seen"):
                    hit["changed"] = False
                if not save_json(HISTORY_FILE, hist):
                    return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/history/delete":
            q = b.get("query")
            with _lock:
                hist = get_history()
                gone = next((h for h in hist if h.get("query") == q), None)
                if gone is None:
                    return self._send(404, {"error": "entry not found"})
                rest = [h for h in hist if h.get("query") != q]
                if not save_json(HISTORY_FILE, rest):
                    return self._send(500, {"error": "could not save"})
                # v98 Stage B: delete ka tombstone — doosri
                # copies par ye record dobara zinda nahi hoga.
                _st98 = _sync_state()
                _sync_add_tombstone(_st98, q)
                _sync_state_save(_st98)
                ph = gone.get("photo")
                if ph and not any(h.get("photo") == ph for h in rest):
                    try:
                        (PHOTOS_DIR / Path(ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True})
        if p == "/api/settings":
            b = b or {}
            # v48: the password hash is managed ONLY via /api/password —
            # a settings save must never overwrite or inject it.
            b.pop("app_pass", None)
            # v98 Stage B: sync ki chabiyan sirf un ke apne
            # routes se badalti hain — aam settings save inhein
            # chhoo bhi nahi sakta.
            for _sk in ("sync_role", "sync_hub_url",
                        "sync_token_hash", "sync_client_token",
                        "sync_instance_id", "profile_sync_ts"):
                b.pop(_sk, None)
            try:
                if "recheck_hours" in b:
                    rh = float(b["recheck_hours"])
                    if rh not in (3, 6, 12, 24):
                        raise ValueError("recheck_hours")
                    b["recheck_hours"] = rh
                if "free_days" in b:
                    fd = float(b["free_days"])
                    if not (0 <= fd <= 60):
                        raise ValueError("free_days")
                    b["free_days"] = fd
                if "demurrage_rate" in b:
                    dr = float(b["demurrage_rate"])
                    if dr < 0:
                        raise ValueError("demurrage_rate")
                    b["demurrage_rate"] = dr
                if "return_days" in b:
                    rd = float(b["return_days"])
                    if not (1 <= rd <= 60):
                        raise ValueError("return_days")
                    b["return_days"] = rd
            except (TypeError, ValueError) as e:
                return self._send(400, {"error": f"invalid setting: {e}"})
            for k in ("company_name", "company_tagline", "profile_name"):
                if k in b:
                    b[k] = str(b[k]).strip()[:80]
            if "ai_key" in b:
                _k = str(b["ai_key"] or "").strip()
                if _k:
                    b["ai_key"] = _k[:220]
                else:
                    b.pop("ai_key")
            if "gemini_key" in b:
                _k = str(b["gemini_key"] or "").strip()
                if _k:
                    b["gemini_key"] = _k[:220]
                else:
                    b.pop("gemini_key")
            if "groq_key" in b:
                _k = str(b["groq_key"] or "").strip()
                if _k:
                    b["groq_key"] = _k[:220]
                else:
                    b.pop("groq_key")
            if "traqo_key" in b:
                _k = str(b["traqo_key"] or "").strip()
                if _k:
                    b["traqo_key"] = _k[:220]
                else:
                    b.pop("traqo_key")
            if "mail_user" in b:
                b["mail_user"] = str(b["mail_user"] or "").strip()[:80]
            if "mail_pass" in b:
                _k = str(b["mail_pass"] or "").strip()
                if _k:
                    b["mail_pass"] = _k[:220]
                else:
                    b.pop("mail_pass")
            s = get_settings()
            _prof_changed = ("profile_name" in b and str(
                b.get("profile_name") or "").strip()
                != str(s.get("profile_name") or "").strip())
            s.update(b)
            if _prof_changed:
                # profile sync ki ghari — doosri copies par ye
                # naam tabhi jeetega jab ye stamp sab se naya ho
                s["profile_sync_ts"] = _sync_next_ts()
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/sync/make-hub":
            # Is copy ko markazi hub banao: naya token banta
            # hai, settings mein sirf us ka HASH rehta hai;
            # asal token is jawab mein EK dafa dikhta hai.
            token = secrets.token_urlsafe(24)
            s = get_settings()
            s["sync_role"] = "hub"
            s["sync_token_hash"] = hashlib.sha256(
                token.encode("utf-8")).hexdigest()
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True, "token": token,
                                    "note": "Shown only once — "
                                    "copy it into the other "
                                    "copies now."})
        if p == "/api/sync/set-client":
            hub = str(b.get("hub_url") or "").strip().rstrip("/")
            tok = str(b.get("token") or "").strip()
            if not hub.startswith(("http://", "https://")):
                return self._send(400, {
                    "error": "hub address must start with "
                             "http:// or https://"})
            if len(tok) < 10:
                return self._send(400, {
                    "error": "paste the sync token from the hub"})
            s = get_settings()
            s["sync_role"] = "joined"
            s["sync_hub_url"] = hub
            s["sync_client_token"] = tok
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            ok, msg = _sync_join_now()
            return self._send(200 if ok else 502,
                              {"ok": ok, "message": msg,
                               "sync": _sync_public()})
        if p == "/api/sync/leave":
            s = get_settings()
            s["sync_role"] = ""
            if not save_json(SETTINGS_FILE, s):
                return self._send(500, {"error": "could not save"})
            return self._send(200, {"ok": True})
        if p == "/api/sync/now":
            if _sync_role() == "joined":
                _sync_cycle()
            elif _sync_role() == "hub":
                _sync_stamp_pass(mark_clean=True)
            return self._send(200, {"ok": True,
                                    "sync": _sync_public()})
        if p == "/api/photo":
            import base64
            q = ENG.norm(str(b.get("query") or ""))
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            if len(raw) > 8 * 1024 * 1024:
                return self._send(400, {"error": "photo too large (8 MB max)"})
            # The payload must really be an image — trust the file
            # signature, never the caller's word (v41 audit fix).
            fmt = None
            if raw[:3] == b"\xff\xd8\xff":
                fmt = ".jpg"
            elif raw[:8] == b"\x89PNG\r\n\x1a\n":
                fmt = ".png"
            elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                fmt = ".webp"
            if not fmt:
                return self._send(400, {"error": "that file is not an image"})
            name = f"{q}{fmt}"
            with _lock:
                hist = get_history()
                hit = next((h for h in hist if h.get("query") == q), None)
                if hit is None:
                    return self._send(404, {"error": "entry not found"})
                old_ph = hit.get("photo")
                (PHOTOS_DIR / name).write_bytes(raw)
                hit["photo"] = name
                if not save_json(HISTORY_FILE, hist):
                    return self._send(500, {"error": "could not save"})
                if old_ph and old_ph != name:
                    try:
                        (PHOTOS_DIR / Path(old_ph).name).unlink(missing_ok=True)
                    except Exception:
                        pass
            return self._send(200, {"ok": True, "photo": name})
        if p == "/api/profile/photo":
            # v96 Profile photo: client canvas se 512px tak chhoti ho kar
            # aati hai; yahan signature + size ki pakki jaanch, phir
            # DATA_DIR mein ek hi file (doosri ext wali purani delete).
            import base64
            if b.get("remove"):
                for ext in PROFILE_PHOTO_EXTS:
                    try:
                        (DATA_DIR / ("profile_photo" + ext)).unlink(
                            missing_ok=True)
                    except Exception:
                        pass
                _sp = get_settings()
                _sp["profile_sync_ts"] = _sync_next_ts()
                save_json(SETTINGS_FILE, _sp)
                return self._send(200, {"ok": True,
                                        "profile_photo_set": False})
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            if len(raw) > 2 * 1024 * 1024:
                return self._send(400, {"error": "photo too large (2 MB max)"})
            fmt = None
            if raw[:3] == b"\xff\xd8\xff":
                fmt = ".jpg"
            elif raw[:8] == b"\x89PNG\r\n\x1a\n":
                fmt = ".png"
            elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                fmt = ".webp"
            if not fmt:
                return self._send(400, {"error": "that file is not an image"})
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            for ext in PROFILE_PHOTO_EXTS:
                if ext != fmt:
                    try:
                        (DATA_DIR / ("profile_photo" + ext)).unlink(
                            missing_ok=True)
                    except Exception:
                        pass
            (DATA_DIR / ("profile_photo" + fmt)).write_bytes(raw)
            _sp = get_settings()
            _sp["profile_sync_ts"] = _sync_next_ts()
            save_json(SETTINGS_FILE, _sp)
            return self._send(200, {"ok": True, "profile_photo_set": True})
        if p == "/api/ocr":
            # v49 photo scan: app ke andar band OCR engine
            # (RapidOCR, ocr/venv) + seekha-huwa BL extractor
            # (bl-formats-learned.md). Tesseract bilkul nahi.
            import base64
            data = b.get("data") or ""
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = base64.b64decode(data, validate=True)
            except Exception:
                return self._send(400, {"error": "bad image"})
            tmp = DATA_DIR / (f"ocr_tmp_{int(time.time()*1000)}_"
                              f"{threading.get_ident()}.png")
            try:
                tmp.write_bytes(raw)
                d, err = _run_ocr_items(tmp)
            finally:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass
            if err:
                # v51: local engine tayyar nahi (missing / setup
                # chal raha / setup fail) aur settings mein Groq
                # key ho to vision fallback se record banao —
                # warna wahi saaf error jo pehle tha.
                vrec = None
                if not _ocr_python():
                    try:
                        _key = _ai_key_single()
                    except Exception:
                        _key = ""
                    if _key:
                        if raw[:8] == b"\x89PNG\r\n\x1a\n":
                            _mime = "image/png"
                        elif raw[:3] == b"\xff\xd8\xff":
                            _mime = "image/jpeg"
                        elif raw[:4] == b"RIFF" \
                                and raw[8:12] == b"WEBP":
                            _mime = "image/webp"
                        else:
                            _mime = "image/png"
                        vrec = _vision_extract_record(
                            raw, _mime, _key)
                if vrec:
                    return self._send(200, _finalize_scan(vrec))
                return self._send(200, {"ok": False, "error": err})
            rec, meta = extract_bl_record(d["items"], d["w"], d["h"])
            engine = "rapidocr-onnxruntime"
            # OPTIONAL vision booster: sirf cross-check/enrichment;
            # offline result hamesha buniyad hai aur koi vision
            # ghalti scan ko kabhi nahi rokti.
            try:
                vb = _vision_bl_extract(
                    "data:image/png;base64,"
                    + base64.b64encode(raw).decode(), rec, meta)
            except Exception:
                vb = None
            if vb:
                warns = list(rec.get("warnings") or [])
                if rec["bl_no"] \
                        and _sq(str(vb.get("bl_no"))) != rec["bl_no"]:
                    warns.append(
                        "The AI vision check read a different BL "
                        "number (" + str(vb.get("bl_no")) + ") — "
                        "please verify against the document.")
                merged = dict(rec)
                # v84: "bl_no" is list se bahar — vision ka parha
                # number asal OCR number ko kabhi nahi badalta
                # (27 Oct 2026, FRLS wali I/1 ghalti).
                for k in ("carrier", "vessel", "voyage",
                          "shipper", "consignee", "pol", "pod",
                          "ts_port", "on_board", "issue_date",
                          "goods", "packages", "freight"):
                    val = vb.get(k)
                    if val not in (None, ""):
                        merged[k] = val
                for k in ("gross_kg", "net_kg", "cbm", "free_days"):
                    val = vb.get(k)
                    if val not in (None, ""):
                        merged[k] = _num_or_blank(val) or val
                vc = []
                for c in vb.get("containers") or []:
                    if isinstance(c, dict) and c.get("no"):
                        no = _sq(str(c["no"]))
                        vc.append({"no": no,
                                   "seal": _sq(str(c.get("seal")
                                                    or "")),
                                   "type": str(c.get("type") or ""),
                                   "check_ok": _iso_ok(no)})
                if vc:
                    have = {c["no"] for c in merged["containers"]}
                    merged["containers"] = merged["containers"] + \
                        [c for c in vc if c["no"] not in have]
                if merged.get("bl_no"):
                    merged["proforma"] = False
                merged["warnings"] = warns
                rec = merged
                engine = "gemini-vision+rapidocr"
            # v86: variant + rescue ab AKHRI DARWAZE
            # (_finalize_scan) mein hai — har rasta wahin
            # se guzarta hai, koi bypass nahi.
            try:
                _vbno = str(vb.get("bl_no") or "") \
                    if vb else ""
            except Exception:
                _vbno = ""
            rec = _finalize_scan(rec, _vbno)
            rec["ok"] = True
            rec["engine"] = engine
            return self._send(200, rec)
        return self._send(404, {"error": "not found"})



def _iso_ok(s):
    """ISO 6346 check digit ki jaanch."""
    VAL = {"A": 10, "B": 12, "C": 13, "D": 14, "E": 15, "F": 16,
           "G": 17, "H": 18, "I": 19, "J": 20, "K": 21, "L": 23,
           "M": 24, "N": 25, "O": 26, "P": 27, "Q": 28, "R": 29,
           "S": 30, "T": 31, "U": 32, "V": 34, "W": 35, "X": 36,
           "Y": 37, "Z": 38}
    try:
        tot = 0
        for i, ch in enumerate(s[:10]):
            v = int(ch) if ch.isdigit() else VAL[ch]
            tot += v * (2 ** i)
        return (tot % 11) % 10 == int(s[10])
    except Exception:
        return False


def _lev(a, b):
    if abs(len(a) - len(b)) > 3:
        return 99
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1,
                           prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def doctor_number(raw):
    """Number Doctor (idea 20): search se PEHLE number ki
    jaanch — ye BL hai ya container, kis line ka lagta hai,
    digit theek hai ya nahi, aur list ke kisi number se
    milta julta to nahi."""
    import re as _re
    n = ENG.norm(str(raw or ""))
    out = {"input": raw, "normalized": n, "type": "Not recognized",
           "carrier": None, "valid": None, "notes": [],
           "suggestion": None, "expanded": None}
    if not n:
        out["notes"].append("Nothing was entered.")
        return out
    if _re.fullmatch(r"\d{5}", n) and n[0] == "5":
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True, expanded="EMKAYMBAKHI" + n)
        out["notes"].append("5 digits starting with 5 — by the "
                            "standing rule this is an Emkay Lines "
                            "BL; TRACK adds EMKAYMBAKHI by itself.")
        return out
    if n.startswith("EMKAY") or n.startswith("MBAK"):
        out.update(type="BL — Emkay Lines", carrier="Emkay Lines",
                   valid=True)
        out["notes"].append("This is an Emkay Lines BL.")
        return out
    if _re.fullmatch(r"[A-Z]{4}\d{7}", n):
        ok = _iso_ok(n)
        out.update(type="Container", valid=ok,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if ok:
            out["notes"].append("The container number's shape and its "
                                "final check digit are both correct.")
        else:
            out["notes"].append("The final digit (check digit) does not "
                                "match the calculation — there is "
                                "likely a typing mistake in the number.")
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} usually belongs to "
                                f"{out['carrier']}.")
        return out
    if _re.fullmatch(r"[A-Z]{4}[A-Z0-9]{5,}", n):
        out.update(type="BL", valid=True,
                   carrier=ENG.CARRIERS.get(n[:4]))
        if out["carrier"]:
            out["notes"].append(f"Prefix {n[:4]} — this looks like a "
                                f"{out['carrier']} BL.")
        else:
            out["notes"].append("BL-shaped number, but the prefix does "
                                "not match a well-known line — the "
                                "search will still try every route.")
        return out
    if _re.fullmatch(r"\d{9,12}", n):
        out.update(type="BL (digits only)",
                   carrier="COSCO Shipping (likely)", valid=True)
        out["notes"].append("Digits-only BLs are usually COSCO — "
                            "the app will search by the digits.")
        return out
    if _re.fullmatch(r"[A-Z ]{3,}", n) and " " in n.strip():
        out.update(type="Vessel name", valid=True)
        out["notes"].append("This looks like a vessel name — "
                            "search it in Vessel mode.")
        return out
    out["notes"].append("The shape is unclear — it does not look "
                        "like a BL, a container or a vessel name.")
    best = None
    for h in get_history():
        q = (h.get("query") or "").upper()
        if q and abs(len(q) - len(n)) <= 2:
            d = _lev(n, q)
            if best is None or d < best[0]:
                best = (d, q)
    if best and 0 < best[0] <= 2:
        out["suggestion"] = best[1]
        out["notes"].append(f"This closely matches {best[1]} in your "
                            "list — could it be the same one?")
    return out


def _parse_doc_fields(text):
    """BL ki photo ke text se poori tafseel (idea 26): jahaz,
    voyage, wazan, tadaad, samaan — jo mile, imaandari se."""
    import re as _re
    t = text or ""
    f = {}
    m = _re.search(r"VESSEL[:\s]*([A-Za-z][A-Za-z ]{2,28})", t)
    if m:
        f["vessel"] = m.group(1).strip().upper()
    m = _re.search(r"(?:VOYAGE|VOY\.?|V\.)[:\s]*([A-Za-z0-9]{2,10})", t)
    if m:
        f["voyage"] = m.group(1).upper()
    m = _re.search(r"([\d.,]+)\s*KGS?\b", t, _re.I)
    if m:
        f["weight"] = m.group(1) + " KGS"
    m = _re.search(r"(\d+)\s*(PACKAGES|PKGS|CARTONS|BAGS|PCS|UNITS)",
                   t, _re.I)
    if m:
        f["packages"] = m.group(1) + " " + m.group(2).upper()
    for label in ("DESCRIPTION OF GOODS", "DESCRIPTION",
                  "PARTICULARS", "COMMODITY"):
        m = _re.search(label + r"[:\s]*([^\n]{4,90})", t, _re.I)
        if m:
            f["commodity"] = m.group(1).strip(" :-").upper()
            break
    return f


def _ast_date(v):
    """App ki mukhtalif date shaklo ko date mein badlo."""
    if not v:
        return None
    t = str(v).strip()
    for f in ("%d %b %Y", "%d-%b-%Y", "%d %b %y", "%Y-%m-%d",
              "%d/%m/%Y", "%d-%m-%Y", "%d %B %Y"):
        try:
            return datetime.strptime(t.title()
                                     if f in ("%d %b %Y", "%d %b %y")
                                     else t, f).date()
        except Exception:
            continue
    m = re.match(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{4})", t)
    if m:
        try:
            return datetime.strptime(
                f"{m.group(1)} {m.group(2)[:3]} {m.group(3)}",
                "%d %b %Y").date()
        except Exception:
            return None
    return None


def _ast_completed(h):
    r = h.get("result") or {}
    if bool(r.get("gate_out")) or "deliver" in (
            r.get("status") or "").lower() or (
            (r.get("position") or "").upper() == "OUT"):
        return True
    return ((r.get("position") or "").strip().lower() == "departed"
            and bool(r.get("discharge_time"))
            and (r.get("terminal") or "") in (
                "KGTL", "KICT", "SAPT", "QICT"))



def _milestones(h):
    """v60: sakht window — Departed / Berthed / Discharged /
    Gate out. Har marhala: state, when, certainty, note.
    USOOL (Yousuf ki tasheeh, 25 Oct): data KABHI nahi chhupaya
    jata — jo mila wo dikhta hai; lekin sachai ka darja (final /
    confirmed / single / estimate) har marhale ke sath lazmi
    likha jata hai, aur tartib torhne wala record CONFLICT
    ban kar aata hai, final kabhi nahi."""
    from datetime import timedelta, timezone
    today = datetime.now(timezone(timedelta(hours=5))).date()
    r = h.get("result") or {}
    st = (r.get("status") or "").lower()
    ok_names = [str((l or {}).get("name") or "")
                for l in (h.get("layers") or [])
                if (l or {}).get("status") == "done"
                and "identification" not in str((l or {}).get("name") or "").lower()]
    term_ok = any(("terminal" in n.lower() or "qict" in n.lower()
                   or "kict" in n.lower() or "sapt" in n.lower())
                  for n in ok_names)
    n_src = len([n for n in ok_names if n])
    def _d60(v):
        if not v:
            return None
        t = str(v)
        m = re.search(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{2,4})", t)
        if m:
            yy = int(m.group(3))
            if yy < 100:
                yy += 2000
            try:
                return datetime.strptime(
                    f"{m.group(1)} {m.group(2)[:3].title()} {yy}",
                    "%d %b %Y").date()
            except Exception:
                return None
        return _ast_date(v)
    eta_d = _d60(r.get("eta"))
    etd_d = _d60(r.get("etd"))
    dis_d = _d60(r.get("discharge_time"))
    gate_d = _d60(r.get("gate_out"))
    M = []
    dep = {"key": "departed", "label": "Vessel departed",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    mdep = re.search(r"departed[^.]*?(\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4})",
                     r.get("status") or "", re.I)
    dep_when = mdep.group(1) if mdep else None
    if not dep_when and r.get("departed"):
        # v96 FIX B: tareekh ab apne 'departed' field mein bhi
        # mehfooz rehti hai — status text 'Arrived' ban jane par
        # bhi milestone wohi tareekh dikhata hai jo carrier ne
        # tasdeeq ki thi (COAU6468022200: '09 Oct 2026').
        dep_when = str(r["departed"])
    arrived_ev = bool(r.get("vir") or r.get("discharge_time")
                      or r.get("gate_out"))
    if dep_when:
        dep.update(state="done", when=dep_when,
                   certainty="confirmed" if n_src >= 2 else "single",
                   note="carrier event")
    elif arrived_ev:
        dep.update(state="done", certainty="single",
                   note="vessel arrived - departure certain, "
                   "date not in record")
    elif etd_d and etd_d <= today:
        dep.update(state="done", when=str(r.get("etd") or ""),
                   certainty="single", note="ETD passed")
    elif ("in transit" in st or "on board" in st or "loaded" in st
          or eta_d or r.get("discharge_time") or r.get("vir")):
        dep.update(state="done", certainty="single",
                   note="in transit - departure date not in record")
    M.append(dep)
    ber = {"key": "berthed", "label": "Vessel berthed",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    if r.get("vir") or r.get("discharge_time") or r.get("gate_out"):
        ber.update(state="done", certainty="final",
                   note="terminal record"
                   + (f" - VIR {r['vir']}" if r.get("vir") else ""))
    elif ("at " in st and ("terminal" in st or "qict" in st
                           or "kict" in st or "sapt" in st)
          and "expected" not in st):
        ber.update(state="done", certainty="single",
                   note="at terminal - VIR not in record")
    elif eta_d:
        ber.update(state="expected", when=str(r.get("eta") or ""),
                   certainty="estimate",
                   note="ETA is an estimate - not an arrival")
    M.append(ber)
    dis = {"key": "discharged", "label": "Container discharged",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    if r.get("gate_out"):
        dis.update(state="done",
                   when=str(r.get("discharge_time") or ""),
                   certainty="final" if term_ok else "single",
                   note="gate out recorded - discharge certain")
    elif r.get("discharge_time"):
        dis.update(state="partial" if st.startswith("partially")
                   else "done",
                   when=str(r.get("discharge_time") or ""),
                   certainty="final" if term_ok else "single",
                   note="terminal record" if term_ok
                   else "terminal confirmation pending")
        if st.startswith("partially"):
            dis["note"] = ("some containers only - full count "
                           "is in the terminal record")
    elif "discharged" in st:
        dis.update(state="done", certainty="single",
                   note="status only - exact time not in record")
    if dis_d:
        dd = _d60(dep.get("when"))
        if dd and dis_d < dd:
            dis.update(state="conflict",
                       note="discharge is BEFORE departure - "
                       "records disagree, not final")
        elif dis_d > today:
            dis.update(state="conflict",
                       note="discharge date is in the future - "
                       "records disagree, not final")
    M.append(dis)
    gat = {"key": "gateout", "label": "Gate out",
           "state": "pending", "when": "", "certainty": "none",
           "note": ""}
    if r.get("gate_out"):
        gat.update(state="done", when=str(r.get("gate_out") or ""),
                   certainty="final" if term_ok else "single",
                   note="terminal record" if term_ok
                   else "terminal confirmation pending")
    elif "gate out" in st:
        gat.update(state="done", certainty="single",
                   note="status only - exact time not in record")
    elif "deliver" in st:
        gat.update(state="done", certainty="single",
                   note="marked delivered - terminal gate "
                   "record pending")
    elif (r.get("position") or "").strip().lower() == "departed" \
            and r.get("discharge_time") \
            and (r.get("terminal") or "") in (
                "KGTL", "KICT", "SAPT", "QICT"):
        gat.update(state="done", certainty="single",
                   note="the terminal's own record shows this "
                   "container as Departed (left the terminal) - "
                   "the terminal did not give an exact gate-out "
                   "time")
    if gate_d and dis_d and gate_d < dis_d:
        gat.update(state="conflict",
                   note="gate out is BEFORE discharge - records "
                   "disagree, not final")
    M.append(gat)
    return M


def _milestones_line(h):
    # v67 fix: compact codes — verbose line context ka ~50% tha aur
    # Groq free TPM (8000/min) se takra kar Assistant band kar deta tha.
    kmap = {"departed": "dep", "berthed": "ber",
            "discharged": "dis", "gateout": "out"}
    sym = {"done": "\u2713", "partial": "\u25d0", "expected": "~",
           "pending": "\u2026", "conflict": "!"}
    cert = {"final": "F", "confirmed": "C", "single": "1",
            "estimate": "E", "none": ""}
    import re as _re67

    def _sw(w):
        w = str(w or "").strip()
        if not w:
            return ""
        md = _re67.search(r"(\d{1,2})[- ]([A-Za-z]{3})", w)
        mt = _re67.search(r"(\d{1,2})[.:](\d{2})(?:[.:]\d{2})?\s*(AM|PM)?",
                           w, _re67.I)
        out = ""
        if md:
            out = f"{md.group(1)}-{md.group(2).title()}"
        if mt:
            t = f"{int(mt.group(1))}:{mt.group(2)}"
            if mt.group(3):
                t += mt.group(3).upper()
            out = (out + " " + t).strip()
        return out or w[:11]

    parts = []
    for m in _milestones(h):
        pp = (kmap.get(m["key"], str(m["key"])[:3])
              + sym.get(m["state"], "?") + cert.get(m["certainty"], ""))
        sw = _sw(m.get("when"))
        if sw:
            pp += " " + sw
        parts.append(pp)
    return "MS[" + " ".join(parts) + "]"


def _lifecycle(h):
    """v62: shipment ka lifecycle marhala. Gate out ho jaye to
    stage 'out' — record Completed hisse mein jata hai aur us
    par demurrage / empty-return ki koi warning nahi banti;
    record mukammal mehfooz rehta hai (khali container ki
    wapsi h['returned'] wale nishan se, ya kisi source ke text
    mein 'empty returned' ke record se darj hoti hai)."""
    r = h.get("result") or {}
    out = _ast_completed(h)
    when = str(r.get("gate_out") or "")
    cert = "single" if out else "none"
    try:
        for m in _milestones(h):
            if m.get("key") == "gateout" and m.get("state") == "done":
                out = True
                when = when or str(m.get("when") or "")
                cert = m.get("certainty") or cert
    except Exception:
        pass
    empty = "returned" if h.get("returned") else "pending"
    if empty == "pending":
        try:
            blob = (json.dumps(h.get("layers") or [])
                    + " " + str(r.get("status") or "")).lower()
            if ("empty returned" in blob or "returned empty" in blob
                    or "empty container returned" in blob):
                empty = "returned"
        except Exception:
            pass
    empty_certainty = "final" if empty == "returned" else "none"
    if empty == "pending" and out and when:
        # v96 — user's 2+ day rule (29 Oct 2026, his trade knowledge):
        # jo container gate out hota hai wo 1-2 din mein (aksar usi
        # din) empty wapis aa jata hai. Gate-out 2 din se purana ho
        # aur kisi check mein empty-return ka record NA mila ho to
        # wapsi PRESUMED hai — certainty grade 'estimate', kabhi
        # terminal-confirmed nahi. Asal return record milte hi upar
        # wala 'returned' is ki jagah le leta hai.
        try:
            from datetime import timedelta, timezone
            gd = None
            mg = re.search(r"(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{2,4})",
                           str(when))
            if mg:
                yy = int(mg.group(3))
                if yy < 100:
                    yy += 2000
                gd = datetime.strptime(
                    f"{mg.group(1)} {mg.group(2)[:3].title()} {yy}",
                    "%d %b %Y").date()
            if gd is None:
                gd = _ast_date(when)
            if gd is not None and (datetime.now(
                    timezone(timedelta(hours=5))).date() - gd).days > 2:
                empty = "presumed"
                empty_certainty = "estimate"
        except Exception:
            pass
    return {"stage": "out" if out else "active",
            "gate_out": when,
            "gate_out_certainty": cert if out else "none",
            "empty": empty,
            "empty_certainty": empty_certainty}


def _computed_facts(found):
    """v57: Assistant ke liye app ke GINAY HUAY facts — din aur
    gin-ti model ke andaze par nahi chhorte. Aamad (arrivals),
    hold, late aur bina-ETA fehristein TAMAM records se banti
    hain, taake bot aadhi list ko poori na keh sake (v56 ki
    ghalti: context mein sirf pehle 25 records jate thay)."""
    from datetime import timedelta, timezone
    today = datetime.now(timezone(timedelta(hours=5))).date()
    arr, late, noeta, holds = [], [], [], []
    for h in found:
        r = h.get("result") or {}
        st = (r.get("status") or "").lower()
        if "hold" in st:
            holds.append(h)
        if _ast_completed(h):
            continue
        d = _ast_date(r.get("eta"))
        if d and d >= today:
            arr.append((d, h))
        elif d:
            late.append((d, h))
        elif "discharg" not in st and "deliver" not in st \
                and "arriv" not in st and "berthed" not in st \
                and "terminal" not in st:
            noeta.append(h)
    arr.sort(key=lambda x: x[0])
    L = ["",
         "COMPUTED FACTS - counted by the app itself from ALL "
         f"{len(found)} found records (today: "
         f"{today.strftime('%d %b %Y')}, Karachi time). For ANY "
         "question about arrivals, holds or totals, answer ONLY "
         "from this section: list EVERY matching shipment and "
         "state the total number. Never do your own date maths "
         "and never present a partial list as complete."]
    if arr:
        L.append(f"Upcoming arrivals ({len(arr)} total, "
                 "soonest first):")
        for d, h in arr:
            r = h.get("result") or {}
            n = (d - today).days
            when = ("today" if n == 0 else
                    "tomorrow" if n == 1 else f"in {n} days")
            L.append(f"- {h.get('query')} - ETA {r.get('eta')} "
                     f"({when}) - {r.get('vessel') or 'vessel n/a'}"
                     f" - {r.get('terminal') or ''} - "
                     f"{r.get('status') or ''}")
        for w in (7, 14, 20, 30):
            sub = [str(h.get("query")) for d, h in arr
                   if (d - today).days <= w]
            L.append(f"Arriving within {w} days: {len(sub)}"
                     + (": " + ", ".join(sub) if sub else ""))
        nm_first = (today.replace(day=28)
                    + timedelta(days=4)).replace(day=1)
        nm = [str(h.get("query")) for d, h in arr
              if d.year == nm_first.year and d.month == nm_first.month]
        L.append(f"Arriving next month ({nm_first.strftime('%B %Y')}, "
                 "calendar month - keep this SEPARATE from this week): "
                 f"{len(nm)}"
                 + (": " + ", ".join(nm) if nm else ""))
    else:
        L.append("Upcoming arrivals: none with a future ETA.")
    if late:
        L.append("ETA date already passed, still in transit "
                 "(no new date yet): "
                 + ", ".join(str(h.get("query")) for _, h in late))
    if noeta:
        L.append("In transit with NO ETA recorded yet (never "
                 "invent a date for these): "
                 + ", ".join(str(h.get("query")) for h in noeta))
    if holds:
        dis_l, gate_l, conf_l = [], [], []
        for _h in found:
            _ms = {m["key"]: m for m in _milestones(_h)}
            if _ms["discharged"]["state"] in ("done", "partial"):
                dis_l.append(str(_h.get("query")))
            if _ms["gateout"]["state"] == "done":
                gate_l.append(str(_h.get("query")))
            if any(m["state"] == "conflict" for m in _ms.values()):
                conf_l.append(str(_h.get("query")))
        L.append(f"Discharged so far ({len(dis_l)}): "
                 + (", ".join(dis_l) if dis_l else "none"))
        L.append(f"Gate out so far ({len(gate_l)}): "
                 + (", ".join(gate_l) if gate_l else "none"))
        if conf_l:
            L.append("RECORD CONFLICTS - never present these as "
                     "final; say the records disagree: "
                     + ", ".join(conf_l))
        L.append(f"ON HOLD right now ({len(holds)}): "
                 + ", ".join(str(h.get("query")) for h in holds))
    _out62 = [str(h.get("query")) for h in found
              if _lifecycle(h)["stage"] == "out"]
    if _out62:
        L.append(f"OUT OF PORT — Completed section ({len(_out62)}): "
                 + ", ".join(_out62)
                 + " — these shipments are finished (container out "
                 "of the port). NEVER raise demurrage, free-time "
                 "or empty-return warnings for them; their full "
                 "record is kept in the Completed section.")
    return L


def _arrivals_rows(days=30):
    """v59: aane wali shipments ki saaf rows - file (PDF/CSV/TXT)
    banane ke liye. Sirf asal data, koi andaza nahi."""
    from datetime import timedelta, timezone
    today = datetime.now(timezone(timedelta(hours=5))).date()
    rows = []
    for h in get_history():
        if not h.get("found") or _ast_completed(h):
            continue
        r = h.get("result") or {}
        d = _ast_date(r.get("eta"))
        if d and today <= d and (d - today).days <= days:
            rows.append((d, {"bl": str(h.get("query")),
                             "vessel": r.get("vessel") or "-",
                             "eta": r.get("eta") or "-",
                             "terminal": r.get("terminal") or "-",
                             "status": r.get("status") or "-"}))
    rows.sort(key=lambda x: x[0])
    return [r for _, r in rows]


def _assistant_context(lean=False):
    hist = get_history()
    found = [h for h in hist if h.get("found")]
    nf = [h for h in hist if not h.get("found")]
    lines = [f"Shipments in the app: {len(hist)} tracked, "
             f"{len(found)} found, {len(nf)} not found.",
             f"COMPLETE LIST of found shipments (all "
             f"{len(found)} - nothing is cut off):"]
    lines.append(
        "MS[...] milestone codes: dep=vessel departed, ber=berthed, "
        "dis=container discharged, out=gate out; \u2713=done, "
        "\u25d0=partial, ~=expected, \u2026=pending, !=conflict; "
        "F=final (terminal record), C=confirmed (2+ sources), "
        "1=1 source only (unconfirmed), E=estimate. Exact times "
        "are in the app record.")
    for h in found:
        r = h.get("result") or {}
        if _ast_completed(h):
            _cl = (f"- {h.get('query')} ({h.get('carrier') or 'carrier unknown'}): "
                   f"COMPLETED")
            if r.get("vessel"):
                _cl += f", vessel {r['vessel']}"
            if r.get("terminal"):
                _cl += f", terminal {r['terminal']}"
            _cl += f", gate out {r.get('gate_out') or 'done'}"
            lines.append(_cl)
            continue
        row = (f"- {h.get('query')} ({h.get('carrier') or 'carrier unknown'}): "
               f"{r.get('status') or 'status unknown'}")
        if r.get("vessel"):
            row += f", vessel {r['vessel']}"
        if r.get("eta"):
            row += f", ETA {r['eta']}"
        if r.get("terminal"):
            row += f", terminal {r['terminal']}"
        if r.get("containers"):
            row += f", containers {', '.join(r['containers'])}"
        g59 = r.get("goods") or h.get("goods")
        if g59:
            row += f", goods: {g59}"
        row += " || " + _milestones_line(h)
        lines.append(row)
    if nf:
        lines.append("Not found so far: " + ", ".join(
            str(h.get("query")) for h in nf))
    lines.extend(_computed_facts(found))
    st = get_settings()
    lines.append(f"Free days before demurrage: {st.get('free_days')}; "
                 f"auto re-check every {st.get('recheck_hours')} hours.")
    lines.append("Photo scanning (OCR) on this computer: "
                 + ("ready (engine built into the app)"
                    if _ocr_python() else
                    "not set up on this device yet - it installs "
                    "itself automatically the first time you scan "
                    "a photo (one-time, a few minutes)"))
    return "\n".join(lines)

def _ocr_image_bytes(raw):
    """Photo ke bytes se text — v49: app ka apna band OCR engine
    (RapidOCR, subprocess). (True, text) ya (False, wajah)."""
    tmp = DATA_DIR / (f"ocr_tmp_{int(time.time()*1000)}_"
                      f"{threading.get_ident()}.png")
    try:
        tmp.write_bytes(raw)
        d, err = _run_ocr_items(tmp)
        if err:
            return False, err
        items = sorted(d["items"],
                       key=lambda i: (_it_cy(i), _it_cx(i)))
        lines = _ocr_lines(items, d["h"])
        return True, "\n".join(ln["text"] for ln in lines)
    except Exception as e:
        return False, str(e)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def _pdf_text(raw):
    """v46: PDF se text — koi library nahi, stdlib zlib se FlateDecode
    streams khol kar Tj/TJ text operators jama karo. Scanned-image
    PDF par khaali milega (caller imandari se wahi kehta hai)."""
    import re as _re
    import zlib as _zlib
    out = []
    for m in _re.finditer(rb"stream\r?\n(.*?)endstream", raw, _re.S):
        data = m.group(1)
        try:
            data = _zlib.decompress(data)
        except Exception:
            pass
        for t in _re.findall(rb"\((?:\\.|[^\\)])*\)\s*Tj", data):
            out.append(t[1:t.rindex(b")")])
        for arr in _re.findall(rb"\[(.*?)\]\s*TJ", data, _re.S):
            parts = _re.findall(rb"\((?:\\.|[^\\)])*\)", arr)
            if parts:
                out.append(b"".join(p[1:-1] for p in parts))
    txt = b" ".join(out).decode("latin-1", "replace")
    txt = txt.replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\")
    return " ".join(txt.split())


_GLOCAL = threading.local()


_THINK_LVL = {"gemini-3.5-flash-lite": "minimal",
              "gemini-3.8-flash": "low"}
_MODELS = ("gemini-3.5-flash-lite", "gemini-3.8-flash")


def _gemini_try(key, body, model, timeout, tmo_retry=True):
    """Ek model ki koshishein: pehle us ki sab se kam soch ke
    sath; 400 aye ya (sirf chat/race mein) waqt khatam ho to
    baghair soch ke dobara. Wapasi: (dict|None, path, code,
    thoughts_tokens) — thoughts Google ki asal soch ka naap hai."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    body = dict(body)
    base_gc = dict(body.get("generationConfig") or {})
    short = "lite" if "lite" in model else "3.8"
    lvl = _THINK_LVL[model]
    parts = []
    for use_think in (True, False):
        gc = dict(base_gc)
        if use_think:
            gc["thinkingConfig"] = {"thinkingLevel": lvl}
        body["generationConfig"] = gc
        req = _u.Request(
            "https://generativelanguage.googleapis.com/v1beta/"
            f"models/{model}:generateContent?key={key}",
            data=_j.dumps(body).encode(),
            headers={"Content-Type": "application/json"})
        ta = time.time()
        tag = f"{short}/{lvl if use_think else 'none'}"
        try:
            with _u.urlopen(req, timeout=timeout) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
                th = int(((d.get("usageMetadata") or {})
                          .get("thoughtsTokenCount")) or 0)
                parts.append(f"{tag} {time.time() - ta:.1f}s ok th{th}")
                return d, " > ".join(parts), "", th
        except _ue.HTTPError as e:
            parts.append(f"{tag} {time.time() - ta:.1f}s http{e.code}")
            if e.code == 400 and use_think:
                continue
            return None, " > ".join(parts), e.code, 0
        except Exception:
            parts.append(f"{tag} {time.time() - ta:.1f}s fail")
            if use_think and tmo_retry:
                continue
            return None, " > ".join(parts), "timeout", 0
    return None, " > ".join(parts), "", 0


def _gemini_gen(key, body, timeout=35):
    """Sequential rasta (mic/scan ke liye): pehle lite, phir 3.8.
    Yahan timeout-retry NAHI (tmo_retry=False) — der dugni na ho."""
    paths = []
    last = ""
    for model in _MODELS:
        d, pth, code, th = _gemini_try(key, body, model, timeout,
                                       tmo_retry=False)
        paths.append(pth)
        if d:
            _GLOCAL.path = " > ".join(paths)
            _GLOCAL.model = "lite" if "lite" in model else "3.8"
            _GLOCAL.code = ""
            _GLOCAL.thoughts = th
            return d, ""
        last = code
    _GLOCAL.path = " > ".join(paths)
    _GLOCAL.model = ""
    _GLOCAL.code = last
    _GLOCAL.thoughts = 0
    return None, last


def _gemini_gen_race(key, body, timeout=45):
    """Chat ke liye DONO models EK SATH daudte hain — jo pehle
    jawab de, wahi jeet-ta hai. v74: Google 503 (overload) /
    429 / 5xx / timeout jesi WAQTI wajah de to poori daud
    dobara — 3 rounds tak, darmiyan mein saans (6s, phir 10s),
    kul ~75s ki hadd ke andar. Key (401/403) ya request (400)
    ki ghalti par dobara koshish NAHI — wo theek nahi hoti."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    RETRYABLE = (429, 500, 502, 503, 504, "timeout")
    t_start = time.time()
    all_paths = []
    last = ""
    rnd = 0
    while True:
        rnd += 1
        ex = ThreadPoolExecutor(max_workers=2)
        futs = {ex.submit(_gemini_try, key, body, m, timeout): m
                for m in _MODELS}
        paths = {}
        codes = []
        try:
            for fut in as_completed(futs, timeout=timeout + 15):
                m = futs[fut]
                try:
                    d, pth, code, th = fut.result()
                except Exception:
                    d, pth, code, th = None, "", "timeout", 0
                paths[m] = pth
                if code:
                    codes.append(code)
                if d:
                    _GLOCAL.path = " > ".join(
                        all_paths + [pth])
                    _GLOCAL.model = "lite" if "lite" in m else "3.8"
                    _GLOCAL.code = ""
                    _GLOCAL.thoughts = th
                    ex.shutdown(wait=False)
                    return d, ""
        except Exception:
            codes.append("timeout")
        ex.shutdown(wait=False)
        all_paths += [p for p in paths.values() if p]
        if codes:
            last = codes[-1]
        if any(c in (401, 403) for c in codes):
            break
        if not any(c in RETRYABLE for c in codes):
            break
        if rnd >= 3 or time.time() - t_start > 75:
            break
        time.sleep(6 if rnd == 1 else 10)
    _GLOCAL.path = " > ".join(all_paths)
    _GLOCAL.model = ""
    _GLOCAL.code = last
    _GLOCAL.thoughts = 0
    return None, last


def _ai_fail_note():
    """AI fail hone ki asal wajah saada alfaz mein — banner par
    'key failed' ki bajaye pakki wajah + har koshish ka record."""
    code = getattr(_GLOCAL, "code", "")
    path = getattr(_GLOCAL, "path", "")
    if code == 503 or "http503" in path:
        why = ("The AI service is overloaded right now "
               "(503) - the app retried; it usually recovers "
               "within a minute")
    elif code == 429 or "http429" in path:
        why = ("The AI free limit is full right now (429) - "
               "wait a few minutes and ask again")
    elif code in (401, 403):
        why = (f"The saved AI key was rejected ({code}) - "
               "re-paste the key in Settings")
    elif code == 400:
        why = "The AI service rejected the request (400)"
    elif code == "timeout" or " fail" in path:
        why = ("The AI service took too long to answer this time - "
               "its free service is slow right now")
    elif code:
        why = f"AI service error {code}"
    else:
        why = "Google did not answer"
    return why + (f" [{path}]" if path else "")


def _ai_fail_category():
    """v98 (S1b): AI nakami ki asal QISAM — fallback jawab
    mein aam '(an internet hiccup or the free limit)' wale
    shrug ki bajaye yehi qisam saaf likhi jati hai. Qismein:
    timeout / rate limit / invalid key / network."""
    code = getattr(_GLOCAL, "code", "")
    path = getattr(_GLOCAL, "path", "")
    if code in (401, 403) or "http401" in path \
            or "http403" in path:
        return "invalid key"
    if code == 429 or "http429" in path:
        return "rate limit"
    if code == "timeout" or " fail" in path:
        return "timeout"
    return "network"


_AI_WHY_PHRASE = {
    "timeout": "a timeout — the AI service took too "
               "long to respond",
    "rate limit": "a rate limit — the free AI limit is "
                  "full right now",
    "invalid key": "an invalid key — the AI key saved "
                   "in Settings was rejected",
    "network": "a network error — the AI service could "
               "not be reached",
}


def _gemini_text(d):
    """generateContent ke jawab se sirf asal text — soch wale
    (thought) hisse jawab mein nahi milte."""
    try:
        parts = d["candidates"][0]["content"]["parts"]
        return "".join(x.get("text", "") for x in parts
                       if not x.get("thought")).strip()
    except Exception:
        return ""



def _ai_key_single():
    """v68 — EK hi key ka usool: app ke tamam AI kaam (chat,
    mic, photo scan) ek hi Gemini key par chalte hain. Purani
    ai_key mein agar Gemini wali key pari ho (gsk_ wali NAHI —
    Groq keys band ho chuki hain) to wahi chal jati hai."""
    try:
        s = get_settings()
    except Exception:
        return ""
    k = str(s.get("gemini_key") or "").strip()
    if k:
        return k
    k2 = str(s.get("ai_key") or "").strip()
    if k2 and not k2.startswith("gsk_"):
        return k2
    return ""


def _transcribe_audio(raw, mime=""):
    """v75: pehle Groq Whisper (sab se tez transcription),
    na ho ya fail ho to Gemini wala rasta."""
    gk = _groq_key()
    if gk:
        ok, val = _groq_transcribe(gk, raw, mime)
        if ok:
            return ok, val
        if not _ai_key_single():
            return ok, val
    return _transcribe_gemini(raw, mime)


def _transcribe_gemini(raw, mime=""):
    """Recorded aawaz ko Gemini se text banao (v68). Browser
    recording ko WAV bana kar bhejta hai taake har browser ki
    shakal chal jaye; koi aur shakal aye to mime waisa hi aage
    bhej dete hain."""
    import base64 as _b64
    import urllib.request as _u, urllib.error as _ue, json as _j
    key = _ai_key_single()
    if not key:
        return False, ("Voice typing needs the free Gemini key \u2014 "
                       "add it in Settings first.")
    m = (mime or "").strip().lower()
    if "wav" in m:
        gmime = "audio/wav"
    elif "ogg" in m:
        gmime = "audio/ogg"
    elif m.startswith("audio/"):
        gmime = m
    else:
        gmime = "audio/wav"
    prompt = ("Transcribe this audio exactly, word for word, and "
              "return ONLY the transcription text. The speaker may "
              "speak English, Urdu or Roman Urdu, and may read out "
              "shipping numbers (bill of lading or container "
              "numbers) digit by digit \u2014 write digits as numbers "
              "(0-9). If there is no speech, return nothing.")
    body = {"contents": [{"role": "user", "parts": [
                {"text": prompt},
                {"inline_data": {"mime_type": gmime,
                                 "data": _b64.b64encode(
                                     raw).decode()}}]}],
            "generationConfig": {"temperature": 0}}
    d, code = _gemini_gen(key, body, timeout=40)
    if d:
        txt = _gemini_text(d)
        if txt:
            return True, txt
        return False, ("Nothing was heard in that recording \u2014 "
                       "try again, a little closer to the mic.")
    if code in (401, 403):
        return False, ("The AI key was refused by Google \u2014 "
                       "check the key in Settings.")
    return False, (f"Voice service error ({code}) \u2014 "
                   "please try again.")



def _groq_answer(q, hist, key, extra=""):
    """Groq (muft tier, Llama models) se asal guftagu. Key
    'gsk_' se shuru hoti hai. Ghalti par None — local jawab
    sambhal lega, jhooti tasalli kabhi nahi."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    sys_txt = (
        "You are CargoTrack Assistant, the assistant built into this app - not ChatGPT or any other product, never introduce yourself as one. This is a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. FORMAT: put each fact on its OWN line - for a shipment: the BL on one line, then Vessel, ETA, Terminal and Status each on its own line; never cram several facts into one long sentence, and use bold sparingly. When he asks about different periods (this week, next month), answer in SEPARATE sections, one per period, each with its own heading and count; next month means the next calendar month only - never merge periods or repeat an item in two sections. When he asks what goods or items are inside a container, answer ONLY from the goods recorded in the data; if no goods are recorded for it, say so plainly in your FIRST sentence - never answer an item question with vessel details. For the four critical stages (vessel departed, vessel berthed, container discharged, gate out) answer ONLY from the MILESTONES data and always state its certainty in your reply (final / confirmed / 1 source only / estimate); call every ETA an estimate, never a fact; if a milestone says CONFLICT, tell him the records disagree instead of picking one. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. Answer EXACTLY the question he asked - never substitute a different answer. When he asks for all / every / tamaam / sab, enumerate the COMPLETE matching list from the data below and state how many there are; presenting a partial list as complete is the worst possible answer. The COMPUTED FACTS section was counted by the app from ALL records - trust it over your own counting and date maths. If he asks for a photo, image, card or report but has NOT named a shipment in this conversation, ask in ONE short line which BL he means - never pick a shipment for him, and never volunteer information he did not ask for. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app attaches the real file button under your reply when a shipment is identified - so say only one short line such as: the file button is below. NEVER claim a file is ready when no shipment was identified - in that case ask which BL he means. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically." + _today_line() + _profile_line() + _NO_WEB_RULE + "\n\nLIVE APP DATA:\n"
        + _assistant_context() + extra)
    msgs = [{"role": "system", "content": sys_txt}]
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:500]
        if t:
            msgs.append({"role": "user" if h.get("role") == "user"
                         else "assistant", "content": t})
    msgs.append({"role": "user", "content": q})
    # Groq ka catalog badalta rehta hai — 21 Oct 2026 ko is
    # account par Llama models maujood hi nahi thay, sirf
    # gpt-oss / qwen family thi. Is liye pehle wohi, phir
    # purane naam (jin accounts par hon un ke liye).
    for model in ("openai/gpt-oss-120b", "qwen/qwen3.8-27b",
                  "openai/gpt-oss-20b"):
        try:
            body = {"model": model, "messages": msgs,
                    "temperature": 0.2, "max_tokens": 900}
            if model.startswith("openai/"):
                # gpt-oss reasoning models: low effort taake jawab
                # max_tokens ke andar content mein aye, khaali na rahe.
                body["reasoning_effort"] = "low"
            req = _u.Request(
                "https://api.groq.com/openai/v1/chat/completions",
                data=_j.dumps(body).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}",
                         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; "
                         "Win64; x64) AppleWebKit/537.36 (KHTML, "
                         "like Gecko) Chrome/130.0 Safari/537.36"})
            with _u.urlopen(req, timeout=35) as r:
                d = _j.loads(r.read().decode("utf-8", "replace"))
            txt = (d["choices"][0]["message"].get("content")
                   or "").strip()
            if txt:
                return txt
        except _ue.HTTPError as e:
            if e.code in (404, 400, 403, 408, 413, 429):
                continue
            return None
        except Exception:
            continue  # F-12: one model's network hiccup must not skip the rest
    return None


# ================= v75: tez AI (Groq) + sawal-mutabiq data =================

_GREET_SET = {"hi", "hello", "hey", "salam", "slam", "aoa",
              "kese ho", "kaise ho", "kese hi", "kese ho bhai",
              "hello bhai", "assalam o alaikum",
              "assalamualaikum"}


def _kw_match(ql, words=(), stems=()):
    """Keyword ki jaanch LAFZ KI HAD par: 'call me' ke andar
    'all', 'detail' ke andar 'eta', 'important' ke andar 'port'
    kabhi match nahi hoga (v79 — code review ka bug fix).
    stems wo tukde hain jo lafz ke SHURU mein aayein to
    chalega (arriv -> arriving, kitn -> kitne)."""
    for w in words:
        if re.search(r"\b" + re.escape(w) + r"\b", ql):
            return True
    for s in stems:
        if re.search(r"\b" + re.escape(s), ql):
            return True
    return False


def _is_pure_greeting(q):
    n = re.sub(r"[^a-z ]", "", (q or "").lower())
    n = re.sub(r"\s+", " ", n).strip()
    return n in _GREET_SET


def _groq_key():
    try:
        return str(get_settings().get("groq_key") or "").strip()
    except Exception:
        return ""


def _assistant_context_for(q, hay=""):
    """v75 ka pakka usool (us ki hidayaat, 26 Oct): data SIRF
    tab jayega jab sawal data ka ho. Aam sawal (mosam waghera)
    par SIFAR data; ek shipment ke sawal par sirf wahi record;
    list/sab wale sawal par hi poora khulasa (warna list
    adhoori reh jayegi)."""
    if _is_pure_greeting(q):
        return ""
    ql = " " + (q or "").lower() + " "
    ql = ql.replace(" hold on ", " ")  # angrezi jumla, hold nahi
    if _kw_match(ql,
                 words=("sab", "all", "every", "tamaam", "list",
                        "hold", "holds", "gate out", "discharge",
                        "discharged", "this week", "is week",
                        "is month", "next week", "next month",
                        "agle", "report", "reports", "summary",
                        "overview", "demurrage"),
                 stems=("arriv", "kitn")):
        return _assistant_context()
    full = _assistant_context()
    lines = full.split("\n")
    head0 = lines[0] if lines else ""
    matched = []
    in_rec = False
    hayu = ((hay or "") + " " + (q or "")).upper()
    for ln in lines:
        if ln.startswith("COMPLETE LIST"):
            in_rec = True
            continue
        if ln.startswith("COMPUTED FACTS"):
            break
        if in_rec and ln.startswith("- "):
            tok = ln[2:].split(" ")[0].split("(")[0].strip().upper()
            if tok and len(tok) >= 5 and tok in hayu:
                matched.append(ln)
    if matched:
        return "\n".join([head0] + matched)
    return ""


def _oai_chat_try(key, model, messages, timeout=30, effort=None):
    """OpenAI-compatible chat ki ek koshish (Groq).
    (text|None, path, code) wapas karta hai."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    body = {"model": model, "messages": messages,
            "temperature": 0.2, "max_tokens": 1000}
    if effort:
        body["reasoning_effort"] = effort
    short = ("groq120" if "120b" in model else
             "groq20" if "20b" in model else "groq")
    ta = time.time()
    try:
        req = _u.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=_j.dumps(body).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + key})
        with _u.urlopen(req, timeout=timeout) as r:
            d = _j.loads(r.read().decode("utf-8", "replace"))
        txt = (((d.get("choices") or [{}])[0].get("message")
                or {}).get("content") or "").strip()
        if txt:
            return txt, f"{short} {time.time() - ta:.1f}s ok", ""
        return None, f"{short} {time.time() - ta:.1f}s empty", "empty"
    except _ue.HTTPError as e:
        return None, f"{short} {time.time() - ta:.1f}s http{e.code}", e.code
    except Exception:
        return None, f"{short} {time.time() - ta:.1f}s fail", "timeout"


def _groq_leg(q, hist, gk, model, extra, ctx):
    body = _gemini_body(q, hist, extra, ctx_override=ctx)
    sys_txt = body["systemInstruction"]["parts"][0]["text"]
    msgs = [{"role": "system", "content": sys_txt}]
    for c in body["contents"]:
        msgs.append({
            "role": "user" if c["role"] == "user" else "assistant",
            "content": "".join(p.get("text", "")
                               for p in c["parts"])})
    txt, pth, code = _oai_chat_try(gk, model, msgs, timeout=30,
                                   effort="low")
    return txt, pth, code, 0


def _gemini_leg(gemkey, body, model):
    d, pth, code, th = _gemini_try(gemkey, body, model, 45)
    return (_gemini_text(d) if d else None), pth, code, th


def _multi_race(legs, per_timeout=45):
    """Tamam providers EK SATH — pehla sahi jawab jeet-ta hai.
    Waqti nakami (503/429/5xx/timeout) par dobara daud, 3
    rounds tak; key ki ghalti par dobara nahi."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    RETRYABLE = (429, 500, 502, 503, 504, "timeout")
    t_start = time.time()
    all_paths = []
    last = ""
    rnd = 0
    while True:
        rnd += 1
        ex = ThreadPoolExecutor(max_workers=max(2, len(legs)))
        futs = {ex.submit(lg["fn"]): lg for lg in legs}
        paths = {}
        codes = []
        try:
            for fut in as_completed(futs, timeout=per_timeout + 15):
                lg = futs[fut]
                try:
                    txt, pth, code, th = fut.result()
                except Exception:
                    txt, pth, code, th = None, "", "timeout", 0
                paths[id(lg)] = pth
                if code:
                    codes.append(code)
                if txt:
                    _GLOCAL.path = " > ".join(
                        all_paths + [pth])
                    _GLOCAL.model = lg["model"]
                    _GLOCAL.code = ""
                    _GLOCAL.thoughts = th
                    ex.shutdown(wait=False)
                    return txt
        except Exception:
            codes.append("timeout")
        ex.shutdown(wait=False)
        all_paths += [p for p in paths.values() if p]
        if codes:
            last = codes[-1]
        if any(c in (401, 403) for c in codes):
            break
        if not any(c in RETRYABLE for c in codes):
            break
        if rnd >= 3 or time.time() - t_start > 80:
            break
        time.sleep(5 if rnd == 1 else 8)
    _GLOCAL.path = " > ".join(all_paths)
    _GLOCAL.model = ""
    _GLOCAL.code = last
    _GLOCAL.thoughts = 0
    return None


def _ai_answer_any(q, hist, gk, gemkey, extra=""):
    """Chat ka markazi rasta (v75): Groq (tez) + Gemini
    (backup / PDF / poora data) — ek hi race mein."""
    hay = " ".join(str((h or {}).get("text") or "")
                   for h in (hist or [])[-4:])
    ctx = _assistant_context_for(q, hay)
    legs = []
    if gk:
        gctx = ctx[:9000]
        for model in ("openai/gpt-oss-120b", "openai/gpt-oss-20b"):
            legs.append({"model": "Groq", "fn": (
                lambda m=model: _groq_leg(q, hist, gk, m,
                                          extra, gctx))})
    if gemkey:
        body = _gemini_body(q, hist, extra, ctx_override=ctx)
        for model in _MODELS:
            legs.append({
                "model": "lite" if "lite" in model else "3.8",
                "fn": (lambda m=model: _gemini_leg(gemkey,
                                                   body, m))})
    if not legs:
        return None
    return _multi_race(legs, 45)


def _groq_vision_text(key, prompt, mime, b64):
    """Groq ke vision model se photo ka text/JSON (scan)."""
    import urllib.request as _u, json as _j
    try:
        body = {"model": "meta-llama/llama-4-scout-17b-16e-instruct",
                "messages": [{"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {
                        "url": f"data:{mime};base64,{b64}"}}]}],
                "temperature": 0, "max_tokens": 1500}
        req = _u.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=_j.dumps(body).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + key})
        with _u.urlopen(req, timeout=40) as r:
            d = _j.loads(r.read().decode("utf-8", "replace"))
        return (((d.get("choices") or [{}])[0].get("message")
                 or {}).get("content") or "").strip() or None
    except Exception:
        return None


def _vision_text_any(prompt, mime, b64):
    """Photo parakh: pehle Groq vision (tez), na ho to Gemini."""
    gk = _groq_key()
    if gk:
        t = _groq_vision_text(gk, prompt, mime, b64)
        if t:
            return t
    key = _ai_key_single()
    if not key:
        return None
    d, _c = _gemini_gen(key, {"contents": [{"role": "user",
                        "parts": [{"text": prompt},
                        {"inline_data": {"mime_type": mime,
                                         "data": b64}}]}],
                    "generationConfig": {"temperature": 0}},
                    timeout=45)
    return _gemini_text(d) if d else None


def _groq_transcribe(key, raw, mime=""):
    """Groq Whisper se awaz ka text (mic) — sab se tez."""
    import urllib.request as _u, urllib.error as _ue
    import json as _j, uuid
    try:
        bnd = "----ct" + uuid.uuid4().hex
        fn, ct = "voice.wav", "audio/wav"
        m = (mime or "").lower()
        if "ogg" in m:
            fn, ct = "voice.ogg", "audio/ogg"
        elif "webm" in m:
            fn, ct = "voice.webm", "audio/webm"
        elif "mp4" in m or "m4a" in m:
            fn, ct = "voice.m4a", "audio/mp4"
        parts = []
        for name, val in (("model", "whisper-large-v3-turbo"),
                          ("response_format", "json")):
            parts.append(
                f"--{bnd}\r\nContent-Disposition: form-data; "
                f"name=\"{name}\"\r\n\r\n{val}\r\n".encode())
        head = (f"--{bnd}\r\nContent-Disposition: form-data; "
                f"name=\"file\"; filename=\"{fn}\"\r\n"
                f"Content-Type: {ct}\r\n\r\n").encode()
        body = (b"".join(parts) + head + raw
                + f"\r\n--{bnd}--\r\n".encode())
        req = _u.Request(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            data=body,
            headers={"Authorization": "Bearer " + key,
                     "Content-Type":
                         f"multipart/form-data; boundary={bnd}"})
        with _u.urlopen(req, timeout=35) as r:
            d = _j.loads(r.read().decode("utf-8", "replace"))
        txt = (d.get("text") or "").strip()
        if txt:
            return True, txt
        return False, ("Nothing was heard in that recording "
                       "- try again, a little closer to the mic.")
    except _ue.HTTPError as e:
        if e.code in (401, 403):
            return False, ("The Groq key was refused - check "
                           "the key in Settings.")
        return False, f"Voice service error ({e.code}) - please try again."
    except Exception:
        return False, "Voice service error (network) - please try again."


_DATA_WORDS = ("hold", "holds", "gate out", "gateout",
               "discharge", "discharged", "eta", "vessel",
               "terminal", "demurrage", "berth", "berths",
               "status", "list", "container", "shipment",
               "shipments", "kab", "kahan", "kon se", "port",
               "sapt", "kict", "qict", "kgtl", "late", "delay",
               "release", "custom", "customs", "delivery order",
               "tracking", "track")
_DATA_STEMS = ("arriv", "kitn", "depart")


def _looks_data_q(q):
    """Sawal app ke data ke bare mein lagta hai? (number wala
    token ya data ka lafz)"""
    t = q or ""
    if re.search(r"[A-Za-z]{2,}\d{4,}|\d{6,}", t):
        return True
    ql = " " + t.lower() + " "
    return _kw_match(ql, words=_DATA_WORDS, stems=_DATA_STEMS)


def _local_substantive(out):
    """Local jawab asal data par mabni hai ya aam 'mein sirf
    assistant hu' wali baat? Fast-lane sirf asal jawab par."""
    t = ((out or {}).get("answer") or "").strip()
    if len(t) < 40:
        return False
    if "I am the built-in assistant" in t[:120]:
        return False
    if "Hello! I watch your shipments" in t[:120]:
        return False
    return True


# ================= v77: greeting + mosam — app khud =================


_WX_WORDS = ("mosam", "mausam", "weather", "garmi", "barish",
             "baarish", "sardi", "rain", "dhund", "fog")
_WX_CODES = {0: "saaf asmaan", 1: "takreeban saaf", 2: "thore badal",
             3: "badal chhaye hue", 45: "dhund", 48: "dhund",
             51: "halki boonda bandi", 53: "boonda bandi",
             55: "boonda bandi", 61: "halki barish",
             63: "barish", 65: "tez barish", 71: "halki barf",
             73: "barf", 75: "tez barf", 80: "halki barish",
             81: "barish", 82: "musladhar barish",
             95: "garaj chamak", 96: "garaj chamak",
             99: "garaj chamak"}


_WX_CITIES = ("karachi", "lahore", "islamabad", "rawalpindi",
              "faisalabad", "multan", "peshawar", "quetta",
              "hyderabad", "sukkur", "sialkot", "gujranwala",
              "bahawalpur", "sargodha", "mardan", "swat", "abbottabad",
              "mingora", "gilgit", "skardu", "muzaffarabad",
              "jhelum", "okara", "sahiwal", "larkana",
              "nawabshah", "gwadar", "turbat", "khuzdar",
              "dubai", "abu dhabi", "sharjah", "doha", "muscat",
              "riyadh", "jeddah", "kuwait city", "london",
              "new york", "toronto", "singapore", "kuala lumpur",
              "bangkok", "hong kong", "tokyo", "delhi", "mumbai",
              "beijing", "shanghai", "sydney")
_WX_PANEL = ("Karachi", "Lahore", "Islamabad", "Rawalpindi",
             "Faisalabad", "Multan", "Peshawar", "Quetta",
             "Hyderabad", "Mardan", "Sukkur", "Sialkot")
_WX_FAIL_MSG = ("Mosam ki live maloomat abhi nahi mil sakin — "
                "thodi der baad phir koshish karein. Baghair "
                "asal data ke mein andaza nahi lagaunga.")
_WX_GEO_CACHE = {}


def _wx_geocode(city):
    import urllib.request as _u, urllib.parse as _up
    import json as _j
    key = city.lower()
    if key in _WX_GEO_CACHE:
        return _WX_GEO_CACHE[key]
    url = ("https://geocoding-api.open-meteo.com/v1/search?"
           + _up.urlencode({"name": city, "count": 6,
                            "language": "en", "format": "json"}))
    with _u.urlopen(url, timeout=6) as r:
        g = _j.loads(r.read().decode("utf-8", "replace"))
    _res = g.get("results") or []
    res = (next((x for x in _res
                 if x.get("country_code") == "PK"), None)
           or next((x for x in _res
                    if (x.get("name") or "").lower() == key),
                   None))
    _WX_GEO_CACHE[key] = res
    return res


def _wx_fetch(city):
    """Ek sheher ka asal mosam (Open-Meteo). Na mile to None —
    number kabhi nahi ghara jata."""
    import urllib.request as _u, urllib.parse as _up
    import json as _j
    try:
        res = _wx_geocode(city)
        if not res:
            return None
        tz = res.get("timezone") or "Asia/Karachi"
        url = ("https://api.open-meteo.com/v1/forecast?"
               + _up.urlencode({
                   "latitude": res["latitude"],
                   "longitude": res["longitude"],
                   "current": ("temperature_2m,relative_"
                               "humidity_2m,apparent_"
                               "temperature,weather_code,"
                               "wind_speed_10m"),
                   "daily": ("temperature_2m_max,"
                             "temperature_2m_min,weather_code,"
                             "precipitation_probability_max"),
                   "timezone": tz, "forecast_days": 3,
                   "past_days": 1}))
        with _u.urlopen(url, timeout=6) as r:
            f = _j.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return None
    cur = f.get("current") or {}
    day = f.get("daily") or {}
    if cur.get("temperature_2m") is None:
        return None

    def _at(lst, i):
        try:
            return (lst or [])[i]
        except Exception:
            return None
    return {"name": res.get("name") or city.title(),
            "temp": cur.get("temperature_2m"),
            "feels": cur.get("apparent_temperature"),
            "hum": cur.get("relative_humidity_2m"),
            "wind": cur.get("wind_speed_10m"),
            "code": cur.get("weather_code"),
            "max": [_at(day.get("temperature_2m_max"), 1),
                    _at(day.get("temperature_2m_max"), 2)],
            "min": [_at(day.get("temperature_2m_min"), 1),
                    _at(day.get("temperature_2m_min"), 2)],
            "pop": [_at(day.get("precipitation_probability_max"), 1),
                    _at(day.get("precipitation_probability_max"), 2)],
            "yest": (_at(day.get("temperature_2m_max"), 0),
                     _at(day.get("temperature_2m_min"), 0),
                     _at(day.get("weather_code"), 0))}


def _wx_block(w, kal=False):
    idx = 1 if kal else 0
    desc = _WX_CODES.get(w["code"], "")
    lines = [f"{w['name']} ka mosam (abhi): {w['temp']:.0f}°C"
             + (f" — {desc}" if desc else "")]
    extra = []
    if w["feels"] is not None:
        extra.append(f"Mehsoos: {w['feels']:.0f}°C")
    if w["hum"] is not None:
        extra.append(f"Nami: {w['hum']:.0f}%")
    if w["wind"] is not None:
        extra.append(f"Hawa: {w['wind']:.0f} km/h")
    if extra:
        lines.append(" • ".join(extra))
    if w["max"][idx] is not None and w["min"][idx] is not None:
        lab = "Kal" if kal else "Aaj"
        lines.append(f"{lab}: zyada se zyada {w['max'][idx]:.0f}°C, "
                     f"kam se kam {w['min'][idx]:.0f}°C")
    if w["pop"][idx] is not None:
        lines.append(f"Barish ka chance: {w['pop'][idx]:.0f}%")
    return "\n".join(lines)


def _wx_line(w, kal=False):
    idx = 1 if kal else 0
    desc = _WX_CODES.get(w["code"], "")
    s = f"{w['name']}: abhi {w['temp']:.0f}°C"
    if desc:
        s += f", {desc}"
    if w["max"][idx] is not None and w["min"][idx] is not None:
        s += f" — aaj {w['max'][idx]:.0f}°/{w['min'][idx]:.0f}°C"
    if w["pop"][idx] is not None:
        s += f", barish ka chance {w['pop'][idx]:.0f}%"
    return s


def _weather_answer(q):
    """Mosam ka sawal: jitne sheher sawal mein hon, SAB ka asal
    data. Sheher geocoding se — list sirf pehchan ke liye hai,
    had nahi. Na mile/fail ho to imaandar jawab (AI ke paas
    bhejne se wo number ghar dega — ye sabak mil chuka hai)."""
    ql = " " + (q or "").lower() + " "
    if not _wx_hit(q):
        return None
    kal = (" kal " in ql or "tomorrow" in ql)
    idx = 1 if kal else 0
    hits = []
    for c in _WX_CITIES:
        pos = ql.find(" " + c)
        if pos >= 0:
            hits.append((pos, c))
    hits.sort()
    cities = [c for _, c in hits]
    where_q = any(k in ql for k in ("kahan", "kidhar", "kis jaga",
                                     "kis city", "kis sheher",
                                     "kon se", "where"))
    rain_q = any(k in ql for k in ("barish", "baarish")) \
        or _kw_match(ql, words=("rain",))
    if where_q and rain_q:
        # v98 (S1e): 'barish KAHAN ho sakti hai' ka jawab ek
        # sheher ka aaj-weather card NAHI hai — sawal mein
        # sheher ka naam ho tab bhi panel (bare sheher,
        # chance ki tartib) hi jawab hai. Panel ka data na
        # mile to None — sawal AI ke paas jaye ga; single-city
        # card is sawal ka jawab kabhi nahi bane ga.
        rows = []
        for c in _WX_PANEL:
            w = _wx_fetch(c)
            if w:
                rows.append(w)
        if not rows:
            return None
        rows.sort(key=lambda w: (w["pop"][idx] or 0),
                  reverse=True)
        lab = "Kal" if kal else "Aaj"
        lines = [f"{lab} barish ka chance — bare sheher "
                 f"(asal data, zyada chance pehle):"]
        for w in rows:
            pop = w["pop"][idx]
            lines.append(f"{w['name']}: "
                         + (f"{pop:.0f}%" if pop is not None
                            else "data nahi"))
        return "\n".join(lines)
    if not cities and where_q:
        rows = []
        for c in _WX_PANEL:
            w = _wx_fetch(c)
            if w:
                rows.append(w)
        if not rows:
            return _WX_FAIL_MSG
        rows.sort(key=lambda w: (w["pop"][idx] or 0), reverse=True)
        lab = "Kal" if kal else "Aaj"
        lines = [f"{lab} barish ka chance — bare sheher "
                 f"(asal data, zyada chance pehle):"]
        for w in rows:
            pop = w["pop"][idx]
            lines.append(f"{w['name']}: "
                         + (f"{pop:.0f}%" if pop is not None
                            else "data nahi"))
        return "\n".join(lines)
    notes = []
    if cities:
        stop2 = set(_WX_WORDS) | {
            "ka", "ki", "ke", "mein", "me", "hai", "hy", "aaj",
            "kal", "aur", "and", "batao", "batabo", "bata", "do",
            "kesa", "kaisa", "kya", "kia", "haal", "the", "what",
            "is", "today", "tomorrow", "please", "plz", "abhi",
            "imkaan", "imkan", "chance", "ho", "hogi", "sakti",
            "bhi", "mosam", "mausam"}
        for c in cities:
            for part in c.split():
                stop2.add(part)
        probed = 0
        _words80 = ql.split()
        for tok in re.findall(r"[a-z]{3,}", ql):
            if probed >= 2:
                break
            if tok in stop2:
                continue
            _i80 = (_words80.index(tok) if tok in _words80
                    else -1)
            _nxt = (_words80[_i80 + 1]
                    if 0 <= _i80 < len(_words80) - 1 else "")
            _nx2 = (_words80[_i80 + 2]
                    if 0 <= _i80 < len(_words80) - 2 else "")
            _prv = _words80[_i80 - 1] if _i80 > 0 else ""
            _cityctx = ((_nxt in ("ka", "ki")
                         and _nx2 in ("mosam", "mausam",
                                      "weather", "haal", "hal"))
                        or (_prv == "aur"
                            and _nxt in ("ka", "ki", "ke",
                                         "mein", "me")))
            if not _cityctx:
                continue
            probed += 1
            try:
                res = _wx_geocode(tok)
            except Exception:
                res = None
            if res:
                cities.append(tok)
            else:
                notes.append(tok.title())
    if not cities:
        stop = set(_WX_WORDS) | {
            "ka", "ki", "ke", "mein", "me", "hai", "hy", "aaj",
            "kal", "aur", "batao", "batabo", "bata", "do", "kesa",
            "kaisa", "kesy", "kya", "kia", "haal", "hal", "the",
            "what", "is", "today", "tomorrow", "weather", "please",
            "plz", "abhi", "ka", "imkaan", "imkan", "chance",
            "ho", "hogi", "sakti", "wala", "wali"}
        tried = False
        for tok in re.findall(r"[a-z]{3,}", ql):
            if tok in stop:
                continue
            tried = True
            try:
                res = _wx_geocode(tok)
            except Exception:
                res = None
            if res:
                cities = [tok]
                break
        if not cities:
            if tried:
                return ("Ye sheher mosam wale record mein nahi "
                        "mila — sheher ka naam dobara check karke "
                        "likhein.")
            cities = ["karachi"]
    blocks = []
    multi = len(cities) > 1
    for c in cities[:4]:
        w = _wx_fetch(c)
        if w:
            if multi:
                blocks.append(_wx_line(w, kal))
            elif _wx_detail_asked(ql):
                blocks.append(_wx_detail_block(w))
            else:
                blocks.append(_wx_block(w, kal))
    for n in notes:
        blocks.append(f"{n} ka mosam nahi mil saka — ye sheher "
                      f"record mein nahi mila.")
    if not blocks:
        return _WX_FAIL_MSG
    return "\n".join(blocks)


# ================= v80: tareekh, web search, file =================

def _today_line():
    from datetime import timedelta, timezone
    now = datetime.now(timezone(timedelta(hours=5)))
    return ("\nTODAY'S DATE: " + now.strftime("%A %d %B %Y")
            + " (Pakistan time). Use THIS date for every "
            "date-relative question (next Ramzan, kal, "
            "deadlines) — never answer dates from old memory. "
            "APP FILES: this app creates REAL downloadable "
            "files — PDF, Excel (CSV) and Text — for a "
            "shipment, for lists, and on ANY other topic the "
            "user names; the app attaches the real file "
            "button itself. If he ASKS whether you can make "
            "a file or PDF, say YES and ask the topic — never "
            "claim you cannot make files. REFERENCE MATERIAL: "
            "the app sometimes attaches reference material "
            "with a question — use its facts, but never claim "
            "you browsed or searched the web yourself and "
            "never cite 'web results' as your source; if no "
            "material is attached and a fact needs live data, "
            "say plainly that it is not available in the app. "
            "If he asks a "
            "question, ANSWER it — only DO something when "
            "he asks you to do it.\n")


def _profile_line():
    """v98 (S1c): user ka saved Profile naam AI ke system
    context mein lazmi jaye — 'mera naam kya hai' ka jawab
    app ke Profile se aye, AI ki yaad/andaaze se kabhi nahi.
    Naam na ho to wahi saaf likha jata hai taake AI naam
    ghar na le."""
    try:
        name = str(get_settings().get("profile_name")
                   or "").strip()
    except Exception:
        name = ""
    if name:
        return ("\nUSER PROFILE: the user's name, saved in "
                "this app's Profile (Settings), is " + name
                + ". If he asks his name (e.g. 'mera naam "
                "kya hai'), answer with THIS name.\n")
    return ("\nUSER PROFILE: no name is saved in this app's "
            "Profile yet. If he asks his name, say plainly "
            "that no name is saved in the Profile — never "
            "guess or invent one.\n")


_NO_WEB_RULE = (
    "WEB HONESTY (hard rule): you cannot browse the web "
    "and you never have. Never claim to have browsed, "
    "searched or checked the web, and never cite 'web "
    "results' as a source — in any language (e.g. never "
    "write 'Web results ke mutabiq'). The only outside "
    "information you have is material the app itself "
    "attaches to the question; use it without calling it "
    "your own browsing. If a fact needs live data that "
    "the app has not provided in this conversation, say "
    "plainly that it is not available in the app.\n")


def _wx_hit(q):
    ql = " " + (q or "").lower() + " "
    # v98 (S1e): 'temperature'/'forecast'/'humidity' wale
    # sawal bhi mosam hi hain — pehle ye lafz lane se bahar
    # thay, is liye waisa sawal AI ke paas ja kar 'no live
    # internet' wala jawab le aata tha, jabke 'mosam' wala
    # sawal lane se live data le aata tha (na-ahamwari).
    return bool(any(w in ql for w in
                    ("mosam", "mausam", "garmi", "barish",
                     "baarish", "sardi", "dhund"))
                or _kw_match(ql, words=("weather", "rain",
                                        "fog", "temperature",
                                        "forecast", "humidity")))


def _is_capability_q(q):
    ql = " " + (q or "").lower() + " "
    return any(s in ql for s in
               ("sakte ho", "sakta hai", "sakti hai",
                "sakte hain", "can you", "kya tum", "kia tum",
                "kya aap", "ho sakta", "mumkin hai",
                "possible hai"))


def _generic_file_req(q, local_q=None):
    """Shipment se bahar ke mozua ki file ki saaf khwahish —
    (format, mozua) ya None. Sawaal ('bana sakte ho?') par
    None — poochne par file nahi banti."""
    if not _media_ask(q) or _is_capability_q(q):
        return None
    if _find_mentioned_entry(local_q or q):
        return None
    ql = " " + (q or "").lower() + " "
    if any(s in ql for s in ("shipment", "arriving", "arrivals",
                             " list ", "sab ki", "in sab")):
        return None
    fmt = ("txt" if (_kw_match(ql, words=("txt",))
                     or "text file" in ql) else "pdf")
    topic = ql
    for w in ("text file", "pdf", "file", "txt"):
        topic = topic.replace(" " + w + " ", " ")
    topic = " ".join(topic.split()).strip()
    tails = ("bana do", "de do", "banao", "banana", "bana",
             "chahiye", "download", "do", "de", "par", "mein",
             "report")
    changed = True
    while changed:
        changed = False
        for tword in tails:
            if topic.endswith(" " + tword):
                topic = topic[: -len(tword)].strip()
                changed = True
        if topic in tails:
            topic = ""
    for lead in ("ek", "mujhe", "mujhy", "please", "plz"):
        if topic.startswith(lead + " "):
            topic = topic[len(lead):].strip()
    topic = topic.strip(" ?.")
    if len(topic) < 3:
        return None
    return fmt, topic


def _web_search(q, hist=None):
    """Live internet talash (DuckDuckGo — muft, baghair key)
    taake AI asal results se jawab de, yaad se nahi.
    Na mile to khali string."""
    import urllib.request as _u, urllib.parse as _up
    import html as _html
    ql = " " + (q or "").lower() + " "
    skip = ("tum kon", "tumhara naam", "your name", "shukriya",
            "thank", "tum sunao", "apne bare", "kaise ho",
            "kese ho", "acha laga", "theek ho", "zinda ho")
    if any(s in ql for s in skip):
        return ""
    query = (q or "").strip()
    words = query.split()
    if len(words) <= 4 and hist:
        for t in reversed(hist):
            if (t or {}).get("role") == "user" \
                    and (t.get("text") or "").strip():
                query = (t["text"].strip() + " " + query)[:200]
                break
    _hdr = {"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; "
                           "Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/126.0 "
                           "Safari/537.36"),
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9"}

    def _fetch(u):
        req = _u.Request(u, headers=_hdr)
        with _u.urlopen(req, timeout=7) as r:
            return r.read().decode("utf-8", "replace")

    def _ddg():
        page = _fetch("https://lite.duckduckgo.com/lite/?q="
                      + _up.quote_plus(query))
        got = []
        for m in re.finditer(
                r"<a[^>]*class='result-link'[^>]*>(.*?)</a>",
                page, re.S):
            tag = m.group(0)
            hm = re.search(r'href="([^"]+)"', tag)
            href = hm.group(1) if hm else ""
            title = _html.unescape(
                re.sub(r"<[^>]+>", "", m.group(1))).strip()
            rest = page[m.end():m.end() + 3000]
            sm = re.search(
                r"class='result-snippet'[^>]*>(.*?)</td>",
                rest, re.S)
            snip = (_html.unescape(re.sub(r"<[^>]+>", "",
                                          sm.group(1))).strip()
                    if sm else "")
            dom = ""
            um = re.search(r"uddg=([^&]+)", href)
            if um:
                dom = _up.urlparse(_up.unquote(um.group(1))).netloc
            elif href.startswith("http"):
                dom = _up.urlparse(href).netloc
            if title:
                got.append(f"- {title} ({dom})\n  {snip}")
            if len(got) >= 8:
                break
        return got

    def _bing():
        page = _fetch("https://www.bing.com/search?q="
                      + _up.quote_plus(query))
        got = []
        for m in re.finditer(r'<li class="b_algo".*?</li>',
                             page, re.S):
            blk = m.group(0)
            am = re.search(
                r'<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                blk, re.S)
            if not am:
                continue
            title = _html.unescape(
                re.sub(r"<[^>]+>", "", am.group(2))).strip()
            pm = re.search(r"<p[^>]*>(.*?)</p>", blk, re.S)
            snip = (_html.unescape(re.sub(r"<[^>]+>", "",
                                          pm.group(1))).strip()
                    if pm else "")
            dom = _up.urlparse(am.group(1)).netloc
            if title:
                got.append(f"- {title} ({dom})\n  {snip}")
            if len(got) >= 8:
                break
        return got

    import time as _time
    out = []
    for _att, _fn in enumerate((_ddg, _ddg, _bing)):
        if _att:
            _time.sleep(1.0)
        try:
            out = _fn()
        except Exception:
            out = []
        if out:
            break
    if not out:
        return ""
    return ("\n\nWEB RESULTS (live internet se aaj ki talash "
            "— jawab inhi ki bunyad par do, source ka naam "
            "lo):\n" + "\n".join(out))[:4500]


def _wx_detail_block(w):
    lines = [f"{w['name']} ka mosam — detail report:"]
    yest = w.get("yest") or (None, None, None)
    if yest[0] is not None and yest[1] is not None:
        desc = _WX_CODES.get(yest[2], "")
        lines.append(
            f"Guzra kal: zyada se zyada {yest[0]:.0f}°C, "
            f"kam se kam {yest[1]:.0f}°C"
            + (f" — {desc}" if desc else ""))
    lines.append(_wx_block(w, False))
    if w["max"][1] is not None and w["min"][1] is not None:
        s = (f"Ane wala kal: zyada se zyada {w['max'][1]:.0f}°C, "
             f"kam se kam {w['min'][1]:.0f}°C")
        if w["pop"][1] is not None:
            s += f"; barish ka chance {w['pop'][1]:.0f}%"
        lines.append(s)
    return "\n".join(lines)


def _wx_detail_asked(ql):
    return any(k in ql for k in
               ("guzra", "guzre", "guzri", "yesterday", "pichla",
                "peechla", "beeta", "detail", "tafseel",
                "teen din", "3 din", "three days",
                "poori report"))


def _gemini_body(q, hist, extra="", ctx_override=None):
    """Google Gemini (free tier) se asal jawab. Koi ghalti ho to
    None — jhooti tasalli kabhi nahi."""
    import urllib.request as _u, urllib.error as _ue, json as _j
    contents = []
    for h in (hist or [])[-8:]:
        t = str((h or {}).get("text") or "")[:800]
        if t:
            contents.append({"role": "user" if h.get("role") == "user"
                             else "model",
                             "parts": [{"text": t}]})
    contents.append({"role": "user", "parts": [{"text": q}]})
    # v73: pakki greeting par live data nahi bhejna (halki tez
    # request); punctuation saaf karke pehchan — rakam ya shipment
    # ka lafz ho to hargiz skip nahi.
    _qn = re.sub(r"[^a-z ]", "", (q or "").lower())
    _qn = re.sub(r"\s+", " ", _qn).strip()
    _greet = _qn in (
        "hi", "hello", "hey", "salam", "slam", "aoa",
        "kese ho", "kaise ho", "kese hi", "kese ho bhai",
        "hello bhai", "assalam o alaikum", "assalamualaikum")
    context_data = "" if _greet else (ctx_override if ctx_override is not None else _assistant_context_for(q, " ".join(str((h or {}).get("text") or "") for h in (hist or [])[-4:])))
    sys_txt = (
        "You are CargoTrack Assistant, the assistant built into this app - not ChatGPT or any other product, never introduce yourself as one. This is a shipment tracking "
        "app used by a Karachi clearing/shipping agent. Reply in the "
        "same language the user writes — if he writes Roman "
        "Urdu, reply in Roman Urdu; if English, in English — "
        "briefly and warmly. Chat like a helpful colleague, not a report: short lines, only what was asked. FORMAT: put each fact on its OWN line - for a shipment: the BL on one line, then Vessel, ETA, Terminal and Status each on its own line; never cram several facts into one long sentence, and use bold sparingly. When he asks about different periods (this week, next month), answer in SEPARATE sections, one per period, each with its own heading and count; next month means the next calendar month only - never merge periods or repeat an item in two sections. When he asks what goods or items are inside a container, answer ONLY from the goods recorded in the data; if no goods are recorded for it, say so plainly in your FIRST sentence - never answer an item question with vessel details. For the four critical stages (vessel departed, vessel berthed, container discharged, gate out) answer ONLY from the MILESTONES data and always state its certainty in your reply (final / confirmed / 1 source only / estimate); call every ETA an estimate, never a fact; if a milestone says CONFLICT, tell him the records disagree instead of picking one. When he asks about one BL or shipment, answer in 3-5 short lines — status, vessel, ETA, terminal — never dump a full record, a table, or every field unless he asks for the full report. You are a FULL general-purpose "
        "assistant, like ChatGPT: answer ANY question he asks - "
        "general knowledge, explanations, advice, calculations, "
        "drafting or translating text, everyday help - from your "
        "own knowledge. NEVER refuse or redirect a question just "
        "because it is not about shipments, and never tell him to "
        "go and ask somewhere else. The only thing you cannot do "
        "is look things up live (today's news, live prices, web "
        "pages) - you have no live internet inside this app; if "
        "he asks for something live, say that in ONE short line "
        "and then still share what you do know about the topic. "
        "You may also explain shipping terms and help with his "
        "work. For facts about HIS shipments, "
        "use ONLY the live app data below - never invent a status, "
        "date, vessel or amount. If the data does not have the "
        "answer, say so plainly. Answer EXACTLY the question he asked - never substitute a different answer. When he asks for all / every / tamaam / sab, enumerate the COMPLETE matching list from the data below and state how many there are; presenting a partial list as complete is the worst possible answer. The COMPUTED FACTS section was counted by the app from ALL records - trust it over your own counting and date maths. If he asks for a photo, image, card or report but has NOT named a shipment in this conversation, ask in ONE short line which BL he means - never pick a shipment for him, and never volunteer information he did not ask for. APP ABILITIES: the user can attach a photo or a file to his message - text read from it appears under ATTACHED CONTENT below; use it. The app AUTOMATICALLY attaches real action buttons (Image / Report / Copy / WhatsApp) under your reply whenever a shipment is being discussed - the user taps those. NEVER write button names, bracketed pseudo-buttons like [Generate Shipment Image], or markdown tables in your reply; write plain short lines and simple lists instead. When the user asks for an image or a report of a shipment, the app attaches the real file button under your reply when a shipment is identified - so say only one short line such as: the file button is below. NEVER claim a file is ready when no shipment was identified - in that case ask which BL he means. Never say you cannot make an image of a shipment - the app draws a status-card image from the data when he taps Image. Voice typing in the search box turns his speech into a number automatically." + _today_line() + _profile_line() + _NO_WEB_RULE + "\n\nLIVE APP DATA:\n"
        + context_data + extra)
    body = {"systemInstruction": {"parts": [{"text": sys_txt}]},
            "contents": contents,
            "generationConfig": {"temperature": 0.2,
                                 "maxOutputTokens": 1000}}
    return body


def _gemini_answer(q, hist, key, extra=""):
    """Sirf Gemini wala rasta (purana rawaiya barqarar)."""
    body = _gemini_body(q, hist, extra)
    d, _code = _gemini_gen_race(key, body, timeout=45)
    if not d:
        return None
    return _gemini_text(d) or None


def _find_mentioned_entry(text):
    t = ENG.norm(text or "")
    if not t:
        return None
    for h in get_history():
        if h.get("query") and h["query"].upper() in t:
            return h
        for c in ((h.get("result") or {}).get("containers") or []):
            if c and c.upper() in t:
                return h
    return None


_MEDIA_WORDS = ("image", "photo", "tasveer", "picture", "pic", "jpg",
                "jpeg", "png", "card", "pdf", "report", "file", "download",
                "excel", "csv", "spreadsheet", "txt", "text file")


def _media_ask(q):
    """v47: media (image/card/PDF/report) SIRF tab bane jab user
    ne is sawal mein saaf tor par manga ho. Sirf BL ka status
    poochne par koi card/report nahi banti — sirf text jawab."""
    ql = (q or "").lower()
    return any(re.search(r"\b" + w + r"\b", ql) for w in _MEDIA_WORDS)


def _media_intent_actions(q, local_q, hist=None):
    """Jis shipment ki baat ho rahi ho — chahe zikr is sawal
    mein ho ya Pichli baat-cheet mein — us ke liye mukammal
    options: Image, Report, Copy, WhatsApp. LEKIN v47 se ye
    actions sirf tab aate hain jab user ne media saaf tor par
    manga ho (_media_ask) — warna jawab sirf text hota hai."""
    media = _media_ask(q)
    entry = _find_mentioned_entry(local_q)
    if not entry and media:
        # pichli guftagu ulta tartib mein dekho — sab se
        # aakhri zikr wala shipment hi mauzu hai (sirf media
        # mange par; aam guftagu mein purani baat nahi uthani)
        for turn in reversed(hist or []):
            if (turn or {}).get("role") == "user":
                entry = _find_mentioned_entry(turn.get("text"))
                if entry:
                    break
    if entry and not media:
        # Shipment pehchana gaya lekin media nahi manga —
        # v47: sirf compact text jawab, koi action nahi.
        return []
    if not entry:
        if media:
            rec = []  # v57: BL mange baghair kisi shipment ka card NAHI banta
            # (purana code pehli 3 shipments ke Image/Report
            #  button khud bana deta tha - wohi ghalti jo user ne pakri)
            acts_r = []
            for h in rec:
                acts_r.append({"label": "\U0001F5BC Image — "
                               + h["query"], "act": "image",
                               "arg": h["query"]})
                acts_r.append({"label": "\U0001F4C4 Report — "
                               + h["query"], "act": "report",
                               "arg": h["query"]})
            if acts_r:
                return acts_r
        m = re.search(r"\b[A-Z0-9][A-Z0-9\-]{5,}\b",
                      (local_q or "").upper())
        if m and any(c.isdigit() for c in m.group(0)):
            return [{"label": "\U0001F50D Track — " + m.group(0),
                     "act": "track", "arg": m.group(0),
                     "mode": "bl"}]
        return []
    qy = entry["query"]
    # v47 fix: jo media manga hai, sirf wohi bane — sirf image
    # maangne par report tile bhi ban jati thi (QA finding D3).
    ql = (q or "").lower()

    def _has(words):
        return any(re.search(r"\b" + w + r"\b", ql) for w in words)

    want_img = _has(("image", "photo", "tasveer", "picture",
                     "pic", "jpg", "jpeg", "png", "card"))
    want_rep = _has(("pdf", "report", "file"))
    want_csv = _has(("excel", "csv", "spreadsheet"))
    want_txt = _has(("txt", "text"))
    if _has(("download",)) and not want_img and not want_rep:
        want_img = want_rep = True
    if not want_img and not want_rep:
        want_img = want_rep = True
    acts = []
    if want_img:
        acts.append({"label": "\U0001F5BC Image — " + qy,
                     "act": "image", "arg": qy})
    if want_rep:
        acts.append({"label": "\U0001F4C4 Report — " + qy,
                     "act": "report", "arg": qy})
    if want_csv:
        acts.append({"label": "\U0001F4CA Excel (CSV) — " + qy,
                     "act": "csv", "arg": qy})
    if want_txt:
        acts.append({"label": "\U0001F4DD Text file — " + qy,
                     "act": "txt", "arg": qy})
    acts.append({"label": "\U0001F4CB Copy — " + qy, "act": "copy",
                 "arg": qy})
    acts.append({"label": "\U0001F4AC WhatsApp — " + qy,
                 "act": "wa", "arg": qy})
    return acts


def _send_escalation(turns, title=""):
    """v59: Assistant ki chat user ke APNE email par bhejna
    (wahan se Shezi parh kar hal nikalta hai). Gmail App
    Password Settings mein hota hai - baghair us ke not_set."""
    st = get_settings()
    user = str(st.get("mail_user")
               or "officeuseonlydell@gmail.com").strip()
    pw = str(st.get("mail_pass") or "").strip()
    if not pw:
        return {"ok": False, "reason": "not_set"}
    lines = []
    for t in (turns or [])[-60:]:
        who = "You" if (t or {}).get("role") == "user" else "Assistant"
        lines.append(f"{who}: {str((t or {}).get('text') or '')}")
    body = ("CargoTrack Assistant ki chat - user ko is mein madad "
            "chahiye.\nChat: " + (title or "Assistant chat")
            + "\n\n" + "\n\n".join(lines))
    import smtplib
    from email.mime.text import MIMEText
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = "CargoTrack Assistant - chat bheja gaya"
    msg["From"] = user
    msg["To"] = user
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=30) as sm:
            sm.login(user, pw)
            sm.send_message(msg)
        return {"ok": True}
    except Exception:
        return {"ok": False, "reason": "send_failed"}


def assistant_answer(q, hist=None, attach=None):
    extra = ""
    local_q = q
    if attach:
        if attach.get("kind") == "image" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            if raw:
                ok, val = _ocr_image_bytes(raw)
                if ok:
                    nums = re_find_numbers(val)
                    extra = ("\n\nATTACHED PHOTO — text read "
                             "from it:\n" + val[:1500])
                    if nums:
                        extra += ("\nNumbers found in the photo: "
                                  + ", ".join(nums))
                        local_q = q + " " + " ".join(nums)
                else:
                    extra = ("\n\nThe user attached a photo, but "
                             "this computer could not read it: "
                             + val)
        elif attach.get("kind") == "pdf" and attach.get("data"):
            import base64 as _b64
            data = str(attach["data"])
            if "," in data:
                data = data.split(",", 1)[1]
            try:
                raw = _b64.b64decode(data, validate=False)
            except Exception:
                raw = b""
            ptxt = _pdf_text(raw) if raw else ""
            if ptxt:
                nums = re_find_numbers(ptxt)
                extra = ("\n\nATTACHED PDF ("
                         + str(attach.get("name") or "file")[:60]
                         + ") — text read from it:\n" + ptxt[:4000])
                if nums:
                    extra += ("\nNumbers found in the PDF: "
                              + ", ".join(nums))
                    local_q = q + " " + " ".join(nums)
            else:
                extra = ("\n\nThe user attached a PDF, but no text "
                         "could be read from it on this computer (it "
                         "may be a scanned-image PDF). Say so honestly "
                         "in one line and suggest sending a photo of "
                         "the page instead.")
        elif attach.get("kind") == "file":
            extra = ("\n\nATTACHED FILE ("
                     + str(attach.get("name") or "file")[:60]
                     + ") — its text:\n"
                     + str(attach.get("text") or "")[:4000])
    if not attach and _media_ask(q) and _is_capability_q(q):
        return {"answer": "Haan — mein asal file bana sakta "
                "hoon: PDF, Excel (CSV) aur Text file — kisi "
                "ek shipment ki, shipments ki list ki, ya kisi "
                "bhi doosre mozua ki. Banani ho to mozua bata "
                "kar 'bana do' kahein; mein content tayyar "
                "karke asal file ka button de dunga.",
                "actions": [], "mode": "local"}
    acts = _media_intent_actions(q, local_q, hist)
    # v59: file/media manga ho aur koi shipment pehchani na gayi
    # ho, to AI ka jhoota dawa ("ready hai") nahi chalega - app
    # khud faisla karta hai: list ki file ho to asal file action,
    # warna saaf sawal ke kis BL ki file chahiye.
    if (_media_ask(q) and not acts and not attach
            and not _wx_hit(q)
            and not _generic_file_req(q, local_q)):
        ql59 = (q or "").lower()
        prev_list = False
        if len((q or "").split()) <= 5:
            for t59 in reversed(hist or []):
                if (t59 or {}).get("role") == "model":
                    _pt = (t59.get("text") or "")
                    prev_list = ("shipment(s)" in _pt
                                 or "Arriving" in _pt)
                    break
        list_cue = any(w in ql59 for w in
                       ("list", "tamaam", "aane wal", "shipment",
                        "arriving", "arrivals", "in sab", "sab ki"))
        if list_cue or prev_list:
            rows59 = _arrivals_rows(30)
            if rows59:
                fmt59 = ("csv" if ("excel" in ql59 or "csv" in ql59)
                         else "txt" if ("txt" in ql59
                                        or "text file" in ql59)
                         else "pdf")
                lbl59 = ("📊 Excel (CSV) — Arriving shipments"
                         if fmt59 == "csv" else
                         "📝 Text file — Arriving shipments"
                         if fmt59 == "txt" else
                         "📄 PDF — Arriving shipments")
                return {"answer": "The file button is below - it has "
                        f"{len(rows59)} arriving shipment(s).",
                        "actions": [{"label": lbl59, "act": "filelist",
                                     "fmt": fmt59,
                                     "title": "Arriving shipments",
                                     "rows": rows59}],
                        "mode": "local"}
        return {"answer": "For a photo, image, report or file, type "
                "the shipment's BL number - which BL do you need? "
                "Example: 'pdf of 142G513366'.",
                "actions": [], "mode": "local"}
    # v82: tayyar greeting lane KHATAM (us ki 26 Oct wali pakki
    # hidayat) — salaam/duaa ke jawab bhi ab asal AI hi dega.
    if not attach:
        _wx = _weather_answer(q)
        if _wx:
            return {"answer": _wx, "actions": acts,
                    "mode": "fast"}
    if not attach and _looks_data_q(local_q):
        _fl = _assistant_local(local_q)
        if _local_substantive(_fl):
            _fl["mode"] = "fast"
            _fl["actions"] = (_fl.get("actions") or []) + acts
            return _fl
    key = _ai_key_single()
    gk = _groq_key()
    want_file = None if attach else _generic_file_req(q, local_q)
    if key or gk:
        _t0 = time.time()
        extra2 = (extra or "") + _web_search(q, hist)
        if want_file:
            extra2 += ("\n\nFILE REQUEST: the user wants a "
                       "downloadable file on the topic '"
                       + want_file[1] + "'. Write the COMPLETE "
                       "file content as your reply: first line "
                       "the title, then the full, well-organized "
                       "content. The app attaches the real "
                       "download button under your reply.")
        try:
            txt = _ai_answer_any(q, hist, gk, key, extra2)
        except Exception:
            txt = None
        if not txt and _ai_fail_category() != "invalid key":
            # v98 (S1a): kisi bhi fallback se PEHLE wohi
            # providers ek dafa aur try karo — ek waqti
            # timeout/error par foran haar nahi manni.
            # Invalid key par retry bekaar hai (key theek
            # nahi hoti), is liye wo surat mustasna hai.
            try:
                txt = _ai_answer_any(q, hist, gk, key, extra2)
            except Exception:
                txt = None
        if txt:
            _acts80 = acts
            if want_file:
                _f80, _t80 = want_file
                _acts80 = acts + [{
                    "label": (("📄 PDF — " if _f80 == "pdf"
                               else "📝 Text file — ")
                              + _t80.title()[:44]),
                    "act": "textfile", "fmt": _f80,
                    "title": _t80.title(), "text": txt}]
            return {"answer": txt, "actions": _acts80,
                    "mode": "ai",
                    "ai_secs": round(time.time() - _t0, 1),
                    "ai_model": getattr(_GLOCAL, "model", ""),
                    "ai_path": getattr(_GLOCAL, "path", ""),
                    "ai_thoughts": getattr(_GLOCAL, "thoughts", 0)}
        out = _assistant_local(local_q,
                               _ai_why=_ai_fail_category())
        out["mode"] = "local"
        out["ai_error"] = True
        out["ai_note"] = _ai_fail_note()
        out["actions"] = (out.get("actions") or []) + acts
        return out
    out = _assistant_local(local_q)
    out["mode"] = "local"
    out["actions"] = (out.get("actions") or []) + acts
    return out


def _norm_status_s(s):
    """Frontend ke normStatus ki hu-ba-hu naqal — taake Assistant
    ki gin-ti hamesha Dashboard ki gin-ti se mile."""
    s = (s or "").lower()
    if any(k in s for k in ("discharg", "unload", "gate out",
                            "delivered")):
        return "discharged"
    if "hold" in s:
        return "hold"
    if "released" in s:
        return "discharged"
    if any(k in s for k in ("arriv", "berth", "at port",
                            "anchorage")):
        return "arrived"
    if any(k in s for k in ("depart", "sail", "on board",
                            "loaded")):
        return "departed"
    if "tranship" in s or "transship" in s:
        return "transhipment"
    return "in_transit"


def _is_completed_s(h):
    r = h.get("result") or {}
    lc = h.get("lifecycle")
    if lc:
        return (lc.get("stage") == "out")
    s = (r.get("status") or "").lower()
    return bool(r.get("gate_out")) or ("deliver" in s) \
        or ((r.get("position") or "").strip().upper()
            == "OUT")


def _assistant_local(q, _rec=False, _ai_why=None):
    from datetime import timedelta, timezone
    """App ke andar ka madadgar: jawab hamesha app ke APNE data
    aur system ki asal halat se banta hai — andaza nahi. Jo is ke
    bas se bahar ho, wahan saaf kehta hai ke Shezi se poochein."""
    ql = q.lower()
    hist = get_history()
    st = get_settings()
    today = datetime.now(timezone(timedelta(hours=5))).date()
    acts = []
    lines = []

    def track_act(query, mode, label=None):
        acts.append({"label": label or f"Track {query}",
                     "act": "track", "arg": query, "mode": mode})

    # v91 (wada shuda, 27 Oct): aakhri digits (suffix) se record
    # pehchanna, aur kai numbers ki list seedha records se banana —
    # ye jawab AI limit/mode par nahi rukte.
    if not _rec:
        _full91 = [t.upper() for t in
                   re.findall(r"[A-Za-z0-9]{8,20}", q)
                   if any(ch.isdigit() for ch in t)]
        _sfx91 = re.findall(r"(?<![0-9])[0-9]{5,7}(?![0-9])", q)
        _want_list = (len(_full91) > 1 or len(_sfx91) > 1 or any(
            w in ql for w in ("list", "mukammal", "sab ke", "sab ki",
                              "tamam", "saare", "saari")))

        def _resolve91(num):
            hits = []
            for h in hist:
                hq = str(h.get("query") or "").upper()
                if hq.endswith(num):
                    hits.append(h)
                    continue
                for c in ((h.get("result") or {}).get("containers")
                          or []):
                    if str(c).upper().endswith(num):
                        hits.append(h)
                        break
            return hits

        if _want_list and (_full91 or _sfx91):
            _entries91, _miss91, _seen91 = [], [], set()
            for t in _full91:
                h = next((x for x in hist
                          if x["query"].upper() == t), None) or \
                    next((x for x in hist if t in
                          ((x.get("result") or {}).get("containers")
                           or [])), None)
                if h and h["query"] not in _seen91:
                    _entries91.append(h)
                    _seen91.add(h["query"])
                elif not h:
                    _miss91.append(t)
            for sf in _sfx91:
                hs = _resolve91(sf)
                if not hs:
                    _miss91.append("…" + sf)
                for h in hs:
                    if h["query"] not in _seen91:
                        _entries91.append(h)
                        _seen91.add(h["query"])
            if _entries91:
                lines.append("Full numbers from your tracked "
                             "shipments:")
                for h in _entries91:
                    r = h.get("result") or {}
                    cs = (", ".join(r.get("containers") or [])
                          or "no container recorded")
                    lines.append(
                        f"• {h['query']} — containers: {cs}"
                        + (f" — {r['status']}" if r.get("status")
                           else "")
                        + (f" — ETA {r['eta']}" if r.get("eta")
                           else ""))
                    track_act(h["query"], h.get("mode") or "bl",
                              f"↻ Check {h['query']}")
                for m in _miss91:
                    lines.append(f"• {m} — no tracked record ends "
                                 "with these digits.")
                return {"answer": "\n".join(lines), "actions": acts}
        elif _sfx91:
            hs = _resolve91(_sfx91[0])
            if len(hs) == 1:
                return _assistant_local(
                    q.replace(_sfx91[0], hs[0]["query"], 1), _rec=True)
            if len(hs) > 1:
                lines.append(f"More than one tracked shipment ends "
                             f"with {_sfx91[0]} — which one do you "
                             "mean?")
                for h in hs:
                    r = h.get("result") or {}
                    lines.append(f"• {h['query']}"
                                 + (f" — {r['status']}"
                                    if r.get("status") else ""))
                    track_act(h["query"], h.get("mode") or "bl",
                              f"Open {h['query']}")
                return {"answer": "\n".join(lines), "actions": acts}

    # 1) sawal mein koi number ho to us ki poori report
    # number = kam az kam 8 harf/rakam AUR us mein digit lazmi
    # (warna "shipments" jese aam lafz bhi number ban jate thay)
    token = None
    for cand in re.findall(r"[A-Za-z0-9]{8,20}", q):
        if any(ch.isdigit() for ch in cand):
            token = cand.upper()
            break
    if token and not any(k in ql for k in
                         ("how", "what", "why", "kaise", "kya")):
        h = next((x for x in hist if x["query"].upper() == token),
                 None)
        if not h:
            h = next((x for x in hist
                      if token in ((x.get("result") or {})
                                   .get("containers") or [])), None)
        if h:
            r = h.get("result") or {}
            lines.append(f"{h['query']} — "
                         f"{'FOUND' if h['found'] else 'NOT FOUND'}"
                         f" ({h.get('carrier') or 'carrier unknown'})")
            if r.get("status"):
                lines.append(f"Status: {r['status']}")
            if r.get("vessel"):
                lines.append("Vessel: " + r["vessel"] +
                             (f" ({r['voyage']})" if r.get("voyage")
                              else ""))
            if r.get("eta"):
                lines.append(f"ETA: {r['eta']}")
            if r.get("terminal"):
                lines.append(f"Terminal: {r['terminal']}")
            if r.get("position"):
                lines.append(f"Position: {r['position']}")
            if r.get("holds"):
                lines.append(f"Holds: {r['holds']}")
            if (r.get("containers") or []):
                lines.append("Containers: "
                             + ", ".join(r["containers"]))
            if h.get("found"):
                _st60 = []
                for _m in _milestones(h):
                    _lb = {"departed": "Departed",
                           "berthed": "Berthed",
                           "discharged": "Discharged",
                           "gateout": "Gate out"}[_m["key"]]
                    if _m["state"] == "done":
                        _st60.append(_lb + ": YES"
                                     + (f" ({_m['when']})"
                                        if _m["when"] else "")
                                     + {"final": " [final — "
                                        "terminal record]",
                                        "confirmed": " [confirmed]",
                                        "single": " [1 source only]"}
                                     .get(_m["certainty"], ""))
                    elif _m["state"] == "partial":
                        _st60.append(_lb + ": PARTIAL"
                                     + (f" ({_m['when']})"
                                        if _m["when"] else ""))
                    elif _m["state"] == "expected":
                        _st60.append(_lb + ": expected "
                                     + _m["when"] + " (estimate)")
                    elif _m["state"] == "conflict":
                        _st60.append(_lb + ": RECORDS CONFLICT — "
                                     "not final")
                    else:
                        _st60.append(_lb + ": not yet")
                lines.append("Stages: " + " · ".join(_st60))
            _lc62 = _lifecycle(h)
            if _lc62["stage"] == "out":
                lines.append("Stage: OUT OF PORT — this shipment "
                             "is in the Completed section"
                             + (f" (gate out {_lc62['gate_out']})"
                                if _lc62["gate_out"] else "")
                             + ". No demurrage or empty-return "
                             "warnings apply to it; the full "
                             "record is kept.")
            # v96 FIX 3: 'Last checked' ka matlab = aakhri
            # KOSHISH (attempt), tasdeeq wala purana waqt nahi —
            # warna user samajhta hai record kabhi dobara dekha
            # hi nahi gaya (data audit: checked 22 Oct par atak
            # gaya tha halanke check huwa tha).
            lines.append(f"Last checked: "
                         f"{h.get('attempt_time') or h.get('time') or '—'}")
            if h.get("live_ok") is False and h.get("attempt_ts") \
                    and h.get("checked_ts") \
                    and (h["attempt_ts"] - h["checked_ts"]) > 180:
                lines.append("(That check found nothing newer — "
                             "the record shown was confirmed at "
                             f"{h.get('time') or '—'}.)")
            track_act(h["query"], h.get("mode") or "bl",
                      "↻ Check again now")
            return {"answer": "\n".join(lines), "actions": acts}
        lines.append(f"{token} is not in your tracked shipments yet.")
        track_act(token, "container"
                  if re.fullmatch(r"[A-Z]{4}\d{7}", token) else "bl",
                  f"Track {token} now")
        return {"answer": "\n".join(lines), "actions": acts}

    # 13) istilahat / "kya hota hai" — shipping ki har aam istilah
    GLOSS = {
      "demurrage": "Demurrage: the charge for keeping a container at the terminal BEYOND the free days after discharge. Counted per day, per container. Your free days are set in Settings (currently {fd}).",
      "detention": "Detention: the charge for keeping the container OUTSIDE the terminal (at your godown) beyond the allowed days after gate-out.",
      "bill of lading": "Bill of Lading (BL): the shipment's main document — the contract and receipt for the cargo. Its number tracks the whole shipment: vessel, route, containers, status.",
      " bl ": "BL (Bill of Lading): the shipment's main document and tracking number — one BL can carry several containers.",
      "eta": "ETA (Estimated Time of Arrival): the date the vessel is expected to reach the destination port. It is an estimate — it can move as the voyage progresses.",
      "etd": "ETD (Estimated Time of Departure): the date the vessel is expected to leave the loading port.",
      "gate pass": "Gate Pass: the terminal's permission for a truck to collect the container. 'GatePass Not Issued' means the release steps (delivery order, payments, holds) are not complete yet.",
      "delivery order": "Delivery Order (DO): the shipping line's order telling the terminal to release the cargo to you. It has an expiry date — after that it must be renewed.",
      "vir": "VIR (Vessel Inward Report): the terminal's arrival record for a vessel visit. The VIR number also tells the terminal honestly — PKKHIKICT means KICT, PKKHISAPT means SAPT, PKBQMQICT means QICT.",
      "hold": "Hold: the terminal, customs or the line has stopped the release — billing hold, customs hold or line hold. Cargo cannot move until the hold is cleared.",
      "yard": "Yard: the container's storage area inside the terminal. 'Position: YARD' means the container is physically inside, waiting for release steps.",
      "discharge": "Discharge: unloading the container from the vessel at the port. Your free days start counting from the discharge date.",
      "transhipment": "Transhipment (transshipment): the cargo changes vessel at an in-between port before reaching Karachi.",
      "transshipment": "Transhipment: the cargo changes vessel at an in-between port before reaching Karachi.",
      "free days": "Free days: the days after discharge during which the terminal charges no demurrage. Set yours in Settings — currently {fd} days.",
      "nvocc": "NVOCC: a carrier that books space on other lines' vessels instead of owning ships (like Emkay Line). Their house BLs are tracked through the terminal and the master line.",
      "teu": "TEU: Twenty-foot Equivalent Unit — the standard measure of container capacity. A 40ft container is 2 TEU.",
      "container": "Container number: 4 letters + 7 digits (like CSNU6961392). The last digit is a check digit — this app verifies it with the ISO 6346 formula.",
    }
    for term, definition in GLOSS.items():
        if (term in ql and any(w in ql for w in
                              ("kya hota", "kya hai", "what is",
                               "meaning", "matlab", "samjha",
                               "explain"))
                and not any(w in ql for w in
                            ("which", "list", "kons", "show me",
                             "kitn", "on hold", "batao", "konsi",
                             "konse", "kitne", "kitni", "kab "))):
            lines.append(definition.replace("{fd}",
                                            str(st.get("free_days", 7))))
            return {"answer": "\n".join(lines), "actions": acts}


    found = [h for h in hist if h["found"]]
    notfound = [h for h in hist if not h["found"]]

    # 1c) v57: media manga lekin koi shipment nahi pehchana
    # gaya - andaz se card NAHI banta, pehle poochho kis BL ki
    if _media_ask(q) and not _find_mentioned_entry(q):
        lines.append("For a photo, image or report, type the "
                     "shipment's BL number - which BL do you need? "
                     "Example: 'photo of 142G513366'.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 2) holds
    if _kw_match(ql, words=('hold', 'ruk', 'stuck', 'holds'), stems=()):
        hs = [h for h in found
              if _norm_status_s(h["result"].get("status")) == "hold"
              and not _is_completed_s(h)]
        if hs:
            lines.append(f"{len(hs)} shipment(s) on hold:")
            for h in hs:
                r = h["result"]
                lines.append(f"• {h['query']} — {r.get('status')}"
                             + (f" — hold: {r['holds']}"
                                if r.get("holds") else "")
                             + (f" ({r['terminal']})"
                                if r.get("terminal") else ""))
        else:
            lines.append("No shipment is on hold right now. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 3) arriving soon - v57: sawal ka din-window (20 days /
    # 2 week / hafta) samajh kar, gin-ti ke sath poori list
    if _kw_match(ql, words=('eta', 'kab aay', 'coming', 'expected', 'aane wal', 'aayenge', 'aayega', 'a raha', 'aa raha', 'tamaam', 'aane', 'dinon', 'agle din', 'lagne', 'lagega', 'aa rahi', 'aa rahe', 'aane wale', 'pohnch'), stems=('arriv',)):
        arr = []
        for h in found:
            d = _ast_date((h["result"] or {}).get("eta"))
            if d and d >= today and not _ast_completed(h):
                arr.append((d, h))
        arr.sort(key=lambda x: x[0])
        has_num = re.search(r"\d+\s*(day|days|din|roz|week|haft|month|mahin)", ql)
        nm_want = ("next month" in ql or "agle mahine" in ql
                   or "agla mahina" in ql or "next mahine" in ql)
        wk_want = ("week" in ql or "haft" in ql)
        if (nm_want or wk_want) and not has_num:
            def _fmt59(rows):
                out = []
                for d, h in rows:
                    r = h["result"]
                    out.append(str(h["query"]))
                    out.append(f"Vessel: {r.get('vessel') or '-'}")
                    out.append(f"ETA: {r.get('eta')}")
                    out.append(f"Terminal: {r.get('terminal') or '-'}")
                    out.append(f"Status: {r.get('status') or '-'}")
                    out.append("")
                return out
            if wk_want:
                rows = [(d, h) for d, h in arr
                        if (d - today).days <= 7]
                lines.append("Arriving this week (next 7 days) - "
                             f"{len(rows)} shipment(s):")
                lines.extend(_fmt59(rows) or ["None this week."])
            if nm_want:
                nmf = (today.replace(day=28)
                       + timedelta(days=4)).replace(day=1)
                rows = [(d, h) for d, h in arr
                        if d.year == nmf.year and d.month == nmf.month]
                lines.append(f"Arriving next month "
                             f"({nmf.strftime('%B %Y')}) - "
                             f"{len(rows)} shipment(s):")
                lines.extend(_fmt59(rows) or ["None next month."])
            while lines and lines[-1] == "":
                lines.pop()
            return {"answer": "\n".join(lines), "actions": acts}
        win = None
        m = re.search(r"(\d+)\s*(day|days|din|roz|week|hafte|"
                      r"hafta|month|mahin|maah)", ql)
        if m:
            u = m.group(2)
            win = int(m.group(1)) * (7 if u.startswith(("week",
                     "haft")) else 30 if u.startswith(("month",
                     "mahin", "maah")) else 1)
        elif "week" in ql or "haft" in ql:
            win = 7
        sel = [(d, h) for d, h in arr
               if win is None or (d - today).days <= win]
        if sel:
            lines.append("Arriving"
                         + (f" in the next {win} days" if win
                            else " (soonest first)")
                         + f" - {len(sel)} shipment(s):")
            for d, h in sel[:30]:
                r = h["result"]
                lines.append(str(h["query"]))
                lines.append(f"Vessel: {r.get('vessel') or '-'}")
                lines.append(f"ETA: {r.get('eta')}")
                lines.append(f"Terminal: {r.get('terminal') or '-'}")
                lines.append(f"Status: {r.get('status') or '-'}")
                lines.append("")
            if len(sel) > 30:
                lines.append(f"... and {len(sel) - 30} more.")
        else:
            lines.append("No upcoming arrivals with an ETA in "
                         "your list"
                         + (f" in the next {win} days." if win
                            else "."))
        return {"answer": "\n".join(lines), "actions": acts}

    # 4) delivered
    if _kw_match(ql, words=('pohanch', 'completed', 'done'), stems=('deliver',)):
        ds = [h for h in found if _ast_completed(h)]
        lines.append(f"{len(ds)} shipment(s) completed / delivered:")
        for h in ds[:10]:
            lines.append(f"• {h['query']} — "
                         f"{h['result'].get('status')}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 5) demurrage risk
    if _kw_match(ql, words=('demurrage', 'risk', 'late charge', 'free day'), stems=()):
        fd = st.get("free_days", 7)
        risk = []
        for h in found:
            if _ast_completed(h):
                continue
            d = _ast_date((h["result"] or {}).get("discharge_time"))
            if d and (today - d).days > fd:
                risk.append(((today - d).days - fd, h))
        risk.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if risk:
            lines.append("Demurrage risk (free days over):")
            for over, h in risk[:10]:
                lines.append(f"• {h['query']} — {over} day(s) over "
                             f"the {fd} free days")
        else:
            lines.append("No demurrage risk right now — nothing is "
                         "past its free days. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 6) not found help
    if _kw_match(ql, words=('not found', 'nahi mil', 'missing', 'no record'), stems=()):
        lines.append(f"You have {len(notfound)} not-found number(s):")
        for h in notfound[:10]:
            lines.append(f"• {h['query']}")
        lines.append("Common reasons: one letter typed wrong (the "
                     "app now suggests the close match from your "
                     "history), the carrier has not published the "
                     "record yet, or the system did not respond — "
                     "a 'not found' here never proves your number "
                     "is wrong. Retry after a while.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 15) sab se purani pending shipment
    if _kw_match(ql, words=('oldest', 'purani', 'sab se pehle', 'longest waiting'), stems=()):
        pend = []
        for h in found:
            if _ast_completed(h):
                continue
            dd = _ast_date((h["result"] or {}).get("discharge_time"))
            if dd:
                pend.append(((today - dd).days, h))
        pend.sort(key=lambda x: x[0], reverse=True)  # F-06: never compare the dicts on ties
        if pend:
            lines.append("Longest-waiting shipments (discharged, "
                         "not yet delivered):")
            for days, h in pend[:5]:
                lines.append(f"• {h['query']} — {days} day(s) since "
                             f"discharge • {h['result'].get('status')}")
        else:
            lines.append("No discharged-and-waiting shipments.")
        return {"answer": "\n".join(lines), "actions": acts}


    # 7) payments
    if _kw_match(ql, words=('payment', 'paisa', 'pending', 'receive', 'client', 'payments'), stems=()):
        from collections import defaultdict
        agg = defaultdict(lambda: [0, 0])
        for h in hist:
            c = (h.get("client") or "").strip()
            if not c:
                continue
            try:
                agg[c][0] += float(h.get("amount") or 0)
                agg[c][1] += float(h.get("received") or 0)
            except Exception:
                pass
        pend = [(c, a - r) for c, (a, r) in agg.items() if a - r > 0]
        if pend:
            lines.append("Pending payments:")
            for c, p in pend[:10]:
                lines.append(f"• {c}: PKR {p:,.0f} pending")
        else:
            lines.append("No pending payments in your records. ✓")
        return {"answer": "\n".join(lines), "actions": acts}

    # 8) OCR / photo
    if _kw_match(ql, words=('ocr', 'photo', 'scan', 'camera', 'tasveer', 'photos'), stems=()):
        if _ocr_python():
            lines.append("Photo scanning (OCR) is READY — the "
                         "engine is built into the app itself, "
                         "nothing needs to be installed.")
            lines.append("Use 'Scan photo' on the search box, or "
                         "attach a photo to any result.")
        else:
            lines.append("Photo scanning is not set up on this "
                         "device yet. Nothing to install by hand: "
                         "scan any BL photo once and the engine "
                         "sets itself up automatically (one-time, "
                         "a few minutes, internet needed); after "
                         "that every scan works directly.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 9) system health — "system pe nazar"
    if _kw_match(ql, words=('system', 'health', 'halat', 'report', 'kais'), stems=()):
        stale = [h for h in found if not _ast_completed(h)
                 and h.get("checked_ts")
                 and time.time() - h["checked_ts"] > 3 * 3600]
        lines.append("System health:")
        lines.append(f"• Tracked shipments: {len(hist)} "
                     f"({len(found)} found, {len(notfound)} not found)")
        lines.append(f"• On hold: "
                     f"{len([h for h in found if 'hold' in ((h['result'].get('status') or '').lower())])}")
        lines.append(f"• Data older than 3 hours (press TRACK to "
                     f"refresh): {len(stale)}")
        lines.append(f"• Auto re-check: every "
                     f"{st.get('recheck_hours', 6)} hours")
        lines.append(f"• Photo scanning (OCR): "
                     f"{'ready ✓' if _ocr_python() else 'not set up yet — automatic on first photo scan'}")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 10) backup
    if "backup" in ql:
        lines.append("Your data (history, settings, photos) lives "
                     "outside the app folder, so updates never "
                     "erase it. A backup ZIP can be downloaded any "
                     "time:")
        acts.append({"label": "💾 Download backup", "act": "backup",
                     "arg": ""})
        return {"answer": "\n".join(lines), "actions": acts}

    # 11) delete / clear help
    if _kw_match(ql, words=('delete', 'clear', 'hata', 'remove'), stems=()):
        lines.append("Every row in the Logs lists now has a 🗑 "
                     "Delete button, and the Not Found card has a "
                     "'Clear all' button that removes all not-found "
                     "entries at once (it asks first). Found "
                     "shipments can also be deleted from their "
                     "result card.")
        return {"answer": "\n".join(lines), "actions": acts}

    # 12) greeting / help
    if (re.search(r"\b(hi|hello|salam|aoa|help|madad)\b", ql)
            or "what can" in ql):
        lines.append("I am the built-in assistant. I watch your "
                     "shipments and this app, and answer from your "
                     "own data. Try:")
        lines.append("• 'Which shipments are on hold?'")
        lines.append("• 'What is arriving soon?'")
        lines.append("• 'System health'")
        lines.append("• Type any BL / container number for its "
                     "full report")
        lines.append("• 'Why is my number not found?'")
        return {"answer": "\n".join(lines), "actions": acts}

    # 14) aaj ka brief
    if _kw_match(ql, words=('brief', 'aaj ka', 'today', 'summary'), stems=()):
        arr_today = [h for h in found
                     if _ast_date((h["result"] or {}).get("eta")) == today]
        holds = [h for h in found
                 if "hold" in ((h["result"].get("status") or "").lower())]
        lines.append(f"Today's brief — {len(hist)} tracked, "
                     f"{len(found)} found, {len(notfound)} not found.")
        lines.append(f"• Arriving today: {len(arr_today)}"
                     + (": " + ", ".join(h["query"] for h in arr_today[:5])
                        if arr_today else ""))
        lines.append(f"• On hold: {len(holds)}"
                     + (": " + ", ".join(h["query"] for h in holds[:5])
                        if holds else ""))
        lines.append(f"• Completed / delivered: "
                     f"{len([h for h in found if _ast_completed(h)])}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 16) carrier ke hisab se ginti
    if _kw_match(ql, words=('per carrier', 'carrier wise', 'kis carrier', 'by carrier'), stems=()):
        from collections import Counter
        cc = Counter(h.get("carrier") or "Unknown" for h in hist)
        lines.append("Shipments by carrier:")
        for name, cnt in cc.most_common(10):
            lines.append(f"• {name}: {cnt}")
        return {"answer": "\n".join(lines), "actions": acts}

    # 17) chhoti baatein
    if _kw_match(ql, words=('thank', 'shukriya', 'great', 'acha'), stems=()):
        lines.append("You are welcome! Ask me anything else — "
                     "holds, arrivals, a report for any number, "
                     "or system health.")
        return {"answer": "\n".join(lines), "actions": acts}
    if _kw_match(ql, words=('tum kon', 'who are you', 'tumhara naam', 'your name'), stems=()):
        lines.append("I am the CargoTrack assistant — I live inside "
                     "this app, watch your shipments and answer from "
                     "your own data. Shezi (in your chat) is the one "
                     "who built me and can do everything beyond this "
                     "app.")
        return {"answer": "\n".join(lines), "actions": acts}

    # fallback — imandari se. v98 (S1b): AI asal mein fail
    # huwa ho to wajah ki QISAM saaf likho (timeout / rate
    # limit / invalid key / network) — aam shrug kabhi nahi.
    if _ai_why:
        lines.append("That question needs the full AI, which "
                     "could not answer this time because of "
                     + _AI_WHY_PHRASE.get(
                         _ai_why, _AI_WHY_PHRASE["network"])
                     + ". My built-in answers only cover this "
                     "app and your shipments, so please ask "
                     "again in a little while.")
    else:
        lines.append("That question needs the full AI, and it is not "
                     "answering right now (an internet hiccup or the "
                     "free limit) — my built-in answers only cover "
                     "this app and your shipments, so please ask "
                     "again in a little while.")
    lines.append("What I CAN do right now: holds, arrivals, "
                 "demurrage risk, payments, not-found help, OCR "
                 "status and a full system health report.")
    lines.append("Or tap below — your question will be copied, "
                 "paste it in your chat with Shezi and he will "
                 "answer it there.")
    acts.append({"label": "📋 Copy this question for Shezi",
                 "act": "copyq", "arg": q})
    return {"answer": "\n".join(lines), "actions": acts}


# OCR digit-confusion repair: Tesseract aksar 0 ko O, 1 ko I, 5 ko S
# parh deta hai — container ke digit hisse mein ye badal kar check
# digit dobara jaancha jata hai.
_OCR_DIG_FIX = str.maketrans({"O": "0", "Q": "0", "I": "1", "L": "1",
                              "S": "5", "B": "8", "Z": "2", "G": "6"})


def _iso_repair(tok):
    if len(tok) != 11 or not tok[:4].isalpha():
        return None
    fixed = tok[4:].translate(_OCR_DIG_FIX)
    if not fixed.isdigit():
        return None
    cand = tok[:4] + fixed
    return cand if _iso_ok(cand) else None


def re_extract_doc_numbers(text):
    """v46 Phase C — document se number nikaalne ka naya usool.

    Yousuf ka sikhaya huwa document order: pehle CONTAINER number,
    phir size (20'/40'), phir SEAL number — aksar baghair heading ke.
    Is liye:
    - Container sirf wahi jo ISO check-digit pass kare (ya OCR ki
      digit-ghalti theek karke pass ho jaye).
    - SEAL wali line ka number, aur container ke baad wali line par
      6-8 digit ka khaali number, kabhi BL nahi banta.
    - BL woh alphanumeric number hai jis ki pehchan ho (carrier
      prefix) ya jo ghar ka/house BL lagta ho; 9-10 khaali digits
      Maersk/COSCO ke BL ho sakte hain.
    - OCR aksar number ke beech space/dash daal deta hai — token
      unhein jor kar banta hai.
    """
    import re
    bls, cons, seals, others = [], [], [], []
    seen = set()

    def push(lst, v):
        if v and v not in seen:
            seen.add(v)
            lst.append(v)

    def classify(tok):
        """Ek saaf token ki (score, qism, value). Score: container 3,
        pehchana huwa BL 2, aam BL/other 1, fazool 0. Lambai 17 se
        zyada wali mili-juli satr kabhi number nahi hoti."""
        if len(tok) > 17 or not re.fullmatch(r"[A-Z0-9]+", tok):
            return 0, None, tok
        if re.fullmatch(r"[A-Z]{4}\d{7}", tok):
            if _iso_ok(tok):
                return 3, "container", tok
            rep = _iso_repair(tok)
            if rep:
                return 3, "container", rep
            return 1, "other", tok
        if tok.isdigit():
            if len(tok) in (9, 10):
                return 2, "bl", tok         # Maersk 9-digit / COSCO digits
            if len(tok) == 11:
                return 1, "other", tok      # phone-like — aakhri ummeed
            return 0, None, tok
        if len(tok) >= 9 and re.search(r"[A-Z]", tok) \
                and re.search(r"\d", tok):
            try:
                _pfx, cname = ENG.identify_carrier(tok)
            except Exception:
                cname = None
            return (2, "bl", tok) if cname else (1, "bl", tok)
        return 0, None, tok

    for line in (text or "").upper().splitlines():
        seal_line = "SEAL" in line
        groups = [g.strip(".,;:()") for g in line.split()]
        groups = [g for g in groups if g]
        if seal_line:
            # Seal wali line par jor nahi lagana — "SEAL NO PK123456"
            # ko ek bana kar ghalat value banti thi. Har hisse ko
            # alag seal samjho (label lafz chor kar).
            for g in groups:
                solo = ENG.norm(g)
                if len(solo) >= 5 and re.search(r"\d", solo) \
                        and solo not in ("SEAL", "SEALNO"):
                    push(seals, solo)
            continue
        line_has_container = False
        i = 0
        while i < len(groups):
            hit = None
            # OCR aksar ek hi number ko space se tor deta hai — 1, 2
            # aur 3 hisse jor kar jaancho aur sab se achi pehchan
            # (score) wala window pakro; barabar par lamba window
            # (poora number) jeet-ta hai.
            best = (0, 0, None, None)       # score, w, kind, val
            # Size/type code (40HC, 20GP...) se shuru hone wala hissa
            # kisi number ka aaghaz nahi hota — use jor ka hisa na banao.
            size_first = re.fullmatch(r"(20|40|45)(GP|HC|HQ|RF|DC|DV|OT|FR)?",
                                      ENG.norm(groups[i]))
            for w in (1, 2, 3):
                if size_first:
                    break
                if i + w > len(groups):
                    continue
                joined = ENG.norm("".join(groups[i:i + w]))
                if len(joined) < 6:
                    continue
                sc, kind, val = classify(joined)
                if w >= 2 and sc < 2:
                    continue  # jor kar sirf pakki pehchan chalegi — "WEIGHT 24500" jaisi aam satr BL nahi banti
                if sc > best[0] or (sc == best[0] and sc > 0 and w > best[1]):
                    best = (sc, w, kind, val)
            if best[0] > 0:
                hit = (best[1], best[2], best[3])
            if hit:
                w, kind, val = hit
                if seal_line:
                    push(seals, val)
                elif kind == "container":
                    push(cons, val)
                    line_has_container = True
                elif kind == "bl":
                    push(bls, val)
                else:
                    push(others, val)
                i += w
                continue
            # kuch pehchana nahi gaya: 6-8 digit ka khaali number
            # container wali line par seal hota hai, warna rehne do.
            solo = ENG.norm(groups[i])
            if solo.isdigit() and 6 <= len(solo) <= 8 and line_has_container:
                push(seals, solo)
            elif seal_line and len(solo) >= 5:
                push(seals, solo)
            i += 1
    numbers = bls + cons + others
    return {"numbers": numbers[:12], "bls": bls,
            "containers": cons, "seals": seals}


def re_find_numbers(text):
    return re_extract_doc_numbers(text)["numbers"]


def main():
    threading.Thread(target=_recheck_loop, daemon=True).start()
    threading.Thread(target=_sync_loop, daemon=True).start()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    print(f"CargoTrack v51 is running: http://127.0.0.1:{PORT}")
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        print(f"On your phone (same WiFi): http://{s.getsockname()[0]}:{PORT}")
        s.close()
    except Exception:
        pass
    print("To stop CargoTrack, close this window.")
    try:
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
