@echo off
title CargoTrack v130 - WINDOW version - do not close this window
cd /d "%~dp0"
echo.
echo  This is the WINDOW version of CargoTrack.
echo  Keep this window open - closing it stops the application.
echo.
where python >nul 2>nul
if %errorlevel% neq 0 (
  echo.
  echo  Python was not found on this computer.
  echo  Please install it from https://www.python.org/downloads/
  echo  and tick "Add python.exe to PATH" during setup.
  echo.
  pause
  exit /b
)
python server.py
pause
