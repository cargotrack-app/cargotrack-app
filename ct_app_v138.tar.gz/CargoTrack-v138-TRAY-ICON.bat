@echo off
title CargoTrack v138 - TRAY ICON version (no window)
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel% neq 0 (
  echo.
  echo  Python was not found on this computer.
  echo  Please install it from https://www.python.org/downloads/
  echo  and tick "Add python.exe to PATH" during setup.
  echo.
  pause
  exit /b
)
rem This is the TRAY ICON version: no window opens. After starting,
rem look for the CargoTrack icon near the clock (click the small ^
rem arrow by the clock if the icon is hidden).
for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)"') do set "PYEXE=%%P"
set "PYW=%PYEXE:python.exe=pythonw.exe%"
if not "%PYW%"=="%PYEXE%" if exist "%PYW%" (
  start "" "%PYW%" "%~dp0tray.py"
  exit /b
)
echo %date% %time% - pythonw not found, window mode par gira>> "%~dp0tray_error.log"
echo pythonw was not found, so this time it starts with a window.
python tray.py
pause
